declare module 'file-saver' {
  declare module.exports: any;
}