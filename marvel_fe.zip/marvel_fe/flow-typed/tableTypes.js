// @flow
export type ColumnT = { name: string, title: string };
export type ColumnsT = Array<ColumnT>;

declare module "react-color" {
  declare module.exports: any;
}

declare module "react-dnd" {
  declare module.exports: any;
}

declare module "immutability-helper" {
  declare module.exports: any;
}

declare module "react-dnd-html5-backend" {
  declare module.exports: any;
}


