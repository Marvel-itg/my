// @flow
export type BrandT = {
  id: number,
  name: string,
  description: string | null,
  imageUrl: string | null
};

export type ProductT = {
  id: number,
  code: number,
  packsInBlockCount: number,
  name: string,
  nationalName: string,
  imageUrl: string,
  tar: number,
  nicotine: number,
  price: number,
  isActive: boolean,
  brandId: number,
  filterType: string,
  packFormat: string,
  productTypeId: number,
  taste: string,
  displayAsNovelty: boolean,
};

export type BrandsFullInfoT = {
  id: number,
  name: string,
  description: string | null,
  imageUrl: string | null,
  products: ProductT[]
};

export type PackFormatT = {
  id: string,
  name: string
};

export type FilterTypeT = {
  id: string,
  name: string
};

export type ProductTypeT = {
  id: string,
  name: string
};

export type ProductsAdditionalDataT = {
  packFormats: PackFormatT,
  productTypes: ProductTypeT,
  filterTypes: FilterTypeT
};

export type ProductSectionItemT = {
  id: number,
  displayIndex: number,
  product: ProductT
}

export type ProductSectionT = {
  id: number,
  name: string,
  isActive: boolean,
  displayIndex: number,
  color: string,
  nameColor: string,
  skuColor: string,
  productSectionItems: ProductSectionItemT[]
}

export type ProductSectionBaseT = {
  id: number | null,
  displayIndex: number,
  name: string,
  color: string,
  nameColor: string,
  skuColor: string,
  productLineId: number,
  isActive: boolean
}

export type ProductSectionReorderT = {
  id: number,
  displayIndex: number,
  items: {
    id: number,
    displayIndex: number
  }[]
}
