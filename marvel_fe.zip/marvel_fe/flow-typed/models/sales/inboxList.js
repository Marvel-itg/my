//@flow

export type InboxT = {
  requestId: number,
  accountId: number,
  firstName: string,
  lastName: string,
  middleName: string,
  phone: string,
  city: string,
  reason: string,
  answer: string,
  answerType: string
};

export type AnswerT = {
  requestId: string,
  answerType: number,
  answer: string
};

export type ResponseFetchInboxListT = {
  total: number,
  requests: InboxT[]
};

export type GetByStatusParamsT = { paginationConfig: PaginationConfigT, status: string };
