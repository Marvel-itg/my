//@flow

export type AdminT = {
  id: number,
  firstName: string,
  middleName: string,
  lastName: string,
  email: string,
  phone: string,
  address: string,
  city: string,
  photo: string
};
