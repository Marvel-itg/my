// @flow

export type PriceT = {
  id: number,
  production: string,
  price: string
};
