//@flow
export type ExchangeToGiftRequestDataT = {
  id: number,
  firstName: string,
  middleName: string,
  lastName: string,
  phone: string,
  count: number,
  status: number
};

export type ExchangeToGiftRequestT = {
  data: ExchangeToGiftRequestDataT[],
  rowsCount: number
};
