//@flow

export type LocationT = {
  posCode: string,
  addressPOS: string
};

export type ParamsT = {
  status: string,
  itemsOnPage: number,
  pageNumber: number,
  dateStart: Date,
  dateEnd: Date,
  type: number
};

export type ExchangeParamsT = {
  status: number,
  type: number,
  dateStart: Date,
  dateEnd: Date,
  itemsOnPage: number,
  pageNumber: number
};

export type RequesterT = {
  id: number,
  firstName: string,
  middleName: string,
  lastName: string,
  phone: string
};

export type ExchangeRequestT = {
  id: number,
  count: number,
  creationDate: Date,
  processedBy?: string,
  processedDate?: string,
  id?: number,
  firstName?: string,
  middleName?: string,
  lastName?: string,
  phone?: string,
  status: number,
  comment: ?string,
  locations?: LocationT[],
  requester: RequesterT
};

export type ExchangeToPhoneRequestT = {
  data: ExchangeRequestT[],
  rowsCount: number
};

// ExchangeRequestsListT
