// @flow

export type PhotoTaskT = {
  id: string,
  firstName: string,
  middleName: string,
  lastName: string,
  phone: string,
  shopCode: string,
  taskType: number,
  startDate: string,
  endDate: string,
  bonusPointsRewardPhoto: number,
  taskDescriptionPhoto: string,
  taskPhotoAnswer: string[],
  comment?: string,
  photos: [],
  status: string
};

export type PhotoTaskDeclineT = {
  id: string,
  comment: string
};

export type PhotoParamsT = {
  endDate: string,
  itemsOnPage: number,
  pageNumber: number,
  searchField: number,
  searchValue: string,
  startDate: string
};

export type PhotoExportParamsT = {
  endDate: string,
  searchField: number,
  searchValue: string,
  startDate: string
};