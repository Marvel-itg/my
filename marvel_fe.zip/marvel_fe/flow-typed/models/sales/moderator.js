//@flow

export type ModeratorT = {
  id: string,
  firstName: string,
  middleName: string,
  lastName: string,
  phone: string,
  createdAt: Date,
  createdBy: string
};
