//@flow

export type TradeProgramManagerT = {
  id: string,
  firstName: string,
  middleName: string,
  lastName: string,
  phone: string,
  active: boolean,
  createdAt: Date,
  createdBy: string,
  deactivateDate: null | Date,
  comment: null | string
};
