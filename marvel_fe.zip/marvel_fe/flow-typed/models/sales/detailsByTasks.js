// @flow

export type DetailsByTaskT = {
  id: number,
  lastName: string,
  firstName: string,
  middleName: string,
  phone: string,
  posCode: number,
  taskType: number,
  taskTitle: string
};

export type TestAnswerT = {
  answer: string,
  correct: boolean
};

export type QuestionsT = {
  answers: TestAnswerT[],
  photo?: ImageT[],
  title: string
};
