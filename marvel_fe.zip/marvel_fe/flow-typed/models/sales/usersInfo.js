// @flow

export type SalesRepresentativeT = {
  firstName: string,
  middleName: string,
  lastName: string
};

export type UserInfoT = {
  id: string,
  firstName: string,
  middleName: string,
  lastName: string,
  phone: string,
  birthday: string,
  gender: number,
  posId: string,
  shopName: string,
  address: string,
  netName: string,
  netId: string,
  startAppDate: string,
  salesRepresentative: SalesRepresentativeT,
  region: string
};
