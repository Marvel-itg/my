//@flow

export type AdvertisingImageT = {
	id: number,
	url: string,
	fileName: string
}
    
export type InteractiveT = {
	id: number,
	name: string,
	description: string,
	startDate: string,
	endDate: string,
	frequency: number,
	content: AdvertisingImageT,
	preview: AdvertisingImageT
}

export type AdvertisingItemT = {
	id: number,
	name: string,
	startDate: string,
	endDate: string,
	isActive: boolean,
	banner: AdvertisingImageT,
	interactives: InteractiveT[]
}


export type AdvertisingT = AdvertisingItemT[]

export type ChangeAdvertisingStatusParams = { id: String, isActive: boolean}
