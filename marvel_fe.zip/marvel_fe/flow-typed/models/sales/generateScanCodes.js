//@flow

export type GeneratedScanCodesT = {
  id: number,
  skuName: string,
  generationDate: string,
  count: number,
  size: number,
  state: 1 | 2 | 3
};

export type GeneratedScanCodesResT = {
  rowsCount: number,
  data: GeneratedScanCodesT[],
  lastExcludedCharacters: string[]
};

export type GenerateScanCodesFilterT = {
  startDate: Date,
  endDate: Date,
  productId: OptionT
};

export type GenerateScanCodesReqT = {
  amount: number,
  productId: number,
  excludedCharacters?: string[],
  password: string
};
