//@flow

export type OrderPositionT = {
  positionId: number,
  positionName: string,
  pricePerItem: number,
  count: number
};
export type OrdersT = {
  warehouseId: number,
  warehouseCode: string,
  warehouseName: string,
  warehouseType: number,
  orderPositions: OrderPositionT[]
};

export type OrdersReportT = {
  generalOrderId: number,
  fromAccountId: number,
  firstName: string,
  middleName: string,
  lastName: string,
  phone: string,
  geo: {
    id: number,
    cityName: string,
    districtName: string,
    areaName: string,
    regionName: string,
    divisionName: string,
    geoType: 1
  },
  posId: number,
  posCode: string,
  posAddress: string,
  creationDate: string,
  processingDate: string,
  statusIdByTradeRepresentative: number,
  deliveryDate: string,
  exportDate: string,
  expirationDate: string,
  comment: string,
  orders: OrderT[],
  details: Object
};


export type OrdersParamsT = {
	creationStartDate: string,
	creationEndDate:  string,
	notDelivered: boolean,
	notProcessedByTradeRepresentative: boolean,
	pageNumber: number,
	itemsOnPage: number,
	searchValue: string,
	searchFieldName: string
}