// @flow
export type CertificateT = {
  id: number,
  barcode: string,
  accountId: number,
  accountFullName: string,
  accountPhoneNumber: string,
  expirationDate: string,
  expirationDateForAccount: string,
  creationDate: string,
  value: number,
  status: number
};

export type CertificateResT = {
  totalCount: number,
  activeCount: number,
  activatedCount: number,
  rowCount: number,
  data: CertificateT[]
};

export type AssignCertificateParamsT = {
  certificateId: number,
  certificateStatus: number,
  accountId?: number
};

export type TransactionHistoryT = {
  transactionDate: string,
  status: string,
  userName: string
};

export type CertificateDetailsT = {
  id: 0,
  barcode: string,
  userName: string,
  phoneNumber: string,
  expirationDate: string,
  expirationDateForAccount: string,
  creationDate: string,
  transactionHistory: TransactionHistoryT[]
};
