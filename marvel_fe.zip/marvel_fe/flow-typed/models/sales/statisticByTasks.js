// @flow

export type TaskStatisticT = {
  rowsCount: number,
  data: TaskStatisticDataT[]
};

export type TaskStatisticDataT = {
  taskType: string,
  taskDescription: string,
  availableToUsers: number,
  doneTasks: number,
  availableToPoses: number
};

export type ExportDataT = {
  columns: string[],
  data?: any[]
};

export type DetailedStatisticParamsT = {
  templateId: number,
  searchFieldName: string,
  searchValue: string,
  itemsOnPage: number,
  pageNumber: number
};
export type TaskDetailedStatisticT = {
  taskName: string,
  taskDescription: string,
  taskType: number,
  taskStartDate: string,
  taskEndDate: string,
  fullName: string,
  accountId: number,
  phone: string,
  city: string,
  posCode: number,
  completedDate: string,
  foilCount?: number,
  bonusesPerFoil?: number,
  bonusCount?: number,
  tRFullName?: string
};
export type ExportCSVDetailedStatisticParamsT = { templateId: number, searchFieldName: string, searchValue: string };
export type DetailedStatisticT = { data: any, rowsCount: number };
