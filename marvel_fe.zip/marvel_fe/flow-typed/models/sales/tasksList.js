// @flow

export type TaskT = {
  id: number,
  bonusPointsReward: number,
  description: string,
  startDate: string,
  endDate: string,
  positions: PositionT[],
  posCodes: number[],
  taskType: number,
  completionType: number,
  isActive: boolean
};

export type TaskPostModelT = {
  id: number,
  bonusPointsReward: number,
  description: string,
  startDate: string,
  endDate: string,
  positions: PositionT[],
  posCodes: number[],
  taskType: number,
  completionType: number
};

export type PositionT = {
  productId: number,
  count: number
};

export type ChangeTaskStateT = {
  taskTemplateId: number,
  isActive: boolean
};
