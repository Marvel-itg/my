// @flow

export type OfflineUsersT = {
  id: number,
  lastName: string,
  firstName: string,
  middleName: string,
  phone: string,
  count: number,
  typeOfTask: string
};
