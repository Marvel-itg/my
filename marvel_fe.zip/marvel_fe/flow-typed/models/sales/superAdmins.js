// @flow

export type SuperAdminT = {
  id: string,
  firstName: string,
  lastName: string,
  phone: string,
  createdOn: string
};
