//@flow

export type CentralDepartmentT = {
  id: number | string,
  firstName: string,
  middleName: string,
  lastName: string,
  phone: string,
  active: boolean,
  createdAt: string,
  createdBy: Date,
  deactivateDate: null | Date,
  comment: null | string
};
