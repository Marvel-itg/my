// @flow

export type CertificatesStatusesListT = {
  id: number,
  issuerId: number,
  date: Date,
  statusId: number,
  payload: string,
  successfulAmount: number,
  totalAmount: number
};

export type CertificatesStatusesResT = {
  data: CertificatesStatusesListT[],
  rowsCount: number
};
