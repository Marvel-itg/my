// @flow

export type ProductLineDataT = {
  aboutProductLineHtmlUrl: string,
  brandId: number,
  id: number,
  imageButtonColor: string,
  imageUrl: string,
  name: string
};

export type BrandSettingsDataT = {
  aboutBrandInfoHtmlUrl: string,
  displayIndex: number,
  id: number,
  imageButtonColor: string,
  imageUrl: string,
  name: string,
  productLines: ProductLineDataT[]
};

export type UploadImageT = {
  id: number,
  imageId: number,
  imageUrl: string,
  type: string
};

export type UploadLineT = {
  brandId: number,
  brandSettingsLineHtml: string,
  brandsSettingsLineHex: string,
  brandsSettingsLineImage: UploadImageT[],
  brandsSettingsLineName: string
};
export type UploadBrandT = {
  brandSettingsHtml: string,
  brandsSettingsHex: string,
  brandsSettingsImage: UploadImageT[],
  id: number,
  lines: UploadLineT[]
};

export type UploadBrandSettingsT = {
  brands: UploadBrandT[]
};
