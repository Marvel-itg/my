//@flow

export type BonusReportsT = {
  rowsCount: number,
  data: BonusReportsDataT[]
};

export type BonusReportsDataT = {
  accountId: number,
  availableBonuses: number,
  bonusesByFeedback: number,
  bonusesByFoil: number,
  bonusesByInfo: number,
  bonusesByOrderTask: number,
  bonusesByPhoto: number,
  bonusesByTest: number,
  fullName: string,
  pendingAccrual: number,
  pendingWriteOff: number,
  phone: string,
  poses: PosCodeWithCityAndNetworkT[],
  totalAccrual: number,
  totalWriteOff: number,
  writeOffExchangeOnGift: number,
  writeOffExchangeOnPhone: number,
  additionalBonuses: number
};

export type PosCodeWithCityAndNetworkT = {
  city: string,
  networkCode: number,
  posCode: number
};

export type DetailedBonusReportT = {
  id: number,
  value: number,
  date: string,
  typeName: string,
  statusName: string,
  comment: sting
};

export type FormattedBonusReportsDataT = {
  accountId: number,
  availableBonuses: number,
  bonusesByFeedback: number,
  bonusesByFoil: number,
  bonusesByInfo: number,
  bonusesByOrderTask: number,
  bonusesByPhoto: number,
  bonusesByTest: number,
  fullName: string,
  pendingAccrual: number,
  pendingWriteOff: number,
  phone: string,
  city: string[],
  posCodes: string[],
  networks: string[],
  totalAccrual: number,
  totalWriteOff: number,
  writeOffExchangeOnGift: number,
  writeOffExchangeOnPhone: number,
  additionalBonuses: number
};
