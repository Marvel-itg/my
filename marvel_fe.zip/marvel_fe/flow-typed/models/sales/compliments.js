//@flow

export type ComplimentsReportDataT = {
  posCode: number,
  posAddress: string,
  operationType: number,
  complimentsQuantity: number,
  complimentType: number,
  createdOn: string,
  tradeRepresentativeFullName: string
};

export type ComplimentsReportT = {
  rowsCount: number,
  data: ComplimentsReportDataT[]
};

export type ComplimentsTableDataT = {
  posCode: number,
  lastModifiedOn: Date,
  complimentsGiven: number,
  foilCount: number,
  remainingPlan: number
};

export type ComplimentsActivityT = {
  rowsCount: number,
  data: ComplimentsTableDataT[]
};

export type ComplimentHistoryT = {
  transactionType: 1 | 2,
  operationType: 0 | 1,
  date: Date,
  amount: number
};

export type ComplimentDetailsT = {
  history: ComplimentHistoryT[],
  posCode: number,
  lastModifiedOn: Date,
  complimentsGiven: number,
  foilCount: number,
  remainingPlan: number
};
