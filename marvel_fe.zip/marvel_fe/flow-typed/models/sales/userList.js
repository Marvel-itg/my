// @flow

export type UserT = {
  id: number,
  firstName: string,
  lastName: string,
  birthday: string,
  phone: string,
  position: number,
  gender: number,
  posId: string,
  itn: string
};

export type DeactivateUserT = {
  id: number,
  tab: number,
  comment: string
};

export type PointOfSalesT = {
  pointOfSale: {
    id: number,
    name: string,
    lawName: string,
    code: number,
    geoId: string,
    geoName: string,
    address: string
  }
};

export type UserProfileT = {
  id: number,
  firstName: string,
  lastName: string,
  birthday: string,
  phone: string,
  position: number,
  gender: number,
  posId: string,
  itn: string,
  registrationDate: Date,
  registeredBy: ChiefT,
  pointOfSales: PointOfSalesT[]
};
