//@flow
export type ReportParamsT = {
  dateStart: Date,
  dateEnd: Date,
  searchFieldName: string,
  searchValue: string,
  itemsOnPage: number,
  pageNumber: number
}