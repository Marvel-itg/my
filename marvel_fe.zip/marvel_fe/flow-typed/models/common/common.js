// @flow
export type CityT = {
  label: string,
  cityName: string,
  id: number,
  districtName: string,
  areaName: string,
  regionName: string,
  value: number
};

export type ChiefT = {
  accountType: number,
  firstName: string,
  id: number,
  lastName: string,
  middleName: string
};

export type ProjectT = {
  id: number,
  name: string
};

export type RangeFilterT = {
  startDate: Date,
  endDate: Date
};

export type CurrentUserInfoT = {
  id: number,
  firstName: string,
  lastName: string,
  middleName?: string,
  gender: number,
  accountType: number,
  profilePicture: string,
  status: number
};

export type ImageT = {
  imageId: string,
  imageUrl: string
};

export type TabT = {
  label: string,
  value: string
};

export type TabTMap = {
  [key: string]: TabT
};

export type ColumnT = {
  name: string,
  title: string
};

export type SortT = {
  columnName: string,
  direction: string
};

export type TableColumnExtensionT = {
  columnName: string,
  width: number
};

export type OptionT = {
  value: string,
  label: string
};

export type FieldDialogPropsT = {
  title: string,
  onClose: Function,
  onCancelClick: Function,
  spinner: boolean,
  fullWidth?: boolean,
  content: Object,
  initialValues: Object
};

export type ItemT = {
  id: string,
  name: string
};

export type SelectT = {
  isMulti?: boolean,
  disabled?: boolean,
  isSearchable?: boolean,
  isCreatable?: boolean,
  className?: Object,
  theme?: Object,
  classes?: Object,
  options?: Array<Object>,
  selectConfig?: Object,
  placeholder?: string,
  onChange?: Function,
  onCreateOption?: Function,
  isBlue?: boolean
};

export type AsyncSelectT = {
  loadOptions: any => Promise<*> | void,
  optionsMapper: Function
};

export type RegionT = {
  id: string,
  name: string
};

export type PaginationConfigT = {
  page: number,
  count: number
};

export type CommonIOSParamsT = {
  ItemsOnPage: number,
  count: number,
  searchValue?: string
};

export type DeactivateParamsT = {
  accountId: number,
  comment: string,
  newChiefAccountId: number
};

export type ActivityRecordT = {
  activityType: number,
  changedBy: ChiefT,
  id: number,
  key: string,
  newValue: string,
  oldValue: string,
  timeStamp: Date
};

export type ActivityRecordFormattedT = {
  activityType: number,
  changedBy: ChiefT,
  id: number,
  key: string,
  newValue: any,
  oldValue: any,
  timeStamp: Date
};

export type PersonT = {
  id: number,
  firstName: string,
  lastName: string,
  middleName: string,
  gender: number
};

export type ItemTypesT = "Product" | "Section"
