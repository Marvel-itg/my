// @flow
export type RegionalManagerT = {
  id: number,
  firstName: string,
  lastName: string,
  middleName: string,
  gender: number,
  phone: string,
  creationDate: Date,
  creator: ChiefT,
  chief: ChiefT,
  regions: CityT
};
