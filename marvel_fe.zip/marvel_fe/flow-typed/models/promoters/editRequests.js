// @flow
export type EditRequestT = {
  id: number,
  fullName: string,
  processedOn: Date,
  phone: string
};

export type EditedParamT = {
  key: string,
  oldValue: string,
  newValue: string
};

export type EditRequestDetailsT = {
  id: number,
  fullName: string,
  changes: EditedParamT[]
};
