// @flow

export type MaterialT = {
  id: string,
  fileId: string,
  fileUrl: string,
  startDate: Date,
  endDate: Date,
  geos: CityT[],
  roleIds: number[],
  createdOn: Date,
  createdBy: PersonT,
  lastModifiedOn: Date,
  lastModifiedBy: PersonT,
  status: number
};

export type GetMaterialsListParamsT = {
  ItemsOnPage: string,
  PageNumber: string,
  Status: string
};
