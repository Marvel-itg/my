// @flow

export type TPReportT = {
  week: number,
  region: string,
  city: string,
  codeTT: string,
  titleTT: string,
  addressTT: string,
  supervisor: string,
  consultant: string,
  workDate: string,
  workTime: string,
  workHours: string,
  cph: string,
  presentedBrandTP: string,
  presentationOfTradingPrograms: string
};

export type BrandsReportT = {
  week: string,
  region: string,
  city: string,
  codeTT: string,
  titleTT: string,
  addressTT: string,
  supervisor: string,
  consultant: string,
  workDate: string,
  workTime: string,
  workHours: string,
  cph: string,
  marvelKsSGeneralContracts: string,
  marvelKsSInfoContractsMarvel: string,
  marvelKsSInfoContractsOther: string,
  marvelKsSResultContractsOther: string,
  generalContracts: string,
  infoContractsMarvel: string,
  infoContractsOther: string,
  resultContractsOther: string,
  marvelKsGeneralContracts: string,
  marvelKsInfoContractsMarvel: string,
  marvelKsInfoContractsOther: string,
  marvelKsResultContractsOther: string
};

export type EffectiveTimeReportT = {
  posRegion: string,
  posCode: number,
  posLawName: string,
  posName: string,
  posAddress: string,
  posCity: string,
  chief: string,
  date: Date,
  consultant: string,
  factualEndDate: Date,
  factualStartDate: Date,
  count0: number,
  count1: number,
  count2: number,
  count3: number,
  count4: number,
  count5: number,
  count6: number,
  count7: number,
  count8: number,
  count9: number,
  count10: number,
  count11: number,
  count12: number,
  count13: number,
  count14: number,
  count15: number,
  count16: number,
  count17: number,
  count18: number,
  count19: number,
  count20: number,
  count21: number,
  count22: number,
  count23: number,
  totalWorkedMinutes: number,
  hoursMoreThanDefaultCount: number,
  hoursLessThanDefaultCount: number,
  effectiveTimePercentages: number
};

export type EffectiveTimeParamsT = {
  dateStart: Date,
  dateEnd: Date,
  pageNumber?: string,
  itemsOnPage?: string,
  searchField?: string,
  searchValue?: string
};

export type EffectiveTimeReportListT = {
  data: EffectiveTimeReportT[],
  rowsCount: number
};

export type GeneralReportT = {
  region: string,
  city: string,
  chief: string,
  accountName: string,
  posCode: number,
  startDate: Date,
  dateOfWork: Date,
  endDate: Date,
  totalCount: number,
  infoMarvelCount: number,
  infoOtherCount: number,
  infoMarvelCountActivity: number,
  infoMarvelWithActivityCount: number,
  infoOtherCountActivity: number,
  infoOtherWithActivityCount: number,
  infoMarvelCountResult: number,
  resultMarvelCount: number,
  infoOtherCountResult: number,
  resultOtherCount: number,
  switchingLevel: number,
  plannedDuration: number,
  factualDuration: number,
  percentageCompletion: number,
  cph: number
};

export type GeneralReportWithSummaryT = {
  reports: { data: GeneralReportT[], rowsCount: number },
  summary: GeneralReportT[]
};

export type GeneralReportParamsT = {
  dateStart: Date,
  dateEnd: Date,
  pageNumber?: string,
  itemsOnPage?: string,
  searchFieldName?: string,
  searchValue?: string
};

export type ConsultantsReportT = {
  week: number,
  region: string,
  city: string,
  codeTT: string,
  titleTT: string,
  addressTT: string,
  supervisor: string,
  consultant: string,
  workDate: string,
  contactTime: string,
  question1: string,
  question2: string,
  question3: string,
  question4: string,
  question5: string,
  question6: string,
  question7: string,
  question8: string,
  question9: string,
  question10: string,
  question11: string
};

export type ChangesReportT = {
  chief: string,
  createdBy: string,
  city: string,
  projectName: string,
  posCode: string,
  posLawName: string,
  posName: string,
  posAddress: string,
  accountName: string,
  dateOfShift: Date,
  startTimePlanned: Date,
  startTimeFact: Date,
  endTimePlanned: Date,
  endTimeFact: Date,
  durationPlanned: string,
  durationFact: string,
  technicalBreak: string,
  shiftTime: Date,
  shiftStatus: string
};
export type ChangesReportParamsT = {
  dateStart: Date,
  dateEnd: Date,
  pageNumber?: string,
  itemsOnPage?: string,
  searchFieldName?: string,
  searchValue?: string
};

export type ReportT =
  | EffectiveTimeReportT[]
  | BrandsReportT[]
  | TPReportT[]
  | GeneralReportT[]
  | ConsultantsReportT[]
  | ChangesReportT[];
