// @flow
export type CentralDepartmentManagerT = {
  id: number,
  firstName: string,
  lastName: string,
  middleName: string,
  phone: string,
  chief: ChiefT
};

export type CentralDepartmentManagerListT = {
  rowsCount: number,
  data: {
    id: number,
    firstName: string,
    lastName: string,
    middleName: string,
    phone: string
  }[]
};
