// @flow
export type StatusT = {
  supervisor: string,
  regionalManager: string,
  region: string,
  city: string,
  planPermanentHeadquarters: number,
  planReserve: number,
  factPermanentHeadquarters: number,
  factReserve: number
};
