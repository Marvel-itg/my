//@flow
import { CityT } from "../common/common";

export type LastModifiedByT = {
  id: number,
  firstName: string,
  lastName: string,
  middleName: string,
  gender: number
};

export type CreatorT = {
  id: number,
  firstName: string,
  lastName: string,
  middleName: string,
  gender: number
};

export type CandidateT = {
  id: number,
  status: number,
  firstName: string,
  lastName: string,
  geos: CityT[],
  middleName: string,
  isMainState: boolean,
  gender: number,
  birthday: Date,
  creationDate: Date,
  lastModifiedOn: Date,
  city: CityT,
  chief: ChiefT,
  projects: ProjectT[],
  lastModifiedBy: LastModifiedByT,
  creator: CreatorT,
  profilePicture: string,
  phone: string,
  height: number,
  weight: number,
  chestGirth: number,
  waistGirth: number,
  hipGirth: number,
  clothesTopSize: string,
  clothesBottomSize: string,
  shoeSize: number
};

export type CandidatePostModelT = {
  firstName: string,
  lastName: string,
  middleName: string,
  isMainState: boolean,
  gender: number,
  birthday: string,
  cityId: number,
  projectIds: number[],
  photoIds: number[],
  supervisorId: number,
  phone: string,
  height: number,
  weight: number,
  chestGirth: number,
  waistGirth: number,
  hipGirth: number,
  clothesTopSize: number,
  clothesBottomSize: number,
  shoeSize: number
};

export type DeactivateCandidatePostModelT = {
  id: number,
  comment: string
};
