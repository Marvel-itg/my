// @flow
export type SupervisorT = {
  id: string,
  firstName: string,
  lastName: string,
  middleName: string,
  phone: string,
  cities: CityT[],
  chief: ChiefT,
  creator: ChiefT,
  creationDate: Date,
  estimatedMainStateCount: number,
  estimatedReservedStateCount: number,
  status: number,
  deactivationDate: string | null,
  deactivatedBy: ChiefT | null,
  comment: string | null
};
