// @flow

export type ShiftT = {
  id: number,
  status: number,
  projects: ProjectT,
  consultantIdentifier: 0,
  consultant: {
    id: number,
    firstName: string,
    middleName: string,
    lastName: string
  },
  imageUrl: string,
  storeTitle: string,
  posTitle: string,
  posId: number,
  address: string,
  latitude: number,
  longitude: number,
  startDateTime: string,
  endDateTime: string,
  actualStartDateTime: null,
  actualEndDateTime: null,
  oldStartDateTime: null,
  oldEndDateTime: null,
  history: ChangesHistoryT[],
  tasks: any[]
};

export type ShiftPostModelT = {};

export type ChangesHistoryT = {
  changedBy: {
    id: number,
    firstName: string,
    middleName: string,
    lastName: string
  },
  startDateTime: string,
  endDateTime: string,
  oldStartDateTime: string,
  oldEndDateTime: string,
  posIdentifier: number,
  oldPosIdentifier: number
};

export type ConsultantT = {
  id: number,
  firstName: string,
  lastName: string,
  middleName: string,
  projects: ProjectT[]
};

export type ShiftParamsT = {
  geoId: number,
  projectId: number,
  date: Date,
  consultantId: number,
  itemsOnPage: number,
  pageNumber: number
};

export type ShiftStatisticT = {
  date: Date,
  countPlan: number,
  countWorked: number,
  countCanceled: number
};

export type ShiftPlannedTimePostModelT = { date: Date, consultantId: string };

export type ShiftPlannedTimeT = {
  totalAvailableMinutesPerDay: number,
  totalPlannedMinutes: number
};
