// @flow

export type AnswersT = {
  id: string,
  answer: string
};

export type QuestionnaireReportDataT = {
  id: string,
  answeredDate: string,
  answeredTime: string,
  project: string,
  city: string,
  consultant: {
    firstName: string,
    lastName: string,
    middleName: string
  },
  questions: AnswersT[]
};

export type QuestionT = {
  id: string,
  title: string
};

export type QuestionnaireT = {
  id: string,
  title: string,
  questions: QuestionT[]
};

export type QuestionnaireReportParamsT = {
  PageNumber: string,
  ItemsOnPage: string,
  QuestionnaireId: string,
  DateStart: Date,
  DateEnd: Date
};

export type AnswerPostModelT = {
  id: number,
  value: string,
  canFailedQuestionnaire: boolean,
  leadsToQuestionIds: number[],
  hasDependency: boolean,
  answerType: number
};

export type QuestionsPostModelT = {
  tempId: number,
  id?: number,
  title: string,
  answers: AnswerPostModelT[],
  questionLeadsToQuestionIds: number[]
};

export type QuestionnaireInfosPostModelT = {
  countOfFilling: number,
  fillingType: string,
  projectId: string,
  startDate: Date,
  endDate: Date,
  geoIds: string[]
};

export type QuestionnairePostModelT = {
  questionnaire: {
    title: string,
    questions: QuestionsPostModelT[]
  },
  questionnaireInfos: QuestionnaireInfosPostModelT[]
};

export type FormFormattedQuestionT = {
  title: string,
  tempId: number,
  answers: any[],
  answerType: number,
  questionLeadsToQuestionIds: any[],
  id: number,
  status: number
};

export type FormQuestionT = {
  title: string,
  tempId: number,
  answers: any[],
  questionType: OptionT & { id: number },
  id: number,
  status: boolean
};

export type QuestionnaireProjectT = {
  countOfFilling: OptionT,
  fillingType: OptionT,
  projectId: OptionT,
  startDate: Date,
  endDate: Date,
  geos: OptionT[],
  allGeos: boolean,
  questionnaireId?: number,
  status: number
};

export type QuestionnaireParamsT = {
  pageNumber: string,
  itemsOnPage: string,
  status: string
};

export type QuestionnaireDataProjectT = {
  questionnaireId: number,
  questionnaireTitle: string,
  questionnaireTemplateId: number,
  geos: CityT[],
  project: ProjectT,
  startDate: Date,
  endDate: Date,
  createdOn: Date,
  lastModifiedOn: Date,
  createdByAccount: PersonT,
  lastModifiedByAccount: PersonT
};

export type QuestionnaireDataT = {
  templateId: number,
  templateTitle: string,
  questionnaireProjects: QuestionnaireDataProjectT[],
  questions: QuestionT[]
} | null;
