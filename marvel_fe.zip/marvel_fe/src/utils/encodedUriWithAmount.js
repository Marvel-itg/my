export const encodedUriWithAmount = (posPlan, fields, headers) => {
  if (!posPlan) return "";
  const replacer = function(key, value) {
    return value === null ? "" : value;
  };
  let csv = posPlan.map(row => {
    return fields
      .map(fieldName => {
        return JSON.stringify(row[fieldName], replacer);
      })
      .join(";");
  });
  csv.unshift(headers.join(";"));
  csv = csv.join("\n");
  const csvWithAmountContent = "data:text/csv;charset=utf-8," + csv;
  return encodeURI(csvWithAmountContent);
};
