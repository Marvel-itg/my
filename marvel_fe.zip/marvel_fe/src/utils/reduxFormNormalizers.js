import { createTextMask } from "redux-form-input-masks";

export const normalizePhone = (value, previousValue) => {
  const onlyNums = value.replace(/[^0-9]/g, "");
  return onlyNums.length > 12 ? previousValue : onlyNums;
};

export const normalizeName = (value, previousValue) => {
  const onlyCharacters = value.replace(/[^a-zA-Z\s-]/g, "");
  return onlyCharacters.length > 50 ? previousValue : onlyCharacters;
};

export const normalizeLatinOrCyrillicName = (value, previousValue) => {
  const onlyCharacters = value.replace(/[^a-zA-ZА-ЩЬЮЯҐЄІЇа-щьюяґєії\s-]/i, "");
  return onlyCharacters.length > 50 ? previousValue : onlyCharacters;
};

export const normalizeCyrillicName = (value, previousValue) => {
  const onlyCharacters = value.replace(/[^А-ЩЬЮЯҐЄІЇа-щьюяґєії\s-']/g, "");
  return onlyCharacters.length > 50 ? previousValue : onlyCharacters;
};

export const normalizeCyrillicNameWithNumbers = value => {
  return value.replace(/[^0-9.А-ЩЬЮЯҐЄІЇа-щьюяґєії\s-]/g, "");
};

export const normalizeBrandName = (value, previousValue) => {
  const onlyCharacters = value.replace(/[^0-9a-zA-ZА-ЩЬЮЯҐЄІЇа-щьюяґєії\s']/g, "");
  return onlyCharacters.length > 50 ? previousValue : onlyCharacters;
};

export const normalizeCyrillicBrandName = (value, previousValue) => {
  const onlyCharacters = value.replace(/[^0-9А-ЩЬЮЯҐЄІЇа-щьюяґєії\s']/g, "");
  return onlyCharacters.length > 50 ? previousValue : onlyCharacters;
};

export const normalizePrice = (value, previousValue) => {
  const normalized = value.replace(/[^0-9.]/g, "");
  return normalized.length >= 10 ? previousValue || normalized.slice(0, 10) : normalized;
};

export const normalizePosId = (value, previousValue) => {
  const onlyNums = value.replace(/[^0-9]/g, "");
  return onlyNums.length > 6 ? previousValue : onlyNums;
};

export const phoneMask = createTextMask({
  pattern: "+38 (099) 999 99 99"
});
export const itnMask = createTextMask({
  pattern: "9999999999"
});
export const normalizeStaff = (value, previousValue) => {
  const onlyNums = value.replace(/[^0-9]/g, "");
  if (+onlyNums < 1) {
    return "";
  }
  return +onlyNums > 999 ? previousValue : onlyNums;
};

export const normalizeBrandCode = (value, previousValue) => {
  const onlyNums = value.replace(/[^0-9]/g, "");
  if (+onlyNums < 1) {
    return "";
  }
  return +onlyNums > 9999999999 ? previousValue : onlyNums;
};

export const normalizeInteger = (value, previousValue) => {
  const onlyNums = value.replace(/[^0-9]/g, "");
  if (+onlyNums < 1) {
    return "";
  }
  return onlyNums;
};

export const normalizeLength = length => (value, previousValue) => {
  const trimmedValue = value.trimStart();
  return trimmedValue && trimmedValue.length > length ? previousValue : trimmedValue;
};

export const formatPhone = phone => {
  const first = phone.substr(0, 3);
  const second = phone.substr(3, 3);
  const third = phone.substr(6, 3);
  const forth = phone.substr(9, 2);
  const fifth = phone.substr(11, 2);
  return `${first} (${second}) ${third} ${forth} ${fifth}`;
};

export const normalizeDescription = (value, previousValue) => {
  return value && value.length > 300 ? previousValue : value;
};

export const normalizeWithTrim = value => {
  return value.trim();
};

export const onlyNumbers = (value, previousValue) => value.replace(/[^0-9]/g, "");

export const onlyNumbersAndCapitalLetters = (value, previousValue) => {
  const formatted = value.replace(/[^A-Z0-9]/g, "");
  return [...formatted].join(", ");
};

export const passwordNormalize = value => value.replace(/[А-яА-ЩЬЮЯҐЄІЇа-щьюяґєії\s]/g, "");
