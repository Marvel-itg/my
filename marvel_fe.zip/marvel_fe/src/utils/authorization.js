// @flow
import axios from "../api/axiosConfig";

type SaveTokensT = {
  accessToken: string,
  refreshToken: string
};

export function authorizeUser(jwtToken: string) {
  axios.defaults.headers.common["Authorization"] = `Bearer ${jwtToken}`;
}

export function saveTokens({ accessToken, refreshToken }: SaveTokensT) {
  axios.defaults.headers.common["Authorization"] = `Bearer ${accessToken}`;
  sessionStorage.setItem("accessToken", accessToken);
  sessionStorage.setItem("refreshToken", refreshToken);
}

export function removeUser() {
  sessionStorage.removeItem("accessToken");
  sessionStorage.removeItem("refreshToken");
}

export function getTokens() {
  return {
    accessToken: sessionStorage.getItem("accessToken"),
    refreshToken: sessionStorage.getItem("refreshToken")
  };
}
