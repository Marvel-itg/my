// @flow

type ProductSectionRowDataT = {
  id: number | null,
  displayIndex: number,
  sectionName: string,
  sectionColor: string | null,
  sectionNameColor: string | null,
  sectionSkuColor: string | null,
  productLineId: Object,
  isActive: boolean
};

export class ProductsSectionMapper {
  static productSectionDataToDto(productSectionData: ProductSectionRowDataT): ProductSectionBaseT | null {
    if (!productSectionData) return null;
    const data = {
      id: productSectionData.id,
      displayIndex: productSectionData.displayIndex || 0,
      name: productSectionData.sectionName,
      color: this.formatColorToString(productSectionData.sectionColor),
      nameColor: this.formatColorToString(productSectionData.sectionNameColor),
      skuColor: this.formatColorToString(productSectionData.sectionSkuColor),
      productLineId: productSectionData.productLineId && productSectionData.productLineId.value,
      isActive: productSectionData.isActive
    };
    if (!productSectionData.id) delete data.id;
    return data;
  }

  static productSectionDtoToData(productSectionData: ProductSectionBaseT): ProductSectionRowDataT | null {
    if (!productSectionData) return null;
    const data = {
      id: productSectionData.id,
      displayIndex: productSectionData.displayIndex || 0,
      sectionName: productSectionData.name,
      sectionColor: this.formatStringToColor(productSectionData.color),
      sectionNameColor: this.formatStringToColor(productSectionData.nameColor),
      sectionSkuColor: this.formatStringToColor(productSectionData.skuColor),
      productLineId: productSectionData.productLineId,
      isActive: productSectionData.isActive
    };
    if (!productSectionData.id) delete data.id;
    return data;
  }

  static formatColorToString(color: string | null): string {
    return color ? color.replace("#", "") : "000000";
  }

  static formatStringToColor(string: string | null): string {
    return string ? `#${string}` : "#000000";
  }
}
