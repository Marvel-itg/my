//@flow
import moment from "moment";

export const formatInitialPhone = (phone: string) => {
  return phone && phone.substr(4);
};

export const phoneWithCode = (phone: string) => phone && `+380${phone}`;

export const createOption = (data: { id: string, name: string }): OptionT => ({
  value: (data && data.id) || "",
  label: (data && data.name) || ""
});

export const formatDecimals = (number: number) => number / 10;
export const formatPrice = (number: number) => number / 100;
export const findItemByKey = (arr: any[], key: string, value: any) => arr.find(item => item[key] === value);
export const formatDate = (date: ?string) => {
  if (date) {
    const offset = moment().utcOffset();
    const formattedDate = moment
      .utc(date)
      .utcOffset(offset)
      .format("DD/MM/YYYY HH:mm");
    return formattedDate;
  }
  return date;
};

export const formatDateWithSeconds = (date: ?string) => {
  if (date) {
    const offset = moment().utcOffset();
    const formattedDate = moment
      .utc(date)
      .utcOffset(offset)
      .format("DD/MM/YYYY HH:mm:ss");
    return formattedDate;
  }
  return date;
};
export const formatDurationFromMinutesToHours = (duration: number) => {
  const hours = parseInt(moment.duration(duration, "m").asHours(), 10);
  const minutes = moment.duration(duration, "m").minutes();
  return `${hours < 10 ? `0${hours}` : hours}:${minutes < 10 ? `0${minutes}` : minutes}`;
};

export const maxValue = 10000000;
export const isValueLessThanMax = (values: { floatValue: number }) => !(values.floatValue > maxValue);
