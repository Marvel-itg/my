/* eslint-disable */
import { validationErrorMessages } from "../constants";

export const required = value => (value ? undefined : validationErrorMessages().required);

export const commentFieldValidation = value =>
  value && value.length >= 5 ? undefined : "Мінімальна довжина - 5 символів";

export const passwordFieldValidation = value => (value && value.length < 8 ? "Довжина паролю - 8 символів" : undefined);

export const email = value =>
  value && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(value) ? "Invalid email address" : undefined;

export const emailRegexp = value =>
  value &&
  // eslint-disable-next-line max-len
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(
    value
  );

export const nameRegexp = value => value && /^([А-ЩЬЮЯҐЄІЇа-щьюяґєії]+[-'\sА-ЩЬЮЯҐЄІЇа-щьюяґєії]*)$/.test(value);
export const requireCity = state => (state && state.length ? undefined : "Щонайменше одне місто повинно бути вибране");
export const requireNewChief = state => (state ? undefined : "Оберіть відповідальну особу");
export const requireRegion = state =>
  state && state.length ? undefined : "Щонайменше один регіон повинен бути вибраний";
