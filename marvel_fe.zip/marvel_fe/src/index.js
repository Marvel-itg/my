import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import JssProvider from "react-jss/lib/JssProvider";
import App from "./App";
import * as serviceWorker from "./serviceWorker";
import store from "./store/configureStore";
import { jss, generateClassName } from "./utils/jss";
import "./web.config";
import "./index.scss";

ReactDOM.render(
  <Provider store={store}>
    <JssProvider jss={jss} generateClassName={generateClassName}>
      <App />
    </JssProvider>
  </Provider>,
  document.getElementById("root")
);

serviceWorker.unregister();
