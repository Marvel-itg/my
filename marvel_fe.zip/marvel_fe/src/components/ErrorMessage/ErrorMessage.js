// @flow
import React from "react";
import cx from "classnames";
import styles from "./ErrorMessage.module.scss";

type PropsT = {
  error: string,
  textAlign?: "left" | "right" | "center",
  className?: string
};

const ErrorMessage = (props: PropsT) => {
  const { textAlign = "center", className } = props;
  const customStyle = { textAlign };
  return (
    <div className={cx(className, styles.error)} style={customStyle}>
      {props.error}
    </div>
  );
};

export default ErrorMessage;
