// @flow
import React, { Component } from "react";
import Select from "react-select";
import cx from "classnames";
import get from "lodash/get";
import { withStyles } from "@material-ui/core/styles/index";
import FormControl from "@material-ui/core/FormControl";
import type { FormProps } from "redux-form";
import components from "../Select/helperComponents";
import stylesImported from "../Select/Select.module.scss";
import { selectStyles as styles } from "../styles/styles";

const config = {
  roleIds: {
    id: "roleIds",
    placeholder: "Дозвiл"
  }
};

const errorStyles = {
  container: styles => ({
    ...styles,
    width: "100%",
    display: "inline-flex"
  }),
  control: styles => ({
    ...styles,
    backgroundColor: "pink",
    cursor: "pointer",
    border: "1px solid #d50000",
    boxShadow: "none",
    minHeight: 36,
    minWidth: 220,
    width: "100%",
    display: "inline-flex",
    borderRadius: 4,
    padding: "0 10px"
  }),
  input: styles => ({ ...styles, color: "white" }),
  placeholder: styles => ({ ...styles }),
  singleValue: styles => ({ ...styles, color: "white", fontSize: 14 })
};

const colourStyles = {
  container: styles => ({
    ...styles,
    width: "100%"
  }),
  control: styles => ({
    ...styles,
    backgroundColor: "#ccc",
    cursor: "pointer",
    border: "none",
    boxShadow: "none",
    minHeight: 36,
    minWidth: 220,
    width: "100%",
    display: "inline-flex",
    borderRadius: 4,
    padding: "0 10px"
  }),
  input: styles => ({ ...styles, color: "white" }),
  placeholder: styles => ({ ...styles }),
  singleValue: styles => ({ ...styles, color: "white", fontSize: 14 })
};

type PropsT = SelectT & FormProps;

class SelectWithFixedOptions extends Component<PropsT> {
  onChange = (value, { action, removedValue }) => {
    switch (action) {
      case "remove-value":
      case "pop-value":
        if (removedValue.isFixed) {
          return;
        }
        break;
      case "clear":
        value = this.props.options && this.props.options.filter(option => option.isFixed);
        break;
      default:
        break;
    }
    this.props.input.onChange(value);
  };

  render() {
    const { classes, input, disabled, options } = this.props;
    const selectConfig = this.props.selectConfig || config;
    const placeholder =
      (input && selectConfig[input.name] && selectConfig[input.name].placeholder) || this.props.placeholder;
    const hasError = get(this, "props.meta.touched") && Boolean(get(this, "props.meta.error"));
    const isClearable = options && options.some(option => !option.isFixed);
    return (
      <FormControl
        disabled={disabled}
        classes={{
          root: cx(stylesImported.root)
        }}
      >
        <Select
          classes={{ ...classes, valueContainer: stylesImported.multipleValueContainer }}
          components={components}
          value={this.props.value || (this.props.input && this.props.input.value)}
          isMulti
          styles={hasError ? errorStyles : colourStyles}
          isClearable={isClearable}
          {...this.props.input}
          onBlur={() => {
            get(this, "props.input.onBlur") && this.props.input.onBlur(get(this, "props.input.value"));
          }}
          onChange={this.onChange}
          options={options}
          textFieldProps={{
            required: this.props.required,
            error: hasError,
            helperText: get(this, "props.meta.touched") && get(this, "props.meta.error"),
            label: placeholder,
            InputLabelProps: {
              disabled,
              shrink: !!this.props.value || !!get(this, "props.input.value") || get(this, "props.meta.active")
            }
          }}
        />
      </FormControl>
    );
  }
}

export default withStyles(styles, { withTheme: true })(SelectWithFixedOptions);
