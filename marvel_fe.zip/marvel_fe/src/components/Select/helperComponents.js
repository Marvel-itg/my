// @flow
import React from "react";
import Typography from "@material-ui/core/Typography";
import TextField from "@material-ui/core/TextField";
import Paper from "@material-ui/core/Paper";
import Chip from "@material-ui/core/Chip";
import MenuItem from "@material-ui/core/MenuItem";
import CancelIcon from "@material-ui/icons/CancelTwoTone";
import Icon from "@material-ui/core/Icon";
import ArrowDropDown from "@material-ui/icons/ArrowDropDown";
import cx from "classnames";
import styles from "./Select.module.scss";

function NoOptionsMessage(props: any) {
  return (
    <Typography color="textSecondary" className={props.selectProps.classes.noOptionsMessage} {...props.innerProps}>
      Немає варіантів
    </Typography>
  );
}

function LoadingMessage(props: any) {
  return (
    <Typography color="textSecondary" className={props.selectProps.classes.noOptionsMessage} {...props.innerProps}>
      Завантаження...
    </Typography>
  );
}

function inputComponent({ inputRef, ...props }) {
  return <div ref={inputRef} {...props} />;
}

function Control(props: any) {
  return (
    <TextField
      fullWidth
      InputProps={{
        inputComponent,
        inputProps: {
          className: props.selectProps.classes.input,
          inputRef: props.innerRef,
          children: props.children,
          ...props.innerProps
        }
      }}
      {...props.selectProps.textFieldProps}
    />
  );
}

function Option(props: any) {
  const { icon, addon } = props.data;
  if (icon || addon) {
    return (
      <MenuItem
        buttonRef={props.innerRef}
        selected={props.isFocused}
        component="div"
        style={{
          fontWeight: props.isSelected ? 500 : 400
        }}
        className={props.selectProps.classes.option}
        {...props.innerProps}
      >
        {icon && (
          <Icon classes={{ root: styles.iconStyles }} color="disabled">
            {icon}
          </Icon>
        )}
        {addon && <div className={styles.addonStyles}>{addon}</div>}
        {props.children}
      </MenuItem>
    );
  }
  return (
    <MenuItem
      buttonRef={props.innerRef}
      selected={props.isFocused}
      component="div"
      style={{
        fontWeight: props.isSelected ? 500 : 400
      }}
      className={props.selectProps.classes.option}
      {...props.innerProps}
    >
      {props.children}
    </MenuItem>
  );
}

function Placeholder(props: any) {
  return (
    <Typography color="textSecondary" className={props.selectProps.classes.placeholder} {...props.innerProps}>
      {props.children}
    </Typography>
  );
}

function SingleValue(props: any) {
  const { icon, addon } = props.data;
  if (icon || addon) {
    return (
      <>
        {icon && (
          <Icon classes={{ root: styles.iconStyles }} color="disabled">
            {icon}
          </Icon>
        )}
        {addon && <div className={styles.addonStyles}>{addon}</div>}
        <Typography
          className={cx(props.selectProps.classes.singleValue, {
            [props.selectProps.classes.inputDisabled]: props.isDisabled
          })}
          {...props.innerProps}
        >
          {props.children}
        </Typography>
      </>
    );
  }

  return (
    <Typography
      className={cx(props.selectProps.classes.singleValue, {
        [props.selectProps.classes.inputDisabled]: props.isDisabled
      })}
      {...props.innerProps}
    >
      {props.children}
    </Typography>
  );
}

function ValueContainer(props: any) {
  return <div className={props.selectProps.classes.valueContainer}>{props.children}</div>;
}

function MultiValue(props: any) {
  return (
    <Chip
      tabIndex={-1}
      label={props.children}
      classes={{ label: styles.chipLabel }}
      className={cx(
        props.selectProps.classes.chip,
        {
          [props.selectProps.classes.chipFocused]: props.isFocused,
          [props.selectProps.classes.inputDisabled]: props.isDisabled
        },
        styles.chip,
        props.data.isFixed ? styles.disabledOptions : ""
      )}
      onDelete={props.removeProps.onClick}
      deleteIcon={props.data.isFixed ? <></> : <CancelIcon className={styles.cancel} {...props.removeProps} />}
    />
  );
}

function Menu(props: any) {
  return (
    <Paper square className={props.selectProps.classes.paper} {...props.innerProps}>
      {props.children}
    </Paper>
  );
}

function DropdownIndicator(props: any) {
  return (
    <ArrowDropDown
      className={cx(props.addedStyles, {
        [props.selectProps.classes.inputDisabled]: props.isDisabled
      })}
    />
  );
}

function WhiteDropDownIndicator(props: any) {
  return <DropdownIndicator addedStyles={styles.whiteArrowDropDown} {...props} />;
}

const IndicatorSeparator = () => {
  return <span />;
};

function IndicatorsContainer(props: any) {
  return <div className={props.selectProps.classes.indicatorsContainer}>{props.children}</div>;
}

export const blueComponents = {
  IndicatorSeparator,
  DropdownIndicator: WhiteDropDownIndicator,
  Placeholder,
  Option
};

export const greyComponents = {
  IndicatorSeparator,
  DropdownIndicator,
  Placeholder,
  Option,
  ValueContainer,
  SingleValue
};

export default {
  IndicatorsContainer,
  IndicatorSeparator,
  DropdownIndicator,
  Menu,
  MultiValue,
  ValueContainer,
  SingleValue,
  Placeholder,
  NoOptionsMessage,
  Control,
  Option,
  LoadingMessage
};
