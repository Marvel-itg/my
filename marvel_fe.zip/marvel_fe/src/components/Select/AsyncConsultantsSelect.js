// @flow
import React, { useEffect, useState } from "react";
import type { FormProps } from "redux-form";
import AsyncSelect from "./AsyncSelect";
import { getConsultantsByGeoId } from "../../api/promoters/shifts";

type PropsT = SelectT & FormProps & { roleName: string, predefinedOptions: boolean };

const AsyncConsultantsSelect = (props: PropsT) => {
  const consultantsMapper = (consultant: ConsultantT) => {
    const { id } = consultant;
    const firstName = consultant.firstName || "";
    const lastName = consultant.lastName || "";
    const middleName = consultant.middleName || "";
    const fullName = `${lastName} ${firstName} ${middleName}`;
    return {
      label: fullName,
      value: id,
      projects: consultant.projects && consultant.projects.map(project => ({ label: project.name, value: project.id }))
    };
  };

  const [defaultOptions, setDefaultOptions] = useState([]);

  useEffect(() => {
    // use isSubscribed for prevent setState of unmounted component and memory leak as result
    let isSubscribed = true;
    async function loadDefaultOptions() {
      if (props.predefinedOptions) {
        const defaultOptions = await props.loadOptions();
        if (isSubscribed) {
          setDefaultOptions(defaultOptions);
        }
      }
    }
    loadDefaultOptions();
    return () => {
      isSubscribed = false;
    };
  }, []);

  const loadOptionsFunction = () => {
    if (props.predefinedOptions) {
      return null;
    }
    return props.loadOptions || getConsultantsByGeoId(props.geoId);
  };

  const loadOptions = loadOptionsFunction();

  return (
    <AsyncSelect
      {...props}
      defaultOptions={props.defaultOptions || defaultOptions}
      cacheOptions
      placeholder={props.placeholder || "Консультант"}
      loadOptions={loadOptions}
      optionsMapper={consultantsMapper}
    />
  );
};

export default AsyncConsultantsSelect;
