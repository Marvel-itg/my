// @flow
import React, { useEffect, useState } from "react";
import type { FormProps } from "redux-form";
import AsyncSelect from "./AsyncSelect";

import styles from "./Select.module.scss";
import { getPosCodesByGeoId } from "../../api/promoters/shifts";

type PropsT = SelectT & FormProps & { roleName: string, predefinedOptions: boolean };

const AsyncPosCodesSelect = (props: PropsT) => {
  const posCodesMapper = (pointOfSale): any => {
    const name = (pointOfSale && pointOfSale.name) || "";
    const lawName = (pointOfSale && pointOfSale.lawName) || "";
    const posName = pointOfSale && `Юридична назва:  ${lawName}, фізична назва: ${name}`;

    return {
      value: pointOfSale.id,
      label: <span className={styles.overFlowText}>{`${pointOfSale.code}  ${pointOfSale.address}`}</span>,
      name: posName
    };
  };

  const [defaultOptions, setDefaultOptions] = useState([]);

  useEffect(() => {
    // use isSubscribed for prevent setState of unmounted component and memory leak as result
    let isSubscribed = true;
    async function loadDefaultOptions() {
      if (props.predefinedOptions) {
        const defaultOptions = await props.loadOptions();
        if (isSubscribed) {
          setDefaultOptions(defaultOptions);
        }
      }
    }
    loadDefaultOptions();
    return () => {
      isSubscribed = false;
    };
  }, []);

  const loadOptionsFunction = () => {
    if (props.predefinedOptions) {
      return null;
    }
    return props.loadOptions || getPosCodesByGeoId(props.geoId);
  };

  const loadOptions = loadOptionsFunction();

  return (
    <AsyncSelect
      {...props}
      defaultOptions={defaultOptions}
      cacheOptions
      placeholder={props.placeholder || "Код торгівельной точки"}
      loadOptions={loadOptions}
      optionsMapper={posCodesMapper}
    />
  );
};

export default AsyncPosCodesSelect;
