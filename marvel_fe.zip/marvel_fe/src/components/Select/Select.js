import { withStyles } from "@material-ui/core/styles/index";
import { selectStyles as styles } from "../styles/styles";
import SelectTemplate from "./SelectTemplate";

export default withStyles(styles, { withTheme: true })(SelectTemplate);
