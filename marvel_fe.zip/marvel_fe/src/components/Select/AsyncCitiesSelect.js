// @flow
import React, { useEffect, useState } from "react";
import type { FormProps } from "redux-form";
import AsyncSelect from "./AsyncSelect";
import { mapCityToOptionsOfCities } from "../../helpers/common";
import { getCities, getSpecifiedCities } from "../../api/geo";

type PropsT = SelectT & FormProps & { roleName: string, predefinedOptions: boolean, geoType: number };

const AsyncCitiesSelect = (props: PropsT) => {
  const cityMapper = (city: CityT): OptionT => {
    switch (props.roleName) {
      case "RegionalManagerIOS": {
        return { label: city.regionName, value: `${city.id}` };
      }
      default:
        return mapCityToOptionsOfCities(city);
    }
  };

  const [defaultOptions, setDefaultOptions] = useState([]);

  useEffect(() => {
    // use isSubscribed for prevent setState of unmounted component and memory leak as result
    let isSubscribed = true;
    async function loadDefaultOptions() {
      if (props.predefinedOptions) {
        const defaultOptions = await props.loadOptions();
        if (isSubscribed) {
          setDefaultOptions(defaultOptions);
        }
      }
    }
    loadDefaultOptions();
    return () => {
      isSubscribed = false;
    };
  }, []);

  const loadOptionsFunction = () => {
    if (props.predefinedOptions) {
      return null;
    }
    return props.loadOptions || props.geoType ? getSpecifiedCities(props.geoType) : getCities(props.roleName);
  };

  const loadOptions = loadOptionsFunction();

  return (
    <AsyncSelect
      {...props}
      defaultOptions={props.defaultOptions || defaultOptions}
      cacheOptions
      placeholder={props.placeholder || "Населений пункт"}
      loadOptions={loadOptions}
      optionsMapper={cityMapper}
    />
  );
};

export default AsyncCitiesSelect;
