// @flow
import React from "react";
import cx from "classnames";
import { default as ReactSelect } from "react-select";
import CreatableSelect from "react-select/lib/Creatable";
import FormControl from "@material-ui/core/FormControl";
import type { FormProps } from "redux-form";
import get from "lodash/get";
import components, { greyComponents } from "./helperComponents";
import { completionTypeOptions, shiftCancellationReasons, taskTypesOptions } from "../../constants";
import { formatOptions } from "../../helpers/reduxFormComponents/Select";
import stylesImported from "./Select.module.scss";

const config = {
  city: {
    placeholder: "Населений пункт",
    id: "city",
    options: [
      { value: 1, label: "Київ" },
      { value: 2, label: "Харків" }
    ]
  },
  cities: {
    placeholder: "Населений пункт",
    id: "cities",
    options: []
  },
  projectIds: {
    placeholder: "Проекти",
    id: "projects",
    isMulti: true,
    options: [
      { value: "Роздріб", label: "Роздріб" },
      { value: "ХоРеКа", label: "ХоРеКа" },
      { value: "Сезонні проекти роздріб", label: "Сезонні проекти роздріб" },
      { value: "Сезонні проекти ХоРеКа", label: "Сезонні проекти ХоРеКа" },
      { value: "Івенти", label: "Івенти" }
    ]
  },
  project: {
    placeholder: "Проект",
    id: "project",
    options: [
      { value: "Роздріб", label: "Роздріб" },
      { value: "ХоРеКа", label: "ХоРеКа" },
      { value: "Сезонні проекти роздріб", label: "Сезонні проекти роздріб" },
      { value: "Сезонні проекти ХоРеКа", label: "Сезонні проекти ХоРеКа" },
      { value: "Івенти", label: "Івенти" }
    ]
  },
  clothesTopSize: {
    placeholder: "Верх",
    id: "sizeTop",
    options: [
      { value: 1, label: "XS" },
      { value: 2, label: "S" },
      { value: 3, label: "M" },
      { value: 4, label: "L" },
      { value: 5, label: "XL" },
      { value: 6, label: "XXL" }
    ]
  },
  clothesBottomSize: {
    placeholder: "Низ",
    id: "sizeBottom",
    options: [
      { value: 1, label: "XS" },
      { value: 2, label: "S" },
      { value: 3, label: "M" },
      { value: 4, label: "L" },
      { value: 5, label: "XL" },
      { value: 6, label: "XXL" }
    ]
  },

  shoeSize: {
    placeholder: "Розмiр взуття",
    id: "sizeShoes",
    options: [
      { value: "36", label: "36" },
      { value: "37", label: "37" },
      { value: "38", label: "38" },
      { value: "39", label: "39" },
      { value: "40", label: "40" },
      { value: "41", label: "41" },
      { value: "42", label: "42" },
      { value: "43", label: "43" },
      { value: "44", label: "44" },
      { value: "45", label: "45" },
      { value: "46", label: "46" }
    ]
  },
  supervisorId: {
    placeholder: "Cупервайзер",
    id: "supervisor"
  },
  isMainState: {
    placeholder: "Робочий статус",
    id: "status",
    options: [
      { value: "Постійний штат", label: "Постійний штат" },
      { value: "Резерв", label: "Резерв" }
    ]
  },
  regionalManager: {
    id: "regionalManager",
    placeholder: "Регіональний менеджер"
  },
  responsibleManager: {
    id: "responsibleManager",
    placeholder: "Вiдповiдальний"
  },
  CDManager: {
    id: "CDManager",
    placeholder: "Менеджер ЦО"
  },
  packFormatId: {
    id: "format",
    placeholder: "Формат",
    options: [
      { value: "1", label: "Стандартний формат" },
      { value: "2", label: "Супертонкий формат" },
      { value: "3", label: "Компактний формат" }
    ]
  },
  region: {
    placeholder: "Регіон",
    id: "region",
    options: [{ value: "region", label: "Регіон" }]
  },
  packsInBlockCount: {
    id: "packsInBlockCount",
    placeholder: "Кількість пачок у блоці",
    options: [
      { value: 1, label: "1" },
      { value: 8, label: "8" },
      { value: 10, label: "10" },
      { value: 20, label: "20" },
      { value: 50, label: "50" }
    ]
  },
  productTypeId: {
    id: "productTypeId",
    placeholder: "Тип товару",
    options: [
      { value: 1, label: "Сигарети" },
      { value: 2, label: "Сигарили" }
    ]
  },
  productLineId: {
    id: "productLineId",
    placeholder: "Лінія товару"
  },
  productSectionId: {
    id: "productSectionId",
    placeholder: "Підсім'я товару"
  },
  filterTypeId: {
    id: "filterTypeId",
    placeholder: "Фільтр"
  },
  completionType: {
    id: "completionType",
    placeholder: "Частота виконання",
    options: completionTypeOptions
  },
  taskType: {
    id: "taskType",
    placeholder: "Тип завдання",
    options: taskTypesOptions
  },
  searchBy: {
    id: "searchBy",
    placeholder: "Пошук за параметром"
  },
  ttAddress: {
    id: "ttAddress",
    placeholder: "Aдреса ТТ",
    options: [
      { value: 12412, label: "м.Харків, вул. Лермонтовська, 9 " },
      { value: 22344, label: "м.Київ, вул. Колхозна, 11 " }
    ]
  },
  consultant: {
    id: "consultant",
    placeholder: "Консультант",
    options: [
      { value: 1, label: "Ковальов Іван Іванович" },
      { value: 2, label: "Митрованова Аліна Альбертівна" }
    ]
  },
  cancellationReason: {
    id: "cancellationReason",
    placeholder: "Причина відміни",
    options: shiftCancellationReasons
  }
};

type PropsT = SelectT & FormProps;

type SelectPropsT = {
  allowSelectAll: boolean,
  allOption: OptionT,
  options: OptionT[],
  id: string
} & SelectT &
  FormProps;

const Select = (props: SelectPropsT) => {
  if (props.allowSelectAll) {
    if (props.value.length === props.options.length) {
      return (
        <ReactSelect {...props} value={[props.allOption]} onChange={selected => props.onChange(selected.slice(1))} />
      );
    }

    return (
      <ReactSelect
        {...props}
        options={[props.allOption, ...props.options]}
        onChange={selected => {
          if (selected.length > 0 && selected[selected.length - 1].value === props.allOption.value) {
            return props.onChange(props.options);
          }
          return props.onChange(selected);
        }}
      />
    );
  }

  return <ReactSelect {...props} />;
};

const colourStyles = {
  container: styles => ({
    ...styles,
    width: "100%",
    display: "inline-flex"
  }),
  control: styles => ({
    ...styles,
    backgroundColor: "#ccc",
    cursor: "pointer",
    border: "none",
    boxShadow: "none",
    minHeight: 36,
    minWidth: 220,
    width: "100%",
    display: "inline-flex",
    borderRadius: 4,
    padding: "0 10px"
  }),
  input: styles => ({ ...styles, color: "white" }),
  placeholder: styles => ({ ...styles }),
  singleValue: styles => ({ ...styles, color: "white", fontSize: 14 })
};

const errorStyles = {
  container: styles => ({
    ...styles,
    width: "100%",
    display: "inline-flex"
  }),
  control: styles => ({
    ...styles,
    backgroundColor: "pink",
    cursor: "pointer",
    border: "1px solid #d50000",
    boxShadow: "none",
    minHeight: 36,
    minWidth: 220,
    width: "100%",
    display: "inline-flex",
    borderRadius: 4,
    padding: "0 10px"
  }),
  input: styles => ({ ...styles, color: "white" }),
  placeholder: styles => ({ ...styles }),
  singleValue: styles => ({ ...styles, color: "white", fontSize: 14 })
};

class SearchableSelect extends React.Component<PropsT> {
  render() {
    const {
      classes,
      className,
      input,
      isSearchable = false,
      isMulti,
      disabled,
      options,
      isCreatable = false,
      onCreateOption,
      allowSelectAll,
      allOption,
      isGrey,
      isBlue,
      isClearable = false,
      clearValue,
      id
    } = this.props;

    const selectConfig = this.props.selectConfig || config;
    const formattedOptions = formatOptions(options);
    const SelectComponent = isCreatable ? CreatableSelect : Select;
    const helperComponents = isGrey ? greyComponents : components;
    const hasError = get(this, "props.meta.touched") && Boolean(get(this, "props.meta.error"));
    const placeholder =
      (input && selectConfig[input.name] && selectConfig[input.name].placeholder) || this.props.placeholder;
    return (
      <FormControl
        disabled={disabled}
        classes={{
          root: isBlue
            ? cx(className, stylesImported.blueSelectRoot)
            : isGrey
            ? cx(className, stylesImported.greySelectRoot)
            : cx(className, stylesImported.root)
        }}
      >
        <SelectComponent
          id={(input && selectConfig[input.name] && selectConfig[input.name].id) || id}
          allowSelectAll={allowSelectAll}
          allOption={allOption}
          classes={isMulti ? { ...classes, valueContainer: stylesImported.multipleValueContainer } : classes}
          styles={isGrey && (hasError ? errorStyles : colourStyles)}
          components={helperComponents}
          {...this.props.input}
          value={this.props.value || (this.props.input && this.props.input.value)}
          isDisabled={disabled}
          onCreateOption={onCreateOption}
          onBlur={() => {
            get(this, "props.input.onBlur") && this.props.input.onBlur(get(this, "props.input.value"));
          }}
          isMulti={isMulti}
          options={formattedOptions ? formattedOptions : selectConfig[input.name].options}
          placeholder={isBlue || isGrey ? placeholder : ""}
          isSearchable={isSearchable}
          isClearable={isClearable}
          clearValue={clearValue}
          onChange={this.props.onChange || this.props.input.onChange}
          textFieldProps={{
            required: this.props.required,
            error: hasError,
            helperText: get(this, "props.meta.touched") && get(this, "props.meta.error"),
            label: placeholder,
            InputLabelProps: {
              disabled,
              shrink: !!this.props.value || !!get(this, "props.input.value") || get(this, "props.meta.active")
            }
          }}
        />
        {isGrey && get(this, "props.meta.touched") && Boolean(get(this, "props.meta.error")) && (
          <span className={stylesImported.greySelectError}>
            {get(this, "props.meta.touched") && get(this, "props.meta.error")}{" "}
          </span>
        )}
      </FormControl>
    );
  }
}

export default SearchableSelect;
