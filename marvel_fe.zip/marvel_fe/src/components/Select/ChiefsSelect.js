// @flow
import React from "react";
import type { FormProps } from "redux-form";
import Select from "./Select";

type PropsT = SelectT & FormProps;

const chiefMapper = (chief: ChiefT) => {
  const { id } = chief;
  const firstName = chief.firstName || "";
  const lastName = chief.lastName || "";
  const middleName = chief.middleName || "";
  const fullName = `${lastName} ${firstName} ${middleName}`;
  return {
    label: fullName,
    value: id
  };
};

const ChiefsSelect = (props: PropsT) => {
  const options = props.options ? props.options.map(chiefMapper) : [];
  return <Select {...props} isSearchable placeholder={props.placeholder || "Вiдповiдальний"} options={options} />;
};

export default ChiefsSelect;
