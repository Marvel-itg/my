// @flow
import React from "react";
import cx from "classnames";
import AsyncSelect from "react-select/lib/Async";
import FormControl from "@material-ui/core/FormControl";
import { withStyles } from "@material-ui/core/styles";
import components from "./helperComponents";

import type { FormProps } from "redux-form";
import debounce from "es6-promise-debounce";
import { selectStyles as styles } from "../styles/styles";
import stylesImported from "./Select.module.scss";

type PropsT = AsyncSelectT & SelectT & FormProps;
type StateT = {
  error: null | string
};

class AsyncSelectComponent extends React.Component<PropsT, StateT> {
  state = {
    error: null
  };
  getOptions = async inputValue => {
    try {
      this.setState({ error: null });
      const value = inputValue.trim();
      if (value.length) {
        if (value[0] !== ".") {
          const options = await this.props.loadOptions(value);
          const filteredOptions = this.props.withoutRegions ? options.filter(item => item.geoType !== 2) : options;
          return filteredOptions.map(this.props.optionsMapper);
        } else return [];
      } else return [];
    } catch (error) {
      this.setState({ error: error.message });
      console.error(error.message);
    }
  };

  getDefaultOptions = () => {
    if (this.props.optionsMapper) {
      return this.props.defaultOptions && this.props.defaultOptions.map(this.props.optionsMapper);
    }
    return this.props.defaultOptions;
  };

  handleBlur = () => {
    this.props.input.onBlur(this.props.input.value);
  };

  render() {
    const { classes, placeholder, className, isMulti, disabled } = this.props;
    const styledComponents = {
      Control: components.Control,
      DropdownIndicator: components.DropdownIndicator,
      MultiValue: components.MultiValue,
      NoOptionsMessage: components.NoOptionsMessage,
      LoadingMessage: components.LoadingMessage,
      IndicatorSeparator: components.IndicatorSeparator
    };
    return (
      <FormControl disabled={disabled} classes={{ root: cx(className, stylesImported.root) }}>
        <AsyncSelect
          classes={classes}
          components={styledComponents}
          {...this.props.input}
          isDisabled={disabled}
          onBlur={this.handleBlur}
          isMulti={isMulti}
          placeholder=""
          loadOptions={debounce(this.getOptions, 400)}
          defaultOptions={this.getDefaultOptions()}
          isClearable
          onChange={this.props.onChange || this.props.input.onChange}
          textFieldProps={{
            required: this.props.required,
            error: (this.props.meta.touched && Boolean(this.props.meta.error)) || !!this.state.error,
            helperText: (this.props.meta.touched && this.props.meta.error) || this.state.error,
            label: placeholder,
            InputLabelProps: {
              disabled,
              shrink: !!this.props.input.value || this.props.meta.active
            }
          }}
        />
      </FormControl>
    );
  }
}

export default withStyles(styles, { withTheme: true })(AsyncSelectComponent);
