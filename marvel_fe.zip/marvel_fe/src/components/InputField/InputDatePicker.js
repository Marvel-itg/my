// @flow
import React from "react";
import cx from "classnames";
import moment from "moment";
import { DatePicker } from "material-ui-pickers";

import styles from "./InputField.module.scss";

type PropsT = {
  input: any,
  meta?: any,
  maxDate: Date,
  minDate?: Date,
  className: string | null,
  onClose?: Function,
  onChange?: Function,
  inputClassName?: string
};
const renderLabel = date => {
  if (date && moment(date).isValid()) {
    return moment(date).format("DD/MM/YYYY");
  } else {
    return "";
  }
};
const InputDatePicker = (props: PropsT) => {
  const onClose = () => {
    if (props.onClose) {
      props.onClose();
    }
    props.input.onBlur();
  };
  const onChange = date => {
    if (props.onChange) {
      props.onChange(date);
    }
    props.input.onChange(date);
  };
  const error = props.meta && props.meta.touched && props.meta.error;
  return (
    <DatePicker
      {...props.input}
      {...props}
      error={!!error}
      helperText={error || ""}
      onChange={onChange}
      invalidDateMessage="Некорректна дата"
      minDateMessage="Дата замала"
      cancelLabel="Вiдмiна"
      maxDate={props.maxDate}
      minDate={props.minDate}
      classes={{ root: cx(styles.inputStyle, props.className) }}
      labelFunc={renderLabel}
      onClose={onClose}
    />
  );
};

export default InputDatePicker;
