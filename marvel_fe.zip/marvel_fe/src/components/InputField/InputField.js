// @flow
import React from "react";
import cx from "classnames";
import TextField from "@material-ui/core/TextField";
import styles from "./InputField.module.scss";
import * as moment from "moment";

import { memoize } from "lodash";

const inputConfig = {
  email: {
    type: "email",
    label: "Електронна адреса"
  },
  login: {
    type: "text",
    label: "Логін"
  },
  password: {
    type: "text",
    label: "Пароль"
  },
  address: {
    type: "text",
    label: "Адреса"
  },
  username: {
    type: "text",
    placeholder: "User name"
  },
  city: {
    type: "text",
    label: "Населений пункт"
  },
  answer: {
    type: "text",
    label: "Відповідь"
  },
  reason: {
    type: "text",
    label: "Причина звернення"
  },
  phone: {
    type: "text",
    label: "Номер телефону"
  },
  firstName: {
    type: "text",
    label: "Iм'я"
  },
  lastName: {
    type: "text",
    label: "Прiзвище"
  },
  middleName: {
    type: "text",
    label: "По батькові"
  },
  createdBy: {
    type: "text",
    label: "Ким створено"
  },
  createdOn: {
    type: "text",
    label: "Коли створено",
    InputLabelProps: {
      shrink: true
    }
  },
  bonusPointsReward: {
    type: "text",
    label: "Кількість балів за виконане завдання"
  },
  posId: {
    type: "text",
    label: "Код ТТ"
  },
  trId: {
    type: "text",
    label: "Код торгівельного представника"
  },
  itn: {
    type: "text",
    placeholder: "ІПН"
  },
  functionality: {
    type: "text",
    label: "Функцiональнicть"
  },
  description: {
    type: "text",
    label: "Опис матеріалу"
  },
  height: {
    type: "text",
    label: "Зрiст"
  },
  weight: {
    type: "text",
    label: "Вага"
  },
  chestGirth: {
    type: "text",
    label: "Груди"
  },
  waistGirth: {
    type: "text",
    label: "Талiя"
  },
  hipGirth: {
    type: "text",
    label: "Стегна"
  },
  birthday: {
    type: "date",
    label: "Дата народження",
    value: "1990-01-01",
    InputLabelProps: {
      shrink: true
    }
  },
  dateOfEvaluation: {
    type: "date",
    label: "Дата оцiнювання",
    // $FlowFixMe
    value: moment().format("YYYY-MM-DD"),
    InputLabelProps: {
      shrink: true
    }
  },
  resultsOfEvaluation: {
    type: "text",
    label: "Результати оцiнювання"
  },
  startOfWork: {
    type: "date",
    label: "Старт роботи",
    // $FlowFixMe
    value: moment().format("YYYY-MM-DD"),
    InputLabelProps: {
      shrink: true
    }
  },
  bonusPointsRewardOrder: {
    type: "text",
    label: "Кількість балів за виконане завдання"
  },
  bonusPointsRewardFoil: {
    type: "text",
    label: "Кількість балів за одну фольгу"
  },
  generalCount: {
    type: "text",
    label: "Загальна кількість блоків"
  },
  bonusPointsRewardTest: {
    type: "text",
    label: "Кількість балів за виконане завдання"
  },
  bonusPointsRewardQuestionnaire: {
    type: "text",
    label: "Кількість балів за виконане завдання"
  },
  bonusPointsRewardInformational: {
    type: "text",
    label: "Кількість балів за виконане завдання"
  },
  bonusPointsRewardPhoto: {
    type: "text",
    label: "Кількість балів за виконане завдання"
  },
  bonusPointsRewardTestFeedback: {
    type: "text",
    label: "Кількість балів за виконане завдання"
  },
  taskDescriptionOrder: {
    type: "text",
    label: "Опис завдання"
  },
  taskDescriptionFoil: {
    type: "text",
    label: "Опис завдання"
  },
  taskDescriptionTest: {
    type: "text",
    label: "Опис завдання"
  },
  taskDescriptionQuestionnaire: {
    type: "text",
    label: "Опис завдання"
  },
  taskDescriptionInformational: {
    type: "text",
    label: "Опис завдання"
  },
  taskDescriptionPhoto: {
    type: "text",
    label: "Опис завдання"
  },
  taskDescriptionTestFeedback: {
    type: "text",
    label: "Опис завдання"
  },
  taskTitle: {
    type: "text",
    label: "Назва завдання"
  },
  taskType: {
    type: "text",
    label: "Тип завдання"
  },
  comment: {
    type: "text",
    label: "Коментар"
  },
  netNumber: {
    type: "text",
    label: "Номер мережі"
  },
  estimatedMainStateCount: {
    type: "text",
    label: "Основний штат"
  },
  estimatedReservedStateCount: {
    type: "text",
    label: "Резерв"
  },
  seller: {
    type: "text",
    label: "Продавець"
  },
  production: {
    type: "text",
    label: "Товарна одиниця"
  },
  price: {
    type: "text",
    label: "Ціна"
  },
  scu: {
    type: "text",
    label: "Одиниця товару"
  },
  //brands
  tar: {
    type: "text",
    label: "Cмола, мг"
  },
  nicotine: {
    type: "text",
    label: "Нiкотин"
  },
  filterTypeId: {
    type: "text",
    label: "Фiльтр"
  },
  originalName: {
    type: "text",
    label: "Оригінальна назва"
  },
  nationalName: {
    type: "text",
    label: "Українська назва"
  },
  sectionName: {
    type: "text",
    label: "Назва розділу"
  },
  sectionColor: {
    type: "text",
    label: "Колір розділу"
  },
  sectionNameColor: {
    type: "text",
    label: "Колір тексту назви розділу"
  },
  sectionSkuColor: {
    type: "text",
    label: "Колір тексту назви SKU"
  },
  sectionProductLineId: {
    type: "number",
    label: "Product Line"
  },
  brandId: {
    type: "text",
    label: "Бренд"
  },
  code: {
    type: "text",
    label: "Код товару"
  },
  status: {
    type: "text",
    label: "Статус"
  }
};

type PropsT = {
  input: {
    name: string,
    onChange: Function,
    value: any
  },
  meta: any,
  className: string | null,
  disabled: boolean,
  multiline: ?boolean,
  inputProps: any,
  label?: string,
  type?: string,
  required?: boolean,
  value: any,
  variant?: string
};

const classesMem = memoize(className => ({ root: cx(styles.inputStyle, className) }));

const InputField = (props: PropsT) => {
  const { name } = props.input;
  const isDate = inputConfig[name] && inputConfig[name].type === "date";
  const { meta } = props;
  const error = meta && meta.touched && meta.error;
  const warning = meta && meta.warning;
  const inputDateOnChange = event => {
    inputConfig[name].value = event.target.value;
    props.input.onChange(event.target.value);
  };
  const type = props.type || (inputConfig[name] ? inputConfig[name].type : "text");
  const inputProps = props.inputProps || (inputConfig[name] ? inputConfig[name].inputProps : {});
  return (
    <TextField
      {...props.input}
      value={props.input.value}
      variant={props.variant}
      required={props.required}
      label={props.label}
      {...inputConfig[name]}
      onChange={isDate ? inputDateOnChange : props.input.onChange}
      classes={classesMem(props.className)}
      inputProps={inputProps}
      type={type}
      disabled={props.disabled}
      multiline={props.multiline}
      error={!!error || !!warning}
      helperText={error || warning}
    />
  );
};

export default InputField;
