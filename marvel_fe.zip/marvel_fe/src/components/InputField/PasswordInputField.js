// @flow
import React from "react";
import cx from "classnames";
import IconButton from "@material-ui/core/IconButton";
import TextField from "@material-ui/core/TextField";
import InputAdornment from "@material-ui/core/InputAdornment";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import styles from "./InputField.module.scss";

type PropsT = {
  input: any,
  meta: any,
  autoComplete?: string,
  className?: string
};

type StateT = {
  showPassword: boolean
};

class PasswordInputField extends React.Component<PropsT, StateT> {
  state = {
    showPassword: false
  };

  handleClickShowPassword = () => {
    this.setState(state => ({ showPassword: !state.showPassword }));
  };

  render() {
    const { input, meta, autoComplete = "false", className = "" } = this.props;
    const showPassword = this.state.showPassword;
    const error = meta && meta.touched && meta.error;

    return (
      <TextField
        {...input}
        type={showPassword ? "text" : "password"}
        label="Пароль"
        error={!!error}
        className={cx(styles.inputStyle, className)}
        helperText={error}
        autoComplete={autoComplete}
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <IconButton aria-label="Toggle password visibility" onClick={this.handleClickShowPassword}>
                {showPassword ? <Visibility /> : <VisibilityOff />}
              </IconButton>
            </InputAdornment>
          ),
          autoComplete
        }}
      />
    );
  }
}

export default PasswordInputField;
