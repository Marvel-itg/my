// @flow
import React from "react";
import Radio from "@material-ui/core/Radio";
import FormControlLabel from "@material-ui/core/FormControlLabel";

type PropsT = {
  input: any,
  label: string,
  disabled: boolean
};

const inputConfig = {
  gender: {
    type: "radio"
  }
};

const InputRadioField = (props: PropsT) => {
  return (
    <FormControlLabel
      {...props.input}
      {...inputConfig[props.input.name]}
      control={<Radio />}
      label={props.label}
      disabled={props.disabled}
    />
  );
};

export default InputRadioField;
