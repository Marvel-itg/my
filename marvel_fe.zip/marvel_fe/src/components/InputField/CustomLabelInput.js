// @flow
import React from "react";
import FormControl from "@material-ui/core/FormControl";
import Input from "@material-ui/core/Input";
import styles from "./InputField.module.scss";

type PropsT = {
  input: any,
  customlabel: string,
  disabled: boolean,
  viber: boolean
};

const CustomLabelInput = (props: PropsT) => {
  return (
    <FormControl className={styles.customLabelPicker}>
      <label htmlFor="customLabelPicker">{props.customlabel}</label>

      {props.viber ? (
        <a href={<a href="https://msng.link/vi/380937626675">Message me on Viber</a>}>
          {props.input && props.input.defaultValue}
        </a>
      ) : (
        <Input {...props.input} {...props} id="customLabelPicker" disabled={props.disabled} disableUnderline={true} />
      )}
    </FormControl>
  );
};

export default CustomLabelInput;
