// @flow
import React, { Component } from "react";
import { connect } from "react-redux";
import Dropzone from "react-dropzone";
import CircularProgress from "@material-ui/core/CircularProgress";
import cx from "classnames";
import InputLabel from "@material-ui/core/InputLabel";
import Typography from "@material-ui/core/Typography";
import AddIcon from "@material-ui/icons/AddCircle";
import CloseIcon from "@material-ui/icons/CancelTwoTone";
import DownloadIcon from "@material-ui/icons/CloudDownload";
import ImagesSlider from "./ImagesSlider";
import {
  uploadImage,
  deleteImage,
  resetImages,
  uploadInitialImage,
  setLimit,
  setImageError
} from "../../store/actions/common/images";
import { imageSizeLimit, imageSizeErrorMessage } from "../../constants";
import { MIME_TYPES } from "../../constants";
import { classes } from "../../helpers/spinner";
import styles from "./InputFileMultiple.module.scss";

type StateT = {
  sliderIsOpened: boolean,
  openedImageIndex: number
};

type PropsT = {
  input: any,
  meta: any,
  onChange: Function,
  isMultiple: boolean,
  disabled: boolean,
  withPreview: boolean,
  deletionError: boolean,
  deleting: boolean,
  fullWidth?: boolean,
  linksToImage: any[],
  imageTransactionSuccess: boolean,
  uploadInitialImage: Function,
  uploadImage: Function,
  deleteImage: Function,
  resetImages: Function,
  setLimit: Function,
  imagesLimit: number, //from store
  limit?: number, //from props
  error: string,
  bigPreview?: boolean,
  required?: boolean,
  label: string,
  configName: string,
  uploadUrl: string,
  className: string,
  withSlider: boolean,
  submitted?: boolean,
  saveButtonHandler?: Function,
  showDownloadButton?: boolean,
  formattedError?: string,
  onUpdate?: Function,
  id?: string,
  maxSize?: number,
  maxSizeErrorMessage?: string,
  uploadType: string,
  wideDropzone?: boolean,
  useFormFileField: boolean,
  setImageError: Function,
  canDownload: boolean
};

const inputConfig = {
  photos: {
    accept: [MIME_TYPES.jpg, MIME_TYPES.png],
    acceptLabel: {
      text: "Фотографії",
      extensions: "jpg, .png"
    },
    fileName: "photo"
  },
  photo: {
    accept: [MIME_TYPES.jpg, MIME_TYPES.png],
    acceptLabel: {
      text: "Фото",
      extensions: "jpg, .png"
    },
    fileName: "photo"
  },
  photoIds: {
    accept: [MIME_TYPES.jpg, MIME_TYPES.png],
    acceptLabel: {
      text: "Фотографії",
      extensions: "jpg, .png"
    },
    fileName: "photo"
  },
  posCodes: {
    accept: [".csv"],
    acceptLabel: {
      text: "Завантажити CSV"
    },
    fileName: "posCodes"
  },
  posCodesWithAmount: {
    accept: [".csv"],
    acceptLabel: {
      text: "Завантажити CSV"
    },
    fileName: "posCodes"
  },
  posPlan: {
    accept: [".csv"],
    acceptLabel: {
      text: "Завантажити CSV"
    },
    fileName: "posPlan"
  },
  foilPosPlan: {
    accept: [".csv"],
    acceptLabel: {
      text: "Завантажити CSV"
    },
    fileName: "foilPosPlan"
  },
  posMidPlus: {
    accept: [".csv"],
    acceptLabel: {
      text: "Завантажити CSV"
    },
    fileName: "posMidPlus"
  },
  scanCodes: {
    accept: [".csv"],
    acceptLabel: {
      text: "Завантажити CSV"
    },
    fileName: "scanCodes"
  },
  material: {
    accept: [MIME_TYPES.doc, MIME_TYPES.docx, MIME_TYPES.xlsx, MIME_TYPES.pdf, MIME_TYPES.ppt],
    acceptLabel: {
      text: "Матерiал"
    },
    fileName: "material"
  },
  posCodesForManageBonuses: {
    accept: [".csv"],
    acceptLabel: {
      text: "Завантажити CSV"
    },
    fileName: "posCodes"
  },
  taskPhoto: {
    accept: [MIME_TYPES.jpg, MIME_TYPES.png],
    acceptLabel: {
      text: "Відповідь на завдання",
      extensions: "jpg, .png"
    }
  },
  banner: {
    accept: [MIME_TYPES.jpg, MIME_TYPES.png],
    acceptLabel: {
      text: "Банер",
      extensions: "jpg, .png"
    },
    fileName: "photo"
  },
  preview: {
    accept: [MIME_TYPES.jpg, MIME_TYPES.png],
    acceptLabel: {
      text: "Обкладинка",
      extensions: "jpg, .png"
    },
    fileName: "photo"
  },
  content: {
    accept: [MIME_TYPES.jpg, MIME_TYPES.png, MIME_TYPES.mp4],
    acceptLabel: {
      text: "Файл",
      extensions: "jpg, .png, .mp4"
    },
    fileName: "file"
  },
  posCodesSales: {
    accept: [".csv"],
    acceptLabel: {
      text: "Додати ТТ"
    },
    fileName: "posCodes"
  },
  brandsSettingsImage: {
    accept: [MIME_TYPES.jpg, MIME_TYPES.png],
    acceptLabel: {
      text: "Зображення на сторінку “Наші Бренди”",
      extensions: "jpg, .png"
    },
    fileName: "photo"
  },
  brandsSettingsLineImage: {
    accept: [MIME_TYPES.jpg, MIME_TYPES.png],
    acceptLabel: {
      text: "Зображення на сторінку “Лінійки”",
      extensions: "jpg, .png"
    },
    fileName: "photo"
  }
};

const typographyStyle = { root: styles.error };

class InputFileMultiple extends Component<PropsT, StateT> {
  state = {
    sliderIsOpened: false,
    openedImageIndex: 0
  };

  componentDidMount() {
    const { limit, setLimit } = this.props;
    setLimit(limit, this.props.id);
    this.uploadInitialImage();
  }

  componentDidUpdate(prevProps) {
    if (
      !prevProps.input.value &&
      this.props.input.value &&
      (!this.props.linksToImage || !this.props.linksToImage.length)
    ) {
      this.uploadInitialImage();
    }
    if (prevProps.linksToImage !== this.props.linksToImage) {
      this.props.input.onChange(this.props.linksToImage);
    }
    if (this.props.deletionError && prevProps.deletionError !== this.props.deletionError) {
      this.props.input.onChange(this.props.linksToImage);
    }
  }

  componentWillUnmount() {
    this.props.resetImages(this.props.id);
  }

  openSlider = index => {
    this.setState({ sliderIsOpened: true, openedImageIndex: index });
  };

  closeSlider = () => {
    this.setState({ sliderIsOpened: false });
  };

  changeIndex = index => {
    this.setState({ openedImageIndex: index });
  };

  uploadInitialImage = () => {
    Array.isArray(this.props.input.value)
      ? this.props.input.value.forEach(image => this.props.uploadInitialImage(image, this.props.id))
      : this.props.uploadInitialImage(...this.props.input.value, this.props.id);
  };

  onDropAccepted = (filesToUpload: any[]) => {
    const { maxSize = imageSizeLimit, maxSizeErrorMessage = imageSizeErrorMessage, setImageError } = this.props;

    filesToUpload.forEach((file, idx, array) => {
      if (file.size > maxSize) {
        setImageError(this.props.id, maxSizeErrorMessage);

        return;
      }
      let bodyFormData = new FormData();
      if (this.props.uploadUrl && !this.props.useFormFileField) {
        if (!file.size > maxSize) {
          setImageError(this.props.id, maxSizeErrorMessage);

          return;
        }
        bodyFormData.append("file", file);
      } else {
        bodyFormData.append("formFile", file);
      }
      const uploadUrl = this.props.uploadUrl;
      const params = {
        data: bodyFormData,
        uploadType: this.props.uploadType || "image",
        count: array.length,
        name: this.props.id,
        fileName: file.name,
        uploadUrl,
        withApi: !uploadUrl
      };

      this.props.uploadImage(params);
      if (this.props.onUpdate) {
        this.props.onUpdate(); // set touched for task form for not send posCodes if file was not changed
      }
    });
  };

  deleteFile = (id: string, withApi: boolean) => {
    const propsValue = this.props.input.value;
    const value = Array.isArray(propsValue) ? propsValue : propsValue ? [propsValue] : [];
    const files = value.filter(file => {
      const fileId = file.imageId || file.id;
      return fileId !== id;
    });
    this.props.input.onChange(files);
    const params = {
      id,
      name: this.props.id,
      withApi,
      uploadType: this.props.uploadType || "image"
    };
    this.props.deleteImage(params);
    this.props.setImageError(this.props.id, null);
  };

  getImageClasses = () => {
    return this.props.withSlider
      ? cx(styles.img, styles.imgActiveToClick, { [styles.bigPreview]: this.props.bigPreview }, this.props.className)
      : cx(styles.img, { [styles.bigPreview]: this.props.bigPreview }, this.props.className);
  };

  get isDownloadDisabled() {
    return !(!this.props.disabled || (this.props.disabled && this.props.canDownload));
  }

  imageClasses = this.getImageClasses();

  render() {
    const {
      meta,
      deletionError,
      isMultiple,
      disabled,
      withPreview,
      withSlider,
      error: imageError,
      imagesLimit,
      label,
      configName,
      wideDropzone
    } = this.props;

    const config = inputConfig[this.props.input.name] || inputConfig[configName];

    const propsValue = this.props.input.value;
    const value = Array.isArray(propsValue) ? propsValue : propsValue ? [propsValue] : [];

    let images = [];
    if (value && value.length) {
      images = value.map(file => file.imageUrl);
    }

    const error = this.props.formattedError || imageError || deletionError || (meta.touched && meta.error);

    return (
      <>
        <InputLabel required={this.props.required} error={!!error} disabled={disabled}>
          {(config.acceptLabel && config.acceptLabel.text) || label}
        </InputLabel>

        <div className={styles.wrapper}>
          <ul className={cx(styles.dropzoneContent, disabled && !withSlider ? styles.disabledAll : null)}>
            {withPreview && value && value.length
              ? value.map((file, index) => {
                  const isVideo =
                    (file.fileName && file.fileName.endsWith(".mp4")) ||
                    (file.imageUrl && file.imageUrl.endsWith(".mp4")) ||
                    file.contentType === "video/mp4";
                  const id = file.id || file.imageId || file;
                  return (
                    <li className={styles.imgWrapper} key={id}>
                      {!isVideo ? (
                        <img
                          className={this.imageClasses}
                          src={file.imageUrl || file.url}
                          onClick={() => {
                            this.openSlider(index);
                          }}
                          alt="Preview"
                        />
                      ) : (
                        <video className={styles.videoPreview} controls>
                          <source src={file.imageUrl || file.url} type="video/mp4" width="250" />
                        </video>
                      )}

                      {!disabled && (
                        <CloseIcon className={styles.closeIcon} onClick={() => this.deleteFile(id, file.withApi)} />
                      )}
                    </li>
                  );
                })
              : null}
            {value.length < imagesLimit && (
              <li className={disabled ? styles.disabledAll : ""}>
                <Dropzone
                  accept={config.accept}
                  onFileDialogCancel={this.props.input.onBlur}
                  onDropAccepted={this.onDropAccepted}
                >
                  {({ getRootProps, getInputProps }) => (
                    <div
                      {...getRootProps()}
                      className={cx(styles.dropzone, {
                        [styles.dropzoneReject]: !!error,
                        [styles.dropzoneWide]: wideDropzone
                      })}
                    >
                      <AddIcon color="primary" className={styles.addIcon} />
                      <input {...getInputProps()} multiple={isMultiple} disabled={disabled} />
                      {(this.props.deleting || !this.props.imageTransactionSuccess) && (
                        <CircularProgress classes={classes} />
                      )}
                    </div>
                  )}
                </Dropzone>
              </li>
            )}
          </ul>
          {!withPreview && value && value.length
            ? value.map(item => {
                const id = item.id || item.imageId || item;
                const fileName = item.fileName;
                return (
                  <div key={id} className={styles.fileNameWrapper}>
                    <div className={cx(styles.fileNameField, disabled && !withSlider ? styles.disabledAll : null)}>
                      {fileName}
                    </div>
                    {(item.uploadUri || this.props.showDownloadButton) && (
                      <a
                        href={item.uploadUri}
                        download={item.fileName}
                        disabled={this.isDownloadDisabled}
                        className={this.isDownloadDisabled ? styles.downloadIconDisabled : styles.downloadIcon}
                        onClick={this.props.saveButtonHandler}
                      >
                        <DownloadIcon />
                      </a>
                    )}
                    <CloseIcon
                      className={cx(styles.closeString, disabled && !withSlider ? styles.disabledAll : null)}
                      onClick={() => this.deleteFile(id, item.withApi)}
                    />
                  </div>
                );
              })
            : ""}

          {error && (
            <Typography color="error" classes={typographyStyle}>
              {error}
            </Typography>
          )}
        </div>
        {withPreview && withSlider && (
          <ImagesSlider
            images={images}
            sliderIsOpened={this.state.sliderIsOpened}
            closeSlider={this.closeSlider}
            changeIndex={this.changeIndex}
            index={this.state.openedImageIndex}
          />
        )}
      </>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  const { images } = state;

  const statePart = images[ownProps.id] || {};
  const {
    linksToImage,
    deletedImage,
    deletionError,
    imageTransactionSuccess = true,
    limit = 1,
    deleting,
    error
  } = statePart;

  return {
    linksToImage,
    deletedImage,
    deletionError,
    error,
    imageTransactionSuccess,
    deleting,
    imagesLimit: limit
  };
};
const mapDispatchToProps = { uploadImage, deleteImage, resetImages, uploadInitialImage, setLimit, setImageError };
export default connect(mapStateToProps, mapDispatchToProps)(InputFileMultiple);
