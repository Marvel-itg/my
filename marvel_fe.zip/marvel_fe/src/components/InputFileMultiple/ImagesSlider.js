// @flow
import React, { useEffect } from "react";
import Dialog from "@material-ui/core/Dialog";
import SwipeableViews from "react-swipeable-views";
import CloseIcon from "@material-ui/icons/Close";
import NextIcon from "@material-ui/icons/KeyboardArrowRight";
import PrevIcon from "@material-ui/icons/KeyboardArrowLeft";
import { IconButton } from "@material-ui/core";
import styles from "./InputFileMultiple.module.scss";

type PropsT = {
  images: string[],
  closeSlider: Function,
  sliderIsOpened: boolean,
  index: number,
  changeIndex: (index: number) => void
};

const ImagesSlider = ({ images, openSlider, closeSlider, sliderIsOpened, index, changeIndex }: PropsT) => {
  const imagesAmount = images.length;

  const prevImage = () => {
    const prevIndex = index === 0 ? imagesAmount - 1 : (index - 1) % imagesAmount;
    changeIndex(prevIndex);
  };

  const nextImage = () => {
    const nextIndex = (index + 1) % imagesAmount;
    changeIndex(nextIndex);
  };

  const handleKeyDown = event => {
    switch (event.keyCode) {
      case 37:
        return prevImage();

      case 39:
        return nextImage();
      default:
        return null;
    }
  };
  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  });

  return (
    <Dialog open={sliderIsOpened} onClose={closeSlider} maxWidth="xl" fullWidth>
      <CloseIcon className={styles.slider__closeIcon} onClick={closeSlider} />
      <SwipeableViews index={index} onChangeIndex={changeIndex} enableMouseEvents>
        {images &&
          images.length &&
          images.map((imageSrc, index) => (
            <div key={index} className={styles.sliderImgWrapper}>
              <img src={imageSrc} className={styles.sliderImg} alt="Full width" />
            </div>
          ))}
      </SwipeableViews>
      {images && images.length > 1 && (
        <div className={styles.slider__buttons}>
          <IconButton color="primary" onClick={prevImage} className={styles.slider__button}>
            <PrevIcon fontSize="large" />
          </IconButton>
          <IconButton color="primary" onClick={nextImage} className={styles.slider__button}>
            <NextIcon fontSize="large" />
          </IconButton>
        </div>
      )}
    </Dialog>
  );
};

export default ImagesSlider;
