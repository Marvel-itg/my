// @flow
import React from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";

type PropsT = {
  open: boolean,
  onConfirm: Function,
  onClose: Function,
  onCancel: Function,
  question?: string,
  confirmButtonLabel?: string,
  cancelButtonLabel?: string
};

const ConfirmModal = (props: PropsT) => {
  const {
    onClose,
    open,
    onConfirm,
    onCancel,
    question = "Ви впевнені, що не бажаете зберегти інформацію яка була внесена?",
    confirmButtonLabel = "Так",
    cancelButtonLabel = "Hi"
  } = props;

  return (
    <Dialog open={open} onClose={onClose} aria-describedby="alert-dialog-description">
      <DialogContent>
        <DialogContentText id="alert-dialog-description">{question}</DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={onConfirm} color="primary">
          {confirmButtonLabel}
        </Button>
        <Button onClick={onCancel} color="primary">
          {cancelButtonLabel}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ConfirmModal;
