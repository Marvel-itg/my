// @flow
import React from "react";
import Modal from "@material-ui/core/Modal";
import IconClose from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import { connect } from "react-redux";
import { reduxForm } from "redux-form";
import { compose } from "redux";
import ContainedButton from "../Buttons/ContainedButton/ContainedButton";
import { closeModal } from "../../store/actions/common/modals";
import ConfirmModal from "./ConfirmModal";
import styles from "./Modal.module.scss";

type PropsT = {
  open: boolean,
  onClose: Function,
  children: any,
  type?: string,
  dirty: Function,
  formName: string,
  modalIsOpened: boolean,
  modalName: string,
  closeModal: Function,
  currentModalName: string | null
};

type StateT = {
  isDirty: boolean
};

const modalClasses = {
  deactivate: { root: styles.deactivateRoot },
  errorsModal: { root: styles.deactivateRoot },
  history: { root: styles.historyRoot },
  success: {}
};

class CustomModal extends React.Component<PropsT, StateT> {
  state = {
    isDirty: false
  };

  submitHandler = () => {
    if (this.props.formName && this.props.dirty) {
      this.setDirtyValue(true);
    } else {
      this.props.onClose ? this.props.onClose() : this.props.closeModal();
    }
  };

  setDirtyValue = value => this.setState({ isDirty: value });

  handleCancelDirtyModal = () => {
    this.setState({ isDirty: false });
  };

  handleCloseDirtyModal = () => {
    this.setState({ isDirty: false });
    this.props.onClose ? this.props.onClose() : this.props.closeModal();
  };

  calculateClasses = type => (type ? modalClasses[type] : {});

  get isOpen() {
    const { modalName, currentModalName, open, modalIsOpened } = this.props;
    if (!modalName || !currentModalName) return open || modalIsOpened;
    return modalName === currentModalName && (open || modalIsOpened);
  }

  render() {
    const { onClose, type, children } = this.props;
    return (
      <React.Fragment>
        <Modal open={this.isOpen} onClose={this.submitHandler} classes={this.calculateClasses(type)}>
          <div className={type ? styles[type] : styles.modalWrapper}>
            <IconButton className={styles.closeButton} onClick={this.submitHandler}>
              <IconClose />
            </IconButton>
            {children}
            {type === "success" && <ContainedButton label="Ok" handleClick={onClose} />}
          </div>
        </Modal>

        <ConfirmModal
          open={this.state.isDirty}
          onClose={this.handleCloseDirtyModal}
          onConfirm={this.handleCloseDirtyModal}
          onCancel={this.handleCancelDirtyModal}
        />
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  // FixMe: defaultValue was added for escaping problems in modals without form
  form: ownProps.formName || "defaultForm",
  modalIsOpened: state.modals.modalIsOpened,
  currentModalName: state.modals.modalName
});

const mapDispatchToProps = {
  closeModal
};

export default compose(connect(mapStateToProps, mapDispatchToProps), reduxForm())(CustomModal);
