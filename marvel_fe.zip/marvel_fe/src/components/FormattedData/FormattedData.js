// @flow
import React from "react";
import type { ComponentType } from "react";
import get from "lodash/get";
import { Link } from "react-router-dom";
import moment from "moment";
import fileSaver from "file-saver";
import { memoize } from "lodash";
import { DataTypeProvider, DataTypeProviderProps } from "@devexpress/dx-react-grid";
import cx from "classnames";
import Tooltip from "@material-ui/core/Tooltip";
import Decline from "@material-ui/icons/Close";
import Close from "@material-ui/icons/Check";
import Checkbox from "@material-ui/core/Checkbox";
import AccessTimeIcon from "@material-ui/icons/AccessTime";
import Button from "@material-ui/core/Button";
import DownloadIcon from "@material-ui/icons/CloudDownload";
import InputField from "../InputField/InputField";
import Select from "../Select/Select";
import ContainedButton from "../Buttons/ContainedButton/ContainedButton";
import DestructiveButton from "../Buttons/DestructiveButton/DestructiveButton";
import EditableFieldWithDialog from "../EditableFields/EdtitableFieldWithDialog";
import {
  genderFormat,
  positionFormat,
  answerType,
  shiftStatusMap,
  taskTypeFormat,
  exchangeToGiftRequestStatus,
  configByHistoryKey,
  roles,
  shiftCancellationReasonsMap,
  taskPhotoStatusFormat
} from "../../constants";
import { formatPhone } from "../../utils/reduxFormNormalizers";
import CurrencyFormatter from "../CurrencyFormatter/CurrencyFormatter";
import styles from "./FormattedData.module.scss";
import { mapCityToOptionsOfCities } from "../../helpers/common";
import zipIcon from "../../assets/images/icons8-zip-96.svg";

const imageComponent = memoize((className, onClick) => props => {
  const handleClick = (event: SyntheticEvent<HTMLDivElement>) => {
    event.stopPropagation();
    // FixMe: flow error
    if (onClick) {
      onClick(props.row);
    }
  };

  return (
    <div
      onClick={handleClick}
      style={{ backgroundImage: `url(${props.value})` }}
      className={className ? cx(className, styles.img) : styles.roundImg}
      alt=""
    />
  );
});

export const ImageProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={imageComponent(props.className, props.onClick)} for={props.for} />;
};

const phoneComponent = ({ value }) => (
  <span className={styles.alignment}>
    <span>{value ? formatPhone(value) : ""}</span>
  </span>
);

export const PhoneProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={phoneComponent} for={props.for} />;
};

const emailComponent = ({ value }) => (
  <span className={styles.alignment}>
    <span>{value}</span>
  </span>
);

export const EmailProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={emailComponent} for={props.for} />;
};

const buttonComponent = (label, onClick) => rowData => {
  const id = rowData.row.id;
  const handleClick = (event: SyntheticEvent<HTMLButtonElement>) => {
    event.stopPropagation();
    // FixMe: flow error
    if (onClick) {
      onClick(id, rowData.row);
    }
  };
  return <ContainedButton label={label} className={styles.tableButton} handleClick={handleClick} />;
};

export const ButtonProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={buttonComponent(props.label, props.onClick)} for={props.for} />;
};

const activateButtonComponent = (
  label,
  onClick,
  checkHidden = row => {
    return false;
  }
) => ({ row }) => {
  const id = row.id;
  const handleClick = (event: SyntheticEvent<HTMLButtonElement>) => {
    event.stopPropagation();
    onClick(id);
  };
  return checkHidden(row) ? null : (
    <ContainedButton label={label} className={styles.tableButton} handleClick={handleClick} />
  );
};

export const ActivateButtonProvider: ComponentType<DataTypeProviderProps> = props => {
  return (
    <DataTypeProvider
      formatterComponent={activateButtonComponent(props.label, props.onClick, props.checkHidden)}
      for={props.for}
    />
  );
};

const transparentButtonComponent = (label, onClick, checkHidden = row => false) => rowData => {
  const id = rowData.row.id;
  const handleClick = (event: SyntheticEvent<HTMLButtonElement>) => {
    event.stopPropagation();
    onClick(id, rowData.row);
  };
  return !checkHidden(rowData.row) ? (
    <Button className={styles.transparentButton} color="primary" onClick={handleClick}>
      {label}
    </Button>
  ) : null;
};

export const TransparentButtonProvider: ComponentType<DataTypeProviderProps> = props => {
  return (
    <DataTypeProvider
      formatterComponent={transparentButtonComponent(props.label, props.onClick, props.checkHidden)}
      for={props.for}
    />
  );
};

const downloadButtonComponent = ({ showCondition, handleDownload }) => rowData => {
  const handleClick = (event: SyntheticEvent<HTMLButtonElement>) => {
    event.stopPropagation();
    if (!!handleDownload) {
      handleDownload(rowData.row);
    } else {
      fileSaver.saveAs(rowData.row.fileUrl, rowData.row.fileName);
    }
  };

  if (!!showCondition) {
    return showCondition(rowData.row) ? (
      <DownloadIcon onClick={handleClick} color="primary" className={styles.downloadButton} />
    ) : null;
  }
  return <DownloadIcon onClick={handleClick} color="primary" className={styles.downloadButton} />;
};

export const DownloadButtonProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={downloadButtonComponent(props)} for={props.for} />;
};

const EditRouteComponent = (label, onClick, checkHidden = row => false) => rowData => {
  return !checkHidden(rowData.row) ? transparentButtonComponent(label, onClick)(rowData) : null;
};

export const EditRouteProvider: ComponentType<DataTypeProviderProps> = props => {
  return (
    <DataTypeProvider
      formatterComponent={EditRouteComponent(props.label, props.onClick, props.checkHidden)}
      {...props}
    />
  );
};

const destructiveButtonComponent = (
  label,
  onClick,
  checkHidden = row => {
    return false;
  }
) => ({ row }) => {
  const id = row.id;
  const handleClick = (event: SyntheticEvent<HTMLButtonElement>) => {
    event.stopPropagation();
    onClick(id, row);
  };

  return checkHidden(row) ? null : (
    <DestructiveButton label={label} className={styles.tableButton} handleClick={handleClick} />
  );
};

export const DestructiveButtonProvider: ComponentType<DataTypeProviderProps> = props => {
  return (
    <DataTypeProvider
      formatterComponent={destructiveButtonComponent(props.label, props.onClick, props.checkHidden)}
      for={props.for}
    />
  );
};

//============================================================================//
export const ToggleActiveProvider: ComponentType<DataTypeProviderProps> = props => {
  return (
    <DataTypeProvider
      formatterComponent={rowData => {
        const { id, isActive, startDate, taskType } = rowData.row;

        const handleClick = (event: SyntheticEvent<HTMLButtonElement>) => {
          event.stopPropagation();
          props.onClick(id, isActive, startDate, taskType);
        };
        if (!isActive) {
          return (
            <ContainedButton
              label="Активувати"
              className={cx(styles.tableButton, styles.toggleButtonStyle)}
              handleClick={handleClick}
            />
          );
        }
        return (
          <DestructiveButton
            label="Деактивувати"
            className={cx(styles.tableButton, styles.toggleButtonStyle)}
            handleClick={handleClick}
          />
        );
      }}
      for={props.for}
    />
  );
};

const genderComponent = memoize(forProp => ({ row }) => (
  <span className={styles.alignment}>{genderFormat[row[forProp]]}</span>
));

export const GenderProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={genderComponent(props.for)} for={props.for} />;
};

const positionComponent = memoize(forProp => ({ row }) => (
  <span className={styles.alignment}>{positionFormat[row[forProp]]}</span>
));

export const PositionProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={positionComponent(props.for)} for={props.for} />;
};

const dateFormatComponent = memoize(key => ({ value }) => {
  let dateValue = value;
  if (dateValue && moment(dateValue).toString() === "Invalid date") {
    // for mock data
    dateValue = dateValue.replace(/(\d{2}).(\d{2}).(\d{4})/, "$2/$1/$3");
  }
  let dateFormat = "";
  switch (key) {
    case "showTime":
      dateFormat = "DD/MM/YYYY HH:mm";
      break;
    case "onlyTime":
      dateFormat = "HH:mm";
      break;
    case "timeWithSeconds":
      dateFormat = "HH:mm:ss";
      break;
    case "dateAndTimeWithSeconds":
      dateFormat = "DD/MM/YYYY HH:mm:ss";
      break;
    default:
      dateFormat = "DD/MM/YYYY";
      break;
  }
  var offset = moment().utcOffset();
  const formattedDate = dateValue
    ? moment
        .utc(dateValue)
        .utcOffset(offset)
        .format(dateFormat)
    : "";

  return <span className={styles.alignment}>{formattedDate}</span>;
});

export const DateFormatProvider: ComponentType<DataTypeProviderProps> = props => {
  const key = props.onlyTime
    ? "onlyTime"
    : props.showTime
    ? "showTime"
    : props.timeWithSeconds
    ? "timeWithSeconds"
    : props.dateAndTimeWithSeconds
    ? "dateAndTimeWithSeconds"
    : "";
  return (
    <DataTypeProvider
      formatterComponent={dateFormatComponent(key)}
      for={props.for}
      showTime={props.showTime}
      onlyTime={props.onlyTime}
      dateAndTimeWithSeconds={props.dateAndTimeWithSeconds}
      timeWithSeconds={props.timeWithSeconds}
    />
  );
};

const fullNameComponent = ({ row }) => {
  const { firstName, lastName } = row;
  const fullName = `${firstName} ${lastName}`;
  return <span className={styles.alignment}>{fullName}</span>;
};

export const FullNameProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={fullNameComponent} for={props.for} />;
};

const answerTypeComponent = ({ row }) => {
  const { answerType: type } = row;
  return <span className={styles.alignment}>{answerType[type]}</span>;
};
//============================================================================//
export const AnswerTypeProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={answerTypeComponent} for={props.for} />;
};

const arrayToStringComponent = ({ value }) => (
  <span className={styles.alignment}>
    <span>{value ? value.join(", ") : ""}</span>
  </span>
);

export const ArrayToStringProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={arrayToStringComponent} for={props.for} />;
};

const profileLinkComponent = ({ value }) => {
  if (value) {
    return (
      <span className={styles.alignment}>
        <Link to={value.url}>{value.name}</Link>
      </span>
    );
  } else {
    return <span>No Link</span>;
  }
};
//============================================================================//
export const ProfileLinkProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={profileLinkComponent} for={props.for} />;
};
//============================================================================//
const formatProjects = projects =>
  projects &&
  projects.reduce((acc, item, index, arr) => {
    return (acc += `${item.name} ${index !== arr.length - 1 ? ", " : ""}`);
  }, "");

const projectsFormatterComponent = memoize(forProp => ({ row }) => {
  const projects = row[forProp];
  return <span className={styles.projects}>{formatProjects(projects)}</span>;
});

export const ProjectsProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={projectsFormatterComponent(props.for)} for={props.for} />;
};

const historyKeyFormatterComponent = memoize(forProp => ({ row }) => {
  const formattedFieldValue = configByHistoryKey[row[forProp]];
  return <span className={styles.projects}>{formattedFieldValue}</span>;
});

export const HistoryKeyProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={historyKeyFormatterComponent(props.for)} for={props.for} />;
};

const cityProviderComponent = memoize((forProp, withAllValue) => ({ row }) => {
  const listOfCities = row[forProp] && row[forProp].length && row[forProp].map(mapCityToOptionsOfCities);

  return listOfCities && listOfCities.length ? (
    <ul className={styles.cityList}>
      {listOfCities.map((city, index) => (
        <li key={`${index}${city.value}`} className={styles.cityListSingleItem}>
          {city.label}
        </li>
      ))}
    </ul>
  ) : withAllValue ? (
    <ul className={styles.cityList}>
      <li key={"all"} className={styles.cityListSingleItem}>
        Всі населені пункти
      </li>
    </ul>
  ) : (
    ""
  );
});

const regionProviderComponent = memoize(forProp => ({ row }) => {
  const listOfCities = row[forProp].map(mapCityToOptionsOfCities);

  return (
    <ul className={styles.cityList}>
      {listOfCities.map(city => (
        <li key={city.value} className={styles.cityListSingleItem}>
          {city.region}
        </li>
      ))}
    </ul>
  );
});

export const CityProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={cityProviderComponent(props.for, props.withAllValue)} for={props.for} />;
};

export const RegionProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={regionProviderComponent(props.for)} for={props.for} />;
};

const personInfoComponent = memoize(forProps => ({ row }) => {
  const firstName = (row[forProps] && row[forProps].firstName) || "";
  const middleName = (row[forProps] && row[forProps].middleName) || "";
  const lastName = (row[forProps] && row[forProps].lastName) || "";
  return <span className={styles.alignment}>{`${lastName} ${firstName} ${middleName}`}</span>;
});

export const PersonInfoProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={personInfoComponent(props.for)} for={props.for} />;
};

const chiefInfoComponent = memoize((forProps, path) => ({ row }) => {
  const chief = get(row, path);
  const firstName = (chief && chief.firstName) || "";
  const middleName = (chief && chief.middleName) || "";
  const lastName = (chief && chief.lastName) || "";
  const role = (chief && roles[chief.accountType]) || "";
  return <span className={styles.alignment}>{`${lastName} ${firstName} ${middleName} (${role})`}</span>;
});

export const ChiefInfoProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={chiefInfoComponent(props.for, props.path)} for={props.for} />;
};

const GetPropertyFromObjectComponent = memoize((forProp, property) => ({ row }) => {
  return <span className={styles.alignment}>{row[forProp][property]}</span>;
});

export const GetPropertyFromObject: ComponentType<DataTypeProviderProps> = props => {
  return (
    <DataTypeProvider
      formatterComponent={GetPropertyFromObjectComponent(props.for, props.property)}
      property={props.property}
      for={props.for}
    />
  );
};

const candidateStatusComponent = memoize(forColumn => ({ row }) => {
  const status = row[forColumn] ? "Постійний штат" : "Резерв";
  return <span className={styles.alignment}>{status}</span>;
});

export const CandidateStatusProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={candidateStatusComponent(props.for)} for={props.for} />;
};

const adminStatusComponent = memoize(forColumn => ({ row }) => {
  if (row.key === "UserStatusId") {
    switch (row[forColumn]) {
      case "1":
        return <span className={styles.alignment}>Потенційний</span>;
      case "2":
        return <span className={styles.alignment}>Відхилений</span>;
      case "3":
        return <span className={styles.alignment}>Активний</span>;
      case "4":
        return <span className={styles.alignment}>Деактивований</span>;
      case "5":
        return <span className={styles.alignment}>Зміна телефону</span>;
      default:
        return <span className={styles.alignment} />;
    }
  }
  if (row.key === "PlannedStartDate" || row.key === "PlannedEndDate") {
    const offset = moment().utcOffset();
    const date = moment
      .utc(row[forColumn], "YYYY-MM-DD HH:mm:ss")
      .utcOffset(offset)
      .format("DD/MM/YYYY, HH:mm");
    return <span className={styles.alignment}>{date}</span>;
  }

  if (row.key === "Geo" || row.key === "Projects") {
    return (
      <ul className={styles.cityList}>
        {row[forColumn].map((city, index) => (
          <li
            key={`${index} ${moment(new Date()).valueOf()}`}
            className={row[forColumn].length === 1 ? styles.cityListSingleItem : ""}
          >
            {city.label}
          </li>
        ))}
      </ul>
    );
  }

  if (row.key === "IsMainState") {
    switch (row[forColumn]) {
      case "False":
        return <span className={styles.alignment}>Резерв</span>;
      case "True":
        return <span className={styles.alignment}>Основний штат</span>;
      default:
        return <span className={styles.alignment} />;
    }
  }

  if (row.key === "Gender") {
    return <span>{genderFormat[row[forColumn]]}</span>;
  }

  if (row.key === "Images") {
    return (
      <ul>
        {row[forColumn] && row[forColumn].length
          ? row[forColumn].map((file, index) => {
              return (
                <li className={styles.imgWrapper} key={index}>
                  <img className={styles.smallImg} src={file.Url} alt="Hello" />
                </li>
              );
            })
          : null}
      </ul>
    );
  }
  return <span className={styles.alignment}>{row[forColumn]}</span>;
});

export const AdminStatusProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={adminStatusComponent(props.for)} for={props.for} />;
};

const exchangeRequestsStatusComponent = ({ row }) => {
  const { status } = row;
  return status === 2 ? <Close className={styles.closedOrderIconStyles} /> : <Decline color="error" />;
};

export const ExchangeRequestsStatusProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={exchangeRequestsStatusComponent} for={props.for} />;
};

const exchangeToGiftRequestsStatusComponent = ({ row }) => {
  const { status } = row;
  return <span className={styles.alignment}>{exchangeToGiftRequestStatus[status]}</span>;
};

export const ExchangeToGiftRequestsStatusProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={exchangeToGiftRequestsStatusComponent} for={props.for} />;
};
const orderStatusComponent = ({ row }) => {
  const { statusIdByTradeRepresentative } = row;
  return statusIdByTradeRepresentative === 3 ? (
    <Close className={styles.closedOrderIconStyles} />
  ) : statusIdByTradeRepresentative === 5 ? (
    <Decline color="error" />
  ) : null;
};
//============================================================================//
export const OrderStatusProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={orderStatusComponent} for={props.for} />;
};

const currencyFn = onSave => ({ row: { id }, value }) => <CurrencyFormatter value={value} id={id} onSave={onSave} />;

export const CurrencyProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={currencyFn(props.onSave)} for={props.for} />;
};
//============================================================================//
export const EditableFieldWithDialogProvider: ComponentType<DataTypeProviderProps> = props => {
  // eslint-disable-next-line
  let isMulti;
  let fieldProps;
  switch (props.formElement) {
    case "multiSelect":
      isMulti = true; // eslint-disable-next-line
    case "select":
      fieldProps = elementProps => {
        return {
          ...elementProps,
          ...props,
          isMulti,
          name: elementProps.name,
          fullWidth: true,
          component: Select,
          className: styles.select
        };
      };
      break;
    default:
      fieldProps = elementProps => {
        return {
          ...elementProps,
          ...props,
          fullWidth: true,
          component: InputField
        };
      };
  }
  return (
    <DataTypeProvider
      formatterComponent={({ row: { id }, value, column: { name }, ...rest }) => {
        return (
          <EditableFieldWithDialog
            {...props}
            dialogTitle={props.dialogTitle || name}
            initialValue={value}
            name={`${name}-${id}`}
            id={id}
            fieldProps={fieldProps({ value, rest, name: `field_${name}-${id}` })}
          >
            {props.valueIsOption ? value.label : value}
          </EditableFieldWithDialog>
        );
      }}
      for={props.for}
    />
  );
};

const shiftStatusComponent = ({ row }) => {
  const { status } = row;
  return <div>{shiftStatusMap[status]}</div>;
};

export const ShiftStatusProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={shiftStatusComponent} for={props.for} />;
};

const shiftCancellationComponent = ({ row }) => {
  const { reason } = row;
  return <div>{shiftCancellationReasonsMap[reason]}</div>;
};

export const ShiftCancellationReasonProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={shiftCancellationComponent} for={props.for} />;
};

const shiftDateComponent = ({ row }) => {
  const { startDate } = row;
  if (!startDate) return "Date is unknown";
  const offset = moment().utcOffset();
  return `${moment
    .utc(startDate)
    .utcOffset(offset)
    .format("DD/MM/YYYY")}`;
};

export const ShiftDateProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={shiftDateComponent} for={props.for} />;
};

const taskTypeComponent = memoize(forProp => ({ row }) => (
  <span className={styles.alignment}>{taskTypeFormat[row[forProp]]}</span>
));

export const TaskTypeProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={taskTypeComponent(props.for)} for={props.for} />;
};

const listProviderComponent = forProp => ({ row, value }) => {
  const list = value;

  return (
    <ul className={styles.cityList}>
      {list &&
        list.map((item, index) => (
          <li key={`${index}${item}`} className={styles.cityListSingleItem}>
            {item}
          </li>
        ))}
    </ul>
  );
};

export const ListProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={listProviderComponent(props.for)} for={props.for} />;
};

const codesListProviderComponent = memoize(forProp => ({ row }) => {
  const list = row[forProp];

  return (
    <ul className={styles.cityList}>
      {list &&
        list.map((item, index) => (
          <li key={`${index}${item}`} className={styles.cityListSingleItem}>
            <span className={styles.scanCode}>{item.code}</span> <span>{item.date}</span>
          </li>
        ))}
    </ul>
  );
});

export const CodesListProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={codesListProviderComponent(props.for)} for={props.for} />;
};

const checkBoxComponent = props => rowData => {
  const id = rowData.row.id;
  const { checkedRows, uncheckedRows = [], checkedAll, onClick } = props;
  const handleClick = (event: SyntheticEvent<HTMLButtonElement>, checked) => {
    event.stopPropagation();
    onClick(id, checked);
  };

  const checked = checkedAll ? !uncheckedRows.includes(id) : checkedRows.includes(id);

  return <Checkbox onChange={handleClick} checked={checked} color="primary" />;
};

export const CheckboxProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={checkBoxComponent(props)} for={props.for} />;
};

const distanceStatusComponent = memoize(forProp => ({ row }) => (
  <span className={styles.alignment}>{taskPhotoStatusFormat[row[forProp]]}</span>
));

export const DistanceStatusProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={distanceStatusComponent(props.for)} for={props.for} />;
};

const durationProviderComponent = memoize(forProp => ({ value }) => {
  const totalDuration = moment.duration(value, "minutes");
  let hours = totalDuration && totalDuration.get("hours");
  if (totalDuration && totalDuration.get("days")) {
    hours = Math.trunc(totalDuration.asHours());
  }
  if (hours < 10) {
    hours = `0${hours}`;
  }

  let minutes = totalDuration && totalDuration.get("minutes");

  if (minutes < 10) {
    minutes = `0${minutes}`;
  }
  const string = hours || minutes ? `${hours}:${minutes}:00` : "00:00:00";
  return <div>{string}</div>;
});

export const DurationProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={durationProviderComponent(props.for)} for={props.for} />;
};

const textComponent = memoize(forProp => ({ row }) => <div className={styles.textProvider}>{row[forProp]}</div>);

export const TextProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={textComponent(props.for)} for={props.for} />;
};

const scanCodesStatusComponent = ({ row }) => {
  const { state, failReason } = row;
  if (state === 1) {
    return <AccessTimeIcon />;
  }
  if (state === 2) {
    return <Close className={styles.closedOrderIconStyles} />;
  }
  if (state === 3) {
    return (
      <Tooltip
        className={styles.scanCodesTooltip}
        title={<div className={styles.scanCodesTooltipTitle}>{failReason}</div>}
      >
        <Decline color="error" />
      </Tooltip>
    );
  }
  return null;
};

export const ScanCodesStatusProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={scanCodesStatusComponent} for={props.for} />;
};

const scanCodesZipIconComponent = ({ row }) => {
  const { skuName } = row;

  return (
    <div className={styles.zipWrapper}>
      <img src={zipIcon} alt="" className={styles.zipIcon} />
      <span>{skuName}</span>
    </div>
  );
};

export const ScanCodesZipIconProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={scanCodesZipIconComponent} for={props.for} />;
};

const scanCodesMbComponent = ({ row }) => {
  const { size } = row;

  return size >= 0 && row.state === 2 ? <span>{size} Mb</span> : null;
};

export const ScanCodesMbProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={scanCodesMbComponent} for={props.for} />;
};

const parseCertificateErrors = errors => {
  const parsed = errors
    .replace("duplicates", "")
    .replace("invalidFormat", "")
    .replace(/\]/g, "")
    .replace(/\[/g, "")
    .split(":");
  const duplicatesFormatted = parsed[1].substring(0, parsed[1].length - 1);

  const duplicatesMessage = `При отриманні нових сертифікатів було виявлено дублікати - ${duplicatesFormatted} `;
  // eslint-disable-next-line
  const invalidFormatMessage = `При отриманні нових сертифікатів було виявлено не відповідність формату штрихкоду - ${parsed[2]}`;
  return (
    <div className={styles.textProvider}>
      {duplicatesFormatted && duplicatesMessage}
      <br />
      {parsed[2] && invalidFormatMessage}
    </div>
  );
};

const certificatesStatusProviderComponent = ({ row }) => {
  switch (row.statusId) {
    case 1:
      return <span className={styles.alignment}>Успішно отримано</span>;
    case 2:
      return <span className={styles.alignment}>{parseCertificateErrors(row.payload)}</span>;
    case 3:
      return <span className={styles.alignment}>Немає відповіді від сервера Сільпо</span>;
    case 4:
      return <span className={styles.alignment}>Немає нових сертифікатів</span>;
    case 5:
      return <span className={styles.alignment}>Невідома помилка</span>;
    default:
      return <span className={styles.alignment} />;
  }
};

export const CertificatesStatusProvider: ComponentType<DataTypeProviderProps> = props => {
  return <DataTypeProvider formatterComponent={certificatesStatusProviderComponent} for={props.for} />;
};
