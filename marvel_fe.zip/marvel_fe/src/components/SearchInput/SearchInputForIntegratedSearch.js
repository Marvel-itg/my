// @flow
import React from "react";
import TextField from "@material-ui/core/TextField";
import Search from "@material-ui/icons/Search";
import styles from "./SearchInput.module.scss";

type PropsT = {
  value?: any,
  onValueChange?: Function,
  placeholder: string
};

const textFieldClasses = { root: styles.rootInput };
const InputField = (props: PropsT) => {
  const changeValue = evt => {
    const normalizedValue = evt.target.value.replace(/[^0-9.a-zA-ZА-ЩЬЮЯҐЄІЇа-щьюяґєії\s-'+]/g, "");
    return props.onValueChange && props.onValueChange(normalizedValue);
  };

  return (
    <div className={styles.searchInputWrapper}>
      <TextField
        type="text"
        value={props.value || ""}
        onChange={changeValue}
        placeholder={props.placeholder || "Пошук користувачiв"}
        variant="outlined"
        classes={textFieldClasses}
      />
      <Search className={styles.searchIcon} />
    </div>
  );
};

export default InputField;
