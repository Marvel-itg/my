// @flow
import React from "react";
import TextField from "@material-ui/core/TextField";
import Search from "@material-ui/icons/Search";
import styles from "./SearchInput.module.scss";

type PropsT = {
  value?: any,
  onValueChange?: Function,
  placeholder: string
};

const textFieldClasses = { root: styles.rootInput };
const InputField = (props: PropsT) => {
  const changeValue = evt => {
    const normalizedValue = evt.target.value.replace(/[^0-9a-zA-ZА-ЩЬЮЯЫЪЁЭҐЄІЇа-щьюяыъёэґєії\s-'+]/g, "");
    const value = encodeURIComponent(normalizedValue || "");
    return props.onValueChange && props.onValueChange(value);
  };

  return (
    <div className={styles.searchInputWrapper}>
      <TextField
        type="text"
        value={decodeURIComponent(props.value || "")}
        onChange={changeValue}
        placeholder={props.placeholder || "Пошук користувачiв"}
        variant="outlined"
        classes={textFieldClasses}
      />
      <Search className={styles.searchIcon} />
    </div>
  );
};

export default InputField;
