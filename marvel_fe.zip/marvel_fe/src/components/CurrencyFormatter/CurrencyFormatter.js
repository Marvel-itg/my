// @flow
import React from "react";
import NumberFormat from "react-number-format";
import IconButton from "@material-ui/core/IconButton";
import EditIcon from "@material-ui/icons/Edit";
import CheckIcon from "@material-ui/icons/Check";
import Close from "@material-ui/icons/Close";
import TextField from "@material-ui/core/TextField";
import { withStyles } from "@material-ui/core";

type PropsT = {
  value: string,
  classes: {|
    readableInput: string
  |},
  id: number,
  onSave: Function
};

type StateT = {
  currentMode: string,
  tempValue: string,
  value: string
};

const statuses = ["readable", "editable"];

const maxValue = 10000000;
const isValueLessThanMax = (values: { floatValue: number }) => !(values.floatValue > maxValue);

class CurrencyFormatter extends React.Component<PropsT, StateT> {
  changeMode: Function;
  setValue: Function;

  state = {
    currentMode: statuses[0],
    tempValue: this.props.value || "0.00",
    value: this.props.value || "0.00"
  };

  changeMode = (mode: string) => this.setState({ currentMode: mode });

  setValue = (value: string) => this.setState({ value });

  generateInput = (mode: string) => {
    if (mode === statuses[0]) {
      return (
        <IconButton onClick={() => this.changeMode(statuses[1])}>
          <EditIcon />
        </IconButton>
      );
    } else {
      return (
        <React.Fragment>
          <IconButton onClick={() => this.props.onSave(this.props.id, this.state.value)}>
            <CheckIcon />
          </IconButton>
          <IconButton
            onClick={() => {
              this.setState({
                value: this.state.tempValue
              });
              this.changeMode(statuses[0]);
            }}
          >
            <Close />
          </IconButton>
        </React.Fragment>
      );
    }
  };

  render() {
    return (
      <React.Fragment>
        {this.state.currentMode === statuses[1] ? (
          <NumberFormat
            className={this.props.classes.readableInput}
            value={this.state.value}
            decimalScale={2}
            fixedDecimalScale
            allowEmptyFormatting={false}
            allowNegative={false}
            isAllowed={isValueLessThanMax}
            customInput={TextField}
            onValueChange={({ value }: { value: string }) => this.setValue(value)}
          />
        ) : (
          <TextField className={this.props.classes.readableInput} value={this.state.value} disabled />
        )}
        {this.generateInput(this.state.currentMode)}
      </React.Fragment>
    );
  }
}

export default withStyles(() => ({
  readableInput: {
    verticalAlign: "baseline"
  }
}))(CurrencyFormatter);
