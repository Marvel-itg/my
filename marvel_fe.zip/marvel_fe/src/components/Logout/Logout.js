// @flow
import React from "react";
import { connect } from "react-redux";
import Button from "@material-ui/core/Button";
import LogoutIcon from "@material-ui/icons/ExitToApp";
import styles from "./Logout.module.scss";

import { logout } from "../../store/actions/common/authentication";

type PropsT = {
  logout: Function
};

const logoutIcon = { root: styles.icon };
const buttonClasses = { root: styles.button };
const Logout = (props: PropsT) => (
  <Button aria-label="Logout" onClick={props.logout} color="secondary" classes={buttonClasses}>
    <LogoutIcon classes={logoutIcon} />
    Logout
  </Button>
);

const mapDispatchToProps = { logout };

export default connect(
  null,
  mapDispatchToProps
)(Logout);
