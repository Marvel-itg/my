// @flow
import React from "react";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import Typography from "@material-ui/core/Typography";
import styles from "./RadioGroup.module.scss";

type PropsT = {
  disabled: boolean,
  input: {
    name: string,
    value: any,
    onChange: Function
  },
  meta: any,
  className: string | null,
  required?: boolean,
  options: OptionT[],
  label: string,
  formControlStyle: {},
  handleChange: Function
};

const errorStyle = { root: styles.error };
const formControlStyle = { width: "100%", marginTop: "23px" };
const RadioComponent = <Radio color="primary" />;
const RadioGroupField = (props: PropsT) => {
  const handleChange = (event, value) => (props.handleChange ? props.handleChange(value) : props.input.onChange(value));
  const error = props.meta && props.meta.touched && props.meta.error;
  return (
    <FormControl
      required={props.required}
      component="fieldset"
      disabled={props.disabled}
      style={props.formControlStyle || formControlStyle}
    >
      {props.label && (
        <FormLabel disabled={props.disabled} error={!!error} component="legend">
          {props.label}
        </FormLabel>
      )}
      <RadioGroup
        className={props.className || styles.radioWrapper}
        value={props.input.value.toString()}
        onChange={handleChange}
        aria-label={props.label}
        name={props.input.name}
      >
        {props.options.map(option => (
          <FormControlLabel
            value={option.value.toString()}
            key={option.value.toString()}
            control={RadioComponent}
            label={option.label}
          />
        ))}
      </RadioGroup>
      {error && (
        <Typography color="error" classes={errorStyle}>
          {error}
        </Typography>
      )}
    </FormControl>
  );
};

export default RadioGroupField;
