// @flow
import React from "react";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import { DateFormatProvider, TaskTypeProvider } from "../FormattedData/FormattedData";
import Paper from "@material-ui/core/Paper";
import Button from "@material-ui/core/Button";
import { Grid, Table, TableHeaderRow } from "@devexpress/dx-react-grid-material-ui";

type PropsT = {
  title: string,
  text: string,
  deletingRows: any[],
  rows: any[],
  columns: ColumnsT,
  classes: any,
  tableColumnExtensions: any[],
  cancelDelete: Function,
  deleteRows: Function
};

const forValues = {
  startDate: ["startDate"],
  endDate: ["endDate"],
  taskType: ["taskType"]
};

const DeleteRowDialog = (props: PropsT) => {
  const { title, text, deletingRows, rows, columns, classes, tableColumnExtensions, cancelDelete, deleteRows } = props;
  return (
    <Dialog open={!!deletingRows.length} onClose={cancelDelete} classes={{ paper: classes.dialog }}>
      <DialogTitle>{title}</DialogTitle>
      <DialogContent>
        <DialogContentText>{text}</DialogContentText>
        <Paper>
          <Grid rows={rows && rows.filter(row => deletingRows.indexOf(row.id) > -1)} columns={columns}>
            <DateFormatProvider for={forValues.startDate} />
            <DateFormatProvider for={forValues.endDate} />
            <TaskTypeProvider for={forValues.taskType} />
            <Table columnExtensions={tableColumnExtensions} cellComponent={Table.Cell} />
            <TableHeaderRow />
          </Grid>
        </Paper>
      </DialogContent>
      <DialogActions>
        <Button onClick={cancelDelete} color="primary">
          Відмінити
        </Button>
        <Button onClick={deleteRows} color="secondary">
          Видалити
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeleteRowDialog;
