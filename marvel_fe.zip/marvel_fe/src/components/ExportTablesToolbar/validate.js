import moment from "moment";

export const validate = values => {
  const errors = {};
  if (
    values.startDate &&
    values.endDate &&
    moment(values.endDate).isBefore(moment(values.startDate).format("YYYY-MM-DD"))
  ) {
    errors.endDate = "Введіть корректну дату закінчення";
  }
  return errors;
};
