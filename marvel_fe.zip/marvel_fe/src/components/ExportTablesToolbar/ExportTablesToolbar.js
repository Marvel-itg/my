// @flow
import React from "react";
import { reduxForm, Field } from "redux-form";
import cx from "classnames";
import type { FormProps } from "redux-form";
import InputDatePicker from "../../components/InputField/InputDatePicker";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import OutlinedButton from "../../components/Buttons/OutlinedButton/OutlinedButton";
import UploadButton from "../Buttons/UploadButton/UploadButton";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import Select from "../../components/Select/Select";
import { validate } from "./validate";
import styles from "../../components/ExportTablesToolbar/ExportTablesToolbar.module.scss";

type PropsT = {
  filterData: Function,
  loadHandler?: Function,
  uploadHandler?: Function,
  hasExportButton?: boolean,
  exportButtonColor?: string,
  hasImportButton?: boolean,
  exportButtonLabel?: string,
  importButtonLabel?: string,
  disabled?: boolean,
  errorMessage?: string,
  disableFilterButton?: boolean,
  isClearable?: boolean,
  resetFilterHandler?: Function,
  withoutDateRange?: boolean,
  bulkApproveButtonLabel?: string,
  uploading?: boolean,
  hasBulkApproveButton?: boolean,
  handleBulkApprove?: Function,
  bulkLoading?: boolean,
  isBulkButtonDisabled?: boolean,
  bulkClassName?: string,
  downloadButtonClassName?: string,
  exportButtonColor: string,
  additionalImportButtonLabel?: string,
  hasAdditionalImportButton: boolean,
  additionalUploadHandler?: Function,
  withIssuerSelect?: boolean,
  issuerOptions?: OptionT[],
  onIssuerChange?: Function,
  issuerId?: number,
  withProductSelect?: boolean,
  hasBulkDeactivateButton?: boolean,
  bulkDeactivateHandler?: Function,
  bulkDeactivateClassName?: string,
  bulkDeactivateLabel?: string,
  hasAdditionalBulkApproveButton: boolean,
  additionalBulkApproveButtonLabel?: string,
  additionalBulkApproveButtonColor?: string,
  handleAdditionalBulkApprove?: Function
} & FormProps;

const ExportTablesToolbar = (props: PropsT) => {
  const {
    exportButtonLabel = "Вивантажити CSV",
    exportButtonColor = "primary",
    importButtonLabel = "Завантажити СSV",
    handleSubmit,
    filterData,
    uploading,
    disabled,
    errorMessage,
    disableFilterButton,
    isClearable,
    resetFilterHandler,
    bulkApproveButtonLabel = "Підтвердити обрані запити",
    bulkLoading,
    bulkClassName = "",
    downloadButtonClassName = "",
    isBulkButtonDisabled,
    withoutDateRange = false,
    additionalImportButtonLabel,
    hasAdditionalImportButton,
    withIssuerSelect,
    issuerOptions = [],
    onIssuerChange,
    issuerId,
    withProductSelect,
    productOptions = [],
    hasBulkDeactivateButton,
    bulkDeactivateHandler,
    bulkDeactivateClassName,
    bulkDeactivateLabel
  } = props;
  return (
    <div
      className={cx(styles.toolbarBox, {
        [styles.withoutDateRange]: withoutDateRange && !withIssuerSelect,
        [styles.withIssuerSelect]: withIssuerSelect
      })}
    >
      <div>
        {withIssuerSelect && (
          <Select
            className={styles.issuerSelect}
            id="issuerId"
            component={Select}
            options={issuerOptions}
            onChange={onIssuerChange}
            value={issuerOptions.find(item => item.value === issuerId)}
            placeholder="Компанія"
          />
        )}
        {!withoutDateRange && (
          <form autoComplete="off" noValidate className={styles.reportDateForm} onSubmit={handleSubmit(filterData)}>
            <div>Період</div>
            <div className={cx(styles.dateFieldsBox, { [styles.productFilters]: withProductSelect })}>
              <Field
                className={styles.dateField}
                name="startDate"
                label="Початок"
                maxDate={props.initialValues && props.initialValues.endDate}
                component={InputDatePicker}
              />
              <Field
                className={styles.dateField}
                name="endDate"
                label="Кінець"
                minDate={props.initialValues && props.initialValues.startDate}
                component={InputDatePicker}
              />
              {withProductSelect && (
                <Field
                  className={styles.productSelect}
                  name="productId"
                  label="SKU"
                  placeholder="SKU"
                  component={Select}
                  options={productOptions}
                  isSearchable
                  isClearable
                  classes={{ input: styles.productSelectValue }}
                />
              )}
              <ContainedButton
                type="submit"
                label="Фільтрувати"
                disabled={disableFilterButton}
                className={styles.filterButton}
              />
              {props.hasAdditionalBulkApproveButton && (
                <ContainedButton
                  type="button"
                  color={props.additionalBulkApproveButtonColor}
                  label={props.additionalBulkApproveButtonLabel || ""}
                  className={styles.reportButton}
                  handleClick={props.handleAdditionalBulkApprove}
                  disabled={disabled || uploading}
                  loading={uploading}
                />
              )}
              {isClearable && (
                <OutlinedButton
                  clickHandler={resetFilterHandler}
                  label="Скинути фільтри"
                  className={styles.resetFiltersButton}
                />
              )}
            </div>
          </form>
        )}
      </div>
      <div className={styles.csvButtonsBlock}>
        {props.hasImportButton && (
          <UploadButton
            type="button"
            color="secondary"
            accept=".csv"
            label={importButtonLabel}
            className={styles.downLoadButton}
            handleFiles={props.uploadHandler}
          />
        )}
        {hasAdditionalImportButton && (
          <UploadButton
            type="button"
            color="secondary"
            accept=".csv"
            label={additionalImportButtonLabel}
            className={styles.downLoadButton}
            handleFiles={props.additionalUploadHandler}
          />
        )}
        {props.hasExportButton && (
          <ContainedButton
            type="button"
            color={exportButtonColor}
            label={exportButtonLabel}
            className={cx(styles.downLoadButton, downloadButtonClassName)}
            handleClick={props.loadHandler}
            disabled={disabled || uploading}
            loading={uploading}
          />
        )}
        {props.hasBulkApproveButton && (
          <ContainedButton
            type="button"
            label={bulkApproveButtonLabel}
            className={cx(styles.downLoadButton, bulkClassName)}
            handleClick={props.handleBulkApprove}
            disabled={isBulkButtonDisabled || bulkLoading}
            loading={bulkLoading}
          />
        )}
        {hasBulkDeactivateButton && (
          <UploadButton
            className={bulkDeactivateClassName}
            type="button"
            color="secondary"
            accept=".csv"
            handleFiles={bulkDeactivateHandler}
            label={bulkDeactivateLabel}
          />
        )}
        {errorMessage && (
          <ErrorMessage
            error={errorMessage}
            textAlign="right"
            className={cx(styles.errorMessage, { [styles.errorCertificates]: withIssuerSelect })}
          />
        )}
      </div>
    </div>
  );
};

export default reduxForm({
  form: "dateRangeFilters",
  enableReinitialize: true,
  validate
})(ExportTablesToolbar);
