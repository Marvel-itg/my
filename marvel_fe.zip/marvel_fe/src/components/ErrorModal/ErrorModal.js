// @flow
import React from "react";
import { connect } from "react-redux";
import Modal from "@material-ui/core/Modal/Modal";
import CloseIcon from "@material-ui/icons/Close";
import ErrorMessage from "../ErrorMessage/ErrorMessage";
import { closeErrorModal } from "../../store/actions/common/modals";
import styles from "./ErrorModal.module.scss";

type PropsT = {|
  open: boolean,
  closeErrorModal: Function,
  error: string
|};

const ErrorModal = (props: PropsT) => {
  const { error } = props;
  return (
    <Modal open={props.open} onClose={props.closeErrorModal}>
      <div className={styles.errorsModal}>
        <ErrorMessage error={error} className={styles.errorMessage} />
        <CloseIcon className={styles.closeIcon} onClick={props.closeErrorModal} />
      </div>
    </Modal>
  );
};

const mapStateToProps = ({ modals: { errorModalIsOpened, error } }) => ({ open: errorModalIsOpened, error });
const mapDispatchToProps = {
  closeErrorModal
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ErrorModal);
