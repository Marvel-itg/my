import { emphasize } from "@material-ui/core/styles/colorManipulator";

export const selectStyles = theme => ({
  root: {
    flexGrow: 1,
    height: "auto",
    width: "100%"
  },
  input: {
    display: "flex",
    paddingBottom: "3px"
  },
  inputDisabled: {
    color: "rgba(0, 0, 0, 0.38)"
  },
  valueContainer: {
    display: "flex",
    flex: 1,
    alignItems: "center",
    overflow: "hidden",
    whiteSpace: "nowrap",
    textOverflow: "ellipsis",
    minHeight: "30px"
  },
  chip: {
    margin: `${theme.spacing.unit / 2}px ${theme.spacing.unit / 4}px`
  },
  chipFocused: {
    backgroundColor: emphasize(theme.palette.type === "light" ? theme.palette.grey[300] : theme.palette.grey[700], 0.08)
  },
  noOptionsMessage: {
    padding: `${theme.spacing.unit}px ${theme.spacing.unit * 2}px`
  },
  singleValue: {
    fontSize: 16
  },
  paper: {
    position: "absolute",
    zIndex: 10000,
    marginTop: theme.spacing.unit,
    left: 0,
    right: 0
  },
  indicatorsContainer: {
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    color: theme.palette.secondary.contrastText
  }
});

export const blueSelectStyles = theme => {
  return {
    root: {
      flexGrow: 1,
      color: "#fff"
    },
    input: {
      paddingBottom: "3px",
      background: theme.palette.primary.main,
      borderRadius: 4,
      color: "#fff",
      base: {
        "&:before": {
          display: "none"
        },
        "&:after": {
          display: "none"
        }
      }
    },
    placeholder: {
      color: "white"
    },
    inputDisabled: {
      color: "rgba(0, 0, 0, 0.38)"
    },
    valueContainer: {
      display: "flex",
      flexWrap: "wrap",
      flex: 1,
      alignItems: "center",
      overflow: "hidden",
      color: "#fff"
    },
    chip: {
      margin: `${theme.spacing.unit / 2}px ${theme.spacing.unit / 4}px`
    },
    chipFocused: {
      backgroundColor: emphasize(
        theme.palette.type === "light" ? theme.palette.grey[300] : theme.palette.grey[700],
        0.08
      )
    },
    noOptionsMessage: {
      padding: `${theme.spacing.unit}px ${theme.spacing.unit * 2}px`
    },
    singleValue: {
      fontSize: "14px",
      color: "#fff"
    },
    paper: {
      position: "absolute",
      zIndex: 1000,
      marginTop: theme.spacing.unit,
      left: 0,
      right: 0
    },
    option: {
      fontSize: 14
    },
    indicatorsContainer: {
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      color: "#fff"
    }
  };
};

export const greySelectStyles = theme => {
  return {};
};
