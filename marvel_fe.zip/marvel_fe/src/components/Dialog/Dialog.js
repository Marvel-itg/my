// @flow
import React from "react";
import Dialog from "@material-ui/core/Dialog/Dialog";
import DialogContent from "@material-ui/core/DialogContent/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogActions from "@material-ui/core/DialogActions/DialogActions";
import CircularProgress from "@material-ui/core/CircularProgress/CircularProgress";
import Button from "@material-ui/core/Button/Button";
import { connect } from "react-redux";
import { Field, reduxForm } from "redux-form";
import { compose } from "redux";
import { classes } from "../../helpers/spinner";

type PropsT = {
  content: any,
  onCancelClick: Function,
  onConfirmClick?: Function,
  onClose: Function,
  handleSubmit: Function,
  confirmButtonType?: string,
  open: boolean,
  submitForm?: Function,
  fullWidth: boolean,
  withForm?: boolean,
  title: string,
  spinner: boolean,
  fieldProps: Object
};

const DialogComponent = (props: PropsT) => {
  const renderDialogContent = () => (
    <>
      <DialogTitle>{props.title}</DialogTitle>
      <DialogContent>
        <Field {...props.fieldProps} />
      </DialogContent>
      <DialogActions>
        <Button onClick={props.onCancelClick} color="primary">
          Вiдмiна
        </Button>
        <Button
          type={props.withForm ? "submit" : props.confirmButtonType || "button"}
          onClick={props.onConfirmClick}
          color="primary"
        >
          Пiдтвердити
        </Button>
      </DialogActions>
    </>
  );

  return (
    <Dialog open={props.open} onClose={props.onClose} fullWidth={props.fullWidth} aria-labelledby="scroll-dialog-title">
      <>
        {props.spinner && <CircularProgress classes={classes} />}
        <form onSubmit={props.submitForm && props.handleSubmit(props.submitForm)}>{renderDialogContent()}</form>
      </>
    </Dialog>
  );
};

function mapStateToProps(state, { initialValues }) {
  return {
    initialValues
  };
}

export default compose(
  connect(mapStateToProps),
  reduxForm({
    form: "fieldDialogForm",
    enableReinitialize: true
  })
)(DialogComponent);
