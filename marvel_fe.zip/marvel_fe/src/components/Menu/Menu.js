// @flow
import React from "react";
import cx from "classnames";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import ArrowDropDown from "@material-ui/icons/ArrowDropDown";
import ArrowDropUp from "@material-ui/icons/ArrowDropUp";
import get from "lodash/get";

import PopupState, { bindTrigger, bindMenu } from "material-ui-popup-state/index";

import styles from "./Menu.module.scss";

type PropsT = {
  changeRole: Function,
  panelName: string,
  accountType: number
};

type StateT = {
  menuItems: {
    role: string,
    label: string,
    selected: boolean
  }[]
};

const classesMenu = { paper: styles.menu };
const menuItemClasses = { root: styles.menuItem };

class AdminPanelsMenu extends React.Component<PropsT, StateT> {
  state = {
    menuItems: [
      // {
      //   role: "super-admin",
      //   label: "Супер Адмін",
      //   selected: false
      // },
      {
        role: "sales",
        label: "Додаток для продавців",
        selected: false
      },
      {
        role: "promoters",
        label: "Додаток для промоутерів",
        selected: true
      }
    ]
  };

  selectItem = (role: string) => {
    const items = [...this.state.menuItems];
    const selectedItem = items.find(item => item.role === role);
    items.map(item => (item.selected = item === selectedItem));
    this.setState({ menuItems: items });
  };

  componentDidMount() {
    const portal = get(this, "props.history.location.pathname").split("/")[1];
    this.selectItem(portal);
  }

  render() {
    const { changeRole, panelName, accountType } = this.props;
    const { menuItems } = this.state;
    return accountType === 1 ? (
      <PopupState variant="popper" popupId="popup-menu">
        {popupState => (
          <React.Fragment>
            <div {...bindTrigger(popupState)} className={cx(styles.selected, styles.cursor)}>
              <span>{panelName}</span>
              <span className={styles.iconWrapper}>{popupState.isOpen ? <ArrowDropUp /> : <ArrowDropDown />}</span>
            </div>
            <Menu {...bindMenu(popupState)} disableAutoFocusItem classes={classesMenu}>
              {menuItems.map(({ role, label, selected }) => (
                <MenuItem
                  key={role}
                  classes={menuItemClasses}
                  selected={selected}
                  onClick={() => {
                    changeRole(role);
                    this.selectItem(role);
                    popupState.close();
                  }}
                >
                  {label}
                </MenuItem>
              ))}
            </Menu>
          </React.Fragment>
        )}
      </PopupState>
    ) : (
      <div className={styles.selected}>{panelName}</div>
    );
  }
}

export default AdminPanelsMenu;
