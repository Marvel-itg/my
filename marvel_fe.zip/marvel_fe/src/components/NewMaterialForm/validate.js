import moment from "moment";
import { validationErrorMessages } from "../../constants";

const validate = values => {
  const { required } = validationErrorMessages();
  const errors = {};

  if (!values.material || !values.material.length) {
    errors.material = required;
  }
  if (!values.startDate) {
    errors.startDate = required;
  }
  if (!values.endDate) {
    errors.endDate = required;
  }

  if (values.startDate && values.endDate && moment(values.endDate).isBefore(values.startDate, "day")) {
    errors.endDate = "Введіть корректну дату закінчення";
  }

  if ((!values.geos || !values.geos.length) && !values.allGeos) {
    errors.geos = required;
  }

  if (!values.roleIds || !values.roleIds.length) {
    errors.roleIds = required;
  }

  return errors;
};

export default validate;
