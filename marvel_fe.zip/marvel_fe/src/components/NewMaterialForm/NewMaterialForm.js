// @flow
import * as React from "react";
import { connect } from "react-redux";
import { compose } from "redux";
import { withRouter } from "react-router-dom";
import { reduxForm, Field, formValueSelector, change } from "redux-form";
import type { FormProps } from "react-redux";
import moment from "moment";
import FormLabel from "@material-ui/core/FormLabel";
import CircularProgress from "@material-ui/core/CircularProgress";
import ContainedButton from "../Buttons/ContainedButton/ContainedButton";
import FormGroup from "@material-ui/core/FormGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import AsyncCitiesSelect from "../../components/Select/AsyncCitiesSelect.js";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import SelectWithFixedOptions from "../../components/Select/SelectWithFixedOptions";
import InputDatePicker from "../../components/InputField/InputDatePicker";
import InputFileMultiple from "../InputFileMultiple/InputFileMultiple";
import { getMaterialData, addNewMaterial, editMaterial } from "../../store/actions/promoters/materialsList";
import { initialValuesSelector } from "../../store/selectors/promoters/materials";
import { getCommonParams } from "../../helpers/common";
import { accessOptions } from "../../constants";
import { formatFormValues } from "../../IOsPromoters/ListOfMaterials/helpers";
import validate from "./validate";
import styles from "./NewMaterialForm.module.scss";
import { classes } from "../../helpers/spinner";

type PropsT = {
  getMaterialData: Function,
  addNewMaterial: Function,
  editMaterial: Function,
  id: number | null
} & FormProps;

const CustomCheckbox = props => {
  return (
    <FormGroup row>
      <FormControlLabel
        control={
          <Checkbox color="primary" {...props.input} checked={props.input.value === "true"} disabled={props.disabled} />
        }
        label={props.label}
      />
    </FormGroup>
  );
};

class NewMaterialForm extends React.Component<PropsT> {
  componentDidMount() {
    const { id } = this.props;
    if (id) {
      this.props.getMaterialData(this.props.id);
    }
  }

  componentDidUpdate = prevProps => {
    if (!prevProps.allGeos && this.props.allGeos) {
      this.props.change("geos", []);
    }
  };

  submitForm = values => {
    const { id } = this.props;
    const { tab } = getCommonParams(this.props.location.search);
    const formattedValues = formatFormValues(values);
    id
      ? this.props.editMaterial({ ...formattedValues, id, status: 1 }, tab)
      : this.props.addNewMaterial(formattedValues, tab);
  };

  render() {
    const { errorMessage, loading, id } = this.props;

    const formTitle = id ? "Редагувати матерiал" : "Додати матерiал";
    const buttonLabel = id ? "Редагувати" : "Додати";
    const { tab } = getCommonParams(this.props.location.search);
    const notEditedField = tab === "1" && Boolean(id) ? true : false;
    const today = moment().format("YYYY-MM-DD");

    return loading ? (
      <CircularProgress classes={classes} />
    ) : (
      <form autoComplete="off" onSubmit={this.props.handleSubmit(this.submitForm)}>
        <div className={styles.formTitle}>{formTitle}</div>
        <Field
          name="material"
          component={InputFileMultiple}
          id="material"
          disabled={Boolean(id)}
          required
          uploadType="material"
        />
        <FormLabel component="legend" className={styles.formLabel}>
          Період активності:
        </FormLabel>
        <div className={styles.datesWrapper}>
          <Field
            required
            name="startDate"
            label="Дата старту"
            component={InputDatePicker}
            className={styles.inputHalfField}
            minDate={today}
            disabled={notEditedField}
          />
          <Field
            required
            name="endDate"
            label="Дата завершення"
            component={InputDatePicker}
            className={styles.inputHalfField}
            minDate={today}
          />
        </div>

        <FormLabel className={styles.formLabel} component="legend">
          Населені пункти
        </FormLabel>
        <Field
          name="allGeos"
          label="Всі населені пункти"
          component={CustomCheckbox}
          format={value => (value ? "true" : "false")}
        />
        <Field
          required
          name="geos"
          withoutRegions
          placeholder="Виберіть населені пункти"
          className={styles.inputField}
          component={AsyncCitiesSelect}
          disabled={this.props.allGeos}
          geoType={5}
          isMulti
        />
        <Field name="roleIds" component={SelectWithFixedOptions} options={accessOptions} />
        <ContainedButton
          label={buttonLabel}
          disabled={this.props.invalid}
          type="submit"
          className={styles.createButton}
        />
        {errorMessage && <ErrorMessage error={errorMessage} />}
      </form>
    );
  }
}

const mapStateToProps = state => {
  const {
    materialsList: { formError, loadingMaterial }
  } = state;
  const selector = formValueSelector("newMaterialForm");
  const allGeos = selector(state, "allGeos");
  const initialValues = initialValuesSelector(state);
  return {
    initialValues,
    allGeos,
    loading: loadingMaterial,
    errorMessage: formError
  };
};

const mapDispatchToProps = {
  change,
  getMaterialData,
  editMaterial,
  addNewMaterial
};

const Form = reduxForm({
  form: "newMaterialForm",
  validate,
  enableReinitialize: true,
  keepDirtyOnReinitialize: true
})(NewMaterialForm);

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(Form);
