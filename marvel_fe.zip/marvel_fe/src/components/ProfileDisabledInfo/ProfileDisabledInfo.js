// @flow
import React from "react";
import { Field } from "redux-form";
import InputField from "../InputField/InputField";

type PropsT = {};

const ProfileDisabledInfo = (props: PropsT) => {
  return (
    <>
      <Field name="status" label="Статус" component={InputField} disabled />
      <Field name="createdBy" component={InputField} disabled />
      <Field name="createdAt" label="Коли створено" component={InputField} disabled />
    </>
  );
};

export default ProfileDisabledInfo;
