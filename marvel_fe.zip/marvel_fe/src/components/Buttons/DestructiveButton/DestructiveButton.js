// @flow
import React from "react";
import Button from "@material-ui/core/Button/Button";
import cx from "classnames";
import styles from "./DestructiveButton.module.scss";

type PropsT = {
  label: string,
  disabled?: boolean,
  className?: string,
  handleClick: Function
};

const DestructiveButton = (props: PropsT) => {
  const { label = "", disabled = false, className = "", handleClick } = props;
  return (
    <Button
      variant="contained"
      classes={{
        root: cx(styles.buttonStyle, className, disabled && styles.disableStyle),
        label: styles.labelStyle
      }}
      disabled={disabled}
      onClick={handleClick}
    >
      {label}
    </Button>
  );
};

export default DestructiveButton;
