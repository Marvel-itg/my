// @flow
import React from "react";
import Button from "@material-ui/core/Button/Button";
import KeyboardBackspaceIcon from "@material-ui/icons/KeyboardBackspace";
import cx from "classnames";
import styles from "./BackButton.module.scss";

type PropsT = {
  label: string,
  handleClick: Function,
  className?: string,
  disabled?: boolean
};

const BackButton = (props: PropsT) => {
  const { label, handleClick, disabled } = props;
  return (
    <Button
      className={cx(styles.transparentButton, props.className)}
      color="primary"
      disabled={disabled}
      onClick={handleClick}
    >
      <KeyboardBackspaceIcon className={styles.iconStyles} />
      {label}
    </Button>
  );
};

export default BackButton;
