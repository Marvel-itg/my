// @flow
import React from "react";
import Button from "@material-ui/core/Button/Button";
import CircularProgress from "@material-ui/core/CircularProgress";
import cx from "classnames";
import styles from "./ContainedButton.module.scss";
import { classes } from "../../../helpers/spinner";

type PropsT = {|
  label: string,
  type?: string,
  component?: string,
  disabled?: boolean,
  className?: string,
  handleClick?: Function,
  color?: string,
  onClick?: Function,
  classes?: string,
  loading?: boolean
|};

const ContainedButton = (props: PropsT) => {
  const {
    label = "",
    type = "button",
    disabled = false,
    className = "",
    handleClick,
    color,
    component = "button",
    loading = false
  } = props;

  return (
    <Button
      variant="contained"
      component={component}
      color={color || "primary"}
      type={type}
      classes={{
        root: cx(styles.buttonStyle, className),
        label: styles.labelStyle
      }}
      disabled={disabled}
      onClick={handleClick}
    >
      {loading && <CircularProgress classes={classes} size={20} />}
      {label}
    </Button>
  );
};

export default ContainedButton;
