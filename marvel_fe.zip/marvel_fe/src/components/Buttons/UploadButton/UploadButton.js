// @flow
import React, { Component } from "react";
import uniqueId from "lodash/uniqueId";
import CloudUploadIcon from "@material-ui/icons/CloudUpload";
import ImageIcon from "@material-ui/icons/Image";
import CloseIcon from "@material-ui/icons/Close";
import cx from "classnames";
import ContainedButton from "../ContainedButton/ContainedButton";
import styles from "./UploadButton.module.scss";

type StateT = {
  files: any[]
};

type PropsT = {
  accept: string,
  filesWrapperStyles?: Object,
  label?: string,
  className?: Object,
  color?: string,
  isMultiple?: boolean,
  handleFiles: Function
};

class UploadButton extends Component<PropsT, StateT> {
  state = {
    files: []
  };

  handleChange = (evt: SyntheticEvent<HTMLInputElement>) => {
    const filesArray = evt.currentTarget.files;
    const newFiles = [filesArray].map(item => {
      return { ...item, uid: uniqueId() };
    });
    const files = this.props.isMultiple ? [...this.state.files, ...newFiles] : [...newFiles];
    this.setState({ files }, () => {
      this.props.isMultiple ? this.props.handleFiles(this.state.files) : this.props.handleFiles(this.state.files[0][0]);
    });
  };

  handleDeleteUploadedFile = (evt: SyntheticEvent<HTMLButtonElement>, uid: string) => {
    evt.preventDefault();
    const files = this.state.files.filter(file => file.uid !== uid);
    this.setState({ files });
  };

  render() {
    const id = uniqueId();
    const { label, filesWrapperStyles, color, isMultiple } = this.props;
    const acceptRegex = new RegExp(`${this.props.accept}$`);
    return (
      <div>
        <input
          accept={this.props.accept}
          id={id}
          type="file"
          style={{ display: "none" }}
          multiple={isMultiple}
          onChange={this.handleChange}
          // onClick handler below allows to upload the same file two and more times
          onClick={event => {
            event.target.value = null;
          }}
        />
        {isMultiple && this.state.files.filter(file => acceptRegex.test(file[0].name)).length ? (
          <div className={cx(styles.filesWrapper, filesWrapperStyles)}>
            {this.state.files.map(file => (
              <div className={styles.fileWrapper} key={file.uid}>
                <span className={styles.fileNameWrapper}>
                  <ImageIcon />
                  <span className={styles.fileName}>{file[0].name}</span>
                </span>
                <CloseIcon onClick={evt => this.handleDeleteUploadedFile(evt, file.uid)} />
              </div>
            ))}
            <label className={styles.uploadLabel} htmlFor={id}>
              <CloudUploadIcon />
              <span>Upload</span>
            </label>
          </div>
        ) : (
          <label htmlFor={id}>
            <ContainedButton
              className={this.props.className}
              color={color || "primary"}
              component="span"
              label={label || "Upload"}
            />
          </label>
        )}
      </div>
    );
  }
}

export default UploadButton;
