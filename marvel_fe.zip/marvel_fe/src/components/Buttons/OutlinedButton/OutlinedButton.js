// @flow
import React from "react";
import cx from "classnames";
import Button from "@material-ui/core/Button/Button";
import styles from "./OutlinedButton.module.scss";

type PropsT = {
  label: string,
  type?: string,
  disabled?: boolean,
  clickHandler?: Function,
  className?: string,
  color?: string
};

const OutlinedButton = (props: PropsT) => {
  const { label, type = "button", disabled = false, clickHandler, color = "primary", className = "" } = props;
  return (
    <Button
      variant="outlined"
      color={color}
      type={type}
      classes={{ root: cx(styles.buttonStyle, className) }}
      disabled={disabled}
      onClick={clickHandler}
    >
      {label}
    </Button>
  );
};

export default OutlinedButton;
