// @flow
import React from "react";
import OutlinedButton from "../OutlinedButton/OutlinedButton";
import cx from "classnames";
import styles from "./DeteButton.module.scss";

type PropsT = {
  label?: string,
  type?: string,
  disabled?: boolean,
  clickHandler?: Function,
  className?: Object,
  color?: string
};

const DeleteButton = (props: PropsT) => {
  return (
    <OutlinedButton label={props.label || "Видалити"} className={cx(styles.deleteButton, props.className)} {...props} />
  );
};

export default DeleteButton;
