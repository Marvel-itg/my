import React, { useState, useEffect } from "react";
import cx from "classnames";
import { Editor } from "react-draft-wysiwyg";
import draftToHtml from "draftjs-to-html";
import htmlToDraft from "html-to-draftjs";
import { EditorState, convertToRaw, ContentState } from "draft-js";
import Typography from "@material-ui/core/Typography";
import styles from "./EditorComponent.module.scss";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";

const typographyStyle = { root: styles.error };

const EditorComponent = props => {
  const getInitialState = () => {
    const contentBlock = htmlToDraft(props.input.value);
    const contentState = ContentState.createFromBlockArray(contentBlock.contentBlocks);
    const editorState = EditorState.createWithContent(contentState);
    return editorState;
  };
  const initialState = getInitialState();
  const [editorState, setEditorState] = useState(initialState);

  useEffect(() => {
    const currentState = draftToHtml(convertToRaw(editorState.getCurrentContent()));
    if (currentState !== props.input.value) {
      setEditorState(getInitialState());
    }
  }, [props.input.value]);

  const onEditorStateChange = values => {
    setEditorState(values);
    changeValue(values);
  };

  const changeValue = editorState => {
    const value = draftToHtml(convertToRaw(editorState.getCurrentContent()));
    props.input.onChange(value);
  };

  const error = props.meta.touched && props.meta.error;
  return (
    <>
      <Editor
        editorState={editorState}
        editorClassName={styles.editorStyles}
        toolbarClassName={styles.toolbarStyles}
        wrapperClassName={cx(styles.wrapperClassName, { [styles.editorError]: !!error })}
        onEditorStateChange={onEditorStateChange}
        onBlur={props.input.onBlur}
        toolbar={{
          options: ["inline", "list"],
          inline: {
            options: ["bold", "italic", "underline"]
          },
          list: { options: ["unordered", "ordered"] }
        }}
      />

      {error && (
        <Typography color="error" classes={typographyStyle}>
          {error}
        </Typography>
      )}
    </>
  );
};

export default EditorComponent;
