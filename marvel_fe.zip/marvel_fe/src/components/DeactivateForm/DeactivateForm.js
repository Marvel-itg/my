// @flow
import React from "react";
import { Field, reduxForm } from "redux-form";
import type { FormProps } from "redux-form";
import { connect } from "react-redux";
import Button from "@material-ui/core/Button";
import DestructiveButton from "../Buttons/DestructiveButton/DestructiveButton";
import InputField from "../../components/InputField/InputField";
import { commentFieldValidation } from "../../utils/reduxFormValidation";
import { normalizeLength } from "../../utils/reduxFormNormalizers";
import styles from "./DeactivateForm.module.scss";
import ErrorMessage from "../ErrorMessage/ErrorMessage";

type PropsT = {
  title: string,
  legendText: string,
  textFieldLabel: string,
  textFieldName: string,
  submitButtonText: string,
  cancelButtonText: string,
  cancelButtonHandler: Function,
  errorState: Object => string,
  errorMessage: string,
  submitForm: Function,
  disabled?: boolean
} & FormProps;

class DeactivateForm extends React.Component<PropsT> {
  render() {
    const {
      handleSubmit,
      submitForm,
      title,
      textFieldLabel,
      textFieldName,
      submitButtonText,
      cancelButtonText,
      cancelButtonHandler,
      valid,
      errorMessage,
      noCommentField,
      isButtonDisabled
    } = this.props;
    return (
      <form onSubmit={handleSubmit(submitForm)} className={styles.formWrapper}>
        <div className={styles.formTitle}>{title}</div>
        {!noCommentField && (
          <Field
            name={textFieldName}
            component={InputField}
            multiline
            label={textFieldLabel}
            validate={[commentFieldValidation]}
            normalize={normalizeLength(250)}
          />
        )}
        {errorMessage && <ErrorMessage textAlign="left" error={errorMessage} />}
        <div className={styles.buttonsWrapper}>
          <Button onClick={cancelButtonHandler} color="primary" disabled={isButtonDisabled}>
             {cancelButtonText}
          </Button>
          <DestructiveButton
            disabled={!valid || isButtonDisabled}
            label={submitButtonText}
            className={styles.button}
            handleClick={handleSubmit(submitForm)}
          />
        </div>
      </form>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    errorMessage: ownProps.errorState(state),
    isButtonDisabled: ownProps.disableButtonState && ownProps.disableButtonState(state)
  };
};

export default connect(mapStateToProps)(reduxForm()(DeactivateForm));
