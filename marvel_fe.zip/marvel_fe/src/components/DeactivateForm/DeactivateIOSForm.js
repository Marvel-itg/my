// @flow
import React from "react";
import { Field, reduxForm } from "redux-form";
import type { FormProps } from "redux-form";
import { connect } from "react-redux";
import type { BrowserHistory } from "history";
import Button from "@material-ui/core/Button";
import DestructiveButton from "../Buttons/DestructiveButton/DestructiveButton";
import InputField from "../InputField/InputField";
import ChiefsSelect from "../../components/Select/ChiefsSelect";
import { commentFieldValidation, requireNewChief } from "../../utils/reduxFormValidation";
import { normalizeLength } from "../../utils/reduxFormNormalizers";
import ErrorMessage from "../ErrorMessage/ErrorMessage";
import { replacingAccounts } from "../../api/promoters/teamMember";
import styles from "./DeactivateForm.module.scss";

type PropsT = {
  title: string,
  legendText: string,
  textFieldLabel: string,
  textFieldName: string,
  submitButtonText: string,
  cancelButtonText: string,
  cancelButtonHandler: Function,
  errorState: Object => string,
  errorMessage: string,
  submitForm: Function
} & FormProps &
  BrowserHistory;

type StateT = {
  defaultOptions: any[]
};

class DeactivateIOSForm extends React.Component<PropsT, StateT> {
  state = {
    defaultOptions: []
  };

  async componentDidMount() {
    const { targetAccountId, accountType, memberType } = this.props;
    const params = {
      TargetAccountId: targetAccountId,
      CurrentAccountType: accountType
    };
    const defaultOptions = await replacingAccounts(memberType, params);
    this.setState({ defaultOptions });
  }

  render() {
    const {
      handleSubmit,
      submitForm,
      title,
      textFieldLabel,
      textFieldName,
      submitButtonText,
      cancelButtonText,
      cancelButtonHandler,
      valid,
      errorMessage,
      targetAccountId
    } = this.props;
    const { defaultOptions } = this.state;
    return (
      <form onSubmit={handleSubmit(submitForm)} className={styles.formWrapper}>
        <div className={styles.formTitle}>{title}</div>
        <Field
          required
          name="responsibleManager"
          placeholder="Оберіть відповідальну особу"
          options={defaultOptions}
          component={ChiefsSelect}
          validate={[requireNewChief]}
        />
        <Field
          required
          name={textFieldName}
          component={InputField}
          multiline
          label={textFieldLabel}
          validate={[commentFieldValidation]}
          normalize={normalizeLength(250)}
        />
        {errorMessage && <ErrorMessage textAlign="left" error={errorMessage} />}
        <div className={styles.buttonsWrapper}>
          <Button onClick={cancelButtonHandler} color="primary">
             {cancelButtonText}
          </Button>
          <DestructiveButton
            disabled={!valid}
            label={submitButtonText}
            className={styles.button}
            handleClick={handleSubmit(values => submitForm(values, targetAccountId))}
          />
        </div>
      </form>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  const {
    authenticationReducer: {
      user: { accountType }
    }
  } = state;
  return {
    errorMessage: ownProps.errorState(state),
    accountType
  };
};

export default connect(mapStateToProps)(reduxForm()(DeactivateIOSForm));
