//@flow
import React from "react";
import type { FormProps } from "redux-form";
import Checkbox from "@material-ui/core/Checkbox";
import FormGroup from "@material-ui/core/FormGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";

type PropsT = {
  label: string
} & FormProps;

const CustomCheckbox = (props: PropsT) => {
  return (
    <FormGroup row>
      <FormControlLabel
        control={
          <Checkbox
            color="primary"
            {...props.input}
            value={String(props.input.value)}
            checked={props.input.value === "true" || props.input.value === true}
          />
        }
        label={props.label}
      />
    </FormGroup>
  );
};

export default CustomCheckbox;
