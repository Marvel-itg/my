// @flow
import React from "react";
import { connect } from "react-redux";
import Modal from "@material-ui/core/Modal/Modal";
import CloseIcon from "@material-ui/icons/Close";
import { closeSuccessModal } from "../../store/actions/common/modals";
import styles from "./SuccessModal.module.scss";

type PropsT = {|
  open: boolean,
  closeSuccessModal: Function
|};

const SuccessModal = (props: PropsT) => {
  return (
    <Modal open={props.open} onClose={props.closeSuccessModal}>
      <div className={styles.successModal}>
        <CloseIcon className={styles.closeIcon} onClick={props.closeSuccessModal} />
        <div>Успішно!</div>
      </div>
    </Modal>
  );
};

const mapStateToProps = ({ modals: { successModalIsOpened } }) => ({ open: successModalIsOpened });
const mapDispatchToProps = {
  closeSuccessModal
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SuccessModal);
