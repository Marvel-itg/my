import React from "react";
import IconButton from "@material-ui/core/IconButton";
import DeleteIcon from "@material-ui/icons/Delete";
import EditIcon from "@material-ui/icons/Edit";
import SaveIcon from "@material-ui/icons/Save";
import SaveAltIcon from "@material-ui/icons/SaveAlt";
import CancelIcon from "@material-ui/icons/Cancel";

export const SaveButton = ({ onExecute }) => (
  <IconButton onClick={onExecute} title="Вивантажити матерiал">
    <SaveAltIcon />
  </IconButton>
);

export const EditButton = ({ onExecute }) => (
  <IconButton onClick={onExecute} title="Редагувати матерiал">
    <EditIcon />
  </IconButton>
);

export const DeleteButton = ({ onExecute }) => (
  <IconButton onClick={onExecute} title="Видалити матерiал">
    <DeleteIcon />
  </IconButton>
);

export const CommitButton = ({ onExecute }) => (
  <IconButton onClick={onExecute} title="Зберегти змiни">
    <SaveIcon />
  </IconButton>
);

export const CancelButton = ({ onExecute }) => (
  <IconButton color="secondary" onClick={onExecute} title="Вiдмiнити змiни">
    <CancelIcon />
  </IconButton>
);
