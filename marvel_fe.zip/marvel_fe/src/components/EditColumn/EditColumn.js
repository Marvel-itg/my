// @flow
import React from "react";
import { Getter } from "@devexpress/dx-react-core";
import cx from "classnames";
import { memoize } from "lodash";
import { TableEditRow, TableEditColumn } from "@devexpress/dx-react-grid-material-ui";
import OutlinedButton from "../Buttons/OutlinedButton/OutlinedButton";
import { SaveButton, EditButton, DeleteButton, CommitButton, CancelButton } from "../EditColumn/EditColumnButtons";
import styles from "./EditColumn.module.scss";

type PropsT = {
  toolsList?: any[],
  width: number,
  onAddButtonClick?: Function,
  classNames?: string,
  cellComponent?: any
};

const AddButton = props => {
  const { onAddButtonClick, classNames } = props.props;

  return <OutlinedButton label="Додати" className={cx(styles.addButton, classNames)} clickHandler={onAddButtonClick} />;
};

const commandComponents = {
  save: SaveButton,
  edit: EditButton,
  delete: DeleteButton,
  commit: CommitButton,
  add: AddButton,
  cancel: CancelButton
};

const CommandVisibilityMap = {
  showEditCommand: "edit",
  showSaveCommand: "save",
  showAddCommand: "add",
  showDeleteCommand: "delete"
};

const EditCell = props => {
  return <TableEditRow.Cell {...props} />;
};

const ColumnEditCell = props => {
  return <TableEditColumn.Cell {...props} disabled className={props.row.disabled ? "disabled" : ""} />;
};

export const EditColumn = (props: PropsT) => {
  const { toolsList, cellComponent } = props;
  const visibilityProps = {};
  for (const key in CommandVisibilityMap) {
    const flag = toolsList ? toolsList.includes(CommandVisibilityMap[key]) : true;
    visibilityProps[key] = flag;
  }

  const Command = ({ id, onExecute }) => {
    const CommandButton = commandComponents[id];
    return <CommandButton props={props} onExecute={onExecute} />;
  };

  return (
    <TableEditColumn
      width={props.width}
      showEditCommand={visibilityProps.showEditCommand}
      showSaveCommand={visibilityProps.showSaveCommand}
      showAddCommand={visibilityProps.showAddCommand}
      showDeleteCommand={visibilityProps.showDeleteCommand}
      cellComponent={cellComponent || ColumnEditCell}
      commandComponent={Command}
    />
  );
};

export const EditRow = () => <TableEditRow cellComponent={EditCell} />;

type ColumnOrder = {
  order: number
};

const computedFn = memoize(order => ({ tableColumns }) => {
  const noEditColumns = tableColumns.filter(column => column.type !== TableEditColumn.COLUMN_TYPE);
  const editColumn = tableColumns.find(column => column.type === TableEditColumn.COLUMN_TYPE);

  const nthColumn = [...noEditColumns.slice(0, order - 1)];
  const otherColumns = [...noEditColumns.slice(order - 1)];

  const result = [
    ...nthColumn,
    {
      key: "editCommand",
      type: TableEditColumn.COLUMN_TYPE,
      width: editColumn.width || 140
    },
    ...otherColumns
  ];
  return result;
});

export const EditColumnOrder = (props: ColumnOrder) => {
  const { order } = props;
  return <Getter name="tableColumns" computed={computedFn(order)} />;
};
