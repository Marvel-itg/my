// @flow
import React, { useState } from "react";
import { ChromePicker } from "react-color";
import InputField from "../InputField/InputField";
import styles from "./ColorPicker.module.scss";

type PropsT = {
  input: {
    name: string,
    onChange: Function,
    value: any
  },
  meta: any,
  className: string | null,
  disabled: boolean,
  multiline: ?boolean,
  inputProps: any,
  label?: string,
  type?: string,
  required?: boolean,
  value: any,
  variant?: string
};

const converters = {
  rgba: value => `rgba(${value.rgb.r}, ${value.rgb.g}, ${value.rgb.b}, ${value.rgb.a})`,
  rgb: value => `rgb(${value.rgb.r}, ${value.rgb.g}, ${value.rgb.b})`,
  hex: value => value.hex,

  rgba_hex: value => (value.rgb.a === 1 ? converters.hex(value) : converters.rgba(value))
};

const ColorPicker = ({ input, ...props }: PropsT) => {
  const [showPicker, setShowPicker] = useState(false);

  const handleChange = data => {
    input.onChange(data);
  };

  return (
    <>
      <div className={styles.inputWrapper} onClick={() => setShowPicker(!showPicker)}>
        <InputField input={{ ...input, value: input.value, onChange: data => handleChange(data) }} {...props} />
        <div className={styles.colorDemo} style={{ background: input.value || "#000" }} />
      </div>

      {showPicker && (
        <div className={styles.popover}>
          <div className={styles.cover} onClick={() => setShowPicker(false)} />
          <ChromePicker color={input.value} onChange={data => handleChange(converters.rgba_hex(data))} />
        </div>
      )}
    </>
  );
};

export default ColorPicker;
