// @flow

import React from "react";
import EditIcon from "@material-ui/icons/Edit";
import IconButton from "@material-ui/core/IconButton";
import { compose } from "redux";
import { connect } from "react-redux";
import { closeFieldDialog, openFieldDialog } from "../../store/actions/common/modals";
import styles from "./EditableFieldWithDialog.module.scss";

type PropsT = {
  modalContent: any,
  userId: string,
  handleConfirm: Function,
  handleSubmit: Function,
  onConfirmClick: Function,
  initialValues: Object,
  valuesWrapper?: string,
  updated: boolean,
  updating: boolean,
  updatingError: boolean,
  editComponent: Object,
  children: any,
  dialogTitle: string,
  editing: boolean,
  edited: boolean,
  submittingError: ?string,
  openFieldDialog: Function,
  closeFieldDialog: Function,
  initialValue: string,
  fieldProps: Object,
  name: string,
  disabled: boolean
};

type StateT = {
  spinner: boolean
};

const iconButtonStyle = { root: styles.editSmall };

class EditableFieldWithModal extends React.Component<PropsT, StateT> {
  state = {
    spinner: this.props.editing //TODO ADD UPDATING/RECEIVING etc
  };

  openDialog = () => {
    const { dialogTitle, fieldProps, openFieldDialog, closeFieldDialog, initialValue, name } = this.props;
    const { spinner } = this.state;
    const dialogProps = {
      title: dialogTitle,
      onClose: closeFieldDialog,
      spinner,
      onCancelClick: closeFieldDialog,
      fullWidth: true,
      fieldProps,
      initialValues: { [`field_${name}`]: initialValue }
    };
    openFieldDialog(dialogProps);
  };

  render() {
    return (
      <div className={styles.root}>
        <IconButton onClick={this.openDialog} color="primary" classes={iconButtonStyle} disabled={this.props.disabled}>
          <EditIcon fontSize="small" />
        </IconButton>
        {this.props.children}
      </div>
    );
  }
}

const mapDispatchToProps = {
  openFieldDialog,
  closeFieldDialog
};

export default compose(connect(null, mapDispatchToProps))(EditableFieldWithModal);
