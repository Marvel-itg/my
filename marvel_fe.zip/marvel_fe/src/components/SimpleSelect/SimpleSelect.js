// @flow
import React from "react";
import Select from "@material-ui/core/Select";
import FormControl from "@material-ui/core/FormControl";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import Chip from "@material-ui/core/Chip";
import styles from "./Select.module.scss";

const selectConfig = {
  city: {
    placeholder: "Мiсто",
    id: "city",
    options: [
      { value: "Харкiв", label: "Харкiв" },
      { value: "Львiв", label: "Львiв" },
      { value: "Мерефа", label: "Мерефа" }
    ]
  },
  projects: {
    placeholder: "Проекти",
    id: "projects",
    multiple: true,
    options: [
      { value: "Роздріб", label: "Роздріб" },
      { value: "ХоРеКа", label: "ХоРеКа" },
      { value: "Сезонні проекти", label: "Сезонні проекти" }
    ]
  },
  sizeTop: {
    placeholder: "Верх",
    id: "sizeTop",
    options: [
      { value: "XS", label: "XS" },
      { value: "S", label: "S" },
      { value: "M", label: "M" },
      { value: "XL", label: "XL" },
      { value: "XXl", label: "XXL" }
    ]
  },
  sizeBottom: {
    placeholder: "Низ",
    id: "sizeBottom",
    options: [
      { value: "XS", label: "XS" },
      { value: "S", label: "S" },
      { value: "M", label: "M" },
      { value: "XL", label: "XL" },
      { value: "XXl", label: "XXL" }
    ]
  },

  sizeShoes: {
    placeholder: "Розмiр взуття",
    id: "sizeShoes",
    options: [
      { value: "36", label: "36" },
      { value: "37", label: "37" },
      { value: "38", label: "38" },
      { value: "39", label: "39" },
      { value: "40", label: "40" },
      { value: "41", label: "41" },
      { value: "42", label: "42" },
      { value: "43", label: "43" },
      { value: "44", label: "44" },
      { value: "45", label: "45" },
      { value: "46", label: "46" }
    ]
  },
  supervisor: {
    placeholder: "Cупервайзер",
    id: "supervisor",
    options: [
      { value: "Ivan Ivanov", label: "Ivan Ivanov" },
      { value: "Luka Lukich", label: "Luka Lukich" },
      { value: "Soso Pavliashvili", label: "Soso Pavliashvili" }
    ]
  },
  status: {
    placeholder: "Статус",
    id: "status",
    options: [
      { value: "Постійний штат", label: "Постійний штат" },
      { value: "Резерв", label: "Резерв" },
      { value: "Кандидидат", label: "Кандидидат" }
    ]
  }
};

const renderValueFunction = (selected: any[]) => (
  <div>
    {selected.map(value => (
      <Chip key={value} label={value} />
    ))}
  </div>
);

type PropsT = {
  disabled: boolean,
  input: {
    name: string,
    onChange: Function,
    value: any
  },
  className: string
};

const InputSelect = (props: PropsT) => {
  const { name } = props.input;
  const isMultiple = selectConfig[name].multiple;

  const handleChange = event => {
    props.input.onChange(event.target.value);
  };

  return (
    <FormControl disabled={props.disabled} classes={{ root: props.className }}>
      <InputLabel htmlFor={selectConfig[name].id}>{selectConfig[name].placeholder}</InputLabel>
      <Select
        {...props.input}
        multiple={isMultiple}
        renderValue={isMultiple ? renderValueFunction : null}
        onChange={handleChange}
        value={isMultiple ? props.input.value || [] : props.input.value}
        {...selectConfig[name]}
      >
        {isMultiple ? "" : <MenuItem value="" />}

        {selectConfig[name].options.map(item => {
          return (
            <MenuItem classes={isMultiple && { selected: styles.selectedField }} key={item.value} value={item.value}>
              {item.label}
            </MenuItem>
          );
        })}
      </Select>
    </FormControl>
  );
};

export default InputSelect;
