// @flow
import cx from "classnames";
import React from "react";
import Switch from "@material-ui/core/Switch";
import FormLabel from "@material-ui/core/FormLabel";
import styles from "./Switch.module.scss";

type PropsT = {
  label?: string,
  input?: {
    name: string,
    onChange: Function,
    value: any
  },
  onChange: Function,
  className?: string,
  disabled?: boolean,
  checked?: boolean
};
const CustomSwitch = ({ label = "Залежність питання", input, onChange, disabled, checked, className }: PropsT) => {
  return (
    <FormLabel>
      <div className={cx(styles.switch, className)}>
        <span className={styles.label}>{label}</span>
        <Switch
          color="primary"
          {...input}
          onChange={onChange ? onChange : input && input.onChange}
          checked={checked || (input && input.value)}
          disabled={disabled}
        />
      </div>
    </FormLabel>
  );
};

export default CustomSwitch;
