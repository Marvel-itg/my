// @flow
import React from "react";
import { Template } from "@devexpress/dx-react-core";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";

type PropsT = {
  activeTab: string | number,
  changeTab: Function,
  tabs: TabT[],
  children?: any
};

const TabsHeader = (props: PropsT) => (
  <Template name="toolbarContent">
    <Tabs value={props.activeTab} indicatorColor="primary" textColor="primary" onChange={props.changeTab}>
      {props.tabs.map(({ label, value }) => (
        <Tab label={label} key={label} value={value} />
      ))}
    </Tabs>
    {props.children}
  </Template>
);
export default TabsHeader;
