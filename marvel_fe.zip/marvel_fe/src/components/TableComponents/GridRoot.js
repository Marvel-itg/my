import React from "react";
import { Grid } from "@devexpress/dx-react-grid-material-ui";

const style = { height: "100%" };
const GridRoot = props => <Grid.Root {...props} style={style} />;

export default GridRoot;
