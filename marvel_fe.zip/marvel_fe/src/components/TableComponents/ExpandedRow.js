import React from "react";
import { TableRowDetail } from "@devexpress/dx-react-grid-material-ui";

const ExpandedRow = props => <TableRowDetail.Row className="expandedTableRow" style={{ height: "auto" }} {...props} />;

export default ExpandedRow;
