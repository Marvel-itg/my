import React from "react";
import { TableHeaderRow } from "@devexpress/dx-react-grid-material-ui";

const styles = {
  whiteSpace: "normal",
  wordWrap: "break-word"
};

const HeaderWrap = ({ style, ...props }) => {
  return <TableHeaderRow.Cell style={styles} {...props} />;
};

export default HeaderWrap;
