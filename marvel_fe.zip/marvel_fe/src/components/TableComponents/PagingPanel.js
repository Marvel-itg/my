// @flow
import React, { Fragment } from "react";
import { PagingPanel } from "@devexpress/dx-react-grid-material-ui";

type PropsT = {
  pageSizes: number[],
  noData: boolean
};

const PaginationPanel = ({ pageSizes, noData }: PropsT) => (
  <Fragment>{noData ? <div /> : <PagingPanel pageSizes={pageSizes} />}</Fragment>
);
export default PaginationPanel;
