import React from "react";
import { Table } from "@devexpress/dx-react-grid-material-ui";

const TableContainerComponent = ({ style, ...props }) => <Table.Container {...props} style={{ flex: 1, ...style }} />;

export default TableContainerComponent;
