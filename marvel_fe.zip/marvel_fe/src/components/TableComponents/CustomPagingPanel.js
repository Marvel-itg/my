import React from "react";
import { PagingPanel } from "@devexpress/dx-react-grid-material-ui";

const CustomPagingPanel = ({ rowsAmount, pageSize, ...rest }) => props => {
  const totalPages = Math.ceil(rowsAmount / pageSize);
  return <PagingPanel.Container {...props} {...rest} totalCount={rowsAmount} totalPages={totalPages} />;
};

export default CustomPagingPanel;
