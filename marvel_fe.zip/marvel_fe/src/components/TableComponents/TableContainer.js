import React from "react";
import { Table } from "@devexpress/dx-react-grid-material-ui";

const TableContainer = ({ style, ...props }) => <Table.Container {...props} style={{ height: "100%", ...style }} />;

export default TableContainer;
