import React from "react";
import { withStyles } from "@material-ui/core/styles";
import get from "lodash/get";
import cx from "classnames";
import { Toolbar } from "@devexpress/dx-react-grid-material-ui";

const styles = {
  customToolbar: {
    display: "flex",
    alignItems: "flex-end"
  }
};

const ToolbarRootBase = ({ classes, className, ...restProps }) => (
  <Toolbar.Root className={cx(className, get(classes, "customToolbar", null))} {...restProps} />
);

const ToolbarRoot = withStyles(styles)(ToolbarRootBase);

export const ToolBarRootStyled = className => props => ToolbarRootBase({ ...props, className });

export default ToolbarRoot;
