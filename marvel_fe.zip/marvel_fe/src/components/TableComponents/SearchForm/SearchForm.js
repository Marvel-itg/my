// @flow
import * as React from "react";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import cx from "classnames";
import Select from "../../Select/Select";
import SearchInput from "../../SearchInput/SearchInput";
import { onFieldChange, onSearchChange } from "../../../helpers/common";
import styles from "./SearchForm.module.scss";

type PropsT = {
  selectOptions: OptionT[],
  placeholder: string,
  className?: string
} & BrowserHistory;

const SearchForm = (props: PropsT) => {
  const { selectOptions, placeholder, className } = props;
  const params = new URLSearchParams(props.location.search);
  const searchValue = params.get("searchValue") || "";
  const searchFieldValue = params.get("searchField");
  const searchField = selectOptions.find(option => option.value === searchFieldValue);

  const onSearchValueChange = value => {
    if (searchValue !== value) {
      return onSearchChange(value, props.location.search, props.history, props.location.state);
    }
  };

  const onSearchFieldChange = searchField => {
    return onFieldChange(searchField.value, props.location.search, props.history, props.location.state);
  };

  const formHeaderClass = props.toolbarIconOff ? styles.searchHeaderDefault : styles.searchHeader;

  return (
    <form className={cx(formHeaderClass, className)} autoComplete="off" noValidate>
      <Select
        className={styles.selectSearchType}
        id="searchBy"
        component={Select}
        options={selectOptions}
        onChange={onSearchFieldChange}
        value={searchField}
        placeholder="Пошук за параметром"
      />
      <SearchInput onValueChange={onSearchValueChange} value={searchValue} placeholder={placeholder} />
    </form>
  );
};

export default withRouter(SearchForm);
