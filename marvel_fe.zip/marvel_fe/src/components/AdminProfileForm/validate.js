import { validationErrorMessages } from "../../constants";

const validate = values => {
  const { required } = validationErrorMessages();
  const errors = {};

  if (!values.firstName) {
    errors.firstName = required;
  }
  if (!values.lastName) {
    errors.lastName = required;
  }
  if (!values.middleName) {
    errors.middleName = required;
  }
  if (!values.phone) {
    errors.phone = required;
  } else if (values.phone.length < 9) {
    errors.phone = "Введіть корректний номер телефону";
  }
  return errors;
};

export default validate;
