// @flow
import React from "react";
import { connect } from "react-redux";
import { compose } from "redux";
import { reduxForm, Field } from "redux-form";
import type { FormProps } from "redux-form";
import ContainedButton from "../Buttons/ContainedButton/ContainedButton";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import InputField from "../InputField/InputField";
import validate from "./validate";
import { normalizeCyrillicName, phoneMask } from "../../utils/reduxFormNormalizers";
import { formatInitialPhone } from "../../utils/formatValues";
import styles from "./AdminProfileForm.module.scss";

type PropsT = {
  submitForm: Function,
  changeMode: Function,
  editMode: boolean,
  isEditing: boolean,
  errorMessage: string,
  formTitle: string,
  invalid: boolean
} & FormProps;

const AdminProfileForm = (props: PropsT) => {
  const { handleSubmit, submitForm, changeMode, editMode, isEditing, formTitle, invalid, errorMessage } = props;
  return (
    <form autoComplete="off" noValidate onSubmit={handleSubmit(submitForm)} className={styles.newSupervisorFormWrapper}>
      {!editMode && <div className={styles.formTitle}>{formTitle}</div>}
      <Field
        required
        name="lastName"
        component={InputField}
        className={styles.inputField}
        normalize={normalizeCyrillicName}
        disabled={editMode && !isEditing}
      />
      <Field
        required
        name="firstName"
        component={InputField}
        className={styles.inputField}
        normalize={normalizeCyrillicName}
        disabled={editMode && !isEditing}
      />
      <Field
        required
        name="middleName"
        component={InputField}
        className={styles.inputField}
        normalize={normalizeCyrillicName}
        disabled={editMode && !isEditing}
      />
      <Field
        required
        name="phone"
        component={InputField}
        type="tel"
        className={styles.inputField}
        disabled={editMode && !isEditing}
        {...phoneMask}
      />
      {editMode &&
        (isEditing ? (
          <ContainedButton type="submit" disabled={invalid} label="Зберегти" className={styles.editButton} />
        ) : (
          <ContainedButton type="button" label="Редагувати" className={styles.editButton} handleClick={changeMode} />
        ))}
      {!editMode && (
        <>
          <ContainedButton disabled={invalid} type="submit" label="Додати" className={styles.createButton} />
          {errorMessage && <ErrorMessage error={errorMessage} />}
        </>
      )}
      {errorMessage && <ErrorMessage error={errorMessage} />}
    </form>
  );
};

const mapStateToProps = (state, ownProps) => {
  const phone = ownProps.info ? formatInitialPhone(ownProps.info.phone) : "";

  return {
    initialValues: { ...ownProps.info, phone }
  };
};

export default compose(
  connect(mapStateToProps),
  reduxForm({
    validate,
    form: "newAdminForm",
    enableReinitialize: true,
    keepDirtyOnReinitialize: true
  })
)(AdminProfileForm);
