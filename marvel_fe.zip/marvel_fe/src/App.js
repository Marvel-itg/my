// @flow
import React from "react";
import { Route, Switch, Redirect } from "react-router-dom";
import { ConnectedRouter } from "connected-react-router";
import { MuiThemeProvider, createMuiTheme } from "@material-ui/core/styles";
import AuthorizationPage from "./containers/AuthorizationPage/AuthorizationPage";
import NotFoundPage from "./containers/NotFoundPage/NotFoundPage";
import AdminPanel from "./containers/AdminPanel/AdminPanel";
import { MuiPickersUtilsProvider } from "material-ui-pickers";
import PrivacyPolicyAndroid from "./components/PrivacyPolicyAndroid/PrivacyPolicyAndroid";
import PrivacyPolicyIOS from "./components/PrivacyPolicyIOS/PrivacyPolicyIOS";
import DateFnsUtils from "@date-io/date-fns";
import ukLocale from "date-fns/locale/uk";
import { history } from "./store/configureStore";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";

const theme = createMuiTheme({
  typography: {
    useNextVariants: true
  },
  palette: {
    primary: {
      main: "#003a70",
      contrastText: "#2b2b2b"
    },
    secondary: {
      main: "#4a90e2",
      contrastText: "#5c5c5c"
    },
    error: {
      main: "#d50000"
    }
  }
});

const ProtectedRoute = ({ component: Component, ...rest }) => (
  <Route
    {...rest}
    render={props => (sessionStorage.getItem("accessToken") ? <Component {...props} /> : <Redirect to="/login" />)}
  />
);
class App extends React.PureComponent<{}> {
  render() {
    return (
      <MuiThemeProvider theme={theme}>
        <MuiPickersUtilsProvider utils={DateFnsUtils} locale={ukLocale}>
          <DndProvider backend={HTML5Backend}>
            <ConnectedRouter history={history}>
              <Switch>
                <Route path="/login" component={AuthorizationPage} />
                <Route path="/privacy-policy-android" component={PrivacyPolicyAndroid} />
                <Route path="/privacy-policy-ios" component={PrivacyPolicyIOS} />
                <Route path="/404" component={NotFoundPage} />
                <ProtectedRoute path="/" component={AdminPanel} />
              </Switch>
            </ConnectedRouter>
          </DndProvider>
        </MuiPickersUtilsProvider>
      </MuiThemeProvider>
    );
  }
}

export default App;
