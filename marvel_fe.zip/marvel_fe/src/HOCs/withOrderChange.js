// @flow
import React, { useRef } from "react";
import { DragSourceMonitor, useDrag, useDrop } from "react-dnd";

interface DragItem {
  index: number;
  type: string;
}

const style = {
  cursor: "move"
};

type PropsT = {
  moveComponent: Function,
  itemType: ItemTypesT,
  sectionId?: number,
  index: number,
  endMovement: Function
};

const withOrderChange = (WrappedComponent: Object) => ({
  moveComponent,
  itemType,
  sectionId,
  endMovement,
  ...props
}: PropsT) => {
  const ref = useRef(null);
  const [{ handlerId }, drop] = useDrop({
    accept: itemType,
    collect(monitor) {
      return {
        handlerId: monitor.getHandlerId(),
        canDrop: monitor.canDrop()
      };
    },
    hover(item: DragItem, monitor) {
      if (!ref.current) {
        return;
      }
      const dragIndex: number = item.index;
      const hoverIndex: number = props.index;
      if (dragIndex === hoverIndex) {
        return;
      }
      const hoverBoundingRect = ref.current.getBoundingClientRect();
      const hoverMiddleY = (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;
      const clientOffset = monitor.getClientOffset();
      const hoverClientY = clientOffset.y - hoverBoundingRect.top;
      if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
        return;
      }
      if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
        return;
      }
      moveComponent(dragIndex, hoverIndex);
      item.index = hoverIndex;
    }
  });

  const [{ isDragging }, drag, preview] = useDrag({
    type: itemType,
    item: { props, index: props.index },
    collect: (monitor: DragSourceMonitor) => ({
      isDragging: monitor.isDragging()
    }),
    end: (item, monitor) => {
      endMovement();
    }
  });

  drag(drop(ref));
  const opacity = isDragging ? 0.5 : 1;
  return (
    <WrappedComponent
      {...props}
      moveComponent={moveComponent}
      endMovement={endMovement}
      // $FlowFixMe
      ref={{ ref, preview }}
      style={{ ...style, opacity }}
      data-handler-id={handlerId}
      isDraggingBlock={isDragging}
    />
  );
};

export default withOrderChange;
