// @flow

import React from "react";
export default function withStickyBandsTable(WrappedComponent: Object) {
  type StateT = {
    cssNodes: any[]
  };
  return class extends React.Component<any, StateT> {
    addStickyStyles = () => {
      let previousRowHeight = 0;
      document.querySelectorAll("thead tr").forEach((row, index) => {
        let css = document.createElement("style");
        css.type = "text/css";
        css.innerHTML = `thead>tr${"~tr".repeat(
          index
        )} th { top: ${previousRowHeight}px!important}`;
        css.className = "sticky-styles";
        document.body && document.body.appendChild(css);
        previousRowHeight += row.offsetHeight;
      });
    };

    removeStickyStyles = () => {
      document
        .querySelectorAll(".sticky-styles")
        .forEach(style => style.remove());
    };
    componentDidMount() {
      this.addStickyStyles();
    }

    componentWillUnmount() {
      this.removeStickyStyles();
    }

    render() {
      return <WrappedComponent {...this.props} />;
    }
  };
}
