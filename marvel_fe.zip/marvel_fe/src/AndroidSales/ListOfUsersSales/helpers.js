// @flow
import isEmpty from "lodash/isEmpty";
import { formatDate } from "../../utils/formatValues";

export const formatInitialValues = (data: UserProfileT) => {
  if (!isEmpty(data)) {
    const phone = data.phone && data.phone.substr(4);
    const registrationDate = data.registrationDate && formatDate(data.registrationDate);
    const registeredBy = data.registeredBy && data.registeredBy.fullName;
    const initialValues = {
      ...data,
      phone,
      registeredBy,
      registrationDate
    };
    return initialValues;
  } else {
    const minBirthDate = new Date(new Date().setFullYear(new Date().getFullYear() - 18));
    return { birthday: minBirthDate };
  }
};
