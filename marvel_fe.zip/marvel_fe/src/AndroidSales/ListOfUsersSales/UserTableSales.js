// @flow
import React from "react";
import { Grid, TableHeaderRow, Table, Toolbar } from "@devexpress/dx-react-grid-material-ui";
import {
  PhoneProvider,
  ButtonProvider,
  TransparentButtonProvider,
  GenderProvider,
  PositionProvider,
  DateFormatProvider,
  DestructiveButtonProvider,
  CityProvider,
  ListProvider
} from "../../components/FormattedData/FormattedData";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import ToolbarRoot from "../../components/TableComponents/ToolbarRoot";
import GridRoot from "../../components/TableComponents/GridRoot";
import TableContainerComponent from "../../components/TableComponents/TableContainerComponent";
import PagingPanel from "../../components/TableComponents/PagingPanel";
import TabsHeader from "../../components/TableComponents/TabsHeader";
import SearchForm from "../../components/TableComponents/SearchForm/SearchForm";
import { defaultItemsPerPage, availableItemsPerPage, listOfSalesUsersOptions } from "../../constants";

type PropsT = {
  data: UserT[],
  tabs: TabT[],
  columns: ColumnT[],
  changeTab: Function,
  activeTab: string,
  activate: Function,
  page: number,
  count: number,
  total: number,
  defaultHiddenColumnNames?: any[],
  changeCurrentPage: Function,
  changePageSize: Function,
  changeTab: Function,
  openDeactivateModal: Function,
  openDetails: Function
};

const forValues = {
  phone: ["phone"],
  birthday: ["birthday"],
  activate: ["activate"],
  deactivate: ["deactivate"],
  details: ["details"],
  gender: ["gender"],
  position: ["position"],
  posCodes: ["posCodes"],
  tradeRepresentative: ["tradeRepresentative"],
  registrationDate: ["registrationDate"],
  city: ["city"],
  lastActivity: ["lastActivity"],
  approve: ["approve"],
  decline: ["decline"]
};

export const columnExtensions = [
  { columnName: "id", width: 69 },
  { columnName: "lastName", width: 200 },
  { columnName: "firstName", width: 200 },
  { columnName: "middleName", width: 200 },
  { columnName: "birthday", width: 150 },
  { columnName: "itn", width: 150 },
  { columnName: "phone", width: 200 },
  { columnName: "position", width: 150 },
  { columnName: "gender", width: 150 },
  { columnName: "comment", width: 200 },
  { columnName: "city", width: 350 },
  { columnName: "posCodes", width: 150 },
  { columnName: "tradeRepresentative", width: 250 },
  { columnName: "registrationDate", width: 150 },
  { columnName: "details", width: 200 },
  { columnName: "activate", width: 200 },
  { columnName: "deactivate", width: 200 },
  { columnName: "lastActivity", width: 170 },
  { columnName: "approve", width: 170 },
  { columnName: "decline", width: 170 }
];

const UserTableSales = (props: PropsT) => {
  const {
    columns,
    data,
    activate,
    activeTab,
    tabs,
    page,
    count,
    total,
    changeCurrentPage,
    changePageSize,
    changeTab,
    openDeactivateModal,
    openDetails
  } = props;

  return (
    <Grid rows={data} columns={columns} rootComponent={GridRoot}>
      <PagingState
        currentPage={page || 0}
        onCurrentPageChange={changeCurrentPage}
        pageSize={count || defaultItemsPerPage}
        onPageSizeChange={changePageSize}
      />
      <CustomPaging totalCount={total} />
      <PhoneProvider for={forValues.phone} />
      <DateFormatProvider for={forValues.birthday} />
      <DateFormatProvider for={forValues.registrationDate} />
      <DateFormatProvider for={forValues.lastActivity} dateAndTimeWithSeconds />
      <ButtonProvider for={forValues.activate} onClick={activate} label="Активувати" />
      <DestructiveButtonProvider for={forValues.deactivate} onClick={openDeactivateModal} label="Деактивувати" />
      <ButtonProvider for={forValues.approve} onClick={activate} label="Підтвердити" />
      <DestructiveButtonProvider for={forValues.decline} onClick={openDeactivateModal} label="Відхилити" />
      <TransparentButtonProvider for={forValues.details} onClick={openDetails} label="Деталі профілю" />
      <GenderProvider for={forValues.gender} />
      <PositionProvider for={forValues.position} />
      <CityProvider for={forValues.city} />
      <ListProvider for={forValues.posCodes} />
      <ListProvider for={forValues.tradeRepresentative} />
      <Table height="auto" columnExtensions={columnExtensions} containerComponent={TableContainerComponent} />
      <TableHeaderRow />
      <Toolbar rootComponent={ToolbarRoot} />
      <TabsHeader changeTab={changeTab} activeTab={activeTab} tabs={tabs || []} />
      <PagingPanel pageSizes={availableItemsPerPage} noData={!total} />
      <SearchForm selectOptions={listOfSalesUsersOptions} placeholder="Пошук" />
    </Grid>
  );
};

export default UserTableSales;
