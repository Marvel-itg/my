// @flow
import React from "react";
import { connect } from "react-redux";
import type { BrowserHistory } from "history";
import debounce from "es6-promise-debounce";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import SalesForm from "./SalesForm/SalesForm";
import UserTableSales from "./UserTableSales";
import Modal from "../../components/Modal/Modal";
import ConfirmModal from "../../components/Modal/ConfirmModal";
import DeactivateForm from "../../components/DeactivateForm/DeactivateForm";
import Toolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import {
  receiveUsers,
  activateUser,
  deactivateUser,
  importOnlineUsersBonusesCSV,
  deactivateOnlineUsersCSV,
  forceLogoutUsers,
  exportCSVUsersReport
} from "../../store/actions/sales/userListSales";
import { usersListSelector, errorState, importCSVErrorSelector } from "../../store/selectors/sales/listOfUsers";
import { openModal, closeModal } from "../../store/actions/common/modals";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  changeTab,
  getCommonParams,
  shouldNotSendRequest
} from "../../helpers/common";
import { classes } from "../../helpers/spinner";
import styles from "./ListOfUsersSales.module.scss";

type PropsT = {
  receiveUsers: Function,
  usersList: UserT[],
  activateUser: Function,
  approveUser: Function,
  declineUser: Function,
  deactivateUser: Function,
  isEdit: boolean,
  submitted: boolean,
  loading: boolean,
  openModal: Function,
  closeModal: Function,
  total: number,
  forceLogoutUsers: Function,
  forceLogoutError: string | null,
  exportingReport: boolean,
  exportingError: string | null
} & BrowserHistory;

type StateT = {
  modalType: string,
  modalBody: any,
  formName: string
};

const tabs = [
  { label: "Активні", value: "3" },
  { label: "Деактивовані", value: "4" },
  { label: "Очікують на підтверження", value: "1" }
];

const columns = {
  "3": [
    { name: "id", title: "ID" },
    { name: "lastName", title: "Прiзвище" },
    { name: "firstName", title: "Ім'я" },
    { name: "middleName", title: "По батьковi" },
    { name: "birthday", title: "Дата народження" },
    { name: "phone", title: "Номер телефону" },
    { name: "itn", title: "ІНН" },
    { name: "position", title: "Посада" },
    { name: "gender", title: "Стать" },
    { name: "city", title: "Населений пункт" },
    { name: "posCodes", title: "Код ТТ" },
    { name: "tradeRepresentative", title: "ТП, що зареєстрував" },
    { name: "registrationDate", title: "Дата реєстрації" },
    { name: "lastActivity", title: "Дата останньої активності" },
    { name: "details", title: "Деталі профілю" },
    { name: "deactivate", title: "Деактивувати" }
  ],
  "4": [
    { name: "id", title: "ID" },
    { name: "lastName", title: "Прiзвище" },
    { name: "firstName", title: "Ім'я" },
    { name: "middleName", title: "По батьковi" },
    { name: "birthday", title: "Дата народження" },
    { name: "phone", title: "Номер телефону" },
    { name: "itn", title: "ІНН" },
    { name: "position", title: "Посада" },
    { name: "gender", title: "Стать" },
    { name: "comment", title: "Коментар" },
    { name: "city", title: "Населений пункт" },
    { name: "posCodes", title: "Код ТТ" },
    { name: "tradeRepresentative", title: "ТП, що зареєстрував" },
    { name: "registrationDate", title: "Дата реєстрації" },
    { name: "lastActivity", title: "Дата останньої активності" },
    { name: "details", title: "Деталі профілю" },
    { name: "activate", title: "Активувати" }
  ],
  "1": [
    { name: "id", title: "ID" },
    { name: "lastName", title: "Прiзвище" },
    { name: "firstName", title: "Ім'я" },
    { name: "middleName", title: "По батьковi" },
    { name: "birthday", title: "Дата народження" },
    { name: "phone", title: "Номер телефону" },
    { name: "itn", title: "ІНН" },
    { name: "position", title: "Посада" },
    { name: "gender", title: "Стать" },
    { name: "city", title: "Населений пункт" },
    { name: "posCodes", title: "Код ТТ" },
    { name: "tradeRepresentative", title: "ТП, що зареєстрував" },
    { name: "registrationDate", title: "Дата реєстрації" },
    { name: "approve", title: "Підтвердити" },
    { name: "decline", title: "Відхилити" }
  ]
};

class ListOfUsersSales extends React.Component<PropsT, StateT> {
  state = {
    modalType: "",
    modalBody: <div />,
    formName: ""
  };

  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key },
      errorsList,
      forceLogoutError
    } = this.props;

    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }

    if (prevProps.errorsList !== errorsList && errorsList && errorsList.length) {
      this.openModal("showErrors");
    }

    if (prevProps.forceLogoutError !== forceLogoutError && forceLogoutError) {
      this.openModal("forceLogoutError");
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changeTab = (event: any, tab: string) => changeTab(tab, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  fetchData = debounce(() => {
    const { searchFieldName, searchValue, itemsOnPage, pageNumber, tab: status } = getCommonParams(
      this.props.location.search
    );
    let params = { itemsOnPage, pageNumber, status };
    if (searchValue) {
      params = { ...params, searchField: searchFieldName, searchValue };
    }
    this.props.receiveUsers(params);
  }, 200);

  submitDeactivateForm = (values, userId) => {
    const { tab } = getCommonParams(this.props.location.search);
    this.props.deactivateUser({ ...values, userId, tab });
  };

  openDetails = (id: any) => {
    this.props.history.push(`/sales/list-of-online-users/${id}`);
  };

  openDeactivateModal = id => this.openModal("deactivate", id);

  openForceLogout = () => this.openModal("forceLogout");

  forceLogout = () => {
    this.props.closeModal();
    this.props.forceLogoutUsers();
  };

  openModal = (type, id) => {
    switch (type) {
      case "add": {
        const modalBody = <SalesForm />;
        this.setState({ modalBody, modalType: "", formName: "salesUserForm" });
        return this.props.openModal();
      }
      case "deactivate": {
        const modalBody = (
          <DeactivateForm
            form="DeactivateSalesUser"
            submitForm={values => this.submitDeactivateForm(values, id)}
            title="Деактивувати користувача?"
            textFieldLabel="Додати коментар"
            textFieldName="comment"
            submitButtonText="Деактивувати"
            cancelButtonText="Ні"
            cancelButtonHandler={this.props.closeModal}
            errorState={errorState}
          />
        );
        this.setState({ modalBody, modalType: "deactivate", formName: "" });
        return this.props.openModal();
      }
      case "showErrors": {
        const modalBody =
          this.props.errorsList.length > 1 ? (
            <ul>
              {this.props.errorsList.map((error, index) => (
                <li key={index}>{error}</li>
              ))}
            </ul>
          ) : (
            <div>{this.props.errorsList[0]}</div>
          );

        this.setState({ modalBody, modalType: "errorsModal", formName: "" });
        return this.props.openModal();
      }

      case "forceLogout": {
        const modalBody = (
          <ConfirmModal
            open={true}
            onClose={this.props.closeModal}
            onCancel={this.props.closeModal}
            onConfirm={this.forceLogout}
            question="Ви дiйсно бажаєте зробити примусовий вихід для усіх продавців з Андроід додатку?"
          />
        );

        this.setState({ modalBody, modalType: "deactivate", formName: "" });
        return this.props.openModal();
      }

      case "forceLogoutError": {
        const modalBody = <div> {this.props.forceLogoutError}</div>;
        this.setState({ modalBody, modalType: "errorsModal", formName: "" });
        return this.props.openModal();
      }

      default:
        return null;
    }
  };

  importCSV = csv => {
    this.props.importOnlineUsersBonusesCSV(csv);
  };

  deactivateUsersCSV = csv => {
    this.props.deactivateOnlineUsersCSV(csv);
  };

  activateUser = id => {
    const { tab } = getCommonParams(this.props.location.search);
    this.props.activateUser(id, tab);
  };

  render() {
    const { page, count } = getPaginationConfig(this.props.location.search);
    const { tab } = getCommonParams(this.props.location.search);
    const showToolbar = this.props.user && this.props.user.accountType === 1 && tab === "3"; // superAdmin, tab "active users"
    const showDownloadReportButton = this.props.user && this.props.user.accountType !== 1 && tab === "3";
    return (
      <React.Fragment>
        {showToolbar && (
          <React.Fragment>
            <Toolbar
              hasImportButton
              uploadHandler={this.importCSV}
              uploading={this.props.exportingReport}
              loadHandler={this.props.exportCSVUsersReport}
              hasExportButton
              exportButtonLabel="Звіт продавці"
              hasBulkApproveButton
              handleBulkApprove={this.openForceLogout}
              bulkApproveButtonLabel="Bимушений вихід"
              isBulkButtonDisabled={this.props.forceLogoutLoading}
              withoutDateRange
              errorMessage={this.props.exportError}
              hasBulkDeactivateButton
              bulkDeactivateHandler={this.deactivateUsersCSV}
              bulkDeactivateClassName={styles.bulkDeactivateUsersCsv}
              bulkDeactivateLabel="Деактивувати користувачiв"
            />
          </React.Fragment>
        )}
        {showDownloadReportButton && (
          <React.Fragment>
            <Toolbar
              uploading={this.props.exportingReport}
              loadHandler={this.props.exportCSVUsersReport}
              hasExportButton
              exportButtonLabel="Звіт продавці"
              withoutDateRange
              errorMessage={this.props.exportError}
            />
          </React.Fragment>
        )}
        <Paper square className="mainContent">
          <UserTableSales
            data={this.props.usersList || []}
            activeTab={tab || "3"}
            columns={columns[tab || "3"]}
            changeTab={this.changeTab}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            openDetails={this.openDetails}
            activate={this.activateUser}
            openDeactivateModal={this.openDeactivateModal}
            tabs={tabs}
            page={page}
            count={count}
            total={this.props.total}
          />
          {this.props.loading && <CircularProgress classes={classes} />}
        </Paper>
        <Modal formName={this.state.formName} type={this.state.modalType}>
          {this.state.modalBody}
        </Modal>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    usersListSales: {
      submitting,
      receiving,
      activating,
      deactivating,
      bulkDeactivating,
      bulkDeactivateError,
      total,
      forceLogoutError,
      forceLogoutLoading,
      exportingReport,
      exportError
    },
    authenticationReducer: { user }
  } = state;
  return {
    usersList: usersListSelector(state),
    loading: receiving || submitting || deactivating || activating || bulkDeactivating || exportingReport,
    total,
    user,
    errorsList: importCSVErrorSelector(state),
    forceLogoutError,
    forceLogoutLoading,
    bulkDeactivateError,
    exportError,
    exportingReport
  };
};

const mapDispatchToProps = {
  receiveUsers,
  activateUser,
  deactivateUser,
  openModal,
  closeModal,
  importOnlineUsersBonusesCSV,
  deactivateOnlineUsersCSV,
  forceLogoutUsers,
  exportCSVUsersReport
};

export default connect(mapStateToProps, mapDispatchToProps)(ListOfUsersSales);
