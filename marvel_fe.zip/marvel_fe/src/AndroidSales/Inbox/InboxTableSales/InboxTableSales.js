// @flow
import React from "react";
import { Grid, TableHeaderRow, Table, Toolbar, SearchPanel } from "@devexpress/dx-react-grid-material-ui";
import { SearchState, PagingState, CustomPaging, IntegratedFiltering } from "@devexpress/dx-react-grid";
import TabsHeader from "../../../components/TableComponents/TabsHeader";
import {
  PhoneProvider,
  AnswerTypeProvider,
  ButtonProvider,
  TransparentButtonProvider,
  DateFormatProvider
} from "../../../components/FormattedData/FormattedData";
import TableContainer from "../../../components/TableComponents/TableContainer";
import ToolbarRoot from "../../../components/TableComponents/ToolbarRoot";
import GridRoot from "../../../components/TableComponents/GridRoot";
import SearchInput from "../../../components/SearchInput/SearchInputForIntegratedSearch";
import PagingPanel from "../../../components/TableComponents/PagingPanel";
import { availableItemsPerPage, columnExtensions } from "../../../constants";

type PropsT = {
  data: InboxT[],
  openModal: Function,
  total: Number,
  page: number,
  count: number,
  columns: ColumnT[],
  tab: string,
  changeCurrentPage: Function,
  changeTab: Function,
  changePageSize: Function
};

const forValues = {
  phone: ["phone"],
  answerType: ["answerType"],
  details: ["details"],
  answer: ["answer"],
  answeredAt: ["answeredAt"],
  createdAt: ["createdAt"]
};

const columnExtensionsInbox = [
  ...columnExtensions,
  { columnName: "details", width: 200 },
  { columnName: "answer", width: 160 }
];

const tabs = [{ label: "Нові", value: "1" }, { label: "Завершені", value: "2" }];

const InboxTableSales = (props: PropsT) => {
  const { data, openModal, total, changeCurrentPage, changePageSize, page, count, tab, changeTab, columns } = props;

  return (
    <Grid rows={data} columns={columns} rootComponent={GridRoot}>
      <SearchState />
      <PagingState
        currentPage={page}
        onCurrentPageChange={changeCurrentPage}
        pageSize={count}
        onPageSizeChange={changePageSize}
      />

      <CustomPaging totalCount={total} />
      <IntegratedFiltering />

      <PhoneProvider for={forValues.phone} />
      <DateFormatProvider for={forValues.createdAt} showTime />
      <DateFormatProvider for={forValues.answeredAt} showTime />
      <AnswerTypeProvider for={forValues.answerType} />
      <TransparentButtonProvider
        for={forValues.details}
        onClick={id => props.openModal("details", id)}
        label="Деталі звернення"
      />
      <ButtonProvider for={forValues.answer} onClick={id => openModal("answer", id)} label="Відповісти" />
      <Table height="auto" containerComponent={TableContainer} columnExtensions={columnExtensionsInbox} />

      <TableHeaderRow />

      <Toolbar rootComponent={ToolbarRoot} />
      <TabsHeader changeTab={changeTab} activeTab={tab} tabs={tabs} />
      <PagingPanel pageSizes={availableItemsPerPage} noData={!data.length} />
      <SearchPanel inputComponent={props => <SearchInput {...props} placeholder="Пошук звернень" />} />
    </Grid>
  );
};

export default InboxTableSales;
