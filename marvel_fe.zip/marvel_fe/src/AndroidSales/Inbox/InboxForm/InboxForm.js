// @flow
import React from "react";
import { Field, reduxForm } from "redux-form";
import type { FormProps } from "redux-form";
import { connect } from "react-redux";
import { compose } from "redux";
import ContainedButton from "../../../components/Buttons/ContainedButton/ContainedButton";
import InputField from "../../../components/InputField/InputField";
import ErrorMessage from "../../../components/ErrorMessage/ErrorMessage";
import { answerInbox, getInboxData, clearInboxData } from "../../../store/actions/sales/inboxListSales";
import { initialValuesSelector } from "../../../store/selectors/sales/inbox";
import { phoneMask, normalizeLength } from "../../../utils/reduxFormNormalizers";
import validate from "./validate";

import styles from "./InboxForm.module.scss";

type PropsT = {
  id: string,
  errorMessage: string,
  initialValues: InboxT,
  getInboxData: Function,
  clearInboxData: Function
} & FormProps;

const inputProps = { classes: { underline: styles.disabled } };

class InboxForm extends React.Component<PropsT> {
  componentDidMount() {
    if (this.props.id) {
      this.props.getInboxData(this.props.id);
    }
  }

  componentWillUnmount() {
    this.props.clearInboxData();
  }

  submitForm = (values, answerType) => {
    const { requestId, answer } = values;
    const respData = {
      requestId,
      answer,
      answerType
    };

    this.props.answerInbox(respData);
  };

  render() {
    const {
      handleSubmit,
      errorMessage,
      initialValues: { accountId }
    } = this.props;

    return (
      <form onSubmit={handleSubmit} className={styles.newSalesFormWrapper}>
        <div className={styles.formTitle}>Інформація від користувача</div>
        <div className={styles.infoWrapper}>
          <Field
            name="lastName"
            component={InputField}
            className={styles.inputField}
            disabled
            InputProps={inputProps}
          />
          <Field
            name="firstName"
            component={InputField}
            className={styles.inputField}
            disabled
            InputProps={inputProps}
          />
          <Field
            name="middleName"
            component={InputField}
            className={styles.inputField}
            disabled
            InputProps={inputProps}
          />

          <Field
            name="phone"
            component={InputField}
            type="tel"
            className={styles.inputField}
            {...phoneMask}
            disabled
            InputProps={inputProps}
          />

          <Field name="city" component={InputField} className={styles.inputField} disabled InputProps={inputProps} />

          <Field
            name="reason"
            component={InputField}
            className={styles.inputField}
            disabled
            InputProps={inputProps}
            multiline
          />
        </div>

        <Field
          required
          name="answer"
          component={InputField}
          className={styles.inputField}
          multiline
          normalize={normalizeLength(500)}
        />
        <div className={styles.buttonsWrapper}>
          <ContainedButton
            type="submit"
            label="Відправити SMS"
            className={accountId ? styles.button : styles.fullWidth}
            handleClick={handleSubmit(values => this.submitForm(values, 2))}
          />
          {accountId && (
            <ContainedButton
              type="submit"
              label="Відправити у додаток"
              className={styles.button}
              handleClick={handleSubmit(values => this.submitForm(values, 1))}
            />
          )}
        </div>
        {errorMessage && <ErrorMessage error={errorMessage} />}
      </form>
    );
  }
}

const mapStateToProps = state => {
  const { error } = state.inboxListSales;
  return {
    initialValues: initialValuesSelector(state),
    errorMessage: error
  };
};

const mapDispatchToProps = {
  answerInbox,
  getInboxData,
  clearInboxData
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  reduxForm({
    form: "InboxForm",
    enableReinitialize: true,
    keepDirtyOnReinitialize: true,
    validate
  })
)(InboxForm);
