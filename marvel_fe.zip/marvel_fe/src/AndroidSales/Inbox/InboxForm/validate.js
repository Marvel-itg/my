import { validationErrorMessages } from "../../../constants";

export default function validate(values) {
  const { required } = validationErrorMessages();
  const errors = {};
  if (!values.answer) {
    errors.answer = required;
  }

  return errors;
}
