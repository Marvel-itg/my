// @flow
import React from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";

import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import InboxForm from "../InboxForm/InboxForm";
import InboxDetails from "../InboxDetails/InboxDetails";
import InboxTableSales from "../InboxTableSales/InboxTableSales";
import Modal from "../../../components/Modal/Modal";
import { fetchInbox, answerInbox } from "../../../store/actions/sales/inboxListSales";
import { inboxListSelector } from "../../../store/selectors/sales/inbox";

import { openModal } from "../../../store/actions/common/modals";
import { getPaginationConfig, changeCurrentPage, changePageSize, changeTab } from "../../../helpers/common";
import { classes } from "../../../helpers/spinner";

type PropsT = {
  fetchInbox: Function,
  total: Number,
  answerInbox: Function,
  openModal: Function,
  inboxList: InboxT[],
  history: BrowserHistory,
  submitted: boolean,
  loading: boolean
} & BrowserHistory;

type StateT = {
  formName: string,
  modalBody: any
};

const commonColumns = [
  { name: "lastName", title: "Прiзвище" },
  { name: "firstName", title: "Iм'я" },
  { name: "middleName", title: "По батькові" },
  { name: "phone", title: "Номер телефону" },
  { name: "city", title: "Населений пункт" },
  { name: "reason", title: "Причина звернення" },
  { name: "createdAt", title: "Дата звернення" }
];

const defaultColumns = {
  "1": [...commonColumns],
  "2": [
    ...commonColumns,
    { name: "answeredAt", title: "Дата відповіді" },
    { name: "details", title: "Деталі звернення" }
  ]
};

const columnsWithAnswerAccess = {
  "1": [...commonColumns, { name: "answer", title: "Відповісти" }],
  "2": [
    ...commonColumns,
    { name: "answeredAt", title: "Дата відповіді" },
    { name: "details", title: "Деталі звернення" }
  ]
};

class Inbox extends React.Component<PropsT, StateT> {
  state = {
    modalBody: <div />,
    formName: ""
  };

  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      submitted,
      location: { key }
    } = this.props;
    if ((!prevProps.submitted && submitted) || prevProps.location.key !== key) {
      this.fetchData();
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  changeTab = (event: any, tab: string) => changeTab(tab, this.props.location.search, this.props.history);

  fetchData = () => {
    const params = new URLSearchParams(this.props.location.search);
    const page = params.get("page");
    const count = params.get("count");
    const tab = params.get("tab");
    this.props.fetchInbox({ status: tab || "1", paginationConfig: { page, count } });
  };

  openModal = (type: string, id: string) => {
    switch (type) {
      case "answer": {
        const modalBody = <InboxForm id={id} />;
        this.setState({ modalBody, formName: "InboxForm" });
        return this.props.openModal();
      }
      case "details": {
        const modalBody = <InboxDetails id={id} />;
        this.setState({ modalBody, formName: "" });
        return this.props.openModal();
      }
      default:
        return null;
    }
  };

  render() {
    const { loading, inboxList, total, accountType } = this.props;
    const { page, count, tab } = getPaginationConfig(this.props.location.search);
    const columnsForRoles =
      accountType === 1 || accountType === 4 || accountType === 2 ? columnsWithAnswerAccess : defaultColumns;
    return (
      <React.Fragment>
        <Paper square className="mainContent">
          <InboxTableSales
            columns={columnsForRoles[tab || "1"]}
            data={inboxList}
            total={total}
            openModal={this.openModal}
            changeCurrentTab={this.changeTab}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            changeTab={this.changeTab}
            page={page}
            count={count}
            tab={tab || "1"}
          />
          {loading && <CircularProgress classes={classes} />}
        </Paper>
        <Modal formName={this.state.formName}>{this.state.modalBody}</Modal>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const { submitted, submitting, declining, loading, total } = state.inboxListSales;
  const {
    user: { accountType }
  } = state.authenticationReducer;
  return {
    inboxList: inboxListSelector(state),
    total,
    submitted,
    declining,
    accountType,
    loading: submitting || loading
  };
};

const mapDispatchToProps = {
  fetchInbox,
  answerInbox,
  openModal
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(Inbox);
