// @flow
import React, { Fragment } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { inboxSelector } from "../../../store/selectors/sales/inbox";
import { getInboxData, clearInboxData } from "../../../store/actions/sales/inboxListSales";
import { formatPhone } from "../../../utils/reduxFormNormalizers";
import styles from "../../ListOfOrdersSales/Orders.module.scss";

type PropsT = {
  id: string,
  inboxData: InboxT,
  getInboxData: Function,
  clearInboxData: Function
};

class InboxDetails extends React.Component<PropsT> {
  componentDidMount() {
    if (this.props.id) {
      this.props.getInboxData(this.props.id);
    }
  }

  componentWillUnmount() {
    this.props.clearInboxData();
  }

  render() {
    const { inboxData } = this.props;
    return (
      <Fragment>
        <h3 className={styles.dialogTitle}>Деталі звернення</h3>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Прізвище: </span>
          <span className={styles.detailsDescription}>{inboxData.lastName}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Ім'я: </span>
          <span className={styles.detailsDescription}>{inboxData.firstName}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>По батькові: </span>
          <span className={styles.detailsDescription}>{inboxData.middleName}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Номер телефону: </span>
          <span className={styles.detailsDescription}>{formatPhone(inboxData.phone)}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Населений пункт: </span>
          <span className={styles.detailsDescription}>{inboxData.city}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Причина звернення: </span>
          <span className={styles.detailsDescription}>{inboxData.reason}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Тип відповіді: </span>
          <span className={styles.detailsDescription}>{inboxData.answerType}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Відповідь: </span>
          <span className={styles.detailsDescription}>{inboxData.answer}</span>
        </div>
      </Fragment>
    );
  }
}

const mapStateToProps = state => ({
  inboxData: inboxSelector(state)
});

const mapDispatchToProps = {
  getInboxData,
  clearInboxData
};

export default compose(connect(mapStateToProps, mapDispatchToProps))(InboxDetails);
