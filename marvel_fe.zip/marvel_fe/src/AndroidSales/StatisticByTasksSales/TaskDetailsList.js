// @flow
import React from "react";
import { connect } from "react-redux";
import get from "lodash/get";
import moment from "moment";
import Paper from "@material-ui/core/Paper";
import debounce from "es6-promise-debounce";
import CircularProgress from "@material-ui/core/CircularProgress";
import type { BrowserHistory } from "history";
import ReportToolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import TaskDetailsTable from "./TaskDetailsTable";
import BackButton from "../../components/Buttons/BackButton/BackButton";
import {
  fetchDetailedStatisticsByTasks,
  exportDetailedStatisticsByTasksCSV
} from "../../store/actions/sales/statisticsByTasksList";
import { detailedStatisticSelector } from "../../store/selectors/sales/detailedStatistic";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  getCommonParams,
  shouldNotSendRequest
} from "../../helpers/common";
import { defaultItemsPerPage } from "../../constants";
import styles from "./StatisticByTasks.module.scss";
import { classes } from "../../helpers/spinner";

type PropsT = {
  fetchStatisticsByTasks: Function,
  exportStatisticsByTasksCSV: Function,
  statistic: TaskStatisticT[],
  loading: boolean,
  uploading: boolean,
  additionalColumns: ColumnT[],
  exportError: string
} & BrowserHistory;

const commonColumns = [
  { name: "taskInstanceId", title: "ID транзакції" },
  { name: "fullName", title: "ПIБ продавця" },
  { name: "accountId", title: "ID користувача" },
  { name: "phone", title: "Номер телефону" },
  { name: "city", title: "Населений пункт" },
  { name: "posCode", title: "Код ТТ" },
  { name: "taskName", title: "Назва завдання" },
  { name: "taskDescription", title: "Опис завдання" },
  { name: "taskStartDate", title: "Дата початку завдання" },
  { name: "taskEndDate", title: "Дата завершення завдання" },
  { name: "completedDate", title: "Дата та час проходження завдання" }
];

const foilTaskColumns = [
  { name: "foilCount", title: "Кількість фольги" },
  { name: "bonusesPerFoil", title: "Кількість балів за одну фольгу" },
  { name: "bonusReceived", title: "Отримано балів" },
  { name: "trFullName", title: "ТП, що підтвердив" }
];
const testAndInfoTaskColumns = [{ name: "bonusReceived", title: "Отримано балів" }];

const scanCodesColumns = [
  { name: "reward", title: "Кількість балів" },
  { name: "rewardPerExtraItem", title: "Кількість балів за додаткову пачку" },
  { name: "bonusReceived", title: "Отримано балів" },
  { name: "plannedPosAmount", title: "Планова кількість пачок" },
  { name: "factualUserAmount", title: "Прогрес користувача" },
  { name: "factualPosAmount", title: "Прогрес точки" }
];

const midPlusColumns = [
  { name: "generalPosAmount", title: "Загальний план блокiв на ТТ" },
  { name: "factualPosAmount", title: "Фактична кiлькicть з загального плану на ТТ" },
  { name: "factualSellerPosAmount", title: "Фактична кiлькicть з загального плану у продавця" },
  { name: "generalMidPlusPosAmount", title: "План MID+ блокiв на ТТ" },
  { name: "factualMidPlusPosAmount", title: "Фактична кiлькicть з MID+ плану блокiв на ТT" },
  { name: "factualSellerMidPlusPosAmount", title: "Фактична кiлькicть з MID+ плану у продавця" },
  { name: "generalPlanReward", title: "Кiлькiсть балiв за загальний план" },
  { name: "generalMidPlusReward", title: "Кiлькiсть балiв за MID+ план" },
  { name: "bonusRecieved", title: "Отримано балiв" }
];
const columnsConfig = {
  "1": [...commonColumns], //  Замовлення
  "2": [
    ...commonColumns,
    ...foilTaskColumns // Фольга
  ],
  "3": [
    ...commonColumns, // Тест
    ...testAndInfoTaskColumns
  ],
  "4": [
    ...commonColumns, // Инфо
    ...testAndInfoTaskColumns
  ],
  "5": [
    ...commonColumns // Анкета
  ],
  "6": [
    ...commonColumns // Фото
  ],
  "7": [
    ...commonColumns // Тест зворонтній зв'язок
  ],
  "8": [
    ...commonColumns, // Відскануй код
    ...scanCodesColumns
  ],
  "9": [
    ...commonColumns, // MID+
    ...midPlusColumns
  ]
};

class TaskDetailsList extends React.Component<PropsT> {
  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;

    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history, this.props.location.state);

  changePageSize = (pageSize: number) =>
    changePageSize(pageSize, this.props.location.search, this.props.history, this.props.location.state);

  fetchData = debounce(() => {
    const { searchFieldName, searchValue, itemsOnPage, pageNumber, type } = getCommonParams(this.props.location.search);
    const { id } = this.props.match.params;
    const templateId = Number(id);
    const params = { searchFieldName, searchValue, itemsOnPage, pageNumber, templateId };

    this.props.fetchDetailedStatisticsByTasks(params, type);
  }, 200);

  exportCSV = () => {
    const { searchFieldName, searchValue, type } = getCommonParams(this.props.location.search);
    const { id } = this.props.match.params;
    const params = { searchFieldName, searchValue, templateId: id };
    this.props.exportDetailedStatisticsByTasksCSV(params, type);
  };

  goBack = () => {
    const returnUrl = get(this.props, "location.state.returnUrl");
    const url = "/sales/statistic-of-tasks";
    const query = `?page=1&count=${defaultItemsPerPage}&start=${moment()
      .subtract(1, "month")
      .format("DD/MM/YYYY")}&end=${moment()
      .endOf("day")
      .format("DD/MM/YYYY")}`;
    const defaultReturnUrl = `${url}${query}`;
    return returnUrl ? this.props.history.push(returnUrl) : this.props.history.push(defaultReturnUrl);
  };

  render() {
    const { loading, uploading, total, additionalColumns, exportError, additionalExtensions } = this.props;
    const { type } = getCommonParams(this.props.location.search);
    const { page, count } = getPaginationConfig(this.props.location.search);
    const columns = type ? [...columnsConfig[type], ...additionalColumns] : commonColumns;
    return (
      <React.Fragment>
        <BackButton label="Повернутися до списку" handleClick={this.goBack} className={styles.backButton} />
        <ReportToolbar
          hasExportButton
          form="taskDetailsFilter"
          loadHandler={this.exportCSV}
          disabled={loading || uploading}
          uploading={uploading}
          withoutDateRange
          errorMessage={exportError}
        />
        <Paper square className="mainContent">
          <TaskDetailsTable
            data={this.props.statistic}
            columns={columns}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            page={page}
            count={count}
            total={total}
            additionalExtensions={additionalExtensions}
            additionalColumns={additionalColumns}
          />
        </Paper>
        {loading && <CircularProgress classes={classes} />}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    statisticsByTasks: { detailedTotal: total, loading, uploading, exportError }
  } = state;
  const { statistic, additionalColumns, additionalExtensions } = detailedStatisticSelector(state);
  return {
    statistic,
    loading,
    uploading,
    total,
    additionalColumns,
    exportError,
    additionalExtensions
  };
};

const mapDispatchToProps = {
  fetchDetailedStatisticsByTasks,
  exportDetailedStatisticsByTasksCSV
};

export default connect(mapStateToProps, mapDispatchToProps)(TaskDetailsList);
