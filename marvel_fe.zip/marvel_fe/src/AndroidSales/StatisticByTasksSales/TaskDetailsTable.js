// @flow
import React from "react";
import { Grid, Table, TableHeaderRow, Toolbar, PagingPanel } from "@devexpress/dx-react-grid-material-ui";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import {
  DateFormatProvider,
  TransparentButtonProvider,
  PhoneProvider,
  CodesListProvider,
  TextProvider
} from "../../components/FormattedData/FormattedData";
import GridRoot from "../../components/TableComponents/GridRoot";
import TableContainer from "../../components/TableComponents/TableContainer";
import SearchForm from "../../components/TableComponents/SearchForm/SearchForm";
import HeaderWrap from "../../components/TableComponents/HeaderWrap";
import WithStickyBandsTable from "../../HOCs/withStickyBandsTable";
import { availableItemsPerPage, defaultItemsPerPage, taskDetailsReportSearchOptions } from "../../constants";
import { Plugin } from "@devexpress/dx-react-core";

type PropsT = {
  data: Object,
  columns: ColumnT[],
  page: number,
  count: number,
  total: number,
  openDetails: Function,
  changeCurrentPage: Function,
  changePageSize: Function,
  additionalExtensions: any[],
  additionalColumns: ColumnT[]
};

const forValues = {
  date: ["taskStartDate", "taskEndDate"],
  completedDate: ["completedDate"],
  details: ["details"],
  phone: ["phone"],
  list: [],
  text: []
};

const columnExtensions = [
  { columnName: "taskInstanceId", width: 100 },
  { columnName: "fullName", width: 300 },
  { columnName: "phone", width: 200 },
  { columnName: "city", width: 400 },
  { columnName: "posCode", width: 100 },
  { columnName: "taskName", width: 250 },
  { columnName: "taskDescription", width: 300 },
  { columnName: "taskStartDate", width: 200 },
  { columnName: "taskEndDate", width: 200 },
  { columnName: "completedDate", width: 200 },
  { columnName: "trFullName", width: 300 }
];

const StatisticByTasks = (props: PropsT) => {
  const {
    data,
    columns,
    page,
    count,
    changeCurrentPage,
    changePageSize,
    total,
    openDetails,
    additionalExtensions = [],
    additionalColumns = []
  } = props;

  if (additionalExtensions.length) {
    forValues.list = additionalExtensions.map(item => item.columnName);
  }
  if (additionalColumns.length && !additionalExtensions.length) {
    forValues.text = additionalColumns.map(item => item.name);
  }

  return (
    <Grid rows={data} columns={columns} rootComponent={GridRoot}>
      <PagingState
        currentPage={page || 0}
        onCurrentPageChange={changeCurrentPage}
        pageSize={count || defaultItemsPerPage}
        onPageSizeChange={changePageSize}
      />
      <DateFormatProvider for={forValues.date} />
      <DateFormatProvider for={forValues.completedDate} showTime />
      <PhoneProvider for={forValues.phone} />
      <Plugin name="providers">
        {!!forValues.list.length && forValues.list.map(item => <CodesListProvider for={[item]} key={item} />)}
      </Plugin>
      <TransparentButtonProvider for={forValues.details} onClick={openDetails} label="Детальніше" />
      <Plugin name="providers">
        {!!forValues.text.length && forValues.text.map(item => <TextProvider for={[item]} key={item} />)}
      </Plugin>
      <CustomPaging totalCount={total} />
      <Table
        height="auto"
        containerComponent={TableContainer}
        columnExtensions={[...columnExtensions, ...additionalExtensions]}
      />
      <TableHeaderRow cellComponent={HeaderWrap} />
      <Toolbar />
      <PagingPanel pageSizes={availableItemsPerPage} noData={!total} />
      <SearchForm selectOptions={taskDetailsReportSearchOptions} placeholder="Пошук" />
    </Grid>
  );
};

export default WithStickyBandsTable(StatisticByTasks);
