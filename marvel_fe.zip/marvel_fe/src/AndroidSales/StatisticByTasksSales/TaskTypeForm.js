// @flow
import React from "react";
import cx from "classnames";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import Select from "../../components/Select/Select";
import { getSearchQuery } from "../../helpers/common";
import { taskTypesOptions } from "../../constants";
import styles from "./StatisticByTasks.module.scss";

type PropsT = {
  className: string | null
} & BrowserHistory;

const TaskTypeForm = ({ className, ...props }: PropsT) => {
  const params = new URLSearchParams(props.location.search);
  const type = params.get("type");
  const typeValue = taskTypesOptions.find(option => option.value === Number(type)) || null;

  const onChange = taskType => {
    const { count, start, end, tab, searchValue, searchField } = getSearchQuery(props.location.search);
    const typeQuery = taskType ? `&type=${taskType.value}` : "";
    props.history.push(`?page=1${count}${start}${end}${tab}${typeQuery}${searchValue}${searchField}`);
  };

  return (
    <form className={cx(styles.searchHeader, className)} autoComplete="off" noValidate>
      <Select
        key={typeValue}
        component={Select}
        options={taskTypesOptions}
        onChange={onChange}
        value={typeValue}
        placeholder="Тип завдання"
        isClearable
      />
    </form>
  );
};

export default withRouter(TaskTypeForm);
