// @flow
import React from "react";
import { Grid, Table, TableHeaderRow, Toolbar, PagingPanel } from "@devexpress/dx-react-grid-material-ui";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import { DateFormatProvider, TransparentButtonProvider } from "../../components/FormattedData/FormattedData";
import GridRoot from "../../components/TableComponents/GridRoot";
import TableContainer from "../../components/TableComponents/TableContainer";
import HeaderWrap from "../../components/TableComponents/HeaderWrap";
import WithStickyBandsTable from "../../HOCs/withStickyBandsTable";
import TaskTypeForm from "./TaskTypeForm";
import { availableItemsPerPage, defaultItemsPerPage, columnExtensions } from "../../constants";
import { Plugin, Template, TemplateConnector, TemplatePlaceholder } from "@devexpress/dx-react-core";

type PropsT = {
  data: Object,
  columns: ColumnT[],
  page: number,
  count: number,
  total: number,
  openDetails: Function,
  changeCurrentPage: Function,
  changePageSize: Function,
  checkIfDetailsButtonIsHidden: Function
};

const forValues = {
  date: ["startDate", "endDate"],
  details: ["details"]
};

const expandedColumnExtensions = [
  ...columnExtensions,
  { columnName: "taskId", width: 150 },
  { columnName: "taskName", width: 280 },
  { columnName: "taskDescription", width: 280 },
  { columnName: "taskType", width: 280 },
  { columnName: "startDate", width: 280 },
  { columnName: "endDate", width: 280 },
  { columnName: "bonusPoints", width: 280 },
  { columnName: "availableToUsers", width: 150 },
  { columnName: "doneTasks", width: 150 },
  { columnName: "availableToPoses", width: 150 },
  { columnName: "details", width: 200 }
];

const StatisticByTasks = (props: PropsT) => {
  const {
    data,
    columns,
    page,
    count,
    changeCurrentPage,
    changePageSize,
    total,
    openDetails,
    checkIfDetailsButtonIsHidden
  } = props;

  return (
    <Grid rows={data} columns={columns} rootComponent={GridRoot}>
      <PagingState
        currentPage={page || 0}
        onCurrentPageChange={changeCurrentPage}
        pageSize={count || defaultItemsPerPage}
        onPageSizeChange={changePageSize}
      />
      <DateFormatProvider for={forValues.date} />
      <TransparentButtonProvider
        for={forValues.details}
        onClick={openDetails}
        label="Детальніше"
        checkHidden={checkIfDetailsButtonIsHidden}
      />

      <CustomPaging totalCount={total} />
      <Table height="auto" containerComponent={TableContainer} columnExtensions={expandedColumnExtensions} />

      <TableHeaderRow cellComponent={HeaderWrap} />
      <Toolbar>
        <TaskTypeForm />
      </Toolbar>
      <Plugin name="TaskTypeForm">
        <Template name="toolbarContent">
          <TemplatePlaceholder />
          <TemplateConnector>{() => <TaskTypeForm />}</TemplateConnector>
        </Template>
      </Plugin>
      <PagingPanel pageSizes={availableItemsPerPage} noData={!total} />
    </Grid>
  );
};

export default WithStickyBandsTable(StatisticByTasks);
