// @flow
import React from "react";
import { connect } from "react-redux";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import type { BrowserHistory } from "history";
import ReportToolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import StatisticByTasksTable from "./StatisticByTasksSalesTable";
import { fetchStatisticsByTasks, exportStatisticsByTasksCSV } from "../../store/actions/sales/statisticsByTasksList";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  filterByDate,
  getCommonParams,
  getSearchQuery,
  shouldNotSendRequest
} from "../../helpers/common";
import { defaultItemsPerPage, taskDetailsReportSearchOptions, taskTypeStringKey } from "../../constants";
import { classes } from "../../helpers/spinner";

type PropsT = {
  fetchStatisticsByTasks: Function,
  exportStatisticsByTasksCSV: Function,
  statistic: TaskStatisticT[],
  loading: boolean,
  uploading: boolean,
  exportError: string
} & BrowserHistory;

const columns = [
  { name: "taskTemplateId", title: "ID завдання" },
  { name: "taskName", title: "Назва завдання" },
  { name: "taskDescription", title: "Опис завдання" },
  { name: "taskType", title: "Тип завдання" },

  { name: "startDate", title: "Дата початку" },
  { name: "endDate", title: "Дата закінчення" },
  { name: "bonusPointsReward", title: "Кількість балів" },
  {
    name: "availableToUsers",
    title: "Кількість юзерів, котрим доступно це завдання"
  },
  { name: "doneTasks", title: "Кількість юзерів, котрі виконали завдання" },
  { name: "availableToPoses", title: "Кількість ТТ, котрим доступно завдання" },
  { name: "details", title: "Детальніше" }
];

class StatisticsByTasks extends React.Component<PropsT> {
  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;

    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  filterByDate = (rangeFilter: RangeFilterT) =>
    filterByDate(rangeFilter, this.props.location.search, this.props.history, this.props.location.state);

  fetchData = () => {
    const { dateStart, dateEnd, itemsOnPage, pageNumber, type } = getCommonParams(this.props.location.search);
    let params = { dateStart, dateEnd, itemsOnPage, pageNumber };
    if (type) {
      params = { ...params, searchFieldName: "TypeId", searchValue: type };
    }
    this.props.fetchStatisticsByTasks(params);
  };

  exportCSV = () => {
    const { dateStart, dateEnd, type } = getCommonParams(this.props.location.search);
    let params = { dateStart, dateEnd };
    if (type) {
      params = { ...params, searchFieldName: "TypeId", searchValue: type };
    }
    this.props.exportStatisticsByTasksCSV(params);
  };

  openDetails = (id, rowData) => {
    const { start, end, type, page, count } = getSearchQuery(this.props.location.search);
    const returnUrl = `/sales/statistic-of-tasks?${page}${count}${start}${end}${type}`;
    const taskType = taskTypeStringKey[rowData.taskType];
    return this.props.history.push(
      `statistic-of-tasks/${rowData.taskTemplateId}?page=1&count=${defaultItemsPerPage}&type=${taskType}&searchField=${taskDetailsReportSearchOptions[0].value}`, //eslint-disable-line
      {
        returnUrl
      }
    );
  };

  checkIfDetailsButtonIsHidden = row => {
    return (
      row.taskType !== "Завдання Інформаційне" &&
      row.taskType !== "Завдання Фольга" &&
      row.taskType !== "Завдання Тестове" &&
      row.taskType !== "Тест-зворотнiй звязок" &&
      row.taskType !== "Завдання Відскануй код" &&
      row.taskType !== "Завдання Замовлення MID+"
    );
  };

  render() {
    const { loading, uploading, exportError } = this.props;
    const { dateStart, dateEnd } = getCommonParams(this.props.location.search);
    const { page, count } = getPaginationConfig(this.props.location.search);
    const initialValues = { startDate: dateStart, endDate: dateEnd };
    return (
      <React.Fragment>
        <ReportToolbar
          hasExportButton
          form="statisticDateFilter"
          filterData={this.filterByDate}
          initialValues={initialValues}
          loadHandler={this.exportCSV}
          disabled={loading || uploading}
          uploading={uploading}
          errorMessage={exportError}
        />
        <Paper square className="mainContent">
          <StatisticByTasksTable
            data={this.props.statistic}
            columns={columns}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            page={page}
            count={count}
            total={this.props.total}
            openDetails={this.openDetails}
            checkIfDetailsButtonIsHidden={this.checkIfDetailsButtonIsHidden}
          />
        </Paper>
        {loading && <CircularProgress classes={classes} />}
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({ statisticsByTasks: { statistic, total, loading, uploading, exportError } }) => ({
  statistic,
  loading,
  uploading,
  total,
  exportError
});

const mapDispatchToProps = {
  fetchStatisticsByTasks,
  exportStatisticsByTasksCSV
};

export default connect(mapStateToProps, mapDispatchToProps)(StatisticsByTasks);
