// @flow
import React from "react";
import { connect } from "react-redux";
import { compose } from "redux";
import { reduxForm, Field, formValueSelector } from "redux-form";
import type { FormProps } from "redux-form";
import CircularProgress from "@material-ui/core/CircularProgress";
import Paper from "@material-ui/core/Paper/Paper";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import InputFileMultiple from "../../components/InputFileMultiple/InputFileMultiple";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import InputField from "../../components/InputField/InputField";
import Switch from "../../components/Switch/Switch";
import validate from "./validate";
import { normalizeInteger } from "../../utils/reduxFormNormalizers";
import { getManageBonusesData, editManageBonusesData, savePosCodeFile } from "../../store/actions/sales/manageBonuses";
import { initialValuesSelector, importCSVErrorSelector } from "../../store/selectors/sales/manageBonuses";
import { classes } from "../../helpers/spinner";
import styles from "./ManageBonusesForm.module.scss";

type PropsT = {
  submitForm: Function,
  changeMode: Function,
  editMode: boolean,
  isEditing: boolean,
  errorMessage: string,
  formTitle: string,
  invalid: boolean
} & FormProps;

class ManageBonusesForm extends React.Component<PropsT> {
  componentDidMount() {
    this.props.getManageBonusesData();
  }

  componentDidUpdate(prevProps) {
    if (!prevProps.edited && this.props.edited) {
      this.props.getManageBonusesData();
    }
  }

  submitForm = values => {
    const { isEnabled, bonusesCount } = values;
    const params = { isEnabled, bonusesCount, type: 2 };
    this.props.editManageBonusesData(params);
  };

  handleChangeSwitch = (event, value) => {
    const params = {
      isEnabled: value,
      bonusesCount: this.props.bonusesCount,
      type: 2
    };
    this.props.editManageBonusesData(params);
  };

  saveFile = event => {
    event.preventDefault();
    this.props.savePosCodeFile();
  };

  render() {
    const { handleSubmit, invalid, loaded, errorMessage, loading, isEnabled } = this.props;
    return (
      <Paper className="mainContent">
        {loading && !loaded ? (
          <CircularProgress classes={classes} />
        ) : (
          <form
            autoComplete="off"
            noValidate
            onSubmit={handleSubmit(this.submitForm)}
            className={styles.manageBonusesForm}
          >
            <Field
              required
              name="isEnabled"
              component={Switch}
              label="Нарахування балів за замовлення"
              className={styles.switch}
              onChange={this.handleChangeSwitch}
            />
            <Field
              required
              component={InputFileMultiple}
              name="posCodesForManageBonuses"
              id="posCodesForManageBonuses"
              showDownloadButton
              disabled={!isEnabled}
              label="Завантажити CSV"
              limit={1}
              formattedError={this.props.importError}
              saveButtonHandler={this.saveFile}
              uploadType="posCodesForManageBonuses"
            />
            <Field
              required
              label="Введіть кількість балів"
              name="bonusesCount"
              component={InputField}
              className={styles.inputField}
              normalize={normalizeInteger}
              disabled={!isEnabled}
            />

            <ContainedButton
              type="submit"
              disabled={invalid || !isEnabled}
              label="Зберегти"
              className={styles.submitButton}
            />
            {errorMessage && <ErrorMessage error={errorMessage} />}
          </form>
        )}
      </Paper>
    );
  }
}

const mapStateToProps = state => {
  const selector = formValueSelector("manageBonuses");
  const isEnabled = selector(state, "isEnabled");
  const bonusesCount = selector(state, "bonusesCount");
  const posCodesForManageBonuses = selector(state, "posCodesForManageBonuses");
  const {
    manageBonuses: { error, loading, loaded, editing, edited }
  } = state;
  return {
    isEnabled,
    importError: importCSVErrorSelector(state),
    bonusesCount,
    initialValues: initialValuesSelector(state),
    errorMessage: error,
    loading: loading || editing,
    editing,
    posCodesForManageBonuses,
    loaded,
    edited
  };
};
const mapDispatchToProps = {
  getManageBonusesData,
  editManageBonusesData,
  savePosCodeFile
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  reduxForm({
    validate,
    form: "manageBonuses",
    enableReinitialize: true
  })
)(ManageBonusesForm);
