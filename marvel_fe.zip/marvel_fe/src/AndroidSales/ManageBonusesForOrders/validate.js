import { validationErrorMessages } from "../../constants";

export default function validate(values) {
  const { required } = validationErrorMessages();
  const errors = {};
  if (!values.bonusesCount) {
    errors.bonusesCount = required;
  } else if (values.bonusesCount && Number(values.bonusesCount) > 1000) {
    errors.bonusesCount = "Максимальна кількість бонусів - 1000";
  }
  if (!values.posCodesForManageBonuses || !values.posCodesForManageBonuses.length) {
    errors.posCodesForManageBonuses = required;
  }
  return errors;
}
