// @flow
import React from "react";
import Paper from "@material-ui/core/Paper";
import { connect } from "react-redux";
import CircularProgress from "@material-ui/core/CircularProgress";
import DetailsByTasksForm from "./DetailsByTasksForm/DetailsByTasksForm";
import DetailsByTasksTable from "./DetailsByTasksTable/DetailsByTasksTable";
import Modal from "../../components/Modal/Modal";
import { openModal } from "../../store/actions/common/modals";
import { fetchDetailsByTasks } from "../../store/actions/sales/detailsByTasks";
import { classes } from "../../helpers/spinner";

type PropsT = {
  fetchDetailsByTasks: Function,
  detailsByTasksList: DetailsByTaskT[],
  loading: boolean,
  openModal: Function
};

type StateT = {
  modalBody: any
};

class DetailsByTasksList extends React.Component<PropsT, StateT> {
  state = {
    modalBody: <div />
  };

  componentDidMount() {
    this.props.fetchDetailsByTasks();
  }

  openModal = (type, id) => {
    switch (type) {
      case "details": {
        const modalBody = <DetailsByTasksForm id={id} disabled />;
        this.setState({ modalBody });
        return this.props.openModal();
      }
      default:
        return null;
    }
  };

  render() {
    const { detailsByTasksList } = this.props;
    return (
      <React.Fragment>
        <Paper square className="mainContent">
          <DetailsByTasksTable data={detailsByTasksList} openModal={this.openModal} />
        </Paper>
        {this.props.loading && <CircularProgress classes={classes} />}
        <Modal>{this.state.modalBody}</Modal>
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({ detailsByTasksList: { detailsByTasksList, loading } }) => ({
  detailsByTasksList,
  loading
});

const mapDispatchToProps = {
  fetchDetailsByTasks,
  openModal
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DetailsByTasksList);
