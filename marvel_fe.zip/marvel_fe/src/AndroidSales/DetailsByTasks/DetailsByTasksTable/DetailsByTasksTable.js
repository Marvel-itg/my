// @flow
import React from "react";
import { Grid, TableHeaderRow, Table, Toolbar, SearchPanel } from "@devexpress/dx-react-grid-material-ui";
import { SearchState, IntegratedFiltering, PagingState, IntegratedPaging } from "@devexpress/dx-react-grid";
import SearchInput from "../../../components/SearchInput/SearchInputForIntegratedSearch";
import ToolbarRoot from "../../../components/TableComponents/ToolbarRoot";
import TableContainer from "../../../components/TableComponents/TableContainer";
import PagingPanel from "../../../components/TableComponents/PagingPanel";
import GridRoot from "../../../components/TableComponents/GridRoot";
import {
  TransparentButtonProvider,
  TaskTypeProvider,
  PhoneProvider
} from "../../../components/FormattedData/FormattedData";
import { availableItemsPerPage, defaultItemsPerPage } from "../../../constants";

type PropsT = {
  data: DetailsByTaskT[],
  openModal: Function
};

type StateT = {
  currentPage: number,
  pageSize: number,
  pageSizes: Array<number>
};

const columns = [
  { name: "lastName", title: "Прізвище" },
  { name: "firstName", title: "Ім'я" },
  { name: "middleName", title: "По батькові" },
  { name: "phone", title: "Номер телефону" },
  { name: "posCode", title: "Код торгівельної точки" },
  { name: "taskType", title: "Тип завдання" },
  { name: "taskTitle", title: "Назва завдання" },
  { name: "details", title: "Деталі завдання" },
  { name: "city", title: "Населений пункт" }
];

const columnExtensions = [{ columnName: "details", width: 170 }];

const forValues = {
  details: ["details"],
  phone: ["phone"],
  taskType: ["taskType"]
};

class TasksTable extends React.Component<PropsT, StateT> {
  state = {
    pageSize: defaultItemsPerPage,
    pageSizes: availableItemsPerPage,
    currentPage: 0
  };

  changeCurrentPage = (currentPage: number) => this.setState({ currentPage });

  changePageSize = (pageSize: number) => this.setState({ pageSize });

  openDetailsModal = (id: string) => {
    this.props.openModal("details", id);
  };

  renderSearchInput = (props: any) => <SearchInput {...props} placeholder="Пошук завдань" />;

  render() {
    const { pageSize, pageSizes, currentPage } = this.state;

    return (
      <Grid rows={this.props.data} columns={columns} rootComponent={GridRoot}>
        <SearchState />
        <PagingState
          currentPage={currentPage}
          onCurrentPageChange={this.changeCurrentPage}
          pageSize={pageSize}
          onPageSizeChange={this.changePageSize}
        />

        <TaskTypeProvider for={forValues.taskType} />
        <PhoneProvider for={forValues.phone} />
        <TransparentButtonProvider for={forValues.details} onClick={this.openDetailsModal} label="Деталі завдання" />
        <IntegratedFiltering />
        <IntegratedPaging />

        <Toolbar rootComponent={ToolbarRoot} />

        <Table columnExtensions={columnExtensions} height="auto" containerComponent={TableContainer} />

        <TableHeaderRow />

        <PagingPanel pageSizes={pageSizes} noData={!this.props.data.length} />
        <SearchPanel inputComponent={this.renderSearchInput} />
      </Grid>
    );
  }
}

export default TasksTable;
