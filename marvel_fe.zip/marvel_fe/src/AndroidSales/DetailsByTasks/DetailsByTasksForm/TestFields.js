// @flow
import React from "react";
import type { FormProps } from "redux-form";
import Question from "./Question";
import styles from "./DetailsByTasks.module.scss";

type PropsT = {
  disabled: boolean,
  questions: QuestionsT[]
} & FormProps;

const TestFields = (props: PropsT) => {
  const { fields, disabled, questions } = props;
  return (
    <div className={styles.sectionWrapper}>
      <ul className={styles.sectionList}>
        {fields &&
          !!fields.length &&
          fields.map((question, index) => (
            <Question questions={questions[index]} question={question} index={index} disabled={disabled} key={index} />
          ))}
      </ul>
    </div>
  );
};

export default TestFields;
