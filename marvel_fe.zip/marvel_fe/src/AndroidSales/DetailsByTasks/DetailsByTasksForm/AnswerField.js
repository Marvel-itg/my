// @flow
import React from "react";
import { Field } from "redux-form";
import type { FormProps } from "redux-form";
import Close from "@material-ui/icons/Close";
import Check from "@material-ui/icons/Check";
import InputField from "../../../components/InputField/InputField";
import styles from "./DetailsByTasks.module.scss";

type PropsT = {
  disabled: boolean,
  label: string,
  blockLabel: string,
  answers: TestAnswerT[]
} & FormProps;

const AnswerField = (props: PropsT) => {
  const { fields, answers, disabled, label, blockLabel } = props;
  return (
    <div className={styles.sectionWrapper}>
      <ul className={styles.sectionList}>
        <h4>{blockLabel}</h4>
        {fields &&
          !!fields.length &&
          fields.map((answer, index) => (
            <li key={index} className={styles.answerStyles}>
              <Field
                required
                name={`${answer}.answer`}
                component={InputField}
                label={`${label} ${index + 1}`}
                disabled={disabled}
              />
              {answers[index].correct ? <Check className={styles.correctAnswerStyle} /> : <Close color="error" />}
            </li>
          ))}
      </ul>
    </div>
  );
};

export default AnswerField;
