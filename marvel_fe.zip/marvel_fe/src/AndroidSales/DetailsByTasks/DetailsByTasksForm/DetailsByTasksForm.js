// @flow
import React from "react";
import { Field, reduxForm, FieldArray, formValueSelector } from "redux-form";
import type { FormProps } from "redux-form";
import { connect } from "react-redux";
import { compose } from "redux";
import CircularProgress from "@material-ui/core/CircularProgress";
import InputField from "../../../components/InputField/InputField";
import ErrorMessage from "../../../components/ErrorMessage/ErrorMessage";
import Select from "../../../components/Select/Select";
import TestFields from "./TestFields";
import RenderSkuList from "./RenderSkuList";
import { getDetailsByTask, clearDetailsByTaskData } from "../../../store/actions/sales/detailsByTasks";
import { initialValuesSelector } from "../../../store/selectors/sales/detailsByTasks";
import { classes } from "../../../helpers/spinner";
import styles from "./DetailsByTasks.module.scss";

type PropsT = {
  getTaskData: Function,
  clearDetailsByTaskData: Function,
  id: number,
  taskType: OptionT,
  disabled: boolean,
  withCounts: boolean,
  questions: QuestionsT[]
} & FormProps;

class DetailsByTasksForm extends React.Component<PropsT> {
  componentDidMount() {
    const { id } = this.props;
    if (id) {
      this.props.getDetailsByTask(this.props.id);
    }
  }

  componentWillUnmount() {
    this.props.clearDetailsByTaskData();
  }

  renderFoilPart = () => {
    const { disabled } = this.props;
    return (
      <>
        <Field
          required
          name="bonusPointsRewardFoil"
          component={InputField}
          className={styles.inputField}
          disabled={disabled}
        />
        <Field
          name="numberOfEarnedPoints"
          label="Кількість зароблених балів"
          component={InputField}
          className={styles.inputField}
          disabled={disabled}
          required
        />

        <Field
          required
          name="numberOfGatheredFoil"
          label="Кількість зібраної фольги"
          component={InputField}
          className={styles.inputField}
          disabled={disabled}
        />
      </>
    );
  };

  renderTestPart = () => {
    const { disabled, questions } = this.props;
    return (
      <>
        <Field
          required
          name="bonusPointsReward"
          label="Кількість балів"
          component={InputField}
          className={styles.inputField}
          disabled={disabled}
        />
        <FieldArray name="questions" questions={questions} component={TestFields} disabled={disabled} />
      </>
    );
  };

  renderQuestionnairePart = () => {
    const { disabled, withCounts } = this.props;
    return (
      <>
        <Field
          required
          name="bonusPointsReward"
          label="Кількість балів за завдання"
          component={InputField}
          className={styles.inputField}
          disabled={disabled}
        />
        <FieldArray
          name="answer"
          blockLabel="Список товарних одиниць в наявності"
          component={RenderSkuList}
          withCounts={withCounts}
          disabled={disabled}
        />
      </>
    );
  };

  renderSelectedTaskPart = taskType => {
    switch (+taskType) {
      case 2:
        return this.renderFoilPart();
      case 3:
        return this.renderTestPart();
      case 5:
        return this.renderQuestionnairePart();
      default:
        return null;
    }
  };

  render() {
    const { handleSubmit, loading, errorMessage, disabled, taskType } = this.props;

    return loading ? (
      <CircularProgress classes={classes} />
    ) : (
      <form onSubmit={handleSubmit} autoComplete="off" noValidate>
        <div className={styles.formTitle}>Деталі завдання</div>
        <div className={styles.infoWrapper}>
          <Field required name="taskType" component={Select} className={styles.inputField} disabled={disabled} />
          <Field
            name="taskTitle"
            component={InputField}
            className={styles.inputField}
            multiline
            disabled={disabled}
            required
          />
          <Field
            name="taskDescription"
            component={InputField}
            label="Опис завдання"
            className={styles.inputField}
            multiline
            disabled={disabled}
            required
          />
          {taskType && this.renderSelectedTaskPart(taskType)}
        </div>
        {errorMessage && <ErrorMessage error={errorMessage} />}
      </form>
    );
  }
}

const mapStateToProps = state => {
  const {
    detailsByTasksList: { detailsByTask, loadingTask, error }
  } = state;
  const taskType = (detailsByTask && detailsByTask.taskType) || null;
  const withCounts = (detailsByTask && detailsByTask.withCounts) || null;
  const selector = formValueSelector("DetailsByTasksForm");
  const questions = selector(state, "questions");
  return {
    initialValues: initialValuesSelector(state),
    errorMessage: error,
    loading: loadingTask,
    taskType,
    withCounts,
    questions
  };
};

const mapDispatchToProps = {
  getDetailsByTask,
  clearDetailsByTaskData
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  reduxForm({
    form: "DetailsByTasksForm",
    enableReinitialize: true
  })
)(DetailsByTasksForm);
