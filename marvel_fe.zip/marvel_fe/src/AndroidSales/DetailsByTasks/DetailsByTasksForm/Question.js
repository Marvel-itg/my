// @flow
import React from "react";
import { Field, FieldArray } from "redux-form";
import type { FormProps } from "redux-form";
import InputField from "../../../components/InputField/InputField";
import ImageField from "./ImageField";
import AnswerField from "./AnswerField";
import styles from "./DetailsByTasks.module.scss";

type PropsT = {
  disabled: boolean,
  questions: QuestionsT
} & FormProps;

const Question = (props: PropsT) => {
  const { question, disabled, questions, index } = props;
  const answers = questions.answers || [];
  return (
    <li key={index} className={styles.blockWrapper}>
      <h4>Питання №{index + 1}</h4>
      <Field required name={`${question}.title`} component={InputField} multiline disabled={disabled} />
      {questions.photo && !!questions.photo.length && <ImageField photos={questions.photo} />}
      <FieldArray
        name={`${question}.answers`}
        component={AnswerField}
        label="Відповідь"
        blockLabel="Відповіді"
        disabled={disabled}
        answers={answers}
      />
    </li>
  );
};

export default Question;
