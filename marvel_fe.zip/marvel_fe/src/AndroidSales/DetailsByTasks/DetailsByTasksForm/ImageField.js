// @flow
import React from "react";
import styles from "./DetailsByTasks.module.scss";

type PropsT = {
  photos: ImageT[]
};

const ImageField = (props: PropsT) => {
  const { photos } = props;
  return (
    <>
      <h4>Картинки</h4>
      <div className={styles.imageContainer}>
        {photos.map((photo, index) => (
          <img key={photo.imageId} src={photo.imageUrl} alt="answer" className={styles.imageStyles} />
        ))}
      </div>
    </>
  );
};

export default ImageField;
