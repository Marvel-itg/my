// @flow
import React from "react";
import { Field } from "redux-form";
import type { FormProps } from "redux-form";
import InputField from "../../../components/InputField/InputField";
import styles from "./DetailsByTasks.module.scss";

type PropsT = {
  disabled: boolean,
  label: string,
  blockLabel: string,
  withCounts: boolean
} & FormProps;

const RenderSkuList = (props: PropsT) => {
  const { fields, disabled, blockLabel, withCounts } = props;
  return (
    <div className={styles.sectionWrapper}>
      <ul className={styles.sectionList}>
        <h4>{blockLabel}</h4>
        {fields.map((sku, index) => (
          <li key={index}>
            <Field
              required
              name={`${sku}.sku`}
              className={withCounts ? styles.inputHalfField : styles.inputField}
              component={InputField}
              label={`Товарна одиниця ${index + 1}`}
              disabled={disabled}
            />
            {withCounts && (
              <Field
                required
                name={`${sku}.count`}
                className={styles.inputHalfField}
                component={InputField}
                label="Кількість"
                disabled={disabled}
              />
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default RenderSkuList;
