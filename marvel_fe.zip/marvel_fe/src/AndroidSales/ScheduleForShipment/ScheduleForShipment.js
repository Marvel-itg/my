// @flow
import React, { useEffect } from "react";
import { connect } from "react-redux";
import Paper from "@material-ui/core/Paper";
import UploadButton from "../../components/Buttons/UploadButton/UploadButton";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import Modal from "../../components/Modal/Modal";
import {
  exportCsvScheduleForShipment,
  importCsvScheduleForShipment
} from "../../store/actions/sales/scheduleForShipment";
import { scheduleForShipmentErrors } from "../../store/selectors/sales/scheduleForShipment";
import { closeModal, openModal } from "../../store/actions/common/modals";
import styles from "./ScheduleForShipment.module.scss";

type PropsT = {
  uploading: boolean,
  exportCsvScheduleForShipment: Function,
  importCsvScheduleForShipment: Function,
  openModal: Function,
  errorsList: string[]
};

const ScheduleForShipment = (props: PropsT) => {
  const { uploading, errorsList } = props;
  useEffect(() => {
    props.openModal();
  }, [errorsList]);

  const importCSV = csv => {
    props.importCsvScheduleForShipment(csv);
  };

  const exportCSV = () => {
    props.exportCsvScheduleForShipment();
  };

  return (
    <Paper square className="mainContent">
      <div className={styles.buttonsWrapper}>
        <UploadButton
          className={styles.uploadButton}
          type="button"
          color="secondary"
          accept=".csv"
          label="Завантажити СSV"
          handleFiles={importCSV}
        />

        <ContainedButton
          type="button"
          label="Вивантажити СSV"
          className={styles.uploadButton}
          handleClick={exportCSV}
          loading={uploading}
          disabled={uploading}
        />
        {errorsList && (
          <Modal type={"errorsModal"}>
            <ul>
              {errorsList.map((error, index) => (
                <li key={index}>{error}</li>
              ))}
            </ul>
          </Modal>
        )}
      </div>
    </Paper>
  );
};

const mapDispatchToProps = {
  exportCsvScheduleForShipment,
  importCsvScheduleForShipment,
  openModal,
  closeModal
};

const mapStateToProps = state => {
  const {
    scheduleForShipment: { importing, uploading }
  } = state;
  return { uploading, importing, errorsList: scheduleForShipmentErrors(state) };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ScheduleForShipment);
