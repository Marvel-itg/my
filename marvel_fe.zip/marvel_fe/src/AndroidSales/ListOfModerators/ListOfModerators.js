// @flow
import React from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import ModeratorsTable from "./ModeratorsTable/ModeratorsTable";
import DeactivateForm from "../../components/DeactivateForm/DeactivateForm";
import AdminProfileForm from "../AdminProfileForm/AdminProfileForm";
import Modal from "../../components/Modal/Modal";
import { toolbarOptions } from "../../constants";
import {
  receiveModerators,
  deactivateModeratorSales,
  activateModerator
} from "../../store/actions/sales/moderatorsListSales.js";
import { errorStateDeactivating, errorStateProfile } from "../../store/selectors/sales/moderator";
import { createModerator, clearModeratorInfo } from "../../store/actions/sales/moderatorProfile.js";
import { closeModal, openModal } from "../../store/actions/common/modals";
import { classes } from "../../helpers/spinner";
import { phoneWithCode } from "../../utils/formatValues.js";

type PropsT = {
  receiveModerators: Function,
  openModal: Function,
  closeModal: Function,
  moderatorsList: ModeratorT[],
  deactivateModeratorSales: Function,
  activateModerator: Function,
  createModerator: Function,
  clearModeratorInfo: Function,
  history: BrowserHistory,
  loading: boolean,
  modalIsOpened: boolean
};

type StateT = {
  value: string,
  modalBody: any,
  modalType: string,
  id: ?number
};

const tabs = Object.keys(toolbarOptions).map(keys => toolbarOptions[keys]);

class ListOfModerators extends React.Component<PropsT, StateT> {
  state = {
    value: "3",
    modalBody: <div />,
    modalType: "",
    id: null
  };

  componentDidMount() {
    this.props.receiveModerators(this.state.value);
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.value !== this.state.value) {
      this.props.receiveModerators(this.state.value);
    }
  }

  submitNewModeratorForm = values => {
    const phone = phoneWithCode(values.phone);
    const { firstName, lastName, middleName } = values;
    const normalizedValues = {
      firstName,
      lastName,
      middleName,
      phone
    };
    this.props.createModerator(normalizedValues);
  };

  submitDeactivateForm = values => {
    values.accountId = this.state.id;
    this.props.deactivateModeratorSales(values);
  };

  openDetails = (id: any) => {
    this.props.history.push(`/sales/moderators/${id || 1}`);
  };

  openModal = (type, id) => {
    switch (type) {
      case "add": {
        const modalBody = (
          <AdminProfileForm
            errorState={errorStateProfile}
            submitForm={this.submitNewModeratorForm}
            clearDataHandler={this.props.clearModeratorInfo}
            formTitle="Новий модератор"
            form="addModeratorForm"
          />
        );
        return this.setState({ modalBody, modalType: "" }, () => {
          this.props.openModal();
        });
      }
      case "deactivate": {
        const modalBody = (
          <DeactivateForm
            errorState={errorStateDeactivating}
            form="DeactivateModeratorsSales"
            title="Деактивувати модератора?"
            textFieldLabel="Додати коментар"
            textFieldName="comment"
            submitButtonText="Деактивувати"
            cancelButtonText="Ні"
            cancelButtonHandler={this.props.closeModal}
            submitForm={values => this.submitDeactivateForm(values)}
          />
        );
        return this.setState({ modalBody, modalType: "deactivate", id }, () => {
          this.props.openModal();
        });
      }
      default:
        return null;
    }
  };

  openAddModal = () => this.openModal("add");

  deactivateModerator = id => this.openModal("deactivate", id);

  activateModerator = id => {
    this.props.activateModerator(id);
  };

  changeTab = (event, value) => this.setState({ value });

  render() {
    const { moderatorsList } = this.props;

    return (
      <React.Fragment>
        <Paper square className="mainContent">
          <ModeratorsTable
            data={moderatorsList}
            activeTab={this.state.value}
            changeTab={this.changeTab}
            openModal={this.openAddModal}
            openDetails={this.openDetails}
            deactivateModerator={this.deactivateModerator}
            activateModerator={this.activateModerator}
            tabs={tabs}
          />
        </Paper>
        {this.props.loading && <CircularProgress classes={classes} />}
        <Modal formName="addModeratorForm" type={this.state.modalType}>
          {this.state.modalBody}
        </Modal>
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({
  moderatorsListSales: { moderatorsList, receiving, deactivating },
  moderatorProfile: { creating, error }
}) => ({
  moderatorsList,
  loading: receiving || creating || deactivating,
  creating,
  errorMessage: error
});

const mapDispatchToProps = {
  receiveModerators,
  deactivateModeratorSales,
  activateModerator,
  createModerator,
  clearModeratorInfo,
  closeModal,
  openModal
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(ListOfModerators);
