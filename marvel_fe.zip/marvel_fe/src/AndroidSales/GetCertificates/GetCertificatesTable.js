// @flow
import React from "react";
import { Grid, TableHeaderRow, Table } from "@devexpress/dx-react-grid-material-ui";
import { DateFormatProvider, CertificatesStatusProvider } from "../../components/FormattedData/FormattedData";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import GridRoot from "../../components/TableComponents/GridRoot";
import TableContainerComponent from "../../components/TableComponents/TableContainerComponent";
import PagingPanel from "../../components/TableComponents/PagingPanel";
import { defaultItemsPerPage, availableItemsPerPage, columnExtensions } from "../../constants";

type PropsT = {
  data: CertificatesStatusesListT[],
  columns: ColumnT[],
  page: number,
  count: number,
  total: number,
  changeCurrentPage: Function,
  changePageSize: Function
};

const forValues = {
  date: ["date"],
  statusId: ["statusId"]
};

const expandedColumnExtensions = [
  ...columnExtensions,
  { columnName: "date", width: 300 },
  { columnName: "totalAmount", width: 300 }
];

const CertificatesTable = (props: PropsT) => {
  const { columns, data, page, count, total, changeCurrentPage, changePageSize } = props;

  return (
    <Grid rows={data} columns={columns} rootComponent={GridRoot}>
      <PagingState
        currentPage={page}
        onCurrentPageChange={changeCurrentPage}
        pageSize={count || defaultItemsPerPage}
        onPageSizeChange={changePageSize}
      />
      <CustomPaging totalCount={total} />
      <CertificatesStatusProvider for={forValues.statusId} />
      <DateFormatProvider for={forValues.date} showTime />
      <Table height="auto" columnExtensions={expandedColumnExtensions} containerComponent={TableContainerComponent} />
      <TableHeaderRow />
      <PagingPanel pageSizes={availableItemsPerPage} noData={!total} />
    </Grid>
  );
};

export default CertificatesTable;
