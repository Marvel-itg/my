// @flow
import React from "react";
import { connect } from "react-redux";
import type { BrowserHistory } from "history";
import debounce from "es6-promise-debounce";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import Toolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import CertificatesTable from "./GetCertificatesTable";

import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  getCommonParams,
  shouldNotSendRequest,
  changeIssuerId,
  filterByDate
} from "../../helpers/common";
import { getNewCertificates, fetchCertificatesStatusesList } from "../../store/actions/sales/getCertificates";
import { classes } from "../../helpers/spinner";

type PropsT = {
  data: CertificatesStatusesListT[],
  loading: boolean,
  isFetching: Boolean,
  total: number,
  errorMessage: string
} & BrowserHistory;

const columns = [
  { name: "date", title: "Дата та час отримання нових сертифікатів" },
  { name: "statusId", title: "Статус отримання нових сертифікатів" },
  { name: "successfulAmount", title: "Кількість отриманих нових сертифікатів" }
];

class GetCertificates extends React.Component<PropsT> {
  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;

    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  changeIssuerId = (issuerId: OptionT) =>
    changeIssuerId(Number(issuerId.value), this.props.location.search, this.props.history);

  filterByDate = (rangeFilter: RangeFilterT) =>
    filterByDate(rangeFilter, this.props.location.search, this.props.history, this.props.location.state);

  fetchData = debounce(() => {
    const { itemsOnPage, pageNumber, issuerId, dateStart, dateEnd } = getCommonParams(this.props.location.search);

    const params = { itemsOnPage, pageNumber, issuerId, dateStart, dateEnd };
    this.props.fetchCertificatesStatusesList(params);
  }, 200);

  getNewCertificates = csv => {
    const { itemsOnPage, issuerId, dateStart, dateEnd } = getCommonParams(this.props.location.search);
    const params = { itemsOnPage, pageNumber: 1, issuerId, dateStart, dateEnd };
    this.props.getNewCertificates(issuerId, params);
  };

  render() {
    const { page, count } = getPaginationConfig(this.props.location.search);
    const { issuerId, dateStart, dateEnd } = getCommonParams(this.props.location.search);
    const { errorMessage, loading, total, issuerOptions } = this.props;
    const initialValues = { startDate: dateStart, endDate: dateEnd };

    return (
      <>
        <Toolbar
          initialValues={initialValues}
          filterData={this.filterByDate}
          hasExportButton
          exportButtonLabel="Отримати нові сертифікти"
          exportButtonColor="secondary"
          loadHandler={this.getNewCertificates}
          withIssuerSelect
          issuerOptions={issuerOptions}
          onIssuerChange={this.changeIssuerId}
          issuerId={issuerId}
          errorMessage={errorMessage}
          uploading={loading}
          form="getCertificates"
        />

        <Paper square className="mainContent">
          <CertificatesTable
            data={this.props.data}
            columns={columns}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            page={page}
            count={count}
            total={total}
          />
          {this.props.isFetching && <CircularProgress classes={classes} />}
        </Paper>
      </>
    );
  }
}

const mapStateToProps = state => {
  const {
    certificates: { issuerOptions },
    getNewCertificates: { rowsCount, data, isFetching, fetchingError, error, loading }
  } = state;
  return {
    data,
    issuerOptions,
    loading,
    total: rowsCount,
    errorMessage: error,
    isFetching,
    fetchingError
  };
};

const mapDispatchToProps = { fetchCertificatesStatusesList, getNewCertificates };

export default connect(mapStateToProps, mapDispatchToProps)(GetCertificates);
