// @flow
import React from "react";
import { Editor } from "react-draft-wysiwyg";
import { EditorState, ContentState } from "draft-js";
import Paper from "@material-ui/core/Paper";
import draftToHtml from "draftjs-to-html";
import htmlToDraft from "html-to-draftjs";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { convertToRaw } from "draft-js";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import { receiveAboutCompanyInfo, saveAboutCompanyInfo } from "../../store/actions/sales/aboutCompanySales";
import styles from "./AboutCompany.module.scss";
// $FlowFixMe
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";

type PropsT = {
  receiveAboutCompanyInfo: Function,
  saveAboutCompanyInfo: Function,
  aboutCompanyInfo: string
};

type StateT = {
  editorState: {
    getCurrentContent: Function
  },
  isEdit: boolean,
  isReadOnlyEditor: boolean
};

class AboutCompany extends React.Component<PropsT, StateT> {
  state = {
    editorState: EditorState.createEmpty(),
    isEdit: false,
    isReadOnlyEditor: false
  };

  componentDidMount() {
    this.props.receiveAboutCompanyInfo();
    if (this.props.aboutCompanyInfo) {
      this.setEditorState(this.props.aboutCompanyInfo);
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.aboutCompanyInfo !== prevProps.aboutCompanyInfo) {
      this.setEditorState(this.props.aboutCompanyInfo);
    }
  }

  setEditorState = aboutCompanyInfo => {
    if (aboutCompanyInfo) {
      const contentBlock = htmlToDraft(aboutCompanyInfo);
      const contentState = ContentState.createFromBlockArray(contentBlock.contentBlocks);
      const editorState = EditorState.createWithContent(contentState);
      this.setState({
        editorState,
        isEdit: true,
        isReadOnlyEditor: true
      });
    }
  };

  onEditorStateChange = editorState => {
    this.setState({
      editorState
    });
  };

  onSave = () => {
    this.setState({
      isEdit: true,
      isReadOnlyEditor: true
    });
    this.props.saveAboutCompanyInfo(draftToHtml(convertToRaw(this.state.editorState.getCurrentContent())));
  };

  onEdit = () => {
    this.setState({
      isReadOnlyEditor: false,
      isEdit: false
    });
  };

  handleClick = () => {
    if (this.state.isEdit) {
      this.onEdit();
    } else {
      this.onSave();
    }
  };

  render() {
    const { editorState } = this.state;

    return (
      <>
        <Paper square className="mainContent">
          <Editor
            editorClassName={styles.editorStyles}
            toolbarClassName={styles.toolbarStyles}
            onEditorStateChange={this.onEditorStateChange}
            editorState={editorState}
            readOnly={this.state.isReadOnlyEditor}
          />
        </Paper>
        <ContainedButton
          label={this.state.isEdit ? "Редагувати" : "Зберегти"}
          handleClick={this.handleClick}
          className={styles.buttonStyles}
        />
      </>
    );
  }
}

const mapStateToProps = ({ aboutCompanySales: { aboutCompanyInfo } }) => ({
  aboutCompanyInfo
});

const mapDispatchToProps = {
  receiveAboutCompanyInfo,
  saveAboutCompanyInfo
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(AboutCompany);
