export const columns = [
  { name: "accountId", title: "ID користувача" },
  { name: "fullName", title: "ПІБ" },
  { name: "phone", title: "Мобільний телефон" },
  { name: "posCodes", title: "Код TT" },
  { name: "bonusesByRegistration", title: "Кількість нарахованих балів за Реєстрацію" },
  { name: "bonusesByTest", title: "Кількість нарахованих балів за Завдання Тестове" },
  { name: "bonusesByFoil", title: "Кількість нарахованих балів за Завдання Фольга" },
  { name: "bonusesByInfo", title: "Кількість нарахованих балів за Завдання Інформаційне" },
  { name: "bonusesByOrderTask", title: "Кількість нарахованих балів за Завдання Замовлення" },
  { name: "bonusesByPhoto", title: "Кількість нарахованих балів за Завдання Фото" },
  { name: "bonusesByFeedback", title: "Кількість нарахованих балів за Завдання Тестове-Зворотній зв'язок" },
  { name: "additionalBonuses", title: "Кількість додатково нарахованих балів" },
  { name: "bonusesByOrder", title: "Кількість нарахованих балів за Замовлення" },
  { name: "bonusesByQuestionnaire", title: "Кількість нарахованих балів за Завдання Анкета" },
  { name: "bonusesByScanCodes", title: "Кількість нарахованих балів за Завдання Сканування кодів" },
  { name: "bonusesByMidPlusTask", title: "Кількість нарахованих балів за Завдання MID+" },
  { name: "writeOffExchangeOnGift", title: "Кількість балів списаних на подарунок за період" },
  { name: "writeOffExchangeOnPhone", title: "Кількість балів списаних на поповнення за період" },
  { name: "writeOffExchangeOnCertificate", title: "Кількість балів списаних на сертифікати за період" },
  { name: "totalWriteOff", title: "Всього кількість списаних балів за період" },
  { name: "totalAccrual", title: "Всього кількість зароблених балів за період" },
  { name: "expiredBonuses", title: "Кількість списаних балів, у яких закінчився термін дії" },
  { name: "availableBonusesByPeriodEnd", title: "Баланс на кінець періоду" },
  { name: "availableBonuses", title: "Кількість балів на рахунку на поточний момент" },
  { name: "pendingWriteOff", title: "Кількість балів в очікуванні списання" },
  { name: "pendingAccrual", title: "Кількість балів в очікуванні нарахування" },
  { name: "details", title: "Детальнiше" }
];

export const bonusColumnExtensions = [
  { columnName: "accountId", width: 130 },
  { columnName: "fullName", width: 270 },
  { columnName: "phone", width: 200 },
  { columnName: "posCodes", width: 200 }
];

export const bonusDetailsColumnExtensions = [
  { columnName: "comment", width: 300 },
  { columnName: "statusName", width: 280 }
];
