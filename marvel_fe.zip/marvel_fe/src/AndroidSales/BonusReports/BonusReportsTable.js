// @flow
import React from "react";
import { Grid, Table, TableHeaderRow, Toolbar } from "@devexpress/dx-react-grid-material-ui";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import WithStickyBandsTable from "../../HOCs/withStickyBandsTable";
import GridRoot from "../../components/TableComponents/GridRoot";
import HeaderWrap from "../../components/TableComponents/HeaderWrap";
import TableContainerComponent from "../../components/TableComponents/TableContainerComponent";
import { ListProvider, TransparentButtonProvider } from "../../components/FormattedData/FormattedData";
import PagingPanel from "../../components/TableComponents/PagingPanel";
import SearchForm from "../../components/TableComponents/SearchForm/SearchForm";
import { availableItemsPerPage, bonusReportSearchOptions, columnExtensions } from "../../constants";
import { columns, bonusColumnExtensions } from "./constants";

type PropsT = {
  data: any,
  changeCurrentPage: Function,
  changePageSize: Function,
  currentPage: number,
  pageSize: number,
  rowsCount: number,
  openDetails: Function
} & BonusReportsT;

const forValues = {
  posCodes: ["posCodes"],
  details: ["details"]
};

const expandedColumnExtensions = [...columnExtensions, ...bonusColumnExtensions];

function BonusReportsTable(props: PropsT) {
  const { data, currentPage, pageSize, rowsCount, openDetails, changePageSize, changeCurrentPage } = props;

  return (
    <Grid rows={data} columns={columns} rootComponent={GridRoot}>
      <PagingState
        pageSize={pageSize}
        currentPage={currentPage}
        onCurrentPageChange={changeCurrentPage}
        onPageSizeChange={changePageSize}
      />
      <ListProvider for={forValues.posCodes} />
      <TransparentButtonProvider for={forValues.details} onClick={openDetails} label="Детальніше" />

      <CustomPaging totalCount={rowsCount} />

      <Table height="auto" containerComponent={TableContainerComponent} columnExtensions={expandedColumnExtensions} />

      <TableHeaderRow cellComponent={HeaderWrap} />
      <Toolbar />

      <PagingPanel pageSizes={availableItemsPerPage} noData={!data.length} />
      <SearchForm selectOptions={bonusReportSearchOptions} placeholder="Пошук" />
    </Grid>
  );
}

export default WithStickyBandsTable(BonusReportsTable);
