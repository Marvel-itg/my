// @flow
import React from "react";
import moment from "moment";
import { connect } from "react-redux";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import type { BrowserHistory } from "history";
import ReportToolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import BackButton from "../../components/Buttons/BackButton/BackButton";
import BonusReportDetailsTable from "./BonusReportDetailsTable";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  filterByDate,
  getCommonParams,
  shouldNotSendRequest
} from "../../helpers/common";
import { defaultItemsPerPage, bonusReportSearchOptions } from "../../constants";
import { getBonusReportDetails, exportBonusReportDetails } from "../../store/actions/sales/bonusReportsSales";
import { detailedBonusReportSelector, detailedReportRowsCount } from "../../store/selectors/sales/bonusReports";
import { classes } from "../../helpers/spinner";
import styles from "./BonusReportDetailsList.module.scss";

type PropsT = {
  reportDetailsData: DetailedBonusReportT,
  detailedRowsCount: number,
  uploadingError: string,
  getBonusReportDetails: Function,
  exportBonusReportDetails: Function
} & BrowserHistory;

const columns = [
  { name: "date", title: "Дата та час транзакції" },
  { name: "typeName", title: "Aктивність" },
  { name: "value", title: "Кількість балів" },
  { name: "statusName", title: "Статус" },
  { name: "comment", title: "Коментар" }
];

class BonusReportDetailsList extends React.Component<PropsT> {
  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;

    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history, this.props.location.state);

  changePageSize = (pageSize: number) =>
    changePageSize(pageSize, this.props.location.search, this.props.history, this.props.location.state);

  filterByDate = (rangeFilter: RangeFilterT) =>
    filterByDate(rangeFilter, this.props.location.search, this.props.history, this.props.location.state);

  fetchData = () => {
    const { dateStart, dateEnd, itemsOnPage, pageNumber } = getCommonParams(this.props.location.search);
    const { id } = this.props.match.params;
    const params = {
      dateStart,
      dateEnd,
      accountId: id,
      itemsOnPage,
      pageNumber
    };
    this.props.getBonusReportDetails(params);
  };

  exportCSV = () => {
    const { dateStart, dateEnd } = getCommonParams(this.props.location.search);
    const { id } = this.props.match.params;
    const params = { dateStart, dateEnd, accountId: id };
    this.props.exportBonusReportDetails(params);
  };

  goBack = () => {
    if (this.props.location.state) {
      const { returnUrl } = this.props.location.state;
      this.props.history.push(returnUrl);
    } else {
      // eslint-disable-next-line
      const defaultReturnUrl = `/sales/bonus-reports?page=1&count=${defaultItemsPerPage}&start=${moment()
        .subtract(1, "month")
        .format("DD/MM/YYYY")}&end=${moment()
        .endOf("day")
        .format("DD/MM/YYYY")}&searchField=${bonusReportSearchOptions[0].value}`;
      this.props.history.push(defaultReturnUrl);
    }
  };

  render() {
    const { loading, uploading, detailedRowsCount, reportDetailsData, uploadingError } = this.props;
    const { dateStart, dateEnd } = getCommonParams(this.props.location.search);
    const { page, count } = getPaginationConfig(this.props.location.search);
    const initialValues = { startDate: dateStart, endDate: dateEnd };
    return (
      <React.Fragment>
        <BackButton label="Повернутися до списку" className={styles.backButtonStyles} handleClick={this.goBack} />
        <ReportToolbar
          hasExportButton
          form="bonusReportDetailsFilter"
          filterData={this.filterByDate}
          initialValues={initialValues}
          loadHandler={this.exportCSV}
          disabled={loading || uploading}
          uploading={uploading}
          errorMessage={uploadingError}
        />
        <Paper square className="mainContent">
          <BonusReportDetailsTable
            data={reportDetailsData}
            columns={columns}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            page={page}
            count={count}
            total={detailedRowsCount}
          />
        </Paper>
        {loading && <CircularProgress classes={classes} />}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    bonusReports: { uploading, loading, uploadingError }
  } = state;
  return {
    reportDetailsData: detailedBonusReportSelector(state),
    detailedRowsCount: detailedReportRowsCount(state),
    uploadingError,
    uploading,
    loading
  };
};

const mapDispatchToProps = {
  getBonusReportDetails,
  exportBonusReportDetails
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(BonusReportDetailsList);
