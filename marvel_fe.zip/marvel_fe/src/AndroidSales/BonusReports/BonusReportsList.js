// @flow
import React from "react";
import { compose } from "redux";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import debounce from "es6-promise-debounce";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import BonusReportsTable from "./BonusReportsTable";
import ReportToolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import { fetchBonusReports, exportBonusReportsCSV } from "../../store/actions/sales/bonusReportsSales";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  filterByDate,
  getCommonParams,
  getSearchQuery,
  shouldNotSendRequest
} from "../../helpers/common";
import { defaultItemsPerPage } from "../../constants";
import { classes } from "../../helpers/spinner";

type PropsT = {
  fetchBonusReports: Function,
  exportBonusReportsCSV: Function,
  loading: boolean,
  uploading: boolean,
  data: FormattedBonusReportsDataT[],
  rowsCount: number,
  uploadingError: string
} & BrowserHistory;

class BonusReportsList extends React.Component<PropsT> {
  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;
    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
  }

  fetchData = debounce(() => {
    const { dateStart, dateEnd, itemsOnPage, pageNumber, searchFieldName, searchValue } = getCommonParams(
      this.props.location.search
    );
    let params = { dateStart, dateEnd, itemsOnPage, pageNumber, searchFieldName, searchValue };
    if (searchValue) {
      params = { ...params, searchFieldName, searchValue };
    }
    this.props.fetchBonusReports(params);
  }, 500);

  exportCSV = () => {
    const { dateStart, dateEnd, searchFieldName, searchValue } = getCommonParams(this.props.location.search);
    const params = { dateStart, dateEnd, searchFieldName, searchValue };
    this.props.exportBonusReportsCSV(params);
  };

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history, this.props.location.state);

  changePageSize = (pageSize: number) =>
    changePageSize(pageSize, this.props.location.search, this.props.history, this.props.location.state);

  filterByDate = (rangeFilter: RangeFilterT) =>
    filterByDate(rangeFilter, this.props.location.search, this.props.history, this.props.location.state);

  openDetails = (id, rowData) => {
    const { start, end, page, count, searchField, searchValue } = getSearchQuery(this.props.location.search);
    const idForDetails = rowData.accountId;
    const returnUrl = `/sales/bonus-reports?${page}${count}${start}${end}${searchField}${searchValue}`;
    return this.props.history.push(`bonus-reports/${idForDetails}?page=1&count=${defaultItemsPerPage}${start}${end}`, {
      returnUrl
    });
  };

  render() {
    const { loading, uploading, rowsCount, uploadingError } = this.props;
    const { dateStart, dateEnd } = getCommonParams(this.props.location.search);
    const { page, count } = getPaginationConfig(this.props.location.search);
    const initialValues = { startDate: dateStart, endDate: dateEnd };
    return (
      <React.Fragment>
        <ReportToolbar
          hasExportButton
          form="bonusReportsDateFilter"
          filterData={this.filterByDate}
          initialValues={initialValues}
          loadHandler={this.exportCSV}
          uploading={uploading}
          disabled={loading || uploading}
          errorMessage={uploadingError}
        />

        <Paper square className="mainContent">
          <BonusReportsTable
            data={this.props.data}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            currentPage={page}
            pageSize={count}
            rowsCount={rowsCount}
            openDetails={this.openDetails}
          />

          {loading && <CircularProgress classes={classes} />}
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    bonusReports: { rowsCount, loading, uploading, uploadingError, data }
  } = state;
  return {
    data,
    rowsCount,
    loading,
    uploading,
    uploadingError
  };
};

const mapDispatchToProps = {
  fetchBonusReports,
  exportBonusReportsCSV
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(BonusReportsList);
