// @flow
import React from "react";
import { Grid, Table, TableHeaderRow, PagingPanel } from "@devexpress/dx-react-grid-material-ui";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import { DateFormatProvider, TextProvider } from "../../components/FormattedData/FormattedData";
import GridRoot from "../../components/TableComponents/GridRoot";
import TableContainer from "../../components/TableComponents/TableContainer";
import HeaderWrap from "../../components/TableComponents/HeaderWrap";
import { availableItemsPerPage, defaultItemsPerPage, columnExtensions } from "../../constants";
import { bonusDetailsColumnExtensions } from "./constants";

type PropsT = {
  data: any,
  columns: ColumnT[],
  page: number,
  count: number,
  total: number,
  changeCurrentPage: Function,
  changePageSize: Function
};

const forValues = {
  date: ["date"],
  comment: ["comment"]
};

const expandedColumnExtensions = [...columnExtensions, ...bonusDetailsColumnExtensions];

const BonusReportDetails = (props: PropsT) => {
  const { data, columns, page, count, changeCurrentPage, changePageSize, total } = props;

  return (
    <Grid rows={data || []} columns={columns} rootComponent={GridRoot}>
      <PagingState
        currentPage={page || 0}
        onCurrentPageChange={changeCurrentPage}
        pageSize={count || defaultItemsPerPage}
        onPageSizeChange={changePageSize}
      />
      <DateFormatProvider for={forValues.date} dateAndTimeWithSeconds />
      <TextProvider for={forValues.comment} />

      <CustomPaging totalCount={total} />
      <Table height="auto" containerComponent={TableContainer} columnExtensions={expandedColumnExtensions} />

      <TableHeaderRow cellComponent={HeaderWrap} />
      <PagingPanel pageSizes={availableItemsPerPage} noData={!total} />
    </Grid>
  );
};

export default BonusReportDetails;
