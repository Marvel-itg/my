// @flow
import React from "react";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { compose } from "redux";
import type { BrowserHistory } from "history";
import CircularProgress from "@material-ui/core/CircularProgress";
import Paper from "@material-ui/core/Paper";
import ExchangeToGiftRequestsTable from "./ExchangeToGiftRequestsTable/ExchangeToGiftRequestsTable";
import Toolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import { fetchExchangeToGiftRequests, exportToCsvGiftRequests } from "../../store/actions/sales/exchangeToGiftRequests";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  filterByDate,
  getCommonParams,
  changeTab
} from "../../helpers/common";
import { classes } from "../../helpers/spinner";

type PropsT = {
  fetchExchangeToGiftRequests: Function,
  exchangeToGiftRequests: ExchangeToGiftRequestT[],
  loading: boolean,
  uploading: boolean,
  total: number,
  exportToCsvGiftRequests: Function
} & BrowserHistory;

type StateT = {
  status: string,
  rangeFilter: Object,
  pageNumber: number,
  itemsOnPage: number
};

const commonColumns = [
  { name: "id", title: "ID" },
  { name: "lastName", title: "Прізвище", getCellValue: row => row.requester && row.requester.lastName },
  { name: "firstName", title: "Ім'я", getCellValue: row => row.requester && row.requester.firstName },
  { name: "middleName", title: "По батькові", getCellValue: row => row.requester && row.requester.middleName },
  { name: "posAddress", title: "Адреса ТТ" },
  { name: "posCode", title: "Код ТТ" },
  { name: "requesterId", title: "ID користувача", getCellValue: row => row.requester && row.requester.id },
  { name: "phone", title: "Номер телефону", getCellValue: row => row.requester && row.requester.phone },
  { name: "count", title: "Кількість балів" },
  { name: "code", title: "Код запиту" },
  { name: "creationDate", title: "Дата та час запиту" }
];

const columns = {
  "1": [...commonColumns],
  "2": [
    ...commonColumns,
    { name: "processedDate", title: "Дата та час обробки запиту" },
    {
      name: "processedBy",
      title: "ПІБ ТП, що обробив запит",
      getCellValue: row => row.processedBy && row.processedBy.fullName
    },
    { name: "status", title: "Статус" }
  ]
};
class ExchangeToGiftRequests extends React.Component<PropsT, StateT> {
  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;
    if (prevProps.location.key !== key) {
      this.fetchData();
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  filterByDate = (rangeFilter: RangeFilterT) =>
    filterByDate(rangeFilter, this.props.location.search, this.props.history);

  getSearchData = () => {
    const { dateStart, dateEnd, itemsOnPage, pageNumber, tab = "1" } = getCommonParams(this.props.location.search);
    const params = { dateStart, dateEnd, itemsOnPage, pageNumber, status: tab, type: 2 };
    return params;
  };

  fetchData = () => {
    this.props.fetchExchangeToGiftRequests(this.getSearchData());
  };

  changeTab = (event: any, tab: string) => changeTab(tab, this.props.location.search, this.props.history);

  exportCSV = () => {
    const { dateStart, dateEnd, status, type } = this.getSearchData();
    const params = { dateStart, dateEnd, status, type };
    this.props.exportToCsvGiftRequests(params);
  };

  render() {
    const { page, count, tab } = getPaginationConfig(this.props.location.search);
    const { dateStart, dateEnd } = getCommonParams(this.props.location.search);
    const initialValues = { startDate: dateStart, endDate: dateEnd };
    const { loading, uploading } = this.props;

    return (
      <React.Fragment>
        <Toolbar
          hasExportButton
          form="exchangeRequestGiftDateFilter"
          filterData={this.filterByDate}
          loadHandler={this.exportCSV}
          initialValues={initialValues}
          disabled={loading || uploading}
          uploading={uploading}
        />
        <Paper square className="mainContent">
          <ExchangeToGiftRequestsTable
            data={this.props.exchangeToGiftRequests}
            total={this.props.total}
            activeTab={tab || "1"}
            changeTab={this.changeTab}
            columns={columns[tab || "1"]}
            page={page}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            count={count}
          />
        </Paper>
        {this.props.loading && <CircularProgress classes={classes} />}
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({ exchangeToGiftRequestsList: { loading, exchangeToGiftRequests, total, uploading } }) => {
  return {
    loading,
    uploading,
    exchangeToGiftRequests,
    total
  };
};

const mapDispatchToProps = {
  fetchExchangeToGiftRequests,
  exportToCsvGiftRequests
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(ExchangeToGiftRequests);
