// @flow
import React from "react";
import moment from "moment";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import UsersInfoTableSales from "./UsersInfoTableSales";
import ExportTablesToolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import { fetchUsersInfoList, exportUsersInfoCSV } from "../../store/actions/sales/usersInfoSales";
import { classes } from "../../helpers/spinner";

type PropsT = {
  fetchUsersInfoList: Function,
  exportUsersInfoCSV: Function,
  loading: boolean,
  uploading: boolean,
  usersInfoList: UserInfoT[]
};

type StateT = {
  visibleColumns: string[]
};

class ListOfUsersInfoSales extends React.Component<PropsT, StateT> {
  state = {
    visibleColumns: [
      "id",
      "lastName",
      "firstName",
      "middleName",
      "phone",
      "posId",
      "startAppDate",
      "salesRepresentative"
    ]
  };

  componentDidMount() {
    this.props.fetchUsersInfoList();
  }

  filterByDate = rangeFilter => {
    this.props.fetchUsersInfoList(rangeFilter);
  };

  exportCSV = () => {
    // pass data as param for export
    this.props.exportUsersInfoCSV(this.state.visibleColumns);
  };

  changeVisibleColumns = (newVisible: string[]) =>
    this.setState({
      visibleColumns: newVisible
    });

  render() {
    const { loading, uploading } = this.props;
    const spinner = loading || uploading;
    const rangeFilterInitial = {
      startDate: moment()
        .subtract(1, "months")
        .startOf("day")
        .format("DD/MM/YYYY"),
      endDate: moment()
        .endOf("day")
        .format("DD/MM/YYYY")
    };
    return (
      <React.Fragment>
        <ExportTablesToolbar
          form="usersListDateFilter"
          initialValues={rangeFilterInitial}
          filterData={this.filterByDate}
          loadHandler={this.exportCSV}
          hasExportButton
        />
        <Paper square className="mainContent">
          <UsersInfoTableSales data={this.props.usersInfoList || []} hideColumns={this.changeVisibleColumns} />
          {spinner && <CircularProgress classes={classes} />}
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({ usersInfoList: { usersInfoList, loading, uploading } }) => ({
  usersInfoList,
  loading,
  uploading
});

const mapDispatchToProps = {
  fetchUsersInfoList,
  exportUsersInfoCSV
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(ListOfUsersInfoSales);
