// @flow
import React from "react";
import {
  Grid,
  TableHeaderRow,
  Table,
  Toolbar,
  ColumnChooser,
  TableColumnVisibility
} from "@devexpress/dx-react-grid-material-ui";

import {
  SearchState,
  IntegratedFiltering,
  IntegratedSorting,
  PagingState,
  IntegratedPaging,
  SortingState
} from "@devexpress/dx-react-grid";
import IconButton from "@material-ui/core/IconButton";
import SettingsIcon from "@material-ui/icons/Settings";
import {
  PhoneProvider,
  GenderProvider,
  DateFormatProvider,
  PersonInfoProvider
} from "../../components/FormattedData/FormattedData";
import ToolbarRoot from "../../components/TableComponents/ToolbarRoot";
import GridRoot from "../../components/TableComponents/GridRoot";
import TableContainerComponent from "../../components/TableComponents/TableContainerComponent";
import PagingPanel from "../../components/TableComponents/PagingPanel";
import { availableItemsPerPage, defaultItemsPerPage } from "../../constants";
import SearchForm from "../../components/TableComponents/SearchForm/SearchForm";

type PropsT = {
  data: UserInfoT[],
  hideColumns: Function
};
type StateT = {
  currentPage: number,
  pageSize: number,
  pageSizes: Array<number>,
  sorting: SortT[]
};

const columns = [
  { name: "id", title: "ID" },
  { name: "lastName", title: "Прiзвище" },
  { name: "firstName", title: "Ім'я" },
  { name: "middleName", title: "По батьковi" },
  { name: "phone", title: "Tелефон" },
  { name: "birthday", title: "Дата народження" },
  { name: "gender", title: "Стать" },
  { name: "posId", title: "Код ТТ" },
  { name: "address", title: "Адреса" },
  { name: "shopName", title: "Назва ТТ" },
  { name: "netName", title: "Назва мережі" },
  { name: "netId", title: "Код мережі" },
  { name: "startAppDate", title: "Дата початку використання додатку" },
  { name: "salesRepresentative", title: "Торгівельний представник" },
  { name: "region", title: "Регіон" },
  { name: "lastActiveDate", title: "Дата останньої активності" },
  { name: "city", title: "Місто" }
];

const statisticReportOptions = [
  { value: "lastName", label: "Прiзвище" },
  { value: "firstName", label: "Ім'я" },
  { value: "middleName", label: "По батьковi" },
  { value: "phone", label: "Tелефон" },
  { value: "posId", label: "Код ТТ" },
  { value: "shopName", label: "Назва ТТ" },
  { value: "netName", label: "Назва мережі" },
  { value: "netId", label: "Код мережі" },
  { value: "salesRepresentative", label: "Торгівельний представник" },
  { value: "region", label: "Регіон" }
];

const defaultHiddenColumnNames = ["address", "netName", "netId", "birthday", "gender", "shopName", "region"];

const columnExtensions = [{ columnName: "phone", width: 140 }, { columnName: "salesRepresentative", width: 220 }];

const sortingStateColumnExtensions = [
  { columnName: "id", sortingEnabled: false },
  { columnName: "lastName", sortingEnabled: true },
  { columnName: "firstName", sortingEnabled: true },
  { columnName: "middleName", sortingEnabled: true },
  { columnName: "phone", sortingEnabled: false },
  { columnName: "birthday", sortingEnabled: false },
  { columnName: "gender", sortingEnabled: false },
  { columnName: "posId", sortingEnabled: false },
  { columnName: "address", sortingEnabled: false },
  { columnName: "shopName", sortingEnabled: false },
  { columnName: "netName", sortingEnabled: false },
  { columnName: "netId", sortingEnabled: false },
  { columnName: "startAppDate", sortingEnabled: false },
  { columnName: "salesRepresentative", sortingEnabled: false },
  { columnName: "region", sortingEnabled: false }
];

const style = { margin: "0 5px 5px 15px" };
const SettingsButton = props => {
  return (
    <IconButton style={style} onClick={props.onToggle}>
      <SettingsIcon />
    </IconButton>
  );
};

const forValues = {
  phone: ["phone"],
  birthday: ["birthday"],
  startDate: ["startAppDate"],
  lastActiveDate: ["lastActiveDate"],
  salesRepresentative: ["salesRepresentative"],
  gender: ["gender"]
};

class UsersInfoTableSales extends React.Component<PropsT, StateT> {
  state = {
    pageSize: defaultItemsPerPage,
    pageSizes: availableItemsPerPage,
    currentPage: 0,
    sorting: []
  };

  changeCurrentPage = (currentPage: number) => this.setState({ currentPage });

  changePageSize = (pageSize: number) => this.setState({ pageSize });

  changeSorting = (sorting: SortT[]) => this.setState({ sorting });

  hiddenColumnHandler = (hiddenColumns: string[]) => {
    const visibleColumns = columns.filter(col => !hiddenColumns.includes(col.name)).map(col => col.name);
    this.props.hideColumns(visibleColumns);
  };

  render() {
    const { data } = this.props;
    const { pageSize, pageSizes, currentPage, sorting } = this.state;
    return (
      <Grid rows={data} columns={columns} rootComponent={GridRoot}>
        <SearchState />
        <SortingState
          sorting={sorting}
          onSortingChange={this.changeSorting}
          columnExtensions={sortingStateColumnExtensions}
        />
        <PagingState
          currentPage={currentPage}
          onCurrentPageChange={this.changeCurrentPage}
          pageSize={pageSize}
          onPageSizeChange={this.changePageSize}
        />

        <IntegratedFiltering />
        <IntegratedSorting />
        <IntegratedPaging />

        <PhoneProvider for={forValues.phone} />
        <DateFormatProvider for={forValues.birthday} />
        <DateFormatProvider for={forValues.startDate} />
        <DateFormatProvider for={forValues.lastActiveDate} />
        <PersonInfoProvider for={forValues.salesRepresentative} />
        <GenderProvider for={forValues.gender} />

        <Table columnExtensions={columnExtensions} containerComponent={TableContainerComponent} />
        <TableColumnVisibility
          defaultHiddenColumnNames={defaultHiddenColumnNames}
          onHiddenColumnNamesChange={this.hiddenColumnHandler}
        />
        <TableHeaderRow showSortingControls />

        <Toolbar rootComponent={ToolbarRoot} />
        <PagingPanel pageSizes={pageSizes} noData={!data.length} />
        <SearchForm selectOptions={statisticReportOptions} placeholder="Пошук" />
        <ColumnChooser
          icon="find"
          toggleButtonComponent={props => {
            return <SettingsButton {...props} />;
          }}
        />
      </Grid>
    );
  }
}

export default UsersInfoTableSales;
