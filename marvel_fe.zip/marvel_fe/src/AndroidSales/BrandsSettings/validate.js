import { validationErrorMessages } from "../../constants";

const validate = values => {
  const { required } = validationErrorMessages();
  const errors = {};
  const brandsErrors = [];

  const { brands } = values;

  brands &&
    brands.forEach((brand, brandIdx) => {
      const brandErrors = {};
      const linesErrors = [];

      if (!brand.brandsSettingsImage || brand.brandsSettingsImage.length < 1) {
        brandErrors.brandsSettingsImage = required;
        brandsErrors[brandIdx] = brandErrors;
      }

      if (!brand.brandSettingsHtml) {
        brandErrors.brandSettingsHtml = required;
        brandsErrors[brandIdx] = brandErrors;
      } else if (typeof brand.brandSettingsHtml !== "string" && brand.brandSettingsHtml.size > 2097152) {
        brandErrors.brandSettingsHtml = "Розмір файлу не має перевищувати 2 Mb";
        brandsErrors[brandIdx] = brandErrors;
      } else if (typeof brand.brandSettingsHtml !== "string" && brand.brandSettingsHtml.type !== "text/html") {
        brandErrors.brandSettingsHtml = "HTML файл повинен мати .html розширення";
        brandsErrors[brandIdx] = brandErrors;
      }

      if (!brand || !brand.brandsSettingsHex) {
        brandErrors.brandsSettingsHex = required;
        brandsErrors[brandIdx] = brandErrors;
      } else if (!/^([0-9A-F]{6}){1,2}$/i.test(brand.brandsSettingsHex)) {
        brandErrors.brandsSettingsHex = validationErrorMessages().notCorrectData;
        brandsErrors[brandIdx] = brandErrors;
      }

      brand.lines &&
        brand.lines.forEach((line, lineIdx) => {
          const lineErrors = {};

          if (!line.brandsSettingsLineName) {
            lineErrors.brandsSettingsLineName = required;
            linesErrors[lineIdx] = lineErrors;
          }

          if (
            line.brandSettingsLineHtml &&
            typeof line.brandSettingsLineHtml !== "string" &&
            line.brandSettingsLineHtml.size > 2097152
          ) {
            lineErrors.brandSettingsLineHtml = "Розмір файлу не має перевищувати 2 Mb";
            linesErrors[lineIdx] = lineErrors;
          }
          if (
            line.brandSettingsLineHtml &&
            typeof line.brandSettingsLineHtml !== "string" &&
            line.brandSettingsLineHtml.type !== "text/html"
          ) {
            lineErrors.brandSettingsLineHtml = "HTML файл повинен мати .html розширення";
            linesErrors[lineIdx] = lineErrors;
          }
          if (!line.brandsSettingsLineHex) {
            lineErrors.brandsSettingsLineHex = required;
            linesErrors[lineIdx] = lineErrors;
          } else if (!/^([0-9A-F]{6}){1,2}$/i.test(line.brandsSettingsLineHex)) {
            lineErrors.brandsSettingsLineHex = validationErrorMessages().notCorrectData;
            linesErrors[lineIdx] = lineErrors;
          }
        });

      if (linesErrors.length > 0) {
        brandErrors.lines = linesErrors;
        brandsErrors[brandIdx] = brandErrors;
      }
    });

  if (brandsErrors.length > 0) errors.brands = brandsErrors;

  return errors;
};

export default validate;
