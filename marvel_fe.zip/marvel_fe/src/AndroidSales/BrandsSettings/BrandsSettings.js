// @flow
import React, { useEffect } from "react";
import { connect } from "react-redux";
import type { FormProps } from "redux-form";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import BrandSettingsForm from "./BrandSettingsForm";
import { getBrandSettings } from "../../store/actions/admin/brandSettings";

import brandsStyles from "./BrandsSettings.module.scss";

type PropsT = {
  loading: boolean,
  isDataLoaded: boolean,
  getBrandSettings: Function
} & FormProps;

const paperBrandStyle = { root: brandsStyles.paper };

function BrandSettings(props: PropsT) {
  useEffect(() => {
    props.getBrandSettings();
  }, []);

  return !props.isDataLoaded || props.loading ? (
    <CircularProgress classes={{ root: "spinner" }} />
  ) : (
    <Paper classes={paperBrandStyle}>
      <BrandSettingsForm />
    </Paper>
  );
}

const mapStateToProps = state => {
  const brandSettings = state.brandSettings;
  return {
    isDataLoaded: !!brandSettings.brandSettings,
    loading: brandSettings.loading
  };
};

const mapDispatchToProps = {
  getBrandSettings
};
export default connect(mapStateToProps, mapDispatchToProps)(BrandSettings);
