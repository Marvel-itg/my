import React, { useState } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { FieldArray, reduxForm, formValueSelector } from "redux-form";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import BrandsSettingsItem from "./BrandItem/BrandsSettingsItem";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import { setUploadBrandSettings } from "../../store/actions/admin/brandSettings";
import { reducerDataToFormValues } from "../../store/selectors/admin/brandSettings";
import validate from "./validate";

import brandsStyles from "./BrandsSettings.module.scss";

export const BRAND_SETTINGS_FORM = "brandsSettingsForm";

const renderBrands = ({ fields, isEditMode }) =>
  fields.map(field => {
    return <BrandsSettingsItem key={field} field={field} isEditMode={isEditMode} />;
  });

const BrandSettingsForm = props => {
  const [isEditMode, setIsEditMode] = useState(null);
  const submitForm = values => {
    setIsEditMode(false);
    props.setUploadBrandSettings(values);
  };
  return (
    <form autoComplete="off" noValidate onSubmit={props.handleSubmit(submitForm)}>
      <div className={brandsStyles.topRow}>
        <ErrorMessage textAlign={"left"} error={props.error} />
        {isEditMode ? (
          <div className={brandsStyles.topButtonsContainer}>
            <ContainedButton
              label={"ЗБЕРЕГТИ"}
              type={"submit"}
              className={brandsStyles.editButton}
              disabled={!props.imageTransactionSuccess}
            />
            <ContainedButton
              label={"СКАСУВАТИ"}
              type="button"
              handleClick={ev => {
                ev.preventDefault();
                props.reset(BRAND_SETTINGS_FORM);
                setIsEditMode(false);
              }}
              className={brandsStyles.editButton}
              disabled={!props.imageTransactionSuccess}
            />
          </div>
        ) : (
          <ContainedButton
            label={"РЕДАГУВАТИ"}
            type={"button"}
            handleClick={ev => {
              ev.preventDefault();
              setIsEditMode(true);
            }}
            className={brandsStyles.editButton}
            disabled={props.loading}
            loading={props.loading}
          />
        )}
      </div>
      <FieldArray name="brands" component={renderBrands} isEditMode={isEditMode} />
    </form>
  );
};

const selector = formValueSelector(BRAND_SETTINGS_FORM);

const formMapStateToProps = state => {
  const brandSettings = state.brandSettings;
  const brands = selector(state, "brands");
  const imageTransactionSuccess = state.images.imageTransactionSuccess;
  return {
    initialValues: reducerDataToFormValues(brandSettings.brandSettings),
    error: brandSettings.uploadingError || brandSettings.error,
    brands,
    loading: brandSettings.uploading || brandSettings.loading,
    imageTransactionSuccess
  };
};

const mapDispatchToProps = {
  setUploadBrandSettings
};

export default compose(
  connect(formMapStateToProps, mapDispatchToProps),
  reduxForm({
    form: BRAND_SETTINGS_FORM,
    validate,
    enableReinitialize: true,
    keepDirtyOnReinitialize: true
  })
)(BrandSettingsForm);
