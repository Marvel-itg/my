// @flow
import React from "react";
import { connect } from "react-redux";
import type { BrowserHistory } from "history";
import debounce from "es6-promise-debounce";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import Modal from "../../components/Modal/Modal";
import Toolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import CertificatesTable from "./CertificatesTable";
import CertificateDetails from "./CertificateDetails";
import CertificateAssignForm from "./CertificateAssignForm";
import { fetchCertificatesList, exportCertificatesCSV, getIssuers } from "../../store/actions/sales/certificates";
import { openModal } from "../../store/actions/common/modals";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  changeTab,
  getCommonParams,
  shouldNotSendRequest,
  changeIssuerId
} from "../../helpers/common";
import { classes } from "../../helpers/spinner";
import styles from "./ListOfCertificates.module.scss";

type PropsT = {
  certificates: CertificateT[],
  loading: boolean,
  total: number,
  totalCount: number,
  activatedCount: number,
  activeCount: number,
  errorMessage: string,
  exporting: boolean,
  fetchCertificatesList: Function,
  updateCertificatesCSV: Function,
  uploadCertificatesCSV: Function,
  exportCertificatesCSV: Function
} & BrowserHistory;

type StateT = {
  modalType: string,
  modalBody: any,
  formName: string
};

const tabs = [
  { label: "Доступні", value: "1" },
  { label: "У використанні", value: "2" },
  { label: "Активовані", value: "3" },
  { label: "Використані", value: "4" },
  { label: "Недіючі", value: "5" }
];

const commonColumns = [
  { name: "id", title: "ID" },
  { name: "barcode", title: "Баркод" },
  { name: "accountId", title: "ID користувача" },
  { name: "accountFullName", title: "ПІБ користувача" },
  { name: "accountPhoneNumber", title: "Номер телефону" },
  { name: "expirationDate", title: "Реальний термін дії" },
  { name: "expirationDateForAccount", title: "Термін дії продавця" },
  { name: "creationDate", title: "Дата створення" },
  { name: "value", title: "Номінал" },
  { name: "details", title: "Деталі сертифікату" }
];

const columns = {
  "1": [...commonColumns, { name: "assign", title: "Назначити" }],
  "2": [...commonColumns, { name: "reAssign", title: "Переназначити" }],
  "3": commonColumns,
  "4": commonColumns,
  "5": commonColumns
};

class ListOfCertificates extends React.Component<PropsT, StateT> {
  state = {
    modalType: "",
    modalBody: <div />,
    formName: ""
  };

  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;

    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changeTab = (event: any, tab: string) => changeTab(tab, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  changeIssuerId = (issuerId: OptionT) =>
    changeIssuerId(Number(issuerId.value), this.props.location.search, this.props.history);

  fetchData = debounce(() => {
    const { searchFieldName, searchValue, itemsOnPage, pageNumber, tab: status, issuerId } = getCommonParams(
      this.props.location.search
    );

    let params = { itemsOnPage, pageNumber, status, issuerId };
    if (searchValue) {
      params = { ...params, searchField: searchFieldName, searchValue };
    }
    this.props.fetchCertificatesList(params);
  }, 200);

  openModal = (type, id) => {
    const { issuerId, tab } = getCommonParams(this.props.location.search);
    switch (type) {
      case "details": {
        const modalBody = <CertificateDetails id={id} />;
        this.setState({ modalBody, modalType: "" });
        return this.props.openModal();
      }
      case "assign": {
        const modalBody = <CertificateAssignForm id={id} type="assign" tab={tab || "1"} issuerId={Number(issuerId)} />;
        this.setState({ modalBody, modalType: "deactivate" });
        return this.props.openModal();
      }
      case "reAssign": {
        const modalBody = (
          <CertificateAssignForm id={id} type="reAssign" tab={tab || "1"} issuerId={Number(issuerId)} />
        );
        this.setState({ modalBody, modalType: "deactivate" });
        return this.props.openModal();
      }
      default:
        return null;
    }
  };

  openDetails = id => this.openModal("details", id);
  openAssignModal = id => this.openModal("assign", id);
  openReassignModal = id => this.openModal("reAssign", id);

  exportCSV = () => {
    const { issuerId } = getCommonParams(this.props.location.search);
    this.props.exportCertificatesCSV(issuerId);
  };

  render() {
    const { page, count } = getPaginationConfig(this.props.location.search);
    const { tab, issuerId } = getCommonParams(this.props.location.search);
    const {
      totalCount = 0,
      activatedCount = 0,
      activeCount = 0,
      errorMessage,
      exporting,
      total,
      issuerOptions
    } = this.props;

    return (
      <>
        <Toolbar
          loadHandler={this.exportCSV}
          hasExportButton
          exportButtonLabel="Вивантажити всі сертифікати зі статусами (CSV)"
          withoutDateRange
          withIssuerSelect
          issuerOptions={issuerOptions}
          onIssuerChange={this.changeIssuerId}
          issuerId={issuerId}
          errorMessage={errorMessage}
          uploading={exporting}
        />

        <Paper square className="mainContent">
          <CertificatesTable
            data={this.props.certificates || []}
            activeTab={tab || "1"}
            columns={columns[tab || "1"]}
            changeTab={this.changeTab}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            openDetails={this.openDetails}
            assignCertificate={this.openAssignModal}
            reAssignCertificate={this.openReassignModal}
            tabs={tabs}
            page={page}
            count={count}
            total={total}
          />
          {this.props.loading && <CircularProgress classes={classes} />}
          <div className={styles.summaryRow}>
            <span>Загальна кількість: {totalCount}</span>
            <span>Активні: {activeCount}</span>
            <span>Активовані: {activatedCount}</span>
          </div>
        </Paper>
        <Modal type={this.state.modalType}>{this.state.modalBody}</Modal>
      </>
    );
  }
}

const mapStateToProps = state => {
  const {
    certificates: {
      rowsCount,
      certificates,
      loading,
      totalCount,
      activatedCount,
      activeCount,
      exportError,
      exporting,
      issuerOptions
    }
  } = state;
  return {
    certificates,
    issuerOptions,
    loading,
    total: rowsCount,
    totalCount,
    activatedCount,
    activeCount,
    errorMessage: exportError,
    exporting
  };
};

const mapDispatchToProps = {
  fetchCertificatesList,
  exportCertificatesCSV,
  openModal,
  getIssuers
};

export default connect(mapStateToProps, mapDispatchToProps)(ListOfCertificates);
