// @flow
import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import { TextField, Button } from "@material-ui/core";
import Select from "../../components/Select/Select";

import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import { closeModal } from "../../store/actions/common/modals";
import { assignCertificate, clearAssignError } from "../../store/actions/sales/certificates";
import styles from "./ListOfCertificates.module.scss";

type PropsT = {
  type: string,
  id: number,
  tab: string,
  issuerId: number
};

const assignCertificateOptions = [
  {
    label: "На продавця",
    value: "2"
  }
];

const reAssignCertificateOptions = [
  {
    label: "На продавця",
    value: "2"
  },
  {
    label: "У доступні",
    value: "1"
  }
];

export const CertificateAssignForm = (props: PropsT) => {
  const [assignToValue, setAssignToValue] = useState(assignCertificateOptions[0]);
  const [accountIdValue, setAccountIdValue] = useState("");
  const dispatch = useDispatch();
  const { assignError } = useSelector(state => state.certificates);
  const { id, type, tab, issuerId } = props;
  const title = type === "assign" ? "Оберіть назначення" : "Оберіть тип переназначення";
  const showAccountSelect = assignToValue && assignToValue.value === "2";
  const isSubmitDisabled = !assignToValue || (assignToValue.value === "2" && !accountIdValue);

  useEffect(() => {
    return () => {
      dispatch(clearAssignError());
    };
  }, []);

  const handleClose = () => {
    dispatch(closeModal());
  };

  const handleSubmit = () => {
    if (assignToValue) {
      const params: AssignCertificateParamsT = {
        certificateId: id,
        certificateStatus: Number(assignToValue.value)
      };
      if (assignToValue.value === "2") {
        params.accountId = Number(accountIdValue);
      }
      dispatch(assignCertificate(params, tab, issuerId));
    }
  };

  const handleAccountIdChange = event => {
    setAccountIdValue(event.target.value);
  };

  return (
    <div>
      <div className={styles.assignTitle}>{title}</div>
      <div className={styles.selectsWrapper}>
        <Select
          className={styles.assignToSelect}
          id="assignTo"
          options={type === "assign" ? assignCertificateOptions : reAssignCertificateOptions}
          onChange={setAssignToValue}
          value={assignToValue}
          placeholder={type === "assign" ? "Назначити" : "Переназначити"}
        />
        {showAccountSelect && (
          <TextField id="accountId" onChange={handleAccountIdChange} value={accountIdValue} label="ID" />
        )}
      </div>
      {assignError && <ErrorMessage textAlign="left" error={assignError} />}
      <div className={styles.buttonsWrapper}>
        <Button onClick={handleClose} color="secondary">
          Закрити
        </Button>
        <Button onClick={handleSubmit} color="primary" disabled={isSubmitDisabled}>
          Застосувати
        </Button>
      </div>
    </div>
  );
};

export default CertificateAssignForm;
