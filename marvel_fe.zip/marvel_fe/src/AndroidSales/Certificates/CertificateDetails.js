// @flow
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import CircularProgress from "@material-ui/core/CircularProgress";
import { Grid, Table, TableHeaderRow, Toolbar } from "@devexpress/dx-react-grid-material-ui";

import TableContainer from "../../components/TableComponents/TableContainer";
import { getCertificateDetails } from "../../store/actions/sales/certificates";
import { formatPhone } from "../../utils/reduxFormNormalizers";
import { classes } from "../../helpers/spinner";
import styles from "./ListOfCertificates.module.scss";

type PropsT = {
  id: number
};

const StyledGrid = props => <Grid.Root {...props} style={{ maxHeight: "100%" }} />;

const columns = [
  { name: "transactionDate", title: "Дата" },
  { name: "status", title: "Статус" },
  { name: "accountFullName", title: "Користувач" }
];

const columnExtensions = [
  { columnName: "transactionDate", width: 100 },
  { columnName: "status", width: 110 }
];
const CertificateDetails = ({ id }: PropsT) => {
  const dispatch = useDispatch();
  const { certificateDetails, loadingDetails } = useSelector(state => state.certificates);

  useEffect(() => {
    dispatch(getCertificateDetails(id));
  }, []);

  if (loadingDetails || !certificateDetails) {
    return <CircularProgress classes={classes} />;
  }

  return certificateDetails ? (
    <>
      <h3 className={styles.dialogTitle}>Деталі сертифіката</h3>
      <div className={styles.wrapper}>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>ID: </span>
          <span className={styles.detailsDescription}>{certificateDetails.id}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Баркод: </span>
          <span className={styles.detailsDescription}>{certificateDetails.barcode}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>ID користувача: </span>
          <span className={styles.detailsDescription}>{certificateDetails.accountId}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>ПІБ користувача: </span>
          <span className={styles.detailsDescription}>{certificateDetails.accountFullName}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Номер телефону: </span>
          <span className={styles.detailsDescription}>
            {!!certificateDetails.phoneNumber && formatPhone(certificateDetails.phoneNumber)}
          </span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Реальний термін дії: </span>
          <span className={styles.detailsDescription}>{certificateDetails.expirationDate}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Термін дії для продавця: </span>
          <span className={styles.detailsDescription}>{certificateDetails.expirationDateForAccount}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Дата створення: </span>
          <span className={styles.detailsDescription}>{certificateDetails.creationDate}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Номінал: </span>
          <span className={styles.detailsDescription}>{certificateDetails.value}</span>
        </div>
      </div>
      <Grid rows={certificateDetails.transactionHistory} columns={columns} rootComponent={StyledGrid}>
        <Table columnExtensions={columnExtensions} height="auto" containerComponent={TableContainer} />
        <Toolbar />
        <TableHeaderRow />
        <div className={styles.tableTitle}>Історія зміни статусів</div>
      </Grid>
    </>
  ) : null;
};

export default CertificateDetails;
