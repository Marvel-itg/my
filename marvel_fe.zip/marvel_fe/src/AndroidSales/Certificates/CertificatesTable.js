// @flow
import React from "react";
import { Grid, TableHeaderRow, Table, Toolbar } from "@devexpress/dx-react-grid-material-ui";
import { PhoneProvider, ButtonProvider, TransparentButtonProvider } from "../../components/FormattedData/FormattedData";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import { ToolBarRootStyled } from "../../components/TableComponents/ToolbarRoot";
import GridRoot from "../../components/TableComponents/GridRoot";
import TableContainerComponent from "../../components/TableComponents/TableContainerComponent";
import PagingPanel from "../../components/TableComponents/PagingPanel";
import TabsHeader from "../../components/TableComponents/TabsHeader";
import SearchForm from "../../components/TableComponents/SearchForm/SearchForm";
import {
  defaultItemsPerPage,
  availableItemsPerPage,
  certificatesSearchOptions,
  columnExtensions
} from "../../constants";
import styles from "./ListOfCertificates.module.scss";

type PropsT = {
  data: CertificateT[],
  tabs: TabT[],
  columns: ColumnT[],
  changeTab: Function,
  activeTab: string,
  page: number,
  count: number,
  total: number,
  changeCurrentPage: Function,
  changePageSize: Function,
  changeTab: Function,
  openDetails: Function,
  assignCertificate: Function,
  reAssignCertificate: Function
};

const forValues = {
  phone: ["accountPhoneNumber"],
  details: ["details"],
  assign: ["assign"],
  reAssign: ["reAssign"]
};

const expandedColumnExtensions = [
  ...columnExtensions,
  { columnName: "assign", width: 200 },
  { columnName: "reAssign", width: 220 },
  { columnName: "expirationDate", width: 170 },
  { columnName: "expirationDateForAccount", width: 170 },
  { columnName: "creationDate", width: 170 },
  { columnName: "accountPhoneNumber", width: 200 },
  { columnName: "accountFullName", width: 220 }
];

const CertificatesTable = (props: PropsT) => {
  const {
    columns,
    data,
    activeTab,
    tabs,
    page,
    count,
    total,
    changeCurrentPage,
    changePageSize,
    changeTab,
    openDetails,
    assignCertificate,
    reAssignCertificate
  } = props;

  return (
    <Grid rows={data} columns={columns} rootComponent={GridRoot}>
      <PagingState
        currentPage={page}
        onCurrentPageChange={changeCurrentPage}
        pageSize={count || defaultItemsPerPage}
        onPageSizeChange={changePageSize}
      />
      <CustomPaging totalCount={total} />

      <PhoneProvider for={forValues.phone} />
      <ButtonProvider for={forValues.assign} onClick={assignCertificate} label="Назначити" />
      <ButtonProvider for={forValues.reAssign} onClick={reAssignCertificate} label="Переназначити" />
      <TransparentButtonProvider for={forValues.details} onClick={openDetails} label="Деталі сертифіката" />

      <Table height="auto" columnExtensions={expandedColumnExtensions} containerComponent={TableContainerComponent} />
      <TableHeaderRow />
      <Toolbar rootComponent={ToolBarRootStyled(styles.headerStyle)} />
      <TabsHeader changeTab={changeTab} activeTab={activeTab} tabs={tabs || []} />
      <PagingPanel pageSizes={availableItemsPerPage} noData={!total} />
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <SearchForm selectOptions={certificatesSearchOptions} placeholder="Пошук" className={styles.searchForm} />
      </div>
    </Grid>
  );
};

export default CertificatesTable;
