// @flow

import React from "react";
import { reduxForm, Field } from "redux-form";
import type { FormProps } from "redux-form";
import { Template, TemplatePlaceholder, Plugin, TemplateConnector } from "@devexpress/dx-react-core";
import Checkbox from "../../components/CheckBox/CheckBox";
import styles from "./Orders.module.scss";

type PropsT = {} & FormProps;

const SearchFilters = (props: PropsT) => {
  return (
    <div className={styles.searchFilters}>
      <Field
        name="notProcessed"
        component={Checkbox}
        label="Не оброблені"
        format={value => (value ? "true" : "false")}
      />
      <Field
        name="notDelivered"
        component={Checkbox}
        label="Не відвантажені"
        format={value => (value ? "true" : "false")}
      />
    </div>
  );
};

const Form = reduxForm({
  form: "OrdersSearchFilters"
})(SearchFilters);

type WrapperPropsT = {
  initialValues: { notProcessed?: boolean, notDelivered?: boolean }
};

const SearchFiltersWrapper = (props: WrapperPropsT) => (
  <Plugin name="searchFilters">
    <Template name="toolbarContent">
      <TemplatePlaceholder />
      <TemplateConnector>{() => <Form {...props} />}</TemplateConnector>
    </Template>
  </Plugin>
);

export default SearchFiltersWrapper;
