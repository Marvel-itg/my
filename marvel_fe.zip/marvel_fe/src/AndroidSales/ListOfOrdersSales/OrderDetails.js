// @flow
import React, { Fragment } from "react";
import { formatDate } from "../../utils/formatValues.js";
import { formatPhone } from "../../utils/reduxFormNormalizers";
import styles from "./Orders.module.scss";

type PropsT = {
  data: {
    generalOrderId: number,
    lastName: string,
    firstName: string,
    middleName: string,
    posCode: string,
    posAddress: string,
    comment: string,
    phone: string,
    creationDate: string,
    orders: OrdersT[]
  }
};

const filterPositionsByWarehouses = positions => {
  const reserveWarehouse = positions.find(item => item.warehouseType === 0) || {};
  const firstWarehouse = positions.find(item => item.warehouseType === 1) || {};
  const secondWarehouse = positions.find(item => item.warehouseType === 2) || {};
  return {
    firstWarehouse: firstWarehouse.orderPositions,
    secondWarehouse: secondWarehouse.orderPositions,
    reserveWarehouse: reserveWarehouse.orderPositions
  };
};

const renderMerchandiseDetails = (item: OrderPositionT, index: number) => {
  return (
    <div key={index + "sku"} className={styles.detailsInlineWrapper}>
      <div className={styles.brandWrapper}>
        <span className={styles.detailsTitle}>Марка: </span>
        <span className={styles.detailsDescription} title={item.positionName}>
          {item.positionName}
        </span>
      </div>
      <div>
        <span className={styles.detailsTitle}>Кількість: </span>
        <span className={styles.detailsDescription}>{item.count}</span>
      </div>
    </div>
  );
};

const renderMerchandisesList = (data: OrdersT[]) => {
  const { firstWarehouse, secondWarehouse, reserveWarehouse } = filterPositionsByWarehouses(data);

  return (
    <div>
      {!!firstWarehouse && !!firstWarehouse.length && (
        <div>
          <div className={styles.warehouseTitle}>Основний склад</div>
          {firstWarehouse.map((merchandise, index) => {
            return renderMerchandiseDetails(merchandise, index);
          })}
        </div>
      )}
      {!!secondWarehouse && !!secondWarehouse.length && (
        <div>
          <div className={styles.warehouseTitle}>Додатковий склад</div>
          {secondWarehouse.map((merchandise, index) => {
            return renderMerchandiseDetails(merchandise, index);
          })}
        </div>
      )}
      {!!reserveWarehouse && !!reserveWarehouse.length && (
        <div>
          <div className={styles.warehouseTitle}>Резервний склад</div>
          {reserveWarehouse.map((merchandise, index) => {
            return renderMerchandiseDetails(merchandise, index);
          })}
        </div>
      )}
    </div>
  );
};

const OrderDetails = (props: PropsT) => {
  const { data } = props;

  return (
    <Fragment>
      <h3 className={styles.dialogTitle}>Деталі замовлення</h3>
      <div className={styles.detailsWrapper}>
        <span className={styles.detailsTitle}>ID: </span>
        <span className={styles.detailsDescription}>{data.generalOrderId}</span>
      </div>
      <div className={styles.detailsWrapper}>
        <span className={styles.detailsTitle}>Прізвище: </span>
        <span className={styles.detailsDescription}>{data.lastName}</span>
      </div>
      <div className={styles.detailsWrapper}>
        <span className={styles.detailsTitle}>Ім'я: </span>
        <span className={styles.detailsDescription}>{data.firstName}</span>
      </div>
      <div className={styles.detailsWrapper}>
        <span className={styles.detailsTitle}>По батькові: </span>
        <span className={styles.detailsDescription}>{data.middleName}</span>
      </div>
      <div className={styles.detailsWrapper}>
        <span className={styles.detailsTitle}>Номер телефону: </span>
        <span className={styles.detailsDescription}>{formatPhone(data.phone)}</span>
      </div>
      <div className={styles.detailsWrapper}>
        <span className={styles.detailsTitle}>Код торгiвельної точки: </span>
        <span className={styles.detailsDescription}>{data.posCode}</span>
      </div>
      <div className={styles.detailsWrapper}>
        <span className={styles.detailsTitle}>Адреса ТТ: </span>
        <span className={styles.detailsDescription}>{data.posAddress}</span>
      </div>
      <div className={styles.detailsWrapper}>
        <span className={styles.detailsTitle}>Дата та час замовлення: </span>
        <span className={styles.detailsDescription}>{formatDate(data.creationDate)}</span>
      </div>
      {data.orders && data.orders.length ? renderMerchandisesList(data.orders) : ""}
      {data.comment && (
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Коментар: </span>
          <span className={styles.detailsDescription}>{data.comment}</span>
        </div>
      )}
    </Fragment>
  );
};

export default OrderDetails;
