// @flow
import React from "react";
import { connect } from "react-redux";
import { formValueSelector } from "redux-form";
import debounce from "es6-promise-debounce";
import moment from "moment";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import OrdersTableSales from "./OrdersTableSales";
import OrderDetails from "./OrderDetails";
import Toolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import Modal from "../../components/Modal/Modal";
import {
  fetchOrders,
  exportListOfOrdersCSV,
  exportAgreedOrdersCSV,
  exportOrdersReportCSV
} from "../../store/actions/sales/ordersListSales";
import { openModal, closeModal } from "../../store/actions/common/modals";
import { ordersListSelector } from "../../store/selectors/sales/ordersList";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  filterByDate,
  getCommonParams,
  capitalize,
  changeNotProcessed,
  changeNotDelivered,
  shouldNotSendRequest
} from "../../helpers/common";
import styles from "./Orders.module.scss";
import { classes } from "../../helpers/spinner";

type PropsT = {
  fetchOrders: Function,
  loading: boolean,
  ordersList: OrdersReportT[],
  openModal: Function,
  closeModal: Function,
  notProcessed: boolean,
  notDelivered: boolean,
  uploadingAgreed: boolean,
  uploadingAgreedError: string | null,
  exportOrdersReportCSV: Function
} & BrowserHistory;

type StateT = {
  modalBody: any
};

const createFullCityString = row => {
  const cityName = (row && row.cityName) || "";
  const districtName = (row && row.districtName && `, ${capitalize(row.districtName)} район,`) || "";
  const areaName = (row && row.areaName && `${capitalize(row.areaName)} область`) || "";
  return cityName ? `${cityName}${districtName}${areaName}` : "";
};

const getMaxDate = orders => {
  const dates = !!orders.length && orders.filter(item => item.importDate).map(item => moment(item.importDate));
  return dates && !!dates.length && moment.max(dates);
};
const transformDate = (startDate, endDate) => {
  const start = moment(startDate).format("YYYY-MM-DD");
  const end = moment(endDate).format("YYYY-MM-DD");
  return { startDate: start, endDate: end };
};
const columns = [
  { name: "taskTemplateName", title: "Назва завдання" },
  { name: "generalOrderId", title: "ID" },
  { name: "warehouseType", title: "Тип" },
  { name: "lastName", title: "Прiзвище" },
  { name: "firstName", title: "Ім'я" },
  { name: "middleName", title: "По батьковi" },
  { name: "city", title: "Населений пункт", getCellValue: row => createFullCityString(row.geo) },
  { name: "posCode", title: "Код ТТ" },
  { name: "posAddress", title: "Адреса ТТ" },
  { name: "phone", title: "Номер телефону" },
  { name: "agreementDate", title: "Дата та час згоди продавця виконувати завдання" },
  { name: "creationDate", title: "Дата та час створення замовлення" },
  { name: "processingDate", title: "Дата та час обробки ТП" },
  { name: "statusIdByTradeRepresentative", title: "Статус після обробки ТП" },
  { name: "exportDate", title: "Дата експорту у WebDav" },
  { name: "deliveryDate", title: "Дата відвантаження" },
  {
    name: "importDate",
    title: "Дата імпорту",
    getCellValue: row => getMaxDate(row.orders)
  },
  { name: "expirationDate", title: "Дата закінчення терміну замовлення" },
  { name: "bonusCount", title: "Отримано балів" },
  { name: "details", title: "Деталі замовлення" }
];

class ListOfOrdersSales extends React.Component<PropsT, StateT> {
  state = {
    modalBody: <div />
  };

  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;

    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
    if (prevProps.notProcessed !== this.props.notProcessed) {
      changeNotProcessed(this.props.notProcessed, this.props.location.search, this.props.history);
    }
    if (prevProps.notDelivered !== this.props.notDelivered) {
      changeNotDelivered(this.props.notDelivered, this.props.location.search, this.props.history);
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  filterByDate = (rangeFilter: RangeFilterT) =>
    filterByDate(rangeFilter, this.props.location.search, this.props.history);

  fetchData = debounce(() => {
    const {
      searchFieldName,
      searchValue,
      itemsOnPage,
      pageNumber,
      dateStart,
      dateEnd,
      notProcessed,
      notDelivered
    } = getCommonParams(this.props.location.search);
    let params = {
      pageNumber,
      itemsOnPage,
      notProcessedByTradeRepresentative: notProcessed,
      notDelivered,
      creationStartDate: dateStart,
      creationEndDate: dateEnd
    };

    if (searchValue) {
      params = { ...params, searchFieldName, searchValue };
    }

    this.props.fetchOrders(params);
  }, 200);

  findOrderById = (orderList, id) => {
    return orderList.filter(item => item.generalOrderId === id)[0];
  };

  openModal = (type, id) => {
    switch (type) {
      case "details": {
        const modalBody = <OrderDetails data={this.findOrderById(this.props.ordersList, id)} />;
        this.setState({ modalBody });
        return this.props.openModal();
      }
      default:
        return null;
    }
  };

  openDetailsModal = id => this.openModal("details", id);

  exportCSV = () => {
    const { dateStart, dateEnd, searchFieldName, searchValue, notProcessed, notDelivered } = getCommonParams(
      this.props.location.search
    );
    let params = {
      creationStartDate: dateStart,
      creationEndDate: dateEnd,
      notDelivered,
      notProcessedByTradeRepresentative: notProcessed
    };
    if (searchValue) {
      params = { ...params, searchFieldName, searchValue };
    }
    this.props.exportListOfOrdersCSV(params);
  };

  exportAgreedCSV = () => {
    const { dateStart, dateEnd } = getCommonParams(this.props.location.search);
    let params = {
      StartDate: dateStart,
      EndDate: dateEnd
    };
    this.props.exportAgreedOrdersCSV(params);
  };

  sendToTelegram = ({ startDate, endDate }) => {
    let params = {
      from: startDate,
      to: endDate
    };
    this.props.exportOrdersReportCSV(params);
  };

  render() {
    const { loading, uploading, uploadingAgreed, total, startDate, endDate } = this.props;
    const { dateStart, dateEnd, notProcessed, notDelivered } = getCommonParams(this.props.location.search);
    const { page, count } = getPaginationConfig(this.props.location.search);
    const initialValues = { startDate: dateStart, endDate: dateEnd };
    const searchFiltersInitialValues = { notProcessed, notDelivered };
    return (
      <React.Fragment>
        <Toolbar
          form="ordersDateFilter"
          filterData={this.filterByDate}
          initialValues={initialValues}
          hasExportButton
          bulkLoading={uploading}
          uploading={uploadingAgreed}
          disabled={uploading}
          loadHandler={this.exportAgreedCSV}
          exportButtonLabel="Вивантажити CSV: Згоднi виконати завдання"
          errorMessage={this.props.uploadingError || this.props.uploadingAgreedError}
          hasBulkApproveButton
          isBulkButtonDisabled={uploading}
          bulkApproveButtonLabel="Вивантажити CSV"
          handleBulkApprove={this.exportCSV}
          downloadButtonClassName={styles.exportAgreedButton}
          hasAdditionalBulkApproveButton
          additionalBulkApproveButtonLabel={"Звiт у старому форматi"}
          handleAdditionalBulkApprove={() => this.sendToTelegram(transformDate(startDate, endDate))}
        />
        <Paper square className="mainContent">
          <OrdersTableSales
            data={this.props.ordersList}
            total={total}
            count={count}
            page={page}
            columns={columns}
            openDetailsModal={this.openDetailsModal}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            initialValues={searchFiltersInitialValues}
          />
        </Paper>
        {loading && <CircularProgress classes={classes} />}
        <Modal>{this.state.modalBody}</Modal>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    ordersListSales: { loading, error, total, uploading, uploadingError, uploadingAgreed, uploadingAgreedError }
  } = state;
  const selector = formValueSelector("OrdersSearchFilters");
  const notProcessed = selector(state, "notProcessed");
  const notDelivered = selector(state, "notDelivered");
  const dateSelector = formValueSelector("ordersDateFilter");
  const startDate = dateSelector(state, "startDate");
  const endDate = dateSelector(state, "endDate");
  return {
    ordersList: ordersListSelector(state),
    loading,
    errorMessage: error,
    total,
    notProcessed,
    notDelivered,
    uploadingError,
    uploading,
    uploadingAgreed,
    uploadingAgreedError,
    startDate,
    endDate
  };
};

const mapDispatchToProps = {
  fetchOrders,
  exportListOfOrdersCSV,
  exportAgreedOrdersCSV,
  exportOrdersReportCSV,
  openModal,
  closeModal
};

export default connect(mapStateToProps, mapDispatchToProps)(ListOfOrdersSales);
