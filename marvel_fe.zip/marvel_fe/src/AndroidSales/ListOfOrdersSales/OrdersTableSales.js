// @flow
import React from "react";
import { Grid, TableHeaderRow, Table, Toolbar } from "@devexpress/dx-react-grid-material-ui";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import ToolbarRoot from "../../components/TableComponents/ToolbarRoot";
import GridRoot from "../../components/TableComponents/GridRoot";
import TableContainerComponent from "../../components/TableComponents/TableContainerComponent";
import PagingPanel from "../../components/TableComponents/PagingPanel";
import {
  PhoneProvider,
  OrderStatusProvider,
  TransparentButtonProvider,
  DateFormatProvider
} from "../../components/FormattedData/FormattedData";
import SearchFilters from "./SearchFilters";
import SearchForm from "../../components/TableComponents/SearchForm/SearchForm";
import { ordersSearchOptions } from "../../constants";
import { columnExtensions, defaultItemsPerPage, availableItemsPerPage } from "../../constants";
import styles from "./Orders.module.scss";

const wordWrapStyles = {
  whiteSpace: "normal",
  wordWrap: "break-word"
};

const CellComponent = ({ style, ...props }) => {
  return <Table.Cell style={wordWrapStyles} {...props} />;
};

type PropsT = {
  data: OrdersReportT[],
  columns: ColumnT[],
  openDetailsModal: Function,
  changePageSize: Function,
  changeCurrentPage: Function,
  total: number,
  count: number,
  page: number,
  initialValues: {
    notProcessed?: boolean,
    notDelivered?: boolean
  }
};

const forValues = {
  details: ["details"],
  phone: ["phone"],
  creationDate: ["creationDate"],
  agreementDate: ["agreementDate"],
  processingDate: ["processingDate"],
  deliveryDate: ["deliveryDate"],
  exportDate: ["exportDate"],
  expirationDate: ["expirationDate"],
  importDate: ["importDate"],
  statusIdByTradeRepresentative: ["statusIdByTradeRepresentative"]
};

const mergedColumnExtensions = [
  ...columnExtensions,
  { columnName: "city", width: 400 },
  { columnName: "taskTemplateName", width: 200 },
  { columnName: "fullName", width: 400 },
  { columnName: "warehouseType", width: 140 },
  { columnName: "posCode", width: 160 },
  { columnName: "posAddress", width: 350 },
  { columnName: "creationDate", width: 300 },
  { columnName: "agreementDate", width: 300 },
  { columnName: "processingDate", width: 300 },
  { columnName: "deliveryDate", width: 300 },
  { columnName: "exportDate", width: 200 },
  { columnName: "importDate", width: 200 },
  { columnName: "expirationDate", width: 250 },
  { columnName: "statusIdByTradeRepresentative", width: 300 },
  { columnName: "details", width: 200 }
];

const OrdersTableSales = (props: PropsT) => {
  const {
    data,
    columns,
    page,
    count,
    total,
    changeCurrentPage,
    changePageSize,
    openDetailsModal,
    initialValues
  } = props;
  return (
    <Grid rows={data} columns={columns} rootComponent={GridRoot}>
      <PagingState
        currentPage={page || 0}
        onCurrentPageChange={changeCurrentPage}
        pageSize={count || defaultItemsPerPage}
        onPageSizeChange={changePageSize}
      />
      <CustomPaging totalCount={total} />
      <TransparentButtonProvider for={forValues.details} onClick={openDetailsModal} label="Деталі замовлення" />
      <PhoneProvider for={forValues.phone} />
      <DateFormatProvider for={forValues.creationDate} showTime />
      <DateFormatProvider for={forValues.processingDate} showTime />
      <DateFormatProvider for={forValues.deliveryDate} showTime />
      <DateFormatProvider for={forValues.exportDate} showTime />
      <DateFormatProvider for={forValues.agreementDate} showTime />
      <DateFormatProvider for={forValues.importDate} showTime />
      <DateFormatProvider for={forValues.expirationDate} />

      <OrderStatusProvider for={forValues.statusIdByTradeRepresentative} />
      <Table
        height="auto"
        columnExtensions={mergedColumnExtensions}
        containerComponent={TableContainerComponent}
        cellComponent={CellComponent}
      />
      <TableHeaderRow />
      <Toolbar rootComponent={ToolbarRoot} />
      <PagingPanel pageSizes={availableItemsPerPage} noData={!total} />
      <SearchFilters initialValues={initialValues} />
      <SearchForm selectOptions={ordersSearchOptions} placeholder="Пошук замовлень" className={styles.searchForm} />
    </Grid>
  );
};

export default OrdersTableSales;
