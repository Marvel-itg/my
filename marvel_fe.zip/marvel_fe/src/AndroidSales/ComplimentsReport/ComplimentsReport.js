// @flow
import React from "react";
import { connect } from "react-redux";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import type { BrowserHistory } from "history";
import ReportToolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import ComplimentsReportTable from "./ComplimentsReportTable";
import { fetchComplimentsReport, exportComplimentsReportCSV } from "../../store/actions/sales/complimentsReport";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  filterByDate,
  getCommonParams,
  shouldNotSendRequest
} from "../../helpers/common";
import { classes } from "../../helpers/spinner";

type PropsT = {
  fetchComplimentsReport: Function,
  exportComplimentsReportCSV: Function,
  statistic: ComplimentsReportDataT[],
  loading: boolean,
  uploading: boolean,
  exportError: string
} & BrowserHistory;

const columns = [
  { name: "posCode", title: "Торгівельна точка" },
  { name: "posAddress", title: "Адреса торгівельної точки" },
  { name: "operationType", title: "Тип операції (Видача, повернення)" },
  { name: "complimentsQuantity", title: "Кількість компліментів" },
  { name: "complimentType", title: "Тип компліменту" },
  { name: "createdOn", title: "Дата транзакції" },
  { name: "tradeRepresentativeFullName", title: "Торгівельний представник" }
];

class ComplimentsReport extends React.Component<PropsT> {
  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;

    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  filterByDate = (rangeFilter: RangeFilterT) =>
    filterByDate(rangeFilter, this.props.location.search, this.props.history, this.props.location.state);

  fetchData = () => {
    const { dateStart, dateEnd, itemsOnPage, pageNumber } = getCommonParams(this.props.location.search);
    let params = { dateStart, dateEnd, itemsOnPage, pageNumber };
    this.props.fetchComplimentsReport(params);
  };

  exportCSV = () => {
    const { dateStart, dateEnd } = getCommonParams(this.props.location.search);
    let params = { dateStart, dateEnd };
    this.props.exportComplimentsReportCSV(params);
  };

  render() {
    const { loading, uploading, exportError, data, total } = this.props;
    const { dateStart, dateEnd } = getCommonParams(this.props.location.search);
    const { page, count } = getPaginationConfig(this.props.location.search);
    const initialValues = { startDate: dateStart, endDate: dateEnd };
    return (
      <React.Fragment>
        <ReportToolbar
          hasExportButton
          form="complimentsDateFilter"
          filterData={this.filterByDate}
          initialValues={initialValues}
          loadHandler={this.exportCSV}
          disabled={loading || uploading}
          uploading={uploading}
          errorMessage={exportError}
        />
        <Paper square className="mainContent">
          <ComplimentsReportTable
            data={data}
            columns={columns}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            page={page}
            count={count}
            total={total}
          />
        </Paper>
        {loading && <CircularProgress classes={classes} />}
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({ complimentsReport: { data, rowsCount, loading, uploading, exportError } }) => ({
  data,
  loading,
  uploading,
  total: rowsCount,
  exportError
});

const mapDispatchToProps = {
  fetchComplimentsReport,
  exportComplimentsReportCSV
};

export default connect(mapStateToProps, mapDispatchToProps)(ComplimentsReport);
