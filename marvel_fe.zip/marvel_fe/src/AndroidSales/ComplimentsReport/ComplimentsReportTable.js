// @flow
import React from "react";
import { Grid, Table, TableHeaderRow, Toolbar, PagingPanel } from "@devexpress/dx-react-grid-material-ui";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import { DateFormatProvider } from "../../components/FormattedData/FormattedData";
import GridRoot from "../../components/TableComponents/GridRoot";
import TableContainer from "../../components/TableComponents/TableContainer";
import HeaderWrap from "../../components/TableComponents/HeaderWrap";
import WithStickyBandsTable from "../../HOCs/withStickyBandsTable";
import { availableItemsPerPage, defaultItemsPerPage, columnExtensions } from "../../constants";

type PropsT = {
  data: Object,
  columns: ColumnT[],
  page: number,
  count: number,
  total: number,
  openDetails: Function,
  changeCurrentPage: Function,
  changePageSize: Function,
  checkIfDetailsButtonIsHidden: Function
};

const forValues = {
  date: ["createdOn"]
};

const expandedColumnExtensions = [...columnExtensions, { columnName: "createdOn", width: 280 }];

const ComplimentsReportTable = (props: PropsT) => {
  const { data, columns, page, count, changeCurrentPage, changePageSize, total } = props;

  return (
    <Grid rows={data} columns={columns} rootComponent={GridRoot}>
      <PagingState
        currentPage={page || 0}
        onCurrentPageChange={changeCurrentPage}
        pageSize={count || defaultItemsPerPage}
        onPageSizeChange={changePageSize}
      />
      <DateFormatProvider for={forValues.date} />

      <CustomPaging totalCount={total} />
      <Table height="auto" containerComponent={TableContainer} columnExtensions={expandedColumnExtensions} />

      <TableHeaderRow cellComponent={HeaderWrap} />
      <Toolbar />
      <PagingPanel pageSizes={availableItemsPerPage} noData={!total} />
    </Grid>
  );
};

export default WithStickyBandsTable(ComplimentsReportTable);
