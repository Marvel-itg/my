// @flow
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import CircularProgress from "@material-ui/core/CircularProgress";
import { Grid, Table, TableHeaderRow, Toolbar } from "@devexpress/dx-react-grid-material-ui";

import { DateFormatProvider } from "../../components/FormattedData/FormattedData";
import TableContainer from "../../components/TableComponents/TableContainer";
import HeaderWrap from "../../components/TableComponents/HeaderWrap";
import { getComplimentDetails } from "../../store/actions/sales/uploadCompliments";
import { formatDateWithSeconds } from "../../utils/formatValues";
import { classes } from "../../helpers/spinner";
import styles from "./ComplimentsUpload.module.scss";

type PropsT = {
  id: number
};

const StyledGrid = props => <Grid.Root {...props} style={{ maxHeight: "100%" }} />;

const transactionTypes = {
  "1": "Фольга",
  "2": "Комплімент"
};

const operationTypes = {
  "0": "Повернення",
  "1": "Видача"
};

const columns = [
  { name: "date", title: "Дата та час" },
  {
    name: "transactionType",
    title: "Тип транзакціі (комплімент, фольга)",
    getCellValue: row => transactionTypes[row.transactionType]
  },
  {
    name: "operationType",
    title: "Тип операції по компліментам (видача, повернення)",
    getCellValue: row => operationTypes[row.operationType]
  },
  { name: "amount", title: "Кількість фольги" },
  { name: "complimentAmount", title: "Кількість компліментів" }
];

const forValues = {
  date: ["date"]
};

const columnExtensions = [
  { columnName: "date", width: 150 },
  { columnName: "transactionType", width: 100 },
  { columnName: "operationType", width: 110 },
  { columnName: "amount", width: 110 }
];

const ComplimentDetails = ({ id }: PropsT) => {
  const dispatch = useDispatch();
  const { complimentDetails, loadingDetails } = useSelector(state => state.uploadCompliments);

  useEffect(() => {
    dispatch(getComplimentDetails(id));
  }, []);

  if (loadingDetails) {
    return <CircularProgress classes={classes} />;
  }

  return complimentDetails ? (
    <>
      <h3 className={styles.dialogTitle}>Деталі статистики компліментів</h3>
      <div className={styles.wrapper}>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Код ТТ: </span>
          <span className={styles.detailsDescription}>{complimentDetails.posCode}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Дата та час останнього оновлення: </span>
          <span className={styles.detailsDescription}>{formatDateWithSeconds(complimentDetails.lastModifiedOn)}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Кількість виданих компліментів: </span>
          <span className={styles.detailsDescription}>{complimentDetails.complimentsGiven}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Кількість обміняної фольги: </span>
          <span className={styles.detailsDescription}>{complimentDetails.foilCount}</span>
        </div>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>Залишок не закритих компліментів: </span>
          <span className={styles.detailsDescription}>{complimentDetails.remainingPlan}</span>
        </div>
      </div>
      <Grid rows={complimentDetails.history} columns={columns} rootComponent={StyledGrid}>
        <DateFormatProvider for={forValues.date} dateAndTimeWithSeconds />
        <Table columnExtensions={columnExtensions} height="auto" containerComponent={TableContainer} />
        <Toolbar />
        <TableHeaderRow cellComponent={HeaderWrap} />
        <div className={styles.tableTitle}>Історія транзакцій</div>
      </Grid>
    </>
  ) : null;
};

export default ComplimentDetails;
