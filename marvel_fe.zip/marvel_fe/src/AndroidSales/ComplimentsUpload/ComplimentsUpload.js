// @flow
import React from "react";
import { connect } from "react-redux";
import debounce from "es6-promise-debounce";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import Modal from "../../components/Modal/Modal";
import ExportTablesToolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import ComplimentsTable from "./ComplimentsTable";
import { openModal } from "../../store/actions/common/modals";
import { downloadCompliments, fetchComplimentsActivity } from "../../store/actions/sales/uploadCompliments";
import {
  changeCurrentPage,
  changePageSize,
  getCommonParams,
  shouldNotSendRequest,
  getPaginationConfig
} from "../../helpers/common";

import { classes } from "../../helpers/spinner";
import ComplimentDetails from "./ComplimentDetails";

type PropsT = {
  data: ComplimentsTableDataT[],
  loading: boolean,
  total: number,
  errorMessage: string,
  downloadCompliments: Function,
  fetchComplimentsActivity: Function,
  openModal: Function
} & BrowserHistory;

type StateT = {
  modalType: string,
  modalBody: any
};

const columns = [
  { name: "posCode", title: "Код ТТ" },
  { name: "lastModifiedOn", title: "Дата та час останнього оновлення" },
  { name: "complimentsGiven", title: "Кількість виданих компліментів" },
  { name: "foilCount", title: "Кількість обміняної фольги" },
  { name: "remainingPlan", title: "Залишок незакритих компліментів" },
  { name: "details", title: "Детальніше" }
];

class ComplimentsUpload extends React.Component<PropsT, StateT> {
  state = {
    modalType: "",
    modalBody: <div />
  };

  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps: PropsT) {
    const {
      location: { key }
    } = this.props;

    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  fetchData = debounce(() => {
    const { searchFieldName, searchValue, itemsOnPage, pageNumber } = getCommonParams(this.props.location.search);
    let params = { itemsOnPage, pageNumber };
    if (searchValue) {
      params = { ...params, searchField: searchFieldName, searchValue };
    }
    this.props.fetchComplimentsActivity(params);
  }, 200);

  openModal = (type, id) => {
    switch (type) {
      case "details": {
        const modalBody = <ComplimentDetails id={id} />;
        this.setState({ modalBody, modalType: "complimentDetailsModal" });
        return this.props.openModal();
      }
      default:
        return null;
    }
  };

  openDetails = id => this.openModal("details", id);

  downloadHandler = () => {
    const { searchFieldName, searchValue } = getCommonParams(this.props.location.search);
    let params = {};
    if (searchValue) {
      params = { ...params, searchField: searchFieldName, searchValue };
    }
    this.props.downloadCompliments(params);
  };

  render() {
    const { page, count } = getPaginationConfig(this.props.location.search);
    return (
      <>
        <ExportTablesToolbar
          hasExportButton
          withoutDateRange
          loadHandler={this.downloadHandler}
          errorMessage={this.props.errorMessage}
        />
        <Paper className="mainContent">
          <ComplimentsTable
            data={this.props.data}
            columns={columns}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            openDetails={this.openDetails}
            page={page}
            count={count}
            total={this.props.total}
          />
          {this.props.loading && <CircularProgress classes={classes} />}
          <Modal type={this.state.modalType}>{this.state.modalBody}</Modal>
        </Paper>
      </>
    );
  }
}

const mapStateToProps = state => {
  const {
    uploadCompliments: { total, data, loading, downloadingError }
  } = state;
  return {
    data,
    loading,
    total,
    errorMessage: downloadingError
  };
};

const mapDispatchToProps = {
  openModal,
  downloadCompliments,
  fetchComplimentsActivity
};

export default connect(mapStateToProps, mapDispatchToProps)(ComplimentsUpload);
