// @flow
import React from "react";
import { Grid, TableHeaderRow, Table, Toolbar } from "@devexpress/dx-react-grid-material-ui";
import { DateFormatProvider, TransparentButtonProvider } from "../../components/FormattedData/FormattedData";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import GridRoot from "../../components/TableComponents/GridRoot";
import HeaderWrap from "../../components/TableComponents/HeaderWrap";
import TableContainerComponent from "../../components/TableComponents/TableContainerComponent";
import PagingPanel from "../../components/TableComponents/PagingPanel";
import SearchForm from "../../components/TableComponents/SearchForm/SearchForm";
import {
  defaultItemsPerPage,
  availableItemsPerPage,
  complimentsSearchOptions,
  columnExtensions
} from "../../constants";
import styles from "./ComplimentsUpload.module.scss";

type PropsT = {
  data: ComplimentsTableDataT[],
  columns: ColumnT[],
  page: number,
  count: number,
  total: number,
  changeCurrentPage: Function,
  changePageSize: Function,
  openDetails: Function
};

const forValues = {
  details: ["details"],
  date: ["lastModifiedOn"]
};

const ComplimentsTable = (props: PropsT) => {
  const { columns, data, page, count, total, changeCurrentPage, changePageSize, openDetails } = props;

  return (
    <Grid rows={data} columns={columns} rootComponent={GridRoot}>
      <PagingState
        currentPage={page}
        onCurrentPageChange={changeCurrentPage}
        pageSize={count || defaultItemsPerPage}
        onPageSizeChange={changePageSize}
      />
      <CustomPaging totalCount={total} />

      <DateFormatProvider for={forValues.date} dateAndTimeWithSeconds />
      <TransparentButtonProvider for={forValues.details} onClick={openDetails} label="Детальніше" />

      <Table height="auto" columnExtensions={columnExtensions} containerComponent={TableContainerComponent} />
      <TableHeaderRow cellComponent={HeaderWrap} />
      <Toolbar />
      <PagingPanel pageSizes={availableItemsPerPage} noData={!total} />
      <SearchForm selectOptions={complimentsSearchOptions} placeholder="Пошук" className={styles.searchForm} />
    </Grid>
  );
};

export default ComplimentsTable;
