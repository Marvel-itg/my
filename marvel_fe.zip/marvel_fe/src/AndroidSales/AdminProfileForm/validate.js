import { validationErrorMessages } from "../../constants";

const validate = values => {
  const { required } = validationErrorMessages();
  const errors = {};

  if (!values.firstName || !values.firstName.trim().length) {
    errors.firstName = required;
  }
  if (!values.lastName || !values.lastName.trim().length) {
    errors.lastName = required;
  }
  if (!values.middleName || !values.middleName.trim().length) {
    errors.middleName = required;
  }
  if (!values.phone) {
    errors.phone = required;
  } else if (values.phone.length < 9) {
    errors.phone = "Введіть корректний номер телефону";
  }
  return errors;
};

export default validate;
