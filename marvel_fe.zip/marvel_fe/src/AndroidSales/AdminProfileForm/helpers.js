import isEmpty from "lodash/isEmpty";
import { formatDate } from "../../utils/formatValues";

export const formatInitialValues = data => {
  if (!isEmpty(data)) {
    const phone = data.phone && data.phone.substr(4);
    const firstName = (data.createdBy && data.createdBy.firstName) || "";
    const middleName = (data.createdBy && data.createdBy.middleName) || "";
    const lastName = (data.createdBy && data.createdBy.lastName) || "";
    const fullName = `${lastName} ${firstName} ${middleName}`;
    return {
      ...data,
      phone,
      createdOn: formatDate(data.createdOn),
      createdBy: fullName
    };
  }
};

export const formatValuesBeforeSubmit = values => {
  const firstName = values.firstName.trim();
  const lastName = values.lastName.trim();
  const middleName = values.middleName.trim();
  const formatted = {
    ...values,
    firstName,
    middleName,
    lastName
  };
  return formatted;
};
