// @flow
import React from "react";
import { connect } from "react-redux";
import { compose } from "redux";
import { withRouter } from "react-router-dom";
import { reduxForm, Field } from "redux-form";
import type { FormProps } from "redux-form";
import BackButton from "../../components/Buttons/BackButton/BackButton";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import InputField from "../../components/InputField/InputField";
import validate from "./validate";
import { normalizeCyrillicName, phoneMask } from "../../utils/reduxFormNormalizers";
import { formatInitialValues, formatValuesBeforeSubmit } from "./helpers";
import styles from "./AdminProfileForm.module.scss";

type PropsT = {
  submitForm: Function,
  changeMode: Function,
  editMode: boolean,
  isEditing: boolean,
  errorMessage: string,
  formTitle: string,
  invalid: boolean,
  clearDataHandler: Function
} & FormProps;

type StateT = {
  isSubmitting: boolean
};

class AdminProfileForm extends React.Component<PropsT, StateT> {
  state = { isSubmitting: false };

  componentDidUpdate(prevProps) {
    if (
      (!prevProps.errorMessage && this.props.errorMessage) ||
      (!prevProps.submitSucceeded && this.props.submitSucceeded)
    ) {
      this.setState({ isSubmitting: false });
    }
  }

  componentWillUnmount() {
    this.props.clearDataHandler();
  }

  submitForm = values => {
    if (!this.state.isSubmitting) {
      this.setState({ isSubmitting: true });
      this.props.submitForm(formatValuesBeforeSubmit(values));
    }
  };

  goBack = () => this.props.history.goBack();

  render() {
    const { handleSubmit, changeMode, editMode, submitting, isEditing, formTitle, invalid, errorMessage } = this.props;
    return (
      <form
        autoComplete="off"
        noValidate
        onSubmit={handleSubmit(this.submitForm)}
        className={styles.newSupervisorFormWrapper}
      >
        {!editMode && <div className={styles.formTitle}>{formTitle}</div>}
        {editMode && (
          <BackButton label="Повернутися назад" handleClick={this.goBack} className={styles.backButtonStyles} />
        )}
        <Field
          required
          name="lastName"
          component={InputField}
          className={styles.inputField}
          normalize={normalizeCyrillicName}
          disabled={editMode && !isEditing}
        />
        <Field
          required
          name="firstName"
          component={InputField}
          className={styles.inputField}
          normalize={normalizeCyrillicName}
          disabled={editMode && !isEditing}
        />
        <Field
          required
          name="middleName"
          component={InputField}
          className={styles.inputField}
          normalize={normalizeCyrillicName}
          disabled={editMode && !isEditing}
        />
        <Field
          required
          name="phone"
          component={InputField}
          type="tel"
          className={styles.inputField}
          disabled={editMode && !isEditing}
          {...phoneMask}
        />
        {editMode && (
          <>
            <Field name="createdBy" component={InputField} className={styles.inputField} disabled />
            <Field name="createdOn" component={InputField} className={styles.inputField} disabled />
          </>
        )}
        {editMode &&
          (isEditing ? (
            <ContainedButton type="submit" disabled={invalid} label="Зберегти" className={styles.editButton} />
          ) : (
            <ContainedButton type="button" label="Редагувати" className={styles.editButton} handleClick={changeMode} />
          ))}
        {!editMode && (
          <>
            <ContainedButton
              disabled={invalid || submitting}
              type="submit"
              label="Додати"
              className={styles.createButton}
            />
          </>
        )}
        {errorMessage && <ErrorMessage error={errorMessage} />}
      </form>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  const initialValues = formatInitialValues(ownProps.info);
  return {
    errorMessage: ownProps.errorState(state),
    initialValues
  };
};

export default compose(
  withRouter,
  connect(mapStateToProps),
  reduxForm({
    validate,
    enableReinitialize: true
  })
)(AdminProfileForm);
