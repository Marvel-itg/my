// @flow
import React from "react";
import { compose } from "redux";
import debounce from "es6-promise-debounce";
import { connect } from "react-redux";
import type { BrowserHistory } from "history";
import { withRouter } from "react-router-dom";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import OfflineUsersTable from "./OfflineUsersTable";
import Modal from "../../components/Modal/Modal";
import ReportToolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import {
  receiveOfflineUsersList,
  exportOfflineUsersListCSV,
  importOfflineUsersListCSV
} from "../../store/actions/sales/offlineUsersList";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  filterByDate,
  getCommonParams,
  shouldNotSendRequest
} from "../../helpers/common";
import { uploadOfflineUsersCSVErrorSelector } from "../../store/selectors/sales/offlineUsers";
import { openModal } from "../../store/actions/common/modals";
import { offlineUsersOptions } from "../../constants";
import styles from "./ListOfOfflineUsers.module.scss";
import { classes } from "../../helpers/spinner";

type PropsT = {
  receiveOfflineUsersList: Function,
  usersList: OfflineUsersT[],
  loading: boolean,
  imported: boolean,
  uploading: boolean,
  total: number,
  errorsList: string[]
} & BrowserHistory;

const columns = [
  { name: "lastName", title: "Прiзвище" },
  { name: "firstName", title: "Ім'я" },
  { name: "middleName", title: "По батьковi" },
  { name: "phone", title: "Номер телефону" },
  { name: "bonuses", title: "Кількість балів" },
  { name: "activityDescription", title: "Aктивність" },
  { name: "taskStartDate", title: "Дата старту завдання" },
  { name: "taskEndDate", title: "Дата кінця завдання" },
  { name: "posCode", title: "Код ТТ" },
  { name: "geoName", title: "Населений пункт" },
  { name: "uploadDate", title: "Дата завантаження" },
  {
    name: "isOnline",
    title: "Статус користувача",
    getCellValue: row => (row.isOnline === false ? "offline" : "online")
  }
];

const paperStyles = { root: styles.tableWrapper };

class ListOfOfflineUsers extends React.Component<PropsT> {
  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key },
      errorsList
    } = this.props;
    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }

    if (!prevProps.imported && this.props.imported) {
      this.fetchData();
    }

    if (prevProps.errorsList !== errorsList) {
      this.props.openModal();
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  filterByDate = (rangeFilter: RangeFilterT) =>
    filterByDate(rangeFilter, this.props.location.search, this.props.history);

  importCSV = csv => {
    this.props.importOfflineUsersListCSV(csv);
  };

  exportCSV = () => {
    const { dateStart, dateEnd, searchFieldName, searchValue } = getCommonParams(this.props.location.search);
    let params = { dateStart, dateEnd };
    if (searchValue) {
      params = { ...params, searchField: searchFieldName, searchValue };
    }
    this.props.exportOfflineUsersListCSV(params);
  };

  fetchData = debounce(() => {
    const { searchValue, searchFieldName, itemsOnPage, pageNumber, dateStart, dateEnd } = getCommonParams(
      this.props.location.search
    );
    let params = { itemsOnPage, pageNumber, dateEnd, dateStart };
    if (searchValue) {
      params = { ...params, searchField: searchFieldName, searchValue };
    }
    this.props.receiveOfflineUsersList(params);
  }, 200);

  render() {
    const { dateStart, dateEnd } = getCommonParams(this.props.location.search);
    const { page, count } = getPaginationConfig(this.props.location.search);
    const initialValues = { startDate: dateStart, endDate: dateEnd };
    return (
      <React.Fragment>
        <ReportToolbar
          hasExportButton
          hasImportButton
          filterData={this.filterByDate}
          form="offlineUsers"
          loadHandler={this.exportCSV}
          uploadHandler={this.importCSV}
          initialValues={initialValues}
          disabled={this.props.loading || this.props.uploading}
          uploading={this.props.uploading}
        />
        <Paper square className="mainContent" classes={paperStyles}>
          <OfflineUsersTable
            data={this.props.usersList}
            columns={columns}
            filterOptions={offlineUsersOptions}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            page={page}
            count={count}
            total={this.props.total}
          />
          {this.props.loading && <CircularProgress classes={classes} />}
          {this.props.errorsList && (
            <Modal type={"errorsModal"}>
              <ul>
                {this.props.errorsList.map((error, index) => (
                  <li key={index}>{error}</li>
                ))}
              </ul>
            </Modal>
          )}
        </Paper>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    offlineUsersList: { usersList, loading, uploading, imported, total }
  } = state;
  return {
    usersList,
    loading,
    total,
    imported,
    uploading,
    errorsList: uploadOfflineUsersCSVErrorSelector(state)
  };
};

const mapDispatchToProps = {
  receiveOfflineUsersList,
  exportOfflineUsersListCSV,
  importOfflineUsersListCSV,
  openModal
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(ListOfOfflineUsers);
