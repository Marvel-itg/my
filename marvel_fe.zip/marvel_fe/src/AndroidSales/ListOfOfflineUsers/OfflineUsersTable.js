// @flow
import React from "react";
import { Grid, Table, TableHeaderRow, Toolbar } from "@devexpress/dx-react-grid-material-ui";
import { SearchState, PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import { PhoneProvider, DateFormatProvider } from "../../components/FormattedData/FormattedData";
import ToolbarRoot from "../../components/TableComponents/ToolbarRoot";
import HeaderWrap from "../../components/TableComponents/HeaderWrap";
import GridRoot from "../../components/TableComponents/GridRoot";
import SearchForm from "../../components/TableComponents/SearchForm/SearchForm";
import TableContainerComponent from "../../components/TableComponents/TableContainerComponent";
import PagingPanel from "../../components/TableComponents/PagingPanel";
import { columnExtensions, availableItemsPerPage } from "../../constants";

type PropsT = {
  data: OfflineUsersT[],
  columns: ColumnT[],
  page: number,
  count: number,
  total: number,
  changeCurrentPage: Function,
  changePageSize: Function,
  filterOptions: OptionT[]
};

const forValues = {
  phone: ["phone"],
  date: ["taskStartDate", "taskEndDate", "uploadDate"]
};

const wordWrapStyles = {
  whiteSpace: "normal",
  wordWrap: "break-word"
};

const CellComponent = ({ style, ...props }) => {
  return <Table.Cell style={wordWrapStyles} {...props} />;
};

const expandedColumnExtensions = [...columnExtensions, { columnName: "geoName", width: 300 }];

export default class OfflineUsersTable extends React.Component<PropsT> {
  render() {
    const { columns, data, page, count, filterOptions, total, changeCurrentPage, changePageSize } = this.props;

    return (
      <Grid rows={data} columns={columns} rootComponent={GridRoot}>
        <SearchState />
        <PagingState
          currentPage={page}
          onCurrentPageChange={changeCurrentPage}
          pageSize={count}
          onPageSizeChange={changePageSize}
        />
        <CustomPaging totalCount={total} />

        <PhoneProvider for={forValues.phone} />
        <DateFormatProvider for={forValues.date} />
        <Table
          height="auto"
          columnExtensions={expandedColumnExtensions}
          containerComponent={TableContainerComponent}
          cellComponent={CellComponent}
        />
        <TableHeaderRow cellComponent={HeaderWrap} />
        <Toolbar rootComponent={ToolbarRoot} />
        <SearchForm selectOptions={filterOptions} placeholder="Пошук" />
        <PagingPanel pageSizes={availableItemsPerPage} noData={!data.length} />
      </Grid>
    );
  }
}
