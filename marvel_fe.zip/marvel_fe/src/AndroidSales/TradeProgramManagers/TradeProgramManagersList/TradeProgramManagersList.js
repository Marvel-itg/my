// @flow
import React from "react";
import { compose } from "redux";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import TradeProgramManagersTable from "../TradeProgramManagersTable/TradeProgramManagersTable";
import Modal from "../../../components/Modal/Modal";
import DeactivateForm from "../../../components/DeactivateForm/DeactivateForm";
import AdminProfileForm from "../../AdminProfileForm/AdminProfileForm";
import { toolbarOptions } from "../../../constants";
import {
  receiveTradeProgramManagerList,
  activateTradeProgramManager,
  deactivateTradeProgramManager,
  addNewManager
} from "../../../store/actions/sales/tradeProgramManagersSales";
import { errorStateProfile, errorStateDeactivating } from "../../../store/selectors/sales/manager";
import { clearTradeProgramManagerInfo } from "../../../store/actions/sales/tradeProgramManagerProfile";
import { closeModal, openModal } from "../../../store/actions/common/modals";
import { phoneWithCode } from "../../../utils/formatValues.js";
import { classes } from "../../../helpers/spinner";

const tabs = [toolbarOptions.active, toolbarOptions.notActive];

type PropsT = {
  receiveTradeProgramManagerList: Function,
  activateTradeProgramManager: Function,
  deactivateTradeProgramManager: Function,
  addNewManager: Function,
  clearTradeProgramManagerInfo: Function,
  tradeProgramManagersList: TradeProgramManagerT[],
  history: BrowserHistory,
  loading: boolean,
  closeModal: Function,
  openModal: Function,
  errorMessage: string
};

type StateT = {
  value: string,
  modalType: string,
  modalBody: any,
  id: ?number
};

class TradeProgramManagersList extends React.Component<PropsT, StateT> {
  state = {
    value: "3",
    modalType: "",
    modalBody: <div />,
    id: null
  };

  componentDidMount() {
    this.props.receiveTradeProgramManagerList(this.state.value);
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.value !== this.state.value) {
      this.props.receiveTradeProgramManagerList(this.state.value);
    }
  }

  changeTab = (event, value) => this.setState({ value });

  submitDeactivateForm = values => {
    values.accountId = this.state.id;
    this.props.deactivateTradeProgramManager(values);
  };

  submitAddForm = values => {
    const phone = phoneWithCode(values.phone);
    const { firstName, lastName, middleName } = values;
    const normalizedValues = {
      firstName,
      lastName,
      middleName,
      phone
    };
    this.props.addNewManager(normalizedValues);
  };

  openModal = (type, id) => {
    switch (type) {
      case "deactivate": {
        const modalBody = (
          <DeactivateForm
            errorState={errorStateDeactivating}
            submitForm={this.submitDeactivateForm}
            form="DeactivateTradeProgramManager"
            title="Деактивувати менеджера торгівельних програм?"
            textFieldLabel="Додати коментар"
            textFieldName="comment"
            submitButtonText="Деактивувати"
            cancelButtonText="Ні"
            cancelButtonHandler={this.props.closeModal}
          />
        );
        return this.setState({ modalBody, modalType: "deactivate", id }, () => {
          this.props.openModal();
        });
      }
      case "add": {
        const modalBody = (
          <AdminProfileForm
            clearDataHandler={this.props.clearTradeProgramManagerInfo}
            submitForm={this.submitAddForm}
            form="addTradeProgramManager"
            errorState={errorStateProfile}
            formTitle="Новий менеджер"
          />
        );
        return this.setState({ modalBody, modalType: "" }, () => {
          this.props.openModal();
        });
      }
      default:
        return null;
    }
  };

  deactivateManager = id => {
    this.openModal("deactivate", id);
  };

  openAddModal = () => this.openModal("add");

  activateManager = id => {
    this.props.activateTradeProgramManager(id);
  };

  render() {
    const { tradeProgramManagersList, loading } = this.props;
    return (
      <React.Fragment>
        <Paper square className="mainContent">
          <TradeProgramManagersTable
            data={tradeProgramManagersList}
            activeTab={this.state.value}
            changeTab={this.changeTab}
            deactivate={this.deactivateManager}
            activate={this.activateManager}
            openAddModal={this.openAddModal}
            history={this.props.history}
            tabs={tabs}
          />
        </Paper>
        {loading && <CircularProgress classes={classes} />}
        <Modal type={this.state.modalType} formName="addTradeProgramManager">
          {this.state.modalBody}
        </Modal>
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({ tradeProgramManagerReducer: { tradeProgramManagersList, loading, error } }) => ({
  tradeProgramManagersList,
  loading,
  errorMessage: error
});

const mapDispatchToProps = {
  receiveTradeProgramManagerList,
  activateTradeProgramManager,
  deactivateTradeProgramManager,
  clearTradeProgramManagerInfo,
  addNewManager,
  openModal,
  closeModal
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(TradeProgramManagersList);
