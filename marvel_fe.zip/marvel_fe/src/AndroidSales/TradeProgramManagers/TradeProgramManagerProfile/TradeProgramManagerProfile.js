// @flow
import React from "react";
import Paper from "@material-ui/core/Paper/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import { compose } from "redux";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import type { BrowserHistory } from "history";
import ActivityTable from "../../../containers/ActivityHistoryTable/ActivityTable";
import AdminProfileForm from "../../AdminProfileForm/AdminProfileForm";
import {
  receiveTradeProgramManagerProfile,
  editTradeProgramManagerProfile,
  clearTradeProgramManagerInfo
} from "../../../store/actions/sales/tradeProgramManagerProfile";
import { errorStateProfile, activityHistorySelector } from "../../../store/selectors/sales/manager";
import { classes } from "../../../helpers/spinner";
import { phoneWithCode } from "../../../utils/formatValues.js";
import { activityHistoryColumns } from "../../../constants";
import styles from "./TradeProgramManagerProfile.module.scss";

type PropsT = {
  tradeProgramManagerProfile: TradeProgramManagerT | null,
  receiveTradeProgramManagerProfile: Function,
  editTradeProgramManagerProfile: Function,
  clearTradeProgramManagerInfo: Function
};
type StateT = {
  isEditing: boolean
};

class TradeProgramManagerProfile extends React.Component<PropsT & BrowserHistory, StateT> {
  state = { isEditing: false };

  componentDidMount() {
    const { id } = this.props.match.params;

    if (id) {
      this.props.receiveTradeProgramManagerProfile(id);
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.submitted && !prevProps.submitted) {
      this.setState({
        isEditing: false
      });
    }
  }

  submitForm = data => {
    const { id } = this.props.match.params;
    const { firstName, lastName, middleName } = data;
    const phone = phoneWithCode(data.phone);
    const normalizeData = {
      accountId: id,
      firstName,
      lastName,
      middleName,
      phone
    };
    this.props.editTradeProgramManagerProfile(normalizeData);
  };

  changeMode = event => {
    event.preventDefault();
    this.setState(prevState => ({ isEditing: !prevState.isEditing }));
  };

  render() {
    const { loading } = this.props;
    return loading ? (
      <CircularProgress classes={classes} />
    ) : (
      <Paper className="mainContent">
        <div className={styles.formWrapper}>
          <AdminProfileForm
            clearDataHandler={this.props.clearTradeProgramManagerInfo}
            info={this.props.tradeProgramManagerProfile}
            isEditing={this.state.isEditing}
            submitForm={this.submitForm}
            changeMode={this.changeMode}
            form="tradeProgramManagerProfileForm"
            errorState={errorStateProfile}
            editMode
          />
          <ActivityTable data={this.props.activityHistoryData} columns={activityHistoryColumns} />
        </div>
      </Paper>
    );
  }
}

const mapStateToProps = state => {
  const {
    tradeProgramManagerProfile: { tradeProgramManagerProfile, receivingProfile, submitted }
  } = state;
  return {
    tradeProgramManagerProfile: tradeProgramManagerProfile && tradeProgramManagerProfile.account,
    activityHistoryData: activityHistorySelector(state),
    loading: receivingProfile,
    submitted
  };
};

const mapDispatchToProps = {
  receiveTradeProgramManagerProfile,
  editTradeProgramManagerProfile,
  clearTradeProgramManagerInfo
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(TradeProgramManagerProfile);
