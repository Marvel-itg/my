// @flow
import React from "react";
import { connect } from "react-redux";
import { compose } from "redux";
import { reduxForm, Field, formValueSelector } from "redux-form";
import type { FormProps } from "redux-form";

import CircularProgress from "@material-ui/core/CircularProgress";
import Paper from "@material-ui/core/Paper/Paper";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import InputFileMultiple from "../../components/InputFileMultiple/InputFileMultiple";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import Select from "../../components/Select/Select";
import { required } from "./validate";
import { saveScanCodesFile } from "../../store/actions/sales/scanCodesUpload";
import { brandsOptionsSelector } from "../../store/selectors/sales/brands";
import { getBrandsFullInfo } from "../../store/actions/sales/brands";
import { resetImages } from "../../store/actions/common/images";
import { classes } from "../../helpers/spinner";
import styles from "./ScanCodesUpload.module.scss";

type PropsT = {
  loading: boolean,
  errorMessage: string,
  getBrandsFullInfo: Function
} & FormProps;

class ScanCodesUploadForm extends React.Component<PropsT> {
  componentDidMount() {
    this.props.getBrandsFullInfo();
  }
  componentDidUpdate(prevProps) {
    if (prevProps.brandName !== this.props.brandName && !!this.props.productName) {
      this.props.change("productName", "");
    }

    if (!prevProps.loaded && this.props.loaded) {
      this.props.reset();
      this.props.resetImages("scanCodes");
    }
  }
  submitForm = values => {
    const productId = values.productName.id;
    const scanCodes =
      values.scanCodes && values.scanCodes[0] && values.scanCodes[0].imageUrl.map(item => item.scanCode);
    this.props.saveScanCodesFile({ productId, scanCodes });
  };

  render() {
    const { handleSubmit, brands, errorMessage, loading, invalid, brandName } = this.props;
    return (
      <Paper className="mainContent">
        {loading ? (
          <CircularProgress classes={classes} />
        ) : (
          <form
            autoComplete="off"
            noValidate
            onSubmit={handleSubmit(this.submitForm)}
            className={styles.uploadCodesForm}
          >
            <Field
              required
              name="brandName"
              className={styles.select}
              component={Select}
              placeholder="Назва бренду"
              options={brands || []}
              validate={[required]}
            />
            <Field
              required
              name="productName"
              className={styles.select}
              component={Select}
              placeholder="Назва продукту"
              options={(brandName && brandName.products) || []}
              validate={[required]}
            />
            <Field
              required
              component={InputFileMultiple}
              name="scanCodes"
              id="scanCodes"
              label="Завантажити CSV"
              limit={1}
              uploadType="scanCodes"
              validate={[required]}
            />

            <ContainedButton type="submit" disabled={invalid} label="Зберегти" className={styles.submitButton} />
            {errorMessage && <ErrorMessage error={errorMessage} />}
          </form>
        )}
      </Paper>
    );
  }
}

const mapStateToProps = state => {
  const selector = formValueSelector("scanCodesUpload");
  const brandName = selector(state, "brandName");
  const productName = selector(state, "productName");
  const {
    scanCodesUpload: { error, loading, loaded }
  } = state;
  return {
    brands: brandsOptionsSelector(state),
    brandName,
    productName,
    errorMessage: error,
    loading,
    loaded
  };
};
const mapDispatchToProps = {
  saveScanCodesFile,
  getBrandsFullInfo,
  resetImages
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  reduxForm({
    form: "scanCodesUpload"
  })
)(ScanCodesUploadForm);
