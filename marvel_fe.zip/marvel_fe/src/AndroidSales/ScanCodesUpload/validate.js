export const required = value => (value ? undefined : "Обов'язкове поле");
