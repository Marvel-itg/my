// @flow
import React from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper";
import PricesTable from "./PricesTable/PricesTable";
import CircularProgress from "@material-ui/core/CircularProgress";
import { fetchPrices, editPrice } from "../../store/actions/sales/pricesListSales";
import { classes } from "../../helpers/spinner";

type PropsT = {
  pricesList: PriceT[],
  fetchPrices: Function,
  editPrice: Function,
  history: BrowserHistory,
  submitting: boolean,
  loading: boolean
};

const columns = [
  { name: "production", title: "Товарна одиниця" },
  { name: "price", title: "Ціна" }
];

class ListOfActualPrices extends React.Component<PropsT> {
  componentDidMount() {
    this.props.fetchPrices();
  }

  render() {
    const { pricesList, editPrice, history, submitting, loading } = this.props;
    const spinner = submitting || loading;
    return (
      <React.Fragment>
        {spinner ? (
          <CircularProgress classes={classes} />
        ) : (
          <Paper square className="mainContent">
            <PricesTable data={pricesList} columns={columns} editPrice={editPrice} history={history} />
          </Paper>
        )}
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({ pricesList: { pricesList, submitting, loading } }) => {
  return {
    pricesList,
    submitting,
    loading
  };
};

const mapDispatchToProps = {
  fetchPrices,
  editPrice
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(ListOfActualPrices);
