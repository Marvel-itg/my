// @flow
import React, { useCallback } from "react";
import ProductSectionTop from "../ProductSectionTop/ProductSectionTop";
import ProductItem from "../ProductItem/ProductItem";
import withOrderChange from "../../../HOCs/withOrderChange";
import { itemTypes } from "../../../constants";

import styles from "./ProductSection.module.scss";

type ProductSectionBlockT = ProductSectionT & {
  openModal: Function,
  openSectionModal: Function,
  moveComponent: Function,
  style: Object | null,
  isDraggingBlock: boolean,
  endMovement: Function,
  isReorderOn: boolean
};

const EnhancedProductItem = withOrderChange(ProductItem);

const ProductSection = React.forwardRef<ProductSectionBlockT, any>((props: ProductSectionBlockT, ref: any) => {
  const {
    name,
    nameColor,
    color,
    productSectionItems,
    openModal,
    openSectionModal,
    id,
    moveComponent,
    isActive,
    endMovement,
    isDraggingBlock,
    isReorderOn
  } = props;
  const moveProductComponent = useCallback(
    (dragIndex, hoverIndex) => {
      moveComponent(dragIndex, hoverIndex, id);
    },
    [productSectionItems]
  );
  return (
    <div ref={ref.preview} style={props.style} className={isActive ? styles.root : styles.rootDisabled}>
      <ProductSectionTop
        ref={ref.ref}
        name={name}
        nameColor={nameColor}
        color={color}
        openSectionModal={openSectionModal}
        id={id}
        isActive={isActive}
      />
      {!isDraggingBlock && !isReorderOn && (
        <div className={styles.wrapper}>
          {productSectionItems &&
            productSectionItems.map((item, indexProduct) => (
              <EnhancedProductItem
                index={indexProduct}
                itemType={itemTypes.Product}
                key={item.id}
                data={item.product}
                moveComponent={moveProductComponent}
                openModal={openModal}
                sectionId={id}
                endMovement={endMovement}
              />
            ))}
        </div>
      )}
    </div>
  );
});

export default ProductSection;
