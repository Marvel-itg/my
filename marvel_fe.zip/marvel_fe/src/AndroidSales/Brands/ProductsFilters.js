// @flow
import React from "react";
import { reduxForm } from "redux-form";
// $FlowFixMe
import { Button } from "@material-ui/core";
import AddIcon from "@material-ui/icons/Add";
import styles from "./Brand.module.scss";

type PropsT = {
  openProductModal: Function,
  openSectionModal: Function,
  reorderSections: Function,
  isReorderOn: boolean
};

const ProductsFilters = (props: PropsT) => {
  return (
    <div className={styles.buttonWrapper}>
      <Button color={props.isReorderOn ? "secondary" : "primary"} variant="contained" onClick={props.reorderSections}>
        {props.isReorderOn ? "Редагування підсімей" : "Редагування товарів"}
      </Button>
      <Button color="primary" variant="contained" onClick={props.openSectionModal} aria-label="Add">
        <AddIcon />
        Додати підсім'ю
      </Button>
      <Button color="primary" variant="contained" onClick={props.openProductModal} aria-label="Add">
        <AddIcon />
        Додати одиницю товару
      </Button>
    </div>
  );
};

export default reduxForm({
  form: "ProductsPackFormat"
})(ProductsFilters);
