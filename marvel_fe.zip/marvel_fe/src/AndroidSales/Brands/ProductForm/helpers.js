export const formatFormValues = values => {
  const formattedValues = {};
  if (values.id) {
    formattedValues.id = values.id;
  }
  formattedValues.code = Number(values.code);
  formattedValues.packsInBlockCount = Number(values.packsInBlockCount.value);
  formattedValues.name = values.originalName;
  formattedValues.nationalName = values.nationalName;
  formattedValues.price = Math.round(values.price * 100);
  formattedValues.tar = values.tar * 10;
  formattedValues.nicotine = Math.round(values.nicotine * 10);
  formattedValues.imageUrl = values.photo && values.photo[0] && values.photo[0].imageUrl;
  formattedValues.productTypeId = values.productTypeId.value;
  formattedValues.packFormatId = values.packFormatId.value;
  formattedValues.filterTypeId = values.filterTypeId.value;
  formattedValues.productSectionId = values.productSectionId.value;
  formattedValues.brandId = values.brandId;
  formattedValues.taste = values.taste;
  formattedValues.isActive = values.isActive;
  formattedValues.displayAsNovelty = values.displayAsNovelty;
  formattedValues.displayIndex = values.displayIndex || 0;
  return formattedValues;
};
