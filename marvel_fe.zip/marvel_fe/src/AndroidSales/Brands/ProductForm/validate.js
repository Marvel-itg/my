import { validationErrorMessages } from "../../../constants";

export default function validate(values) {
  const { required, tooLongName } = validationErrorMessages({ maxLength: 300 });
  const errors = {};
  if (!values.photo || !values.photo.length) {
    errors.photo = required;
  }
  if (!values.originalName || !values.originalName.trim().length) {
    errors.originalName = required;
  } else if (values.originalName.length > 35) {
    const { tooLongName } = validationErrorMessages({ maxLength: 35 });
    errors.originalName = tooLongName;
  }

  if (values.nationalName && values.nationalName.length > 35) {
    const { tooLongName } = validationErrorMessages({ maxLength: 35 });
    errors.nationalName = tooLongName;
  }

  if (!values.code) {
    errors.code = required;
  }

  if (!values.packFormatId) {
    errors.packFormatId = required;
  }
  if (!values.packsInBlockCount) {
    errors.packsInBlockCount = required;
  }
  if (!values.productTypeId) {
    errors.productTypeId = required;
  }
  if (!values.tar) {
    errors.tar = required;
  } else if (values.tar > 50) {
    const { maxAmountMilligrams } = validationErrorMessages({ maxAmountMilligrams: 50 });
    errors.tar = maxAmountMilligrams;
  }
  if (!+values.nicotine) {
    errors.nicotine = required;
  } else if (values.nicotine > 50) {
    const { maxAmountMilligrams } = validationErrorMessages({ maxAmountMilligrams: Number.parseFloat(50).toFixed(1) });
    errors.nicotine = maxAmountMilligrams;
  }

  if (!values.filterTypeId) {
    errors.filterTypeId = required;
  }
  if (values.taste && values.taste.length > 300) {
    errors.taste = tooLongName;
  }
  if (!values.price) {
    errors.price = required;
  } else if (+values.price < 1) {
    const { minPrice } = validationErrorMessages({ minPrice: 1 });
    errors.price = minPrice;
  } else if (values.price > 600) {
    const { maxPrice } = validationErrorMessages({ maxPrice: 600 });
    errors.price = maxPrice;
  }

  return errors;
}
