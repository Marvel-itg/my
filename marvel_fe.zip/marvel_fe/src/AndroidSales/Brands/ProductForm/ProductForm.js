// @flow
import React from "react";
import type { FormProps } from "redux-form";
import { Field, reduxForm } from "redux-form";
import NumberFormat from "react-number-format";
import { compose } from "redux";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import TextField from "@material-ui/core/TextField";
import CircularProgress from "@material-ui/core/CircularProgress";
import InputField from "../../../components/InputField/InputField";
import InputFileMultiple from "../../../components/InputFileMultiple/InputFileMultiple";
import Select from "../../../components/Select/Select";
import ContainedButton from "../../../components/Buttons/ContainedButton/ContainedButton";
import DestructiveButton from "../../../components/Buttons/DestructiveButton/DestructiveButton";
import ErrorMessage from "../../../components/ErrorMessage/ErrorMessage";
import { createProduct, deleteProduct, editProduct } from "../../../store/actions/sales/brands";
import {
  filterTypeOptionsSelector,
  initialValuesSelector,
  packFormatOptionsSelector,
  productSectionsListOptionsSelector,
  productTypeOptionsSelector
} from "../../../store/selectors/sales/brands";
import validate from "./validate";
import { isValueLessThanMax } from "../../../utils/formatValues";
import {
  normalizeBrandCode,
  normalizeBrandName,
  normalizeCyrillicBrandName,
  normalizeInteger
} from "../../../utils/reduxFormNormalizers";
import { formatFormValues } from "./helpers";
import { classes } from "../../../helpers/spinner";
import styles from "./ProductForm.module.scss";
import CheckBox from "../../../components/CheckBox/CheckBox";

type PropsT = {
  editProduct: Function,
  createProduct: Function,
  loading: boolean,
  formModalIsOpened: boolean,
  errorMessage: string
} & FormProps;

class ProductForm extends React.Component<PropsT> {
  submitForm = values => {
    const { id, match } = this.props;
    const brandId = match.params.id;
    const formattedValues = formatFormValues({
      ...values,
      originalName: values.originalName.trim(),
      nationalName: values.nationalName && values.nationalName.trim(),
      brandId,
      id,
      isActive: id ? values.isActive : 0
    });
    id ? this.props.editProduct(formattedValues) : this.props.createProduct(formattedValues);
  };

  deleteProduct = () => {
    this.props.deleteProduct(this.props.id);
  };

  activateProduct = () => {
    this.props.editProduct(formatFormValues({ ...this.props.initialValues, isActive: true }));
  };

  renderDecimalNumberField = props => {
    const { meta } = props;
    const { decimalScale = 2 } = props;
    const error = meta && meta.touched && meta.error;
    return (
      <NumberFormat
        required={props.required}
        className={styles.inputField}
        value={props.input.value}
        decimalScale={decimalScale}
        fixedDecimalScale
        allowEmptyFormatting={false}
        allowNegative={false}
        isAllowed={isValueLessThanMax}
        customInput={TextField}
        onValueChange={({ value }: { value: string }) => props.input.onChange(value)}
        onBlur={props.input.onBlur}
        label={props.label}
        error={!!error}
        helperText={error}
      />
    );
  };

  renderDecimalNumberFieldWithOneDigitAfterDot = props => {
    const extendedProps = { ...props, decimalScale: 1 };
    return this.renderDecimalNumberField(extendedProps);
  };

  render() {
    const {
      handleSubmit,
      loading,
      id,
      packFormatOptions,
      productTypeOptions,
      filterTypeOptions,
      invalid,
      errorMessage,
      imageTransactionSuccess,
      productSectionList,
      initialValues
    } = this.props;
    const keyWord = id ? "Змiнити" : "Додати";
    const isActive = initialValues && initialValues.isActive;
    return loading ? (
      <CircularProgress classes={classes} />
    ) : (
      <form
        autoComplete="off"
        noValidate
        onSubmit={handleSubmit(this.submitForm)}
        className={styles.newConsultantFormWrapper}
      >
        <div className={styles.formTitle}>{keyWord} одиницю товару</div>

        <Field
          required
          name="photo"
          component={InputFileMultiple}
          fullWidth
          withPreview
          bigPreview
          editMode={!!id}
          disabled={!imageTransactionSuccess}
          id="productFormPhoto"
        />

        <Field
          required
          name="originalName"
          component={InputField}
          className={styles.inputField}
          normalize={normalizeBrandName}
        />

        <Field
          name="nationalName"
          component={InputField}
          className={styles.inputField}
          normalize={normalizeCyrillicBrandName}
        />
        <Field
          required
          name="code"
          component={InputField}
          className={styles.inputField}
          normalize={normalizeBrandCode}
        />
        <Field required name="packsInBlockCount" component={Select} className={styles.inputField} />

        <Field
          required
          name="packFormatId"
          component={Select}
          className={styles.inputField}
          isSearchable
          options={packFormatOptions}
        />
        <Field
          required
          name="productTypeId"
          component={Select}
          className={styles.inputField}
          options={productTypeOptions}
        />

        <Field
          required
          name="productSectionId"
          component={Select}
          className={styles.inputField}
          options={productSectionList}
        />

        <Field required name="tar" component={InputField} className={styles.inputField} normalize={normalizeInteger} />

        <Field
          required
          name="nicotine"
          component={this.renderDecimalNumberFieldWithOneDigitAfterDot}
          className={styles.inputField}
          label="Нікотин, мг"
        />

        <Field name="taste" component={InputField} className={styles.inputField} label="Смак" multiline />

        <Field
          required
          name="filterTypeId"
          component={Select}
          className={styles.inputField}
          isSearchable
          options={filterTypeOptions}
        />
        <Field
          required
          name="price"
          component={this.renderDecimalNumberField}
          className={styles.inputField}
          label="Ціна"
        />

        <Field name="displayAsNovelty" component={CheckBox} label="Відобразити іконку “НОВИНКА”" />

        <ContainedButton disabled={invalid} type="submit" label={keyWord} className={styles.createButton} />
        {!!id && isActive && (
          <DestructiveButton handleClick={this.deleteProduct} label="Деактивувати" className={styles.deleteButton} />
        )}

        {!!id && !isActive && initialValues.isSectionActive && (
          <ContainedButton
            handleClick={() => this.activateProduct()}
            label="Активувати"
            className={styles.deleteButton}
          />
        )}
        {errorMessage && <ErrorMessage error={errorMessage} />}
      </form>
    );
  }
}

const mapStateToProps = state => {
  return {
    initialValues: initialValuesSelector(state),
    filterTypeOptions: filterTypeOptionsSelector(state),
    packFormatOptions: packFormatOptionsSelector(state),
    productTypeOptions: productTypeOptionsSelector(state),
    productSectionList: productSectionsListOptionsSelector(state),
    errorMessage: state.brands.error,
    loading: state.brands.loading || state.brands.submitting,
    imageTransactionSuccess: state.images && state.images.imageTransactionSuccess
  };
};

const mapDispatchToProps = {
  editProduct,
  createProduct,
  deleteProduct
};

export default compose(
  withRouter,
  connect(mapStateToProps, mapDispatchToProps),
  reduxForm({
    form: "ProductForm",
    enableReinitialize: true,
    validate
  })
)(ProductForm);
