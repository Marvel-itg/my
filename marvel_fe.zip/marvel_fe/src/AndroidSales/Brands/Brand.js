// @flow
import React, { Fragment, PureComponent } from "react";
import { connect } from "react-redux";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import ProductsFilters from "./ProductsFilters";
import Modal from "../../components/Modal/Modal";
import ProductFrom from "./ProductForm/ProductForm";
import {
  changeBrandsFormat,
  getProductDetails,
  getProductsAdditionalData,
  getProductsByBrand,
  getProductSectionDetails,
  resetProductDetails,
  setBrandId
} from "../../store/actions/sales/brands";
import { openModal } from "../../store/actions/common/modals";
import { packFormatOptionsSelector, productSectionsSortByOrder } from "../../store/selectors/sales/brands";

import brandsStyles from "./Brand.module.scss";
import ProductSectionForm from "./ProductSectionForm/ProductSectionForm";
import { getBrandSettings } from "../../store/actions/admin/brandSettings";
import ProductSectionList from "./ProductSectionList/ProductSectionList";

type PropsT = {
  openModal: Function,
  productsList: ProductSectionT[],
  packFormatsOptions: OptionT[],
  loading: boolean,
  loadingAdditional: boolean,
  submitted: boolean
} & BrowserHistory;

type StateT = {
  openedProductId: null | number,
  openedProductSectionId: null | number,
  brandId: null | number,
  isReorderOn: boolean
};

const paperBrandStyle = { root: brandsStyles.paper };

class Brand extends PureComponent<PropsT, StateT> {
  state = {
    openedProductId: null,
    openedProductSectionId: null,
    brandId: Number(this.props.match.params.id),
    isReorderOn: false
  };

  modalBody = (<div />);

  componentDidMount() {
    const { id } = this.props.match.params;
    this.props.getProductsAdditionalData();
    this.props.getProductsByBrand(id);
    this.props.getBrandSettings();
    this.props.setBrandId(Number(id));
  }

  componentDidUpdate(prevProps) {
    const { id } = this.props.match.params;
    if (id !== prevProps.match.params.id) {
      this.props.getProductsByBrand(id);
    }
    if (!prevProps.submitted && this.props.submitted) {
      this.props.getProductsByBrand(id);
    }
  }

  openProductModal = (event: SyntheticEvent<Function>, id: number) => {
    this.props.getProductDetails(id);
    this.setState({ openedProductId: id });
    this.props.openModal("ProductFormModal");
  };

  openSectionModal = (event: SyntheticEvent<Function>, id: number) => {
    this.props.getProductSectionDetails(id);
    this.setState({ openedProductSectionId: id });
    this.props.openModal("ProductSectionFormModal");
  };

  reorderSections = () => {
    this.setState({ isReorderOn: !this.state.isReorderOn });
  };

  render() {
    const { loading, loadingAdditional, productsList } = this.props;
    return (
      <Paper classes={paperBrandStyle}>
        {loading || loadingAdditional ? (
          <CircularProgress classes={{ root: "spinner" }} />
        ) : (
          <Fragment>
            <ProductsFilters
              openProductModal={this.openProductModal}
              openSectionModal={this.openSectionModal}
              reorderSections={this.reorderSections}
              isReorderOn={this.state.isReorderOn}
            />
            <div className={brandsStyles.swipeableViewsWrapper}>
              <ProductSectionList
                productsList={productsList}
                openModal={this.openProductModal}
                openSectionModal={this.openSectionModal}
                brandId={this.state.brandId}
                isReorderOn={this.state.isReorderOn}
              />
            </div>
            <Modal formName="ProductSectionForm" modalName="ProductSectionFormModal">
              <ProductSectionForm brandId={this.state.brandId} id={this.state.openedProductSectionId} />
            </Modal>
            <Modal formName="ProductForm" modalName="ProductFormModal">
              <ProductFrom id={this.state.openedProductId} />
            </Modal>
          </Fragment>
        )}
      </Paper>
    );
  }
}

const mapStateToProps = state => {
  const {
    brands: { loading, loadingAdditional, submitted }
  } = state;
  return {
    productsList: productSectionsSortByOrder(state),
    packFormatsOptions: packFormatOptionsSelector(state),
    loading,
    submitted,
    loadingAdditional
  };
};

const mapDispatchToProps = {
  getProductsByBrand,
  getProductsAdditionalData,
  changeBrandsFormat,
  getProductDetails,
  getProductSectionDetails,
  resetProductDetails,
  openModal,
  getBrandSettings,
  setBrandId
};
export default connect(mapStateToProps, mapDispatchToProps)(Brand);
