// @flow
import React, { useCallback, useState } from "react";
import { useDispatch } from "react-redux";
import update from "immutability-helper";
import ProductSection from "../ProductSection/ProductSection";
import { reorderProductSection } from "../../../store/actions/sales/brands";
import withOrderChange from "../../../HOCs/withOrderChange";
import { itemTypes } from "../../../constants";

const EnhancedProductSection = withOrderChange(ProductSection);

type PropsT = {
  productsList: ProductSectionT[],
  openModal: Function,
  openSectionModal: Function,
  brandId: number | null,
  isReorderOn: boolean
};

const ProductSectionList = ({ productsList, openModal, openSectionModal, brandId, isReorderOn }: PropsT) => {
  const [sectionList, setSectionList] = useState<ProductSectionT[]>(productsList);
  const dispatch = useDispatch();

  const getModernizeList = list => {
    if (!list) return [];
    return list.map((section, index) => ({
      id: section.id,
      displayIndex: index,
      items: section.productSectionItems.map((product, index) => ({
        id: product.id,
        displayIndex: index
      }))
    }));
  };

  const [modernizeInnerList, setModernizeInnerList] = useState(getModernizeList(sectionList));

  const moveComponent = useCallback(
    (dragIndex, hoverIndex, sectionId) => {
      let modernizeList;
      if (sectionId) {
        modernizeList = sectionList.map(item => {
          if (item.id === sectionId) {
            const dragCard = item.productSectionItems[dragIndex];
            return {
              ...item,
              productSectionItems: update(item.productSectionItems, {
                $splice: [
                  [dragIndex, 1],
                  [hoverIndex, 0, dragCard]
                ]
              })
            };
          }
          return item;
        });
        setSectionList(modernizeList);
      } else {
        const dragCard = sectionList[dragIndex];
        modernizeList = update(sectionList, {
          $splice: [
            [dragIndex, 1],
            [hoverIndex, 0, dragCard]
          ]
        });
        setSectionList(modernizeList);
      }
      modernizeList = getModernizeList(modernizeList);

      setModernizeInnerList(modernizeList);
    },
    [sectionList]
  );

  const endMovement = () => {
    dispatch(reorderProductSection(modernizeInnerList, brandId));
  };
  return (
    <>
      {sectionList &&
        sectionList.map((section: ProductSectionT, index: number) => (
          <EnhancedProductSection
            index={index}
            itemType={itemTypes.Section}
            key={section.id}
            {...section}
            moveComponent={moveComponent}
            openModal={openModal}
            openSectionModal={openSectionModal}
            endMovement={endMovement}
            isReorderOn={isReorderOn}
          />
        ))}
    </>
  );
};

export default ProductSectionList;
