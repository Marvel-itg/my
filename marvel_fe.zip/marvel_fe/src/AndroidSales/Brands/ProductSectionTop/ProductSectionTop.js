// @flow
import React from "react";
import { IconButton } from "@material-ui/core";
import { Apps, Create } from "@material-ui/icons";
import styles from "./ProductSectionTop.module.scss";

type ProductSectionTopT = {
  id?: number,
  name: string,
  displayIndex?: number,
  color: string,
  nameColor: string,
  skuColor?: string,
  openSectionModal: Function
};

const ProductSectionTop = React.forwardRef<ProductSectionTopT, any>((props: ProductSectionTopT, ref) => {
  const { name, nameColor, color, id } = props;
  return (
    <div className={styles.wrapper} style={{ background: `#${color}`, color: `#${nameColor}` }}>
      <div className={styles.title}>{name}</div>
      <div className={styles.actions}>
        <IconButton onClick={event => props.openSectionModal(event, id)}>
          <Create style={{ color: `#${nameColor}` }} />
        </IconButton>
        <span ref={ref}>
          <IconButton ref={ref}>
            <Apps style={{ color: `#${nameColor}` }} />
          </IconButton>
        </span>
      </div>
    </div>
  );
});

export default ProductSectionTop;
