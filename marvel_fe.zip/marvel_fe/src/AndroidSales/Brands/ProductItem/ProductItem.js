// @flow

import React from "react";
import { IconButton } from "@material-ui/core";
import EditIcon from "@material-ui/icons/Edit";
import Apps from "@material-ui/icons/Apps";
import { formatDecimals } from "../../../utils/formatValues";
import styles from "./ProductItem.module.scss";

type PropsT = {
  data: ProductT,
  openModal: Function,
  style: Object
};

const ProductItem = React.forwardRef<PropsT, any>(({ data, openModal, style }: PropsT, ref: any) => {
  const tar = data && data.tar && `${formatDecimals(data.tar)} мг`;
  const nicotine = data && data.nicotine && `${formatDecimals(data.nicotine).toFixed(1)} мг`;
  const isActive = data && data.isActive;
  const taste = data && data.taste;
  const handleClick = (event: SyntheticEvent<HTMLElement>) => {
    openModal(event, data.id);
  };
  const { ref: mainRef, preview } = ref;
  return (
    <div style={style} ref={preview} className={isActive ? styles.root : styles.rootDisabled}>
      <div className={styles.editIcon}>
        <IconButton onClick={handleClick}>
          <EditIcon />
        </IconButton>
        <div ref={mainRef}>
          <IconButton>
            <Apps />
          </IconButton>
        </div>
      </div>

      <div className={styles.imageWrapper}>
        <img src={data.imageUrl} alt="Cigarettes" className={styles.image} />
      </div>
      <div className={styles.content}>
        <h3 className={styles.name}>{data.name}</h3>
        {data.nationalName && <h4 className={styles.nationalName}>({data.nationalName})</h4>}
        <p>
          <b>Формат:</b> {data.packFormat}
        </p>
        <p>
          <b>Смола:</b> {tar}
        </p>
        <p>
          <b>Нiкотин:</b> {nicotine}
        </p>
        <p>
          <b>Фiльтр:</b> {data.filterType}
        </p>

        {!!taste && (
          <p>
            <b>Смак:</b> {taste}
          </p>
        )}
      </div>
    </div>
  );
});

export default ProductItem;
