// @flow
import React from "react";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import styles from "./Brand.module.scss";

type PropsT = {
  activeTab: number,
  changeTab: Function,
  tabs?: ItemT[]
};

const ProductsHeader = ({ activeTab, changeTab, tabs = [] }: PropsT) => {
  return (
    <div className={styles.header}>
      <div>
        <Tabs value={activeTab} indicatorColor="primary" textColor="primary" onChange={changeTab}>
          {tabs.map(tab => (
            <Tab key={tab.id} label={tab.name} />
          ))}
        </Tabs>
      </div>
    </div>
  );
};

export default ProductsHeader;
