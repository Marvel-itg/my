// @flow
import React, { useMemo } from "react";
import { compose } from "redux";
import { connect, useDispatch, useSelector } from "react-redux";
import type { FormProps } from "redux-form";
import { Field, reduxForm } from "redux-form";
import CircularProgress from "@material-ui/core/CircularProgress";
import InputField from "../../../components/InputField/InputField";
import ColorPicker from "../../../components/ColorPicker";
import Select from "../../../components/Select/Select";
import ContainedButton from "../../../components/Buttons/ContainedButton/ContainedButton";
import DestructiveButton from "../../../components/Buttons/DestructiveButton/DestructiveButton";
import { ProductsSectionMapper } from "../../../utils/mapper";
import {
  createProductSection,
  deactivateProductSection,
  editProductSection
} from "../../../store/actions/sales/brands";
import { initialValuesSectionSelector } from "../../../store/selectors/sales/brands";
import { normalizeBrandName } from "../../../utils/reduxFormNormalizers";
import validate from "./validate";
import { classes } from "../../../helpers/spinner";
import styles from "../ProductForm/ProductForm.module.scss";

type PropsT = {
  loading: boolean,
  id: number | string,
  brandId: number | string
} & FormProps;

const ProductSectionForm = ({ loading, id, invalid, handleSubmit, brandId, initialValues }: PropsT) => {
  const { brandSettings } = useSelector(state => state.brandSettings);
  const keyWord = id ? "Змiнити" : "Додати";
  const dispatch = useDispatch();
  const isActive = initialValues && initialValues.isActive;

  const brandLines = useMemo(() => {
    if (!brandSettings || !brandId) return [];
    const currentBrandLines = brandSettings.find(item => item.id === Number(brandId));
    return (
      currentBrandLines &&
      currentBrandLines.productLines.map(line => ({
        ...line,
        value: line.id,
        label: line.name
      }))
    );
  }, [brandSettings, brandId]);
  const submitForm = values => {
    const data = ProductsSectionMapper.productSectionDataToDto(values);
    if (id) {
      dispatch(editProductSection(data, brandId));
    } else {
      dispatch(createProductSection(data, brandId));
    }
  };

  const activateSection = () => {
    const data = ProductsSectionMapper.productSectionDataToDto({ ...initialValues, isActive: true });
    dispatch(editProductSection(data, brandId));
  };

  const deactivateSection = ({ id, brandId }) => {
    dispatch(deactivateProductSection(+id, +brandId));
  };
  return loading ? (
    <CircularProgress classes={classes} />
  ) : (
    <form autoComplete="off" noValidate onSubmit={handleSubmit(submitForm)}>
      <div className={styles.formTitle}>{keyWord} підсім'ю</div>

      <Field
        required
        name="sectionName"
        component={InputField}
        className={styles.inputField}
        normalize={normalizeBrandName}
      />
      <Field required name="sectionColor" component={ColorPicker} className={styles.inputField} />
      <Field required name="sectionNameColor" component={ColorPicker} className={styles.inputField} />
      <Field required name="sectionSkuColor" component={ColorPicker} className={styles.inputField} />
      <Field required name="productLineId" component={Select} className={styles.inputField} options={brandLines} />
      <ContainedButton disabled={invalid} type="submit" label={keyWord} className={styles.createButton} />
      {!!id && isActive && (
        <DestructiveButton
          handleClick={() => deactivateSection({ id, brandId })}
          label="Деактивувати"
          className={styles.deleteButton}
        />
      )}
      {!!id && !isActive && (
        <ContainedButton handleClick={() => activateSection()} label="Активувати" className={styles.deleteButton} />
      )}
    </form>
  );
};

const mapStateToProps = state => {
  return {
    initialValues: initialValuesSectionSelector(state)
  };
};

export default compose(
  connect(mapStateToProps),
  reduxForm({
    form: "ProductSectionForm",
    enableReinitialize: true,
    validate
  })
)(ProductSectionForm);
