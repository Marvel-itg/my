import { validationErrorMessages } from "../../../constants";

export default function validate(values) {
  const { required } = validationErrorMessages({ maxLength: 300 });
  const errors = {};

  if (!values.sectionName) {
    errors.sectionName = required;
  }

  if (!values.sectionColor) {
    errors.sectionColor = required;
  }

  if (!values.sectionNameColor) {
    errors.sectionNameColor = required;
  }

  if (!values.sectionSkuColor) {
    errors.sectionSkuColor = required;
  }

  if (!values.productLineId) {
    errors.productLineId = required;
  }

  return errors;
}
