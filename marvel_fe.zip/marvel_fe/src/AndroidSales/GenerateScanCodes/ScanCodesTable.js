// @flow
import React from "react";
import { Grid, TableHeaderRow, Table } from "@devexpress/dx-react-grid-material-ui";
import {
  DateFormatProvider,
  DownloadButtonProvider,
  ScanCodesStatusProvider,
  ScanCodesZipIconProvider,
  ScanCodesMbProvider
} from "../../components/FormattedData/FormattedData";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import GridRoot from "../../components/TableComponents/GridRoot";
import TableContainerComponent from "../../components/TableComponents/TableContainerComponent";
import PagingPanel from "../../components/TableComponents/PagingPanel";

import { defaultItemsPerPage, availableItemsPerPage, columnExtensions } from "../../constants";

type PropsT = {
  data: GeneratedScanCodesT[],
  columns: ColumnT[],
  page: number,
  count: number,
  total: number,
  changeCurrentPage: Function,
  changePageSize: Function,
  showDownloadButton: Function,
  handleDownload: Function
};

const forValues = {
  date: ["generationDate"],
  download: ["download"],
  state: ["state"],
  zip: ["skuName"],
  size: ["size"]
};

const expandedColumnExtensions = [
  ...columnExtensions,
  { columnName: "skuName", width: 250 },
  { columnName: "generationDate", width: 200 },
  { columnName: "state", width: 200 },
  { columnName: "count", width: 200 },
  { columnName: "size", width: 200 }
];

const ScanCodesTable = (props: PropsT) => {
  const {
    columns,
    data,
    page,
    count,
    total,
    changeCurrentPage,
    changePageSize,
    showDownloadButton,
    handleDownload
  } = props;

  return (
    <Grid rows={data} columns={columns} rootComponent={GridRoot}>
      <PagingState
        currentPage={page}
        onCurrentPageChange={changeCurrentPage}
        pageSize={count || defaultItemsPerPage}
        onPageSizeChange={changePageSize}
      />
      <DateFormatProvider for={forValues.date} />
      <DownloadButtonProvider
        for={forValues.download}
        showCondition={showDownloadButton}
        handleDownload={handleDownload}
      />
      <ScanCodesStatusProvider for={forValues.state} />
      <ScanCodesZipIconProvider for={forValues.zip} />
      <ScanCodesMbProvider for={forValues.size} />
      <CustomPaging totalCount={total} />
      <Table height="auto" columnExtensions={expandedColumnExtensions} containerComponent={TableContainerComponent} />
      <TableHeaderRow />
      <PagingPanel pageSizes={availableItemsPerPage} noData={!total} />
    </Grid>
  );
};

export default ScanCodesTable;
