// @flow
import React from "react";
import { connect } from "react-redux";
import { compose } from "redux";
import { reduxForm, Field, formValueSelector } from "redux-form";
import type { FormProps } from "redux-form";

import CircularProgress from "@material-ui/core/CircularProgress";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import InputField from "../../components/InputField/InputField";
import PasswordInputField from "../../components/InputField/PasswordInputField";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import FormLabel from "@material-ui/core/FormLabel";
import Select from "../../components/Select/Select";
import { validate } from "./validate";
import { brandsOptionsSelector } from "../../store/selectors/sales/brands";
import { getBrandsFullInfo } from "../../store/actions/sales/brands";
import { generateScanCodes } from "../../store/actions/sales/generateScanCodes";
import { onlyNumbers, onlyNumbersAndCapitalLetters } from "../../utils/reduxFormNormalizers";
import { classes } from "../../helpers/spinner";
import styles from "./ScanCodes.module.scss";
import CreatePasswordModal from "./CreatePasswordModal";

type PropsT = {
  generating: boolean,
  errorMessage: string,
  getBrandsFullInfo: Function
} & FormProps;

type StateT = {
  passwordModalOpen: boolean
};

class GenerateScanCodesForm extends React.Component<PropsT, StateT> {
  state = {
    passwordModalOpen: false
  };
  componentDidMount() {
    this.props.getBrandsFullInfo();
  }
  componentDidUpdate(prevProps) {
    if (prevProps.brandName !== this.props.brandName && !!this.props.productName) {
      this.props.change("productName", "");
    }
  }
  submitForm = values => {
    const { productName, password, amount } = values;
    const productId = productName.id;
    const params: GenerateScanCodesReqT = { productId, amount, password };
    const excludedCharacters = values.excludedCharacters && values.excludedCharacters.split(", ");
    if (excludedCharacters) {
      params.excludedCharacters = excludedCharacters;
    }
    this.closePasswordModal();
    this.props.generateScanCodes(params);
  };

  openPasswordModal = event => {
    event.preventDefault();
    this.setState({ passwordModalOpen: true });
  };

  closePasswordModal = () => {
    this.setState({ passwordModalOpen: false });
  };

  render() {
    const { brands, errorMessage, generating, brandName, formErrors = {} } = this.props;
    const disableSubmit =
      !!formErrors.brandName || !!formErrors.productName || !!formErrors.amount || !!formErrors.excludedCharacters;

    return (
      <div>
        {generating ? (
          <CircularProgress classes={classes} />
        ) : (
          <form autoComplete="off" noValidate className={styles.generateScanCodesForm}>
            <div className={styles.formTitle}>Генерація кодів</div>
            <Field
              required
              name="password"
              component={PasswordInputField}
              label="Введіть пароль"
              autoComplete="new-password"
              className={styles.hiddenField}
            />
            <Field
              required
              name="passwordConfirm"
              component={PasswordInputField}
              label="Введіть пароль ще раз (для перевірки)"
              autoComplete="new-password"
              className={styles.hiddenField}
            />
            <Field
              required
              name="brandName"
              className={styles.select}
              component={Select}
              placeholder="Назва бренду"
              options={brands || []}
            />
            <Field
              required
              name="productName"
              className={styles.select}
              component={Select}
              placeholder="Назва продукту"
              options={(brandName && brandName.products) || []}
            />
            <Field required name="amount" component={InputField} normalize={onlyNumbers} label="Кількість кодів" />
            <FormLabel component="legend" classes={{ root: styles.label }}>
              Параметри коду
            </FormLabel>
            <Field
              name="excludedCharacters"
              component={InputField}
              label="Виключити символи"
              normalize={onlyNumbersAndCapitalLetters}
            />
            <ContainedButton
              type="button"
              disabled={generating || disableSubmit}
              label="Згенерувати"
              className={styles.submitButton}
              handleClick={this.openPasswordModal}
            />
            {errorMessage && <ErrorMessage error={errorMessage} />}
            <CreatePasswordModal
              closePasswordModal={this.closePasswordModal}
              submitForm={this.submitForm}
              passwordModalOpen={this.state.passwordModalOpen}
              formErrors={formErrors}
            />
          </form>
        )}
      </div>
    );
  }
}

const mapStateToProps = state => {
  const selector = formValueSelector("generateScanCodes");
  const brandName = selector(state, "brandName");
  const productName = selector(state, "productName");

  const {
    generateScanCodes: { generateError, generating },
    form: { generateScanCodes }
  } = state;
  const errors = generateScanCodes && generateScanCodes.syncErrors;
  return {
    brands: brandsOptionsSelector(state),
    brandName,
    productName,
    errorMessage: generateError,
    generating,
    formErrors: errors
  };
};
const mapDispatchToProps = {
  getBrandsFullInfo,
  generateScanCodes
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  reduxForm({
    form: "generateScanCodes",
    validate
  })
)(GenerateScanCodesForm);
