// @flow
import React from "react";

import { reduxForm, Field } from "redux-form";
import type { FormProps } from "redux-form";

import Modal from "@material-ui/core/Modal";
import IconClose from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";

import PasswordInputField from "../../components/InputField/PasswordInputField";

import FormLabel from "@material-ui/core/FormLabel";

import { validate } from "./validate";
import { passwordNormalize } from "../../utils/reduxFormNormalizers";
import styles from "./ScanCodes.module.scss";

type PropsT = {
  submitForm: Function,
  passwordModalOpen: Function,
  closePasswordModal: Function
} & FormProps;

const CreatePasswordModal = (props: PropsT) => {
  const { handleSubmit, submitForm, passwordModalOpen, closePasswordModal, invalid } = props;
  return (
    <Modal open={passwordModalOpen} onClose={closePasswordModal}>
      <form className={styles.passwordModal}>
        <IconButton className={styles.closeButton} onClick={closePasswordModal}>
          <IconClose />
        </IconButton>
        <FormLabel component="legend" classes={{ root: styles.label }} className={styles.modalTitle}>
          Введіть пароль, який буде використовуватись для відкриття згенерованого архіву
        </FormLabel>
        <Field
          required
          name="password"
          component={PasswordInputField}
          label="Введіть пароль"
          autoComplete="new-password"
          normalize={passwordNormalize}
        />
        <Field
          required
          name="passwordConfirm"
          component={PasswordInputField}
          label="Введіть пароль ще раз (для перевірки)"
          autoComplete="new-password"
          normalize={passwordNormalize}
        />
        <span className={styles.message}>
          Пароль має містити від 12 до 20 символів. Це можуть бути комбінації літер (верхній та нижній регістри), цифр і
          символів
        </span>
        <div className={styles.buttonsWrapper}>
          <ContainedButton
            type="button"
            label="Скасувати"
            handleClick={closePasswordModal}
            className={styles.createPasswordButton}
          />

          <ContainedButton
            type="submit"
            disabled={invalid}
            label="Згенерувати"
            handleClick={handleSubmit(submitForm)}
            className={styles.createPasswordButton}
          />
        </div>
      </form>
    </Modal>
  );
};

export default reduxForm({
  form: "generateScanCodes",
  validate
})(CreatePasswordModal);
