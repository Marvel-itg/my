// @flow
import React from "react";
import { connect } from "react-redux";
import type { BrowserHistory } from "history";
import debounce from "es6-promise-debounce";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import Modal from "../../components/Modal/Modal";
import Toolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import ScanCodesTable from "./ScanCodesTable";
import GenerateScanCodesForm from "./GenerateScanCodesForm";
import { fetchScanCodesList, downloadScanCodesZip } from "../../store/actions/sales/generateScanCodes";
import { openModal } from "../../store/actions/common/modals";
import { getBrandsFullInfo } from "../../store/actions/sales/brands";
import { skuOptionsSelector } from "../../store/selectors/sales/brands";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  getCommonParams,
  shouldNotSendRequest,
  changeDateAndProductId
} from "../../helpers/common";
import { classes } from "../../helpers/spinner";

type PropsT = {
  scanCodesList: GeneratedScanCodesT[],
  loading: boolean,
  total: number,
  errorMessage: string,
  skuOptions: OptionT[],
  lastExcludedCharacters: string[],
  downloadScanCodesZip: Function,
  fetchScanCodesList: Function,
  getBrandsFullInfo: Function
} & BrowserHistory;

type StateT = {
  modalType: string,
  modalBody: any,
  formName: string
};

const columns = [
  { name: "skuName", title: "Назва SKU" },
  { name: "generationDate", title: "Дата генерації" },
  { name: "count", title: "Кількість кодів" },
  { name: "size", title: "Розмір" },
  { name: "state", title: "Статус" },
  { name: "download", title: "Завантажити" }
];

class ListOfScanCodes extends React.Component<PropsT, StateT> {
  state = {
    modalType: "",
    modalBody: <div />,
    formName: ""
  };

  componentDidMount() {
    this.fetchData();
    this.props.getBrandsFullInfo();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;

    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history, this.props.location.state);

  changePageSize = (pageSize: number) =>
    changePageSize(pageSize, this.props.location.search, this.props.history, this.props.location.state);

  filterByDateAndProductId = (filter: GenerateScanCodesFilterT) =>
    changeDateAndProductId(filter, this.props.location.search, this.props.history);

  showDownloadButton = row => {
    return row.state === 2;
  };

  fetchData = debounce(() => {
    const { itemsOnPage, pageNumber, dateEnd: endDate, dateStart: startDate, productId } = getCommonParams(
      this.props.location.search
    );
    const params = { itemsOnPage, pageNumber, startDate, endDate, productId };

    this.props.fetchScanCodesList(params);
  }, 200);

  openModal = (type, id) => {
    switch (type) {
      case "add": {
        const initialValues = { excludedCharacters: this.props.lastExcludedCharacters.join(", ") };
        const modalBody = <GenerateScanCodesForm initialValues={initialValues} />;
        this.setState({ modalBody, modalType: "" });
        return this.props.openModal();
      }
      default:
        return null;
    }
  };

  openAddModal = id => this.openModal("add", id);

  downloadScanCodesZip = row => {
    this.props.downloadScanCodesZip(row.id);
  };

  render() {
    const { page, count } = getPaginationConfig(this.props.location.search);
    const { dateStart, dateEnd, productId } = getCommonParams(this.props.location.search);
    const { errorMessage, total, skuOptions, scanCodesList } = this.props;
    const productIdValue = skuOptions && skuOptions.find(option => option.value === productId);
    const initialValues = { startDate: dateStart, endDate: dateEnd, productId: productIdValue };

    return (
      <>
        <Toolbar
          loadHandler={this.openAddModal}
          hasExportButton
          exportButtonLabel="Згенерувати нові коди"
          errorMessage={errorMessage}
          filterData={this.filterByDateAndProductId}
          initialValues={initialValues}
          productOptions={skuOptions}
          withProductSelect
        />

        <Paper square className="mainContent">
          <ScanCodesTable
            data={scanCodesList}
            columns={columns}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            showDownloadButton={this.showDownloadButton}
            handleDownload={this.downloadScanCodesZip}
            page={page}
            count={count}
            total={total}
          />
          {this.props.loading && <CircularProgress classes={classes} />}
        </Paper>
        <Modal type={this.state.modalType}>{this.state.modalBody}</Modal>
      </>
    );
  }
}

const mapStateToProps = state => {
  const {
    generateScanCodes: { total, scanCodesList, loading, lastExcludedCharacters }
  } = state;

  return {
    scanCodesList,
    loading,
    total,
    lastExcludedCharacters,
    skuOptions: skuOptionsSelector(state)
  };
};

const mapDispatchToProps = {
  fetchScanCodesList,
  downloadScanCodesZip,
  getBrandsFullInfo,
  openModal
};

export default connect(mapStateToProps, mapDispatchToProps)(ListOfScanCodes);
