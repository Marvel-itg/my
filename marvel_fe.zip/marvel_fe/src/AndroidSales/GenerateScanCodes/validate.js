import { validationErrorMessages } from "../../constants";

export const validate = values => {
  const { required, tooLongName, tooShortName } = validationErrorMessages({ maxLength: 20, minLength: 12 });
  const errors = {};
  if (!values.brandName) {
    errors.brandName = required;
  }

  if (!values.productName) {
    errors.productName = required;
  }

  if (!values.amount) {
    errors.amount = required;
  } else if (Number(values.amount) === 0) {
    errors.amount = "Мінімальна кількість кодів - 1";
  } else if (values.amount > 999999) {
    errors.amount = "Мaксимальна кількість кодів - 999999";
  }
  if (values.excludedCharacters && values.excludedCharacters.split(",").length > 15) {
    errors.excludedCharacters = "Максимальна кількість символів - 15";
  }
  if (!values.password) {
    errors.password = required;
  } else if (values.password.length < 12) {
    errors.password = tooShortName;
  } else if (values.password.length > 20) {
    errors.password = tooLongName;
  }
  if (!values.passwordConfirm) {
    errors.passwordConfirm = required;
  } else if (!values.password && values.passwordConfirm.length < 12) {
    errors.passwordConfirm = tooShortName;
  } else if (!values.password && values.passwordConfirm.length > 20) {
    errors.passwordConfirm = tooLongName;
  } else if (values.password && values.password !== values.passwordConfirm) {
    errors.passwordConfirm = "Паролі не співпадають";
  }
  return errors;
};
