// @flow
import React from "react";
import { connect } from "react-redux";
import Paper from "@material-ui/core/Paper/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import SuperAdminsTable from "./SuperAdminsTable";
import { receiveSuperAdminsList } from "../../store/actions/sales/superAdminsListSales";

import { classes } from "../../helpers/spinner";

type PropsT = {
  listOfSuperAdmins: any[],
  loading: boolean,
  errorMessage: string,
  receiveSuperAdminsList: Function
};

type StateT = {
  currentPage: number,
  pageSize: number
};

class ListOfSuperAdmins extends React.Component<PropsT, StateT> {
  state = {
    currentPage: 0,
    pageSize: 10
  };

  componentDidMount() {
    this.props.receiveSuperAdminsList();
  }

  changeCurrentPage = (currentPage: number) => this.setState({ currentPage });
  changePageSize = (pageSize: number) => this.setState({ pageSize });

  render() {
    const { listOfSuperAdmins = [], loading } = this.props;
    return (
      <React.Fragment>
        <Paper square className="mainContent">
          <SuperAdminsTable
            data={listOfSuperAdmins}
            changePageSize={this.changePageSize}
            changeCurrentPage={this.changeCurrentPage}
            page={this.state.currentPage}
            count={this.state.currentPage}
          />
        </Paper>
        {loading && <CircularProgress classes={classes} />}
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({ superAdminsReducer: { listOfSuperAdmins, loading, error } }) => ({
  listOfSuperAdmins,
  loading,
  errorMessage: error
});

const mapDispatchToProps = {
  receiveSuperAdminsList
};

export default connect(mapStateToProps, mapDispatchToProps)(ListOfSuperAdmins);
