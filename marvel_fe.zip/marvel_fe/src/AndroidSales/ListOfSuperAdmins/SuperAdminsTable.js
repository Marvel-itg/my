// @flow
import React from "react";
import { Grid, Table, PagingPanel, TableHeaderRow } from "@devexpress/dx-react-grid-material-ui";
import { PagingState, IntegratedPaging } from "@devexpress/dx-react-grid";
import { DateFormatProvider, PhoneProvider } from "../../components/FormattedData/FormattedData";
import GridRoot from "../../components/TableComponents/GridRoot";
import TableContainer from "../../components/TableComponents/TableContainer";
import { availableItemsPerPage, columnExtensions } from "../../constants";

type PropsT = {
  data: any[],
  page: number,
  count: number,
  changeCurrentPage: Function,
  changePageSize: Function
};

const forValues = {
  createdAt: ["createdAt"],
  phone: ["phone"]
};

const columns = [
  { name: "id", title: "ID" },
  { name: "lastName", title: "Прiзвище" },
  { name: "firstName", title: "Ім'я" },
  { name: "middleName", title: "По батьковi" },
  { name: "phone", title: "Номер телефону" },
  { name: "createdAt", title: "Коли створений" }
];

const SuperAdminsTable = (props: PropsT) => {
  const { data, page, count, changeCurrentPage, changePageSize } = props;
  return (
    <Grid rows={data} columns={columns} rootComponent={GridRoot}>
      <PagingState
        currentPage={page}
        onCurrentPageChange={changeCurrentPage}
        pageSize={count}
        onPageSizeChange={changePageSize}
      />

      <IntegratedPaging />
      <PhoneProvider for={forValues.phone} />
      <DateFormatProvider for={forValues.createdAt} showTime />
      <Table height="auto" containerComponent={TableContainer} columnExtensions={columnExtensions} />
      <TableHeaderRow />
      <PagingPanel pageSizes={availableItemsPerPage} noData={!data.length} />
    </Grid>
  );
};

export default SuperAdminsTable;
