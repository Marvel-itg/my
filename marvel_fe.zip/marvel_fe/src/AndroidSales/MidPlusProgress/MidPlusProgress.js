// @flow
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Paper from "@material-ui/core/Paper/Paper";
import ExportTablesToolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import Modal from "../../components/Modal/Modal";

import {
  uploadMidPlusProgress,
  downloadMidPlusProgress,
  clearMidPlusProgressError
} from "../../store/actions/sales/midPlusProgress";
import { openModal } from "../../store/actions/common/modals";

const ComplimentsUpload = () => {
  const dispatch = useDispatch();
  const { error: errorMessage, loading } = useSelector(state => state.midPlusProgress);

  useEffect(() => {
    if (errorMessage) {
      dispatch(openModal());
    }
  }, [errorMessage]);

  useEffect(() => {
    return () => dispatch(clearMidPlusProgressError());
  }, []);

  const uploadHandler = csv => {
    dispatch(uploadMidPlusProgress(csv));
  };
  const downloadHandler = () => {
    dispatch(downloadMidPlusProgress());
  };
  return (
    <Paper className="mainContent" style={{ padding: "20px" }}>
      <ExportTablesToolbar
        hasImportButton
        hasExportButton
        withoutDateRange
        importButtonLabel="Завантажити прогрес"
        exportButtonLabel="Вивантажити прогрес"
        uploadHandler={uploadHandler}
        loadHandler={downloadHandler}
        uploading={loading}
      />
      {errorMessage && (
        <Modal formName="" type="errorsModal">
          <div>{errorMessage}</div>
        </Modal>
      )}
    </Paper>
  );
};

export default ComplimentsUpload;
