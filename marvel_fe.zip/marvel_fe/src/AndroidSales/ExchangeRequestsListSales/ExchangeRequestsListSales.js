// @flow
import React from "react";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import { connect } from "react-redux";
import { compose } from "redux";
import CircularProgress from "@material-ui/core/CircularProgress";
import Paper from "@material-ui/core/Paper";
import ExchangeRequestsTable from "./ExchangeRequestsTable/ExchangeRequestsTable";
import Modal from "../../components/Modal/Modal";
import Toolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import {
  fetchExchangeRequests,
  exportToCsvPhoneRequests,
  importCsvPhoneRequest
} from "../../store/actions/sales/exchangeRequestsListSales";
import { extractionImportCsvPhoneErrors } from "../../store/selectors/sales/exchangeRequests";
import { closeModal, openModal } from "../../store/actions/common/modals";
import { classes } from "../../helpers/spinner";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  filterByDate,
  getCommonParams,
  changeTab
} from "../../helpers/common";

type PropsT = {
  fetchExchangeRequests: Function,
  exportExchangeRequestsCSV: Function,
  exchangeRequests: ExchangeRequestT[],
  exchangeToPhoneRequests: ExchangeToPhoneRequestT[],
  loading: boolean,
  activated: boolean,
  rejected: boolean,
  openModal: Function,
  closeModal: Function,
  uploading: boolean,
  imported: boolean
} & BrowserHistory;

type StateT = {
  activeTab: string,
  modalType: string,
  modalBody: any,
  isModalOpened: boolean
};

const defaultColumns = [
  { name: "id", title: "ID" },
  { name: "lastName", title: "Прізвище", getCellValue: row => row.requester && row.requester.lastName },
  { name: "firstName", title: "Ім'я", getCellValue: row => row.requester && row.requester.firstName },
  { name: "middleName", title: "По батькові", getCellValue: row => row.requester && row.requester.middleName },
  { name: "requesterId", title: "ID користувача", getCellValue: row => row.requester && row.requester.id },
  { name: "phone", title: "Номер телефону" },
  { name: "count", title: "Кількість балів" },
  { name: "creationDate", title: "Дата та час запиту" }
];

const columns = {
  "1": [...defaultColumns],
  "2": [
    ...defaultColumns,
    { name: "processedDate", title: "Дата та час обробки запиту" },
    { name: "processedBy", title: "ПІБ модератора, що обробив запит" },
    { name: "status", title: "Статус" },
    { name: "comment", title: "Коментар" }
  ]
};

const requests = {
  actual: "1",
  completed: "2"
};

class ExchangeRequestsListSales extends React.Component<PropsT, StateT> {
  state = {
    activeTab: "1",
    isModalOpened: false,
    modalType: "",
    modalBody: <div />
  };

  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key },
      errorsList
    } = this.props;
    if (prevProps.location.key !== key) {
      this.fetchData();
    }

    if (!prevProps.imported && this.props.imported) {
      this.changeCurrentPage(0);
    }

    if (prevProps.errorsList !== errorsList) {
      this.props.openModal();
    }
  }

  fetchData = () => {
    this.props.fetchExchangeRequests(this.getSearchData());
  };

  getSearchData = () => {
    const { dateStart, dateEnd, itemsOnPage, pageNumber, tab = "1" } = getCommonParams(this.props.location.search);
    const params = { dateStart, dateEnd, itemsOnPage, pageNumber, status: tab, type: 1 };
    return params;
  };

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  changeTab = (event: any, tab: string) => changeTab(tab, this.props.location.search, this.props.history);

  filterByDate = (rangeFilter: RangeFilterT) =>
    filterByDate(rangeFilter, this.props.location.search, this.props.history);

  exportCSV = () => {
    const { dateStart, dateEnd, status, type } = this.getSearchData();
    const params = { dateStart, dateEnd, status, type };
    this.props.exportToCsvPhoneRequests(params);
  };

  importCSV = csv => {
    this.props.importCsvPhoneRequest(csv);
  };

  render() {
    const { exchangeToPhoneRequests, total, history, errorsList, loading, uploading } = this.props;
    const { page, count, tab } = getPaginationConfig(this.props.location.search);
    const { dateStart, dateEnd } = getCommonParams(this.props.location.search);
    const initialValues = { startDate: dateStart, endDate: dateEnd };

    return (
      <React.Fragment>
        <Toolbar
          hasExportButton={tab === requests.actual}
          hasImportButton={tab === requests.completed}
          exportButtonLabel="Вивантажити Актуальні Запити"
          showDownloadCSV
          filterData={this.filterByDate}
          loadHandler={this.exportCSV}
          uploadHandler={this.importCSV}
          form="exchangeRequestsListDateFilter"
          initialValues={initialValues}
          disabled={loading}
          uploading={uploading}
        />
        <Paper square className="mainContent">
          <ExchangeRequestsTable
            data={exchangeToPhoneRequests}
            history={history}
            activeTab={tab || "1"}
            columns={columns[tab || "1"]}
            page={page}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            changeTab={this.changeTab}
            count={count}
            total={total}
          />
        </Paper>
        {this.props.loading && <CircularProgress classes={classes} />}
        {errorsList && (
          <Modal type={"errorsModal"}>
            <ul>
              {errorsList.map((error, index) => (
                <li key={index}>{error}</li>
              ))}
            </ul>
          </Modal>
        )}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    exchangeRequestsList: {
      loading,
      activated,
      activating,
      rejecting,
      rejected,
      exchangeToPhoneRequests,
      total,
      uploading,
      imported
    }
  } = state;
  return {
    activated,
    rejected,
    loading: activating || loading || rejecting,
    exchangeToPhoneRequests,
    total,
    uploading,
    imported,
    errorsList: extractionImportCsvPhoneErrors(state)
  };
};

const mapDispatchToProps = {
  fetchExchangeRequests,
  exportToCsvPhoneRequests,
  importCsvPhoneRequest,
  openModal,
  closeModal
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(ExchangeRequestsListSales);
