// @flow
import React from "react";
import type { BrowserHistory } from "history";
import debounce from "es6-promise-debounce";
import { connect } from "react-redux";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import TasksTable from "./TasksTable/TasksTable";
import TaskForm from "./TaskForm/TaskForm";
import Modal from "../../components/Modal/Modal";
import Button from "@material-ui/core/Button";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import WithStickyBandsTable from "../../HOCs/withStickyBandsTable";
import { fetchTasks, deleteTask, changeTaskState } from "../../store/actions/sales/tasksListSales";
import { openModal, closeModal } from "../../store/actions/common/modals";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  getCommonParams,
  shouldNotSendRequest,
  changeTab,
  onSearchChange
} from "../../helpers/common";
import { classes } from "../../helpers/spinner";

type PropsT = {
  deleteTask: Function,
  fetchTasks: Function,
  tasksList: TaskT[],
  loading: boolean,
  submitted: boolean,
  openModal: Function,
  closeModal: Function,
  changeTaskState: Function,
  accountType: string
} & BrowserHistory;

type StateT = {
  formName: string,
  modalBody: any,
  modalType: string,
  searchValue: string
};

const tabs = [
  { label: "Активні", value: "1" },
  { label: "В очікуванні", value: "2" },
  { label: "Завершені", value: "3" }
];

const commonColumns = [
  { name: "id", title: "ID завдання" },
  { name: "name", title: "Назва завдання" },
  { name: "taskType", title: "Тип завдання" },
  { name: "startDate", title: "Дата початку" },
  { name: "endDate", title: "Дата кiнця" },
  { name: "bonusPointsReward", title: "Кiлькiсть балiв" }
];

const columns = {
  "1": [...commonColumns, { name: "details", title: "Деталі завдання" }],
  "2": [
    ...commonColumns,
    { name: "edit", title: "Редагувати" },
    { name: "changeState", title: "Зміна статусу" },
    { name: "delete", title: "Видалити" }
  ],
  "3": [...commonColumns, { name: "details", title: "Деталі завдання" }]
};

const superAdminColumns = {
  "1": [...commonColumns, { name: "editActive", title: "Редагувати" }],
  "2": [
    ...commonColumns,
    { name: "edit", title: "Редагувати" },
    { name: "changeState", title: "Зміна статусу" },
    { name: "delete", title: "Видалити" }
  ],
  "3": [...commonColumns, { name: "details", title: "Деталі завдання" }]
};

class ListOfTasksSales extends React.Component<PropsT, StateT> {
  state = {
    formName: "",
    modalBody: <div />,
    modalType: "",
    searchValue: ""
  };

  componentDidMount() {
    const { searchValue } = getCommonParams(this.props.location.search);
    this.setState({ searchValue });
    this.fetchData();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.tab !== this.props.tab || (!prevProps.submitted && this.props.submitted)) {
      this.fetchData();
    }
    const {
      location: { key }
    } = this.props;

    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
  }

  fetchData = debounce(() => {
    const { itemsOnPage, pageNumber, type, tab, searchValue } = getCommonParams(this.props.location.search);
    let params = { itemsOnPage, pageNumber, taskTypeId: type, tab: tab || 1, search: searchValue || "" };
    this.props.fetchTasks(params);
  }, 200);

  openModal = (type, id, taskType) => {
    const { tab } = this.props;
    switch (type) {
      case "add":
      case "edit": {
        const modalBody = <TaskForm id={id} taskType={taskType} />;
        this.setState({ modalBody, formName: "TaskForm", modalType: "" });
        return this.props.openModal();
      }

      case "editActive": {
        const modalBody = <TaskForm id={id} active taskType={taskType} />;
        this.setState({ modalBody, formName: "TaskForm", modalType: "" });
        return this.props.openModal();
      }

      case "details": {
        const modalBody = <TaskForm id={id} disabled taskType={taskType} taskStatus={tab} />;
        this.setState({ modalBody, formName: "TaskForm", modalType: "" });
        return this.props.openModal();
      }

      case "changeDate": {
        const modalBody = <TaskForm id={id} isChangeDateForm taskType={taskType} />;
        this.setState({ modalBody, formName: "TaskForm", modalType: "" });
        return this.props.openModal();
      }
      case "deactivateScan": {
        const data = { taskTemplateId: id, isActive: false };
        const deactivateScanTask = () => {
          this.props.changeTaskState(data);
          this.props.closeModal();
        };
        const modalBody = (
          <>
            <DialogContent>
              <DialogContentText id="alert-dialog-description">
                Ви дiйсно бажаете деактивувати завдання?
              </DialogContentText>
            </DialogContent>
            <DialogActions>
              <Button onClick={deactivateScanTask} color="primary">
                Так
              </Button>
              <Button onClick={this.props.closeModal} color="primary">
                Нi
              </Button>
            </DialogActions>
          </>
        );

        this.setState({ modalBody, formName: "", modalType: "deactivateScan" });
        return this.props.openModal();
      }
      default:
        return null;
    }
  };

  changeTab = (event: any, tab: string) => changeTab(tab, this.props.location.search, this.props.history);

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  setSearchValue = value => {
    this.setState({ searchValue: value });
    onSearchChange(value, this.props.location.search, this.props.history);
  };

  render() {
    const { accountType } = this.props;
    const currentColumns = accountType === 1 || accountType === 3 ? superAdminColumns : columns;
    const { page, count, tab } = getPaginationConfig(this.props.location.search);
    return (
      <React.Fragment>
        <Paper square className="mainContent">
          <TasksTable
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            data={this.props.tasksList}
            activeTab={tab || 0}
            changeTab={this.changeTab}
            openModal={this.openModal}
            changeTaskState={this.props.changeTaskState}
            deleteTask={this.props.deleteTask}
            tabs={tabs}
            columns={currentColumns[tab || 0]}
            page={page}
            count={count}
            setSearchValue={this.setSearchValue}
            total={this.props.rowsCount}
            searchValue={this.state.searchValue}
          />
        </Paper>
        {this.props.loading && <CircularProgress classes={classes} />}
        <Modal formName={this.state.formName} type={this.state.modalType}>
          {this.state.modalBody}
        </Modal>
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({
  tasksListSales: { tasksList, loading, submitted, rowsCount },
  authenticationReducer: {
    user: { accountType }
  }
}) => ({
  tasksList,
  loading,
  submitted,
  accountType,
  rowsCount
});

const mapDispatchToProps = {
  fetchTasks,
  deleteTask,
  changeTaskState,
  openModal,
  closeModal
};

export default WithStickyBandsTable(connect(mapStateToProps, mapDispatchToProps)(ListOfTasksSales));
