// @flow
import React from "react";
import { Field } from "redux-form";
import type { FormProps } from "redux-form";
import cx from "classnames";
// $FlowFixMe
import Fab from "@material-ui/core/Fab";
import IconClose from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import AddIcon from "@material-ui/icons/Add";
import InputField from "../../../components/InputField/InputField";
import Select from "../../../components/Select/Select";
import { required } from "./validate";
import { normalizeInteger } from "../../../utils/reduxFormNormalizers";
import styles from "./TaskForm.module.scss";

type PropsT = {
  brands: any[],
  onBrandChange: Function,
  positions: any[],
  disabled: boolean,
  active: boolean
} & FormProps;

const fabClasses = { root: cx(styles.addButton, styles.big) };

export const RenderBrand = (props: PropsT) => {
  const { fields, brands, positions, disabled, active, isCountFieldHidden, isCloseIconDisabled } = props;
  if (!fields || !fields.length) {
    fields.push({});
  }

  if (!fields || !positions || fields.length !== positions.length) {
    return null;
  }

  const checkNewBrand = index => (positions && positions[index] && positions[index]._id ? true : false);
  return (
    <div className={styles.sectionWrapper}>
      <ul className={styles.sectionList}>
        {fields.map((position, index) => (
          <li key={index} className={styles.blockWrapper}>
            <h4>Бренд #{index + 1}</h4>
            {positions[index].productName && positions[index].productName.imageUrl && (
              <img src={positions[index].productName.imageUrl} alt="brandImage" className={styles.brandImage} />
            )}
            <Field
              required
              name={`${position}.brandName`}
              className={styles.select}
              component={Select}
              placeholder="Назва бренду"
              options={brands || []}
              validate={[required]}
              disabled={disabled || (active && checkNewBrand(index))}
              onChange={() => props.onBrandChange(index)}
            />
            <Field
              required
              name={`${position}.productName`}
              className={styles.select}
              component={Select}
              placeholder="Назва продукції"
              options={(positions[index] && positions[index].brandName && positions[index].brandName.products) || []}
              validate={[required]}
              disabled={disabled || (active && checkNewBrand(index))}
            />
            {!isCountFieldHidden && (
              <Field
                required
                name={`${position}.count`}
                type="text"
                component={InputField}
                label="Кількість блоків"
                normalize={normalizeInteger}
                disabled={
                  disabled || (active && checkNewBrand(index)) || !(positions[index] && positions[index].productName)
                }
              />
            )}
            {((fields.length > 1 && active && !checkNewBrand(index)) || (fields.length > 1 && !active)) && (
              <IconButton
                className={styles.removeBlockButton}
                disabled={isCloseIconDisabled}
                onClick={() => fields.remove(index)}
              >
                <IconClose />
              </IconButton>
            )}
          </li>
        ))}
      </ul>
      <Fab
        size="medium"
        color="secondary"
        classes={fabClasses}
        onClick={() => fields.push({})}
        aria-label="Add"
        disabled={disabled}
      >
        <AddIcon disabled={disabled} />
      </Fab>
    </div>
  );
};

export default RenderBrand;
