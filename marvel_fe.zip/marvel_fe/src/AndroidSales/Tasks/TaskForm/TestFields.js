// @flow
import React from "react";
import type { FormProps } from "redux-form";
import uniqueId from "lodash/uniqueId";
import cx from "classnames";
import moment from "moment";
// $FlowFixMe
import Fab from "@material-ui/core/Fab";
import AddIcon from "@material-ui/icons/Add";
import Question from "./Question";
import styles from "./TaskForm.module.scss";

type PropsT = {
  disabled: boolean,
  feedBack: boolean,
  active: boolean
} & FormProps;

const bigFabClasses = { root: cx(styles.addButton, styles.big) };

const TestFields = (props: PropsT) => {
  const { fields, disabled, feedBack, active, isCloseIconDisabled } = props;
  const disableForNotFeedback = !feedBack && active;
  return (
    <div className={styles.sectionWrapper}>
      <ul className={styles.sectionList}>
        {fields.map((question, index) => (
          <Question
            question={question}
            index={index}
            fields={fields}
            disabled={disabled || disableForNotFeedback}
            key={index}
            feedBack={feedBack}
            isCloseIconDisabled={isCloseIconDisabled}
            active={active}
          />
        ))}
      </ul>
      {!active && (
        <Fab
          size="medium"
          color="secondary"
          classes={bigFabClasses}
          aria-label="Add"
          disabled={disabled || disableForNotFeedback}
          onClick={() =>
            fields.push({
              answers: [{}],
              answersExtended: [{}],
              imageId: `${moment().valueOf()}_questionPhoto${uniqueId()}`
            })
          }
        >
          <AddIcon disabled={disabled} />
        </Fab>
      )}
    </div>
  );
};

export default TestFields;
