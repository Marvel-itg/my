// @flow
import React from "react";
import { withStyles } from "@material-ui/core/styles";
import FormGroup from "@material-ui/core/FormGroup";
import Checkbox from "@material-ui/core/Checkbox";

const styles = {
  root: {
    color: "red",
    "&$checked": {
      color: "green"
    }
  },
  checked: {}
};

const CustomCheckbox = props => {
  return (
    <FormGroup row>
      <Checkbox
        {...props}
        {...props.input}
        classes={{
          root: props.classes.root,
          checked: props.classes.checked
        }}
        checked={props.input.value === "true"}
      />
    </FormGroup>
  );
};

export default withStyles(styles)(CustomCheckbox);
