// @flow
import React from "react";
import { Field } from "redux-form";
import type { FormProps } from "redux-form";
import cx from "classnames";
// $FlowFixMe
import Fab from "@material-ui/core/Fab";
import IconClose from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import AddIcon from "@material-ui/icons/Add";
import TextField from "@material-ui/core/TextField";
import InputField from "../../../components/InputField/InputField";
import { normalizeLength } from "../../../utils/reduxFormNormalizers";
import styles from "./TaskForm.module.scss";

type PropsT = {
  disabled: boolean,
  label: string,
  blockLabel: string,
  active: boolean,
  answers: any[]
} & FormProps;

const smallFabClasses = { root: cx(styles.addButton, styles.small) };

const NotChangedInput = props => {
  return (
    <TextField
      inputProps={{
        readOnly: true
      }}
      {...props}
      value="Відповідь з клавіатури"
    />
  );
};

const AnswerFieldCustom = (props: PropsT) => {
  const {
    fields,
    meta: { touched, error, submitFailed },
    disabled,
    label,
    blockLabel,
    active,
    answers,
    isCloseIconDisabled,
    question
  } = props;

  const isAddAnswerButtonDisabled = disabled || fields.length === 4;
  return (
    <div className={props.hidden ? styles.hidden : styles.sectionWrapper}>
      <ul className={props.hidden ? styles.hidden : styles.sectionList}>
        <h4 className={styles.answerTitle}>{blockLabel}</h4>
        <div className={styles.answerSubtitle}>Виберіть правильні відподвіді</div>
        <li>{(touched || submitFailed) && error && <span>{error}</span>}</li>
        {fields.map((answer, index, array) => {
          const notNewAnswer = answers && answers[index] && answers[index]._id;
          return (
            <div key={index}>
              <li className={styles.answerWrapper}>
                <Field
                  required
                  name={`${answer}.title`}
                  className={styles.inputField}
                  component={InputField}
                  label={`${label} ${index + 1}`}
                  disabled={disabled || active}
                  multiline
                  normalize={normalizeLength(80)}
                />

                {fields.length > 1 && (!active || !notNewAnswer) && (
                  <IconButton
                    disabled={isCloseIconDisabled}
                    className={styles.removeButton}
                    onClick={() => fields.remove(index)}
                  >
                    <IconClose />
                  </IconButton>
                )}
              </li>
            </div>
          );
        })}
        <li className={styles.answerWrapper}>
          <Field
            disabled={disabled || active}
            name={`${question}.additionalField`}
            className={styles.inputField}
            component={NotChangedInput}
            label="Відповідь з клавіатури"
          />
        </li>
      </ul>
      {!active && (
        <Fab
          size="small"
          color="secondary"
          aria-label="Add"
          onClick={() => fields.push({})}
          classes={smallFabClasses}
          disabled={isAddAnswerButtonDisabled}
        >
          <AddIcon disabled={disabled} />
        </Fab>
      )}
    </div>
  );
};

export default AnswerFieldCustom;
