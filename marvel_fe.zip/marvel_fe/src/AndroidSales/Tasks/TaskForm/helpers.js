import moment from "moment";
import { taskQuestionnaireAnswerTypesConfig } from "../../../constants";
import lodash from "lodash";
export const formatValues = (values, isPosCodeFieldChanged = false, active = false, posCodesFieldName) => {
  const completionType = values.completionType.value;
  const taskType = values.taskType.value;
  const startDate = moment(values.startDate).format("YYYY-MM-DD");
  const endDate = moment(values.endDate).format("YYYY-MM-DD");
  let formattedValues = {
    startDate,
    endDate,
    completionType,
    name: values.taskTitle,
    hasPosAmounts: values.hasPosAmounts
  };

  if (isPosCodeFieldChanged && posCodesFieldName === "posCodes") {
    const posCodes =
      values.posCodes &&
      values.posCodes[0] &&
      values.posCodes[0].imageUrl &&
      values.posCodes[0].imageUrl.map(item => item.pointOfSaleCode);

    const posCodesFileName = values.posCodes[0].fileName;
    formattedValues = {
      ...formattedValues,
      posCodes,
      exportCsvFileName: posCodesFileName
    };
  }

  if (isPosCodeFieldChanged && !!Number(values.isGeneralOrderTask) && values.hasPosAmounts) {
    const posCodesWithAmount =
      values.posCodesWithAmount &&
      values.posCodesWithAmount[0] &&
      values.posCodesWithAmount[0].imageUrl &&
      values.posCodesWithAmount[0].imageUrl.map(item => ({ posCode: item.pointOfSaleCode, amount: item.amount }));

    const posCodesFileName =
      values.posCodesWithAmount && values.posCodesWithAmount[0] && values.posCodesWithAmount[0].fileName;
    formattedValues = {
      ...formattedValues,
      posCodesWithAmount,
      exportCsvFileName: posCodesFileName
    };
  }

  if (taskType === 1) {
    formattedValues.bonusPointsReward = values.bonusPointsRewardOrder;
    formattedValues.description = values.taskDescriptionOrder;
    formattedValues.isGeneralOrderTask = !!Number(values.isGeneralOrderTask);
    if (!!Number(values.isGeneralOrderTask && !values.hasPosAmounts)) {
      formattedValues.generalCount = values.generalCount;
    }
    if ((values.positions && !values.positions.length) || !values.positions) {
      formattedValues.positions = [];
    } else {
      formattedValues.positions =
        values.positions &&
        values.positions.map(position => ({
          productId: position.value || (position.productName && position.productName.value),
          count: Number(position.count) || 0
        }));
    }
  }

  if (taskType === 2) {
    formattedValues.description = values.taskDescriptionFoil;
    formattedValues.exchangeFoilToСompliment = values.exchangeFoilToСompliment;
    formattedValues.bonusChargeType = +values.bonusChargeType;
    if (formattedValues.exchangeFoilToСompliment) {
      formattedValues.foilCount = values.foilCount;
      formattedValues.complimentCount = values.complimentCount;
    }
    formattedValues.productsIds =
      values.productIds && values.productIds.length && values.productIds.map(item => item.value);
    if (isPosCodeFieldChanged) {
      const posPlan = lodash.get(values, "foilPosPlan[0].imageUrl");
      const posCodesFileName = lodash.get(values, "foilPosPlan[0].fileName");
      formattedValues = {
        ...formattedValues,
        posPlan,
        exportCsvFileName: posCodesFileName
      };
    }
  }

  if (taskType === 3) {
    formattedValues.questions =
      values.questions &&
      values.questions.map((question, index) => ({
        title: question.title,
        sequence: index,
        photos: question.photo && question.photo.map(photo => photo.imageUrl),
        answers: question.answers.map(answer => ({
          ...answer,
          isCorrect: !!answer.isCorrect,
          answerType: 1
        }))
      }));
    formattedValues.bonusPointsReward = values.bonusPointsRewardTest;
    formattedValues.description = values.taskDescriptionTest;
  }

  if (taskType === 4) {
    formattedValues.bonusPointsReward = values.bonusPointsRewardInformational;
    formattedValues.description = values.taskDescriptionInformational;
    const imageIds = values.photo && values.photo.length && values.photo.map(photo => photo.id);
    if (imageIds) {
      formattedValues.imageIds = imageIds;
    }
  }

  if (taskType === 5) {
    formattedValues.bonusPointsReward = values.bonusPointsRewardQuestionnaire;
    formattedValues.description = values.taskDescriptionQuestionnaire;
    formattedValues.isProductQuantityEnabled = values.withCounts;
    formattedValues.questionnaireQuestions =
      values.products &&
      values.products.length &&
      values.products.map((item, index) => ({
        title: item.label,
        sequence: index,
        ...(item.id && { id: item.id }),
        answers: [
          {
            ...(item.answerId && { id: item.answerId }),
            title: "",
            answerType: values.withCounts
              ? taskQuestionnaireAnswerTypesConfig.manualNumbers
              : taskQuestionnaireAnswerTypesConfig.radio
          }
        ]
      }));
  }

  if (taskType === 6) {
    formattedValues.bonusPointsReward = values.bonusPointsRewardPhoto;
    formattedValues.description = values.taskDescriptionPhoto;
    const imageIds = values.photo && values.photo.length && values.photo.map(photo => photo.id);
    if (imageIds) {
      formattedValues.imageIds = imageIds;
    }
  }

  if (taskType === 7) {
    formattedValues.bonusPointsReward = values.bonusPointsRewardTestFeedback;
    formattedValues.description = values.taskDescriptionTestFeedback;
    formattedValues.questions =
      values.questionsFeedback &&
      values.questionsFeedback.map((question, index) => {
        const answerType = question.answerType && Number(question.answerType.value);
        let formattedAnswers = [];
        switch (answerType) {
          case 1:
            formattedAnswers = question.answers.map(answer => ({
              ...answer,
              answerType: 1
            }));
            break;
          case 2:
            formattedAnswers = question.answersExtended.map(answer => ({
              ...answer,
              answerType: 1
            }));
            formattedAnswers.push(
              question.additionalField
                ? question.additionalField
                : {
                    title: "Відповідь з клавіатури",
                    answerType: 4
                  }
            );
            break;
          case 4:
            formattedAnswers = question.answers.map(answer => ({
              ...answer,
              answerType: 4
            }));
            break;
          default:
            break;
        }
        return {
          id: question.id,
          title: question.title,
          sequence: index,
          photos: question.photo && question.photo.map(photo => photo.imageUrl),
          answers: formattedAnswers
        };
      });
  }

  if (taskType === 8) {
    formattedValues.description = values.scanDescription;
    formattedValues.posPlan = values.posPlan[0].imageUrl;
    formattedValues.exportCsvFileName = values.posPlan[0].fileName;
    formattedValues.automaticBonusCharge = values.automaticBonusCharge;
    formattedValues.productIds =
      values.productIds && values.productIds.length && values.productIds.map(item => item.value);
  }

  if (taskType === 9) {
    formattedValues.description = values.midPlusDescription;
    if (isPosCodeFieldChanged) {
      formattedValues.midPlusPosPlan = values.posMidPlus[0].imageUrl;
      formattedValues.exportCsvFileName = values.posMidPlus[0].fileName;
    }
    const productIds = values.productIds && values.productIds.length && values.productIds.map(item => item.value);
    formattedValues.productIds = productIds;
    formattedValues.midPlusProductIds =
      values.midPlusProductIds &&
      values.midPlusProductIds.length &&
      values.midPlusProductIds.map(item => item.value).filter(item => productIds.includes(item));
  }

  return formattedValues;
};
