// @flow
import React from "react";
import { Field, reduxForm, FieldArray, formValueSelector, getFormMeta } from "redux-form";
import type { FormProps } from "redux-form";
import { connect } from "react-redux";
import moment from "moment";
import { compose } from "redux";
import CircularProgress from "@material-ui/core/CircularProgress";
import FormGroup from "@material-ui/core/FormGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import Checkbox from "@material-ui/core/Checkbox";
import RadioGroup from "../../../components/RadioGroup/RadioGroup";
import ContainedButton from "../../../components/Buttons/ContainedButton/ContainedButton";
import InputField from "../../../components/InputField/InputField";
import InputFileMultiple from "../../../components/InputFileMultiple/InputFileMultiple";
import InputDatePicker from "../../../components/InputField/InputDatePicker";
import ErrorMessage from "../../../components/ErrorMessage/ErrorMessage";
import Select from "../../../components/Select/Select";
import TestFields from "./TestFields";
import { getTaskData, createNewTask, editTask, clearTaskData } from "../../../store/actions/sales/tasksListSales.js";
import { deleteImage } from "../../../store/actions/common/images";
import { scuListSelectorAll, initialValuesSelector } from "../../../store/selectors/sales/tasks";
import { onlyNumbers, normalizeLength } from "../../../utils/reduxFormNormalizers";
import { validate } from "./validate";
import { formatValues } from "./helpers";
import { classes } from "../../../helpers/spinner";
import { orderOptions, foilOptions, TASK_TYPES } from "../../../constants";
import styles from "./TaskForm.module.scss";
import ConfirmModal from "../../../components/Modal/ConfirmModal";
const completedTaskStatus = "3";

type PropsT = {
  getTaskData: Function,
  createNewTask: Function,
  editTask: Function,
  clearTaskData: Function,
  submitting: boolean,
  id: string,
  errorMessage: string,
  selectedType: OptionT,
  isChangeDateForm: boolean,
  disabled: boolean,
  positions: OptionT[],
  change: Function,
  untouch: Function,
  deleteImage: Function
} & FormProps;

type StateT = {
  isSubmitting: boolean,
  isModalOpen: boolean,
  bonusChargeType: string
};

class TaskForm extends React.Component<PropsT, StateT> {
  state = {
    isSubmitting: false,
    isModalOpen: false,
    bonusChargeType: ""
  };

  componentDidMount() {
    this.props.getTaskData(this.props.id, this.props.taskType);
  }

  componentDidUpdate(prevProps) {
    const { errorMessage, initialValues, id, isGeneralOrderTask } = this.props;
    const oldGeneralTask = !!Number(initialValues.isGeneralOrderTask) && !!id && !initialValues.hasPosAmounts;
    if (!prevProps.errorMessage && errorMessage) {
      this.setState({ isSubmitting: false });
    }

    if (!Number(prevProps.isGeneralOrderTask) && !!Number(isGeneralOrderTask) && !oldGeneralTask) {
      this.props.change("hasPosAmounts", true);
    }
    if (!!Number(prevProps.isGeneralOrderTask) && !Number(isGeneralOrderTask)) {
      this.props.change("hasPosAmounts", false);
    }
  }

  componentWillUnmount() {
    this.props.clearTaskData();
  }

  submitForm = values => {
    const { id, active } = this.props;
    const taskType = values.taskType.value;
    let posCodesFieldName = "posCodes";

    if (!!+values.isGeneralOrderTask) {
      posCodesFieldName = "posCodesWithAmount";
    }
    if (taskType === TASK_TYPES.scan) {
      posCodesFieldName = "posPlan";
    }
    if (taskType === TASK_TYPES.foil) {
      posCodesFieldName = "foilPosPlan";
    }
    if (taskType === TASK_TYPES.midPlus) {
      posCodesFieldName = "posMidPlus";
    }

    const isPosCodeFieldChanged =
      this.props.touchedFields && this.props.touchedFields[posCodesFieldName] ? true : false;
    if (!this.state.isSubmitting) {
      this.setState({ isSubmitting: true });
      const formattedValues = formatValues(values, isPosCodeFieldChanged, active, posCodesFieldName);
      const photoId = values.photo && values.photo[0] && values.photo[0].id;
      if (id && (taskType === 6 || taskType === 4) && !photoId) {
        formattedValues.imageIds = [];
      }
      id
        ? this.props.editTask({ ...formattedValues, id }, taskType)
        : this.props.createNewTask(formattedValues, taskType);
    }
  };

  uploadPosIds = file => {
    this.props.uploadPosIds(file);
  };

  onBrandChange = field => {
    this.props.change(`positions[${field}].productName`, "");
  };

  touchEndDate = () => {
    this.props.touch("endDate");
  };

  touchStartDate = () => {
    this.props.touch("startDate");
  };

  touchPosCodes = () => {
    const { initialValues, isGeneralOrderTask, id } = this.props;
    const oldGeneralTask = !!Number(initialValues.isGeneralOrderTask) && !!id && !initialValues.hasPosAmounts;
    const posCodesType = !!Number(isGeneralOrderTask) && !oldGeneralTask ? "posCodesWithAmount" : "posCodes";
    this.props.touch(posCodesType);
  };

  touchPosPlan = () => {
    this.props.touch("posPlan");
  };

  touchFoilPosPlan = () => {
    this.props.touch("foilPosPlan");
  };

  touchPosMidPlus = () => {
    this.props.touch("posMidPlus");
  };

  touchPosAmounts = () => {
    this.props.touch("posCodesWithAmount");
  };

  renderSwitch = props => (
    <FormGroup row>
      <FormControlLabel
        control={<Checkbox color="primary" {...props} {...props.input} checked={props.input.value === "true"} />}
        label="Товарні одиниці з кількістю"
      />
    </FormGroup>
  );

  renderCheckboxList = props => {
    const { options, input, positions, general } = props;
    const { active, disabled } = this.props;
    let results = input.value ? [...input.value] : [];
    const MIN_SKU_COUNT = 8;
    const isPendingTask = !active && !disabled;
    const handleChange = item => {
      let index = results.findIndex(checked => checked.label === item.label);
      this.props.untouch(`positions[${index}].count`);
      if (index === -1) {
        results.push({ ...item });
      } else {
        results.splice(index, 1);
      }
      props.input.onChange(results);
    };
    if (!options || !options.length) {
      return null;
    }
    return (
      <div
        className={(!isPendingTask && results.length > MIN_SKU_COUNT) || isPendingTask ? styles.dropdownWrapper : ""}
      >
        {options.map((item, index) => {
          const indexOfQuestionInOptions = results.findIndex(question => question.label === item.label);
          const isCheckedQuestion = indexOfQuestionInOptions !== -1;
          const positionIndex = positions ? positions.findIndex(position => position.value === item.value) : -1;
          const visible = ((active || disabled) && isCheckedQuestion) || (!active && !disabled);
          const isOrderPlanSku = this.props.selectedType.value === 1 && !general;
          if (visible) {
            return (
              <div key={`${index} ${item.label}`} className={visible && styles.checkboxWithInput}>
                <FormGroup row className={styles.select}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        {...props}
                        color="primary"
                        classes={{ root: styles.checkboxItem }}
                        onChange={() => handleChange(item)}
                        value={item.value.toString()}
                        checked={isCheckedQuestion}
                      />
                    }
                    label={item.label}
                  />
                </FormGroup>
                {isOrderPlanSku && positionIndex !== -1 && (
                  <Field
                    required
                    name={`positions[${positionIndex}].count`}
                    className={styles.countInput}
                    component={InputField}
                    label="Кількість блоків"
                    normalize={onlyNumbers}
                    disabled={props.disabled}
                  />
                )}
              </div>
            );
          } else {
            return null;
          }
        })}
      </div>
    );
  };
  renderSelectAllCheckbox = props => {
    const { options } = props;
    const taskType = this.props.selectedType.value;
    const taskTypeWithPositions = taskType === TASK_TYPES.order;
    const taskTypeWithProductIds =
      taskType === TASK_TYPES.foil || taskType === TASK_TYPES.scan || taskType === TASK_TYPES.midPlus;
    const selectProducts = () => {
      if (taskTypeWithPositions) {
        return this.props.positions;
      } else if (taskTypeWithProductIds) {
        return this.props.productIds;
      } else {
        return this.props.products;
      }
    };
    let products = selectProducts();
    let results = products || [];
    const differenceBetweenCheckedAndAll = products
      ? options.filter(product => {
          const index =
            products &&
            (taskTypeWithPositions
              ? products.findIndex(checkedProduct => checkedProduct.value === product.value)
              : products.findIndex(checkedProduct => checkedProduct.label === product.label));
          return index === -1 ? product : null;
        })
      : options;
    const isAllSelected = Boolean(!differenceBetweenCheckedAndAll.length);
    const selectAll = () => {
      if (options && options.length && !isAllSelected) {
        results = [...(products ? products : []), ...differenceBetweenCheckedAndAll];
      } else {
        results = [];
      }
      if (taskTypeWithPositions) {
        this.props.change("positions", results);
      } else if (taskTypeWithProductIds) {
        this.props.change("productIds", results);
      } else {
        this.props.change("products", results);
      }
    };
    return (
      <FormGroup row>
        <FormControlLabel
          control={
            <Checkbox
              {...props}
              {...props.input}
              color="primary"
              classes={{ root: styles.checkboxItem }}
              onChange={selectAll}
              checked={isAllSelected}
            />
          }
          label="Обрати всі"
        />
      </FormGroup>
    );
  };

  renderAddBrandsCheckbox = props => {
    return (
      <FormGroup row>
        <FormControlLabel
          control={<Checkbox color="primary" {...props} {...props.input} checked={props.input.value === "true"} />}
          label="Додати бренди"
        />
      </FormGroup>
    );
  };

  renderCheckBox = props => {
    return (
      <FormGroup row>
        <FormControlLabel
          control={<Checkbox color="primary" {...props} {...props.input} checked={props.input.value === "true"} />}
          label={props.label}
        />
      </FormGroup>
    );
  };

  renderOrderPart = () => {
    const { disabled, active, isGeneralOrderTask, id, initialValues, positions } = this.props;
    const oldGeneralTask = !!Number(initialValues.isGeneralOrderTask) && !!id && !initialValues.hasPosAmounts;
    const posCodesType = !!Number(isGeneralOrderTask) && !oldGeneralTask ? "posCodesWithAmount" : "posCodes";
    return (
      <>
        <Field
          required
          name="isGeneralOrderTask"
          component={RadioGroup}
          options={orderOptions}
          disabled={disabled || active}
        />
        <Field
          required
          name="hasPosAmounts"
          component={Checkbox}
          disabled={disabled}
          className={styles.hasPosAmounts}
        />
        {oldGeneralTask && (
          <Field
            required
            name="generalCount"
            component={InputField}
            className={styles.inputField}
            disabled={disabled || active}
            normalize={onlyNumbers}
          />
        )}
        <Field
          required
          component={InputFileMultiple}
          name={posCodesType}
          id={posCodesType}
          editMode
          disabled={disabled}
          onUpdate={this.touchPosCodes}
          label="Завантажити CSV"
          limit={1}
          uploadType={posCodesType}
          canDownload={true}
        />
        <Field
          required
          name="bonusPointsRewardOrder"
          component={InputField}
          className={styles.inputField}
          disabled={disabled || active}
          normalize={onlyNumbers}
        />
        <Field
          name="taskDescriptionOrder"
          component={InputField}
          className={styles.inputField}
          multiline
          disabled={disabled}
          required
          normalize={normalizeLength(1000)}
        />
        <div className={styles.midPlusLabel}>
          <FormLabel component="legend" classes={{ root: styles.productLabel }}>
            Товарні одиниці *
          </FormLabel>
          {+isGeneralOrderTask && !active && !disabled ? (
            <Field
              name="selectAllProductIds"
              className={styles.withCounts}
              component={this.renderSelectAllCheckbox}
              format={value => (value ? "true" : "false")}
              options={this.props.scuListAll}
              disabled={disabled || active}
            />
          ) : (
            ""
          )}
          <Field
            required
            name="positions"
            className={styles.select}
            component={this.renderCheckboxList}
            options={this.props.scuListAll}
            positions={positions}
            general={+this.props.isGeneralOrderTask}
            disabled={disabled || active}
          />
        </div>
      </>
    );
  };

  renderFoilPart = () => {
    const { disabled, active, foilToComplimentSelected, bonusChargeType, foilPosPlan } = this.props;
    const handleChange = () => {
      foilPosPlan && foilPosPlan.length && this.setState({ isModalOpen: true, bonusChargeType });
    };
    const handleCancelModal = () => {
      this.props.change("bonusChargeType", this.state.bonusChargeType);
      this.setState({ isModalOpen: false });
    };
    const handleCloseModal = () => {
      const foilPosPlan = "foilPosPlan";
      const params = {
        id: foilPosPlan,
        name: foilPosPlan,
        withApi: undefined,
        uploadType: foilPosPlan
      };
      this.props.deleteImage(params);
      this.props.untouch(foilPosPlan);
      this.props.change(foilPosPlan, undefined);
      this.setState({ isModalOpen: false });
    };
    // wait for backend part, disable editing brands for active, pending and closed tasks
    return (
      <>
        <Field
          name="taskDescriptionFoil"
          component={InputField}
          className={styles.inputField}
          multiline
          disabled={disabled}
          required
          normalize={normalizeLength(1000)}
        />
        <div>
          <FormLabel component="legend" classes={{ root: styles.bonusCharge }}>
            Нарахування балів *
          </FormLabel>
          <Field
            required
            name="bonusChargeType"
            component={RadioGroup}
            className={styles.foilBonusRadio}
            formControlStyle={{}}
            options={foilOptions}
            disabled={disabled || active}
            onChange={handleChange}
          />
        </div>
        <ConfirmModal
          open={this.state.isModalOpen}
          onClose={handleCancelModal}
          onConfirm={handleCloseModal}
          onCancel={handleCancelModal}
          question="При змiнi варiанта нархування балiв завантажений ранiше CSV файл буде видалено"
          confirmButtonLabel="Погоджуюсь"
          cancelButtonLabel="Залишити обраний варiант"
        />
        <Field
          required
          component={InputFileMultiple}
          name="foilPosPlan"
          id="foilPosPlan"
          editMode
          disabled={disabled || (!bonusChargeType && bonusChargeType !== 0)}
          onUpdate={this.touchFoilPosPlan}
          label="Завантажити CSV"
          limit={1}
          uploadType="foilPosPlan"
          canDownload={true}
        />
        <Field
          component={this.renderCheckBox}
          label="Обмінюється на компліменти"
          disabled={disabled || active}
          name="exchangeFoilToСompliment"
          format={value => (value ? "true" : "false")}
        />
        <Field
          component={InputField}
          disabled={disabled || active || !foilToComplimentSelected}
          name="foilCount"
          className={styles.foilInput}
          label="Кількість фольги"
          required
          normalize={onlyNumbers}
        />
        <Field
          component={InputField}
          disabled={disabled || active || !foilToComplimentSelected}
          name="complimentCount"
          className={styles.complimentInput}
          label="Кількість компліментів"
          required
          normalize={onlyNumbers}
        />
        <div className={styles.midPlusLabel}>
          <FormLabel component="legend" classes={{ root: styles.productLabel }}>
            Товарні одиниці *
          </FormLabel>
          {!active && !disabled ? (
            <Field
              name="selectAllProductIds"
              className={styles.withCounts}
              component={this.renderSelectAllCheckbox}
              format={value => (value ? "true" : "false")}
              options={this.props.scuListAll}
              disabled={disabled || active}
            />
          ) : (
            ""
          )}
          <Field
            required
            name="productIds"
            className={styles.select}
            component={this.renderCheckboxList}
            options={this.props.scuListAll}
            disabled={disabled || active}
          />
        </div>
      </>
    );
  };

  renderTestPart = () => {
    const { disabled, active, taskStatus, id } = this.props;
    const isCloseIconDisabled = taskStatus === completedTaskStatus;
    const disableFieldsFromEditing = !!id;
    return (
      <>
        <Field
          required
          component={InputFileMultiple}
          name="posCodes"
          id="posCodes"
          editMode
          disabled={disabled}
          onUpdate={this.touchPosCodes}
          label="Завантажити CSV"
          limit={1}
          uploadType="posCodes"
          canDownload={true}
        />
        <Field
          required
          name="bonusPointsRewardTest"
          component={InputField}
          className={styles.inputField}
          disabled={disabled || active}
          normalize={onlyNumbers}
        />
        <Field
          name="taskDescriptionTest"
          component={InputField}
          className={styles.inputField}
          multiline
          disabled={disabled}
          required
          normalize={normalizeLength(1000)}
        />
        <FieldArray
          name="questions"
          component={TestFields}
          disabled={disabled || disableFieldsFromEditing}
          active={active}
          isCloseIconDisabled={isCloseIconDisabled || disableFieldsFromEditing}
        />
      </>
    );
  };

  renderInformationalPart = () => {
    const { disabled, imageTransactionSuccess, active } = this.props;
    return (
      <>
        <Field
          required
          component={InputFileMultiple}
          name="posCodes"
          id="posCodes"
          editMode
          disabled={disabled}
          onUpdate={this.touchPosCodes}
          label="Завантажити CSV"
          limit={1}
          uploadType="posCodes"
          canDownload={true}
        />
        <Field
          required
          name="bonusPointsRewardInformational"
          component={InputField}
          className={styles.inputField}
          disabled={disabled || active}
          normalize={onlyNumbers}
        />
        <Field
          component={InputFileMultiple}
          name="photo"
          withPreview
          bigPreview
          uploadUrl="TaskTemplates/UploadImage"
          disabled={disabled || !imageTransactionSuccess}
          label="Додати картинку"
          limit={1}
          id="InfoTaskPhoto"
        />
        <Field
          name="taskDescriptionInformational"
          component={InputField}
          className={styles.inputField}
          multiline
          disabled={disabled}
          required
          normalize={normalizeLength(1000)}
        />
      </>
    );
  };

  renderQuestionnairePart = () => {
    const { disabled, active, taskStatus, initialValues } = this.props;
    let scuOptionsList = this.props.scuListAll;
    const isFieldsDisabledForEdit = taskStatus === completedTaskStatus;
    if (initialValues && initialValues.questions && initialValues.questions.length) {
      scuOptionsList = scuOptionsList.map(scu => {
        let index = initialValues.questions.findIndex(question => question.title === scu.label);
        if (index === -1) {
          return scu;
        }
        const formattedQuestion = {
          label: initialValues.questions[index].title,
          id: initialValues.questions[index].id,
          answerId: initialValues.questions[index].answers[0].id
        };
        return { ...formattedQuestion, value: scu.value };
      });
    }

    return (
      <>
        <Field
          required
          component={InputFileMultiple}
          name="posCodes"
          id="posCodes"
          editMode
          disabled={disabled}
          onUpdate={this.touchPosCodes}
          label="Завантажити CSV"
          limit={1}
          uploadType="posCodes"
          canDownload={true}
        />
        <Field
          required
          name="bonusPointsRewardQuestionnaire"
          component={InputField}
          className={styles.inputField}
          disabled={disabled || active}
          normalize={onlyNumbers}
        />

        <Field
          name="taskDescriptionQuestionnaire"
          component={InputField}
          className={styles.inputField}
          multiline
          disabled={disabled}
          required
          normalize={normalizeLength(1000)}
        />

        <Field
          name="withCounts"
          className={styles.withCounts}
          component={this.renderSwitch}
          disabled={disabled || active || isFieldsDisabledForEdit}
          format={value => (value ? "true" : "false")}
          required
        />

        <FormLabel component="legend" classes={{ root: styles.productLabel }}>
          Товарні одиниці *
        </FormLabel>
        {!active && !disabled ? (
          <Field
            name="selectAllProducts"
            className={styles.withCounts}
            component={this.renderSelectAllCheckbox}
            format={value => (value ? "true" : "false")}
            options={scuOptionsList}
            disabled={disabled || active || isFieldsDisabledForEdit}
          />
        ) : (
          ""
        )}
        <Field
          required
          name="products"
          className={styles.select}
          component={this.renderCheckboxList}
          options={scuOptionsList}
          disabled={disabled || active || isFieldsDisabledForEdit}
        />
      </>
    );
  };

  renderPhotoPart = () => {
    const { disabled, imageTransactionSuccess, active } = this.props;
    return (
      <>
        <Field
          required
          component={InputFileMultiple}
          name="posCodes"
          id="posCodes"
          editMode
          disabled={disabled}
          onUpdate={this.touchPosCodes}
          label="Завантажити CSV"
          limit={1}
          uploadType="posCodes"
          canDownload={true}
        />
        <Field
          required
          name="bonusPointsRewardPhoto"
          component={InputField}
          className={styles.inputField}
          disabled={disabled || active}
          normalize={onlyNumbers}
        />
        <Field
          component={InputFileMultiple}
          name="photo"
          withPreview
          bigPreview
          uploadUrl="TaskTemplates/UploadImage"
          disabled={disabled || !imageTransactionSuccess}
          label="Додати картинку"
          limit={1}
          id="PhotoTaskPhoto"
        />
        <Field
          name="taskDescriptionPhoto"
          component={InputField}
          className={styles.inputField}
          multiline
          disabled={disabled}
          required
          normalize={normalizeLength(1000)}
        />
      </>
    );
  };

  renderTestFeedbackPart = () => {
    const { disabled, active, taskStatus } = this.props;
    const isCloseIconDisabled = taskStatus === completedTaskStatus ? true : false;

    return (
      <>
        <Field
          required
          component={InputFileMultiple}
          name="posCodes"
          id="posCodes"
          editMode
          disabled={disabled}
          onUpdate={this.touchPosCodes}
          label="Завантажити CSV"
          limit={1}
          uploadType="posCodes"
          canDownload={true}
        />
        <Field
          required
          name="bonusPointsRewardTestFeedback"
          component={InputField}
          className={styles.inputField}
          disabled={disabled || active}
          normalize={onlyNumbers}
        />
        <Field
          name="taskDescriptionTestFeedback"
          component={InputField}
          className={styles.inputField}
          multiline
          disabled={disabled}
          required
          normalize={normalizeLength(1000)}
        />
        <FieldArray
          name="questionsFeedback"
          component={TestFields}
          disabled={disabled}
          feedBack
          isCloseIconDisabled={isCloseIconDisabled}
          active={active}
        />
      </>
    );
  };

  renderScanPart = () => {
    const { disabled, active } = this.props;
    return (
      <>
        <Field
          required
          disabled={disabled}
          name="scanDescription"
          component={InputField}
          className={styles.inputField}
          label="Опис завдання"
          normalize={normalizeLength(1000)}
          multiline
        />
        <Field
          required
          disabled={disabled}
          component={InputFileMultiple}
          name="posPlan"
          id="posPlan"
          editMode
          onUpdate={this.touchPosPlan}
          label="Завантажити CSV *"
          limit={1}
          uploadType="posPlan"
          canDownload={true}
        />
        <Field
          component={this.renderCheckBox}
          label="Aвтоматичне нарахування балiв"
          disabled={disabled || active}
          name="automaticBonusCharge"
          format={value => (value ? "true" : "false")}
        />
        <FormLabel component="legend" classes={{ root: styles.productLabelScan }}>
          Товарні одиниці *
        </FormLabel>
        {!active && !disabled ? (
          <Field
            name="selectAllProductIds"
            className={styles.withCounts}
            component={this.renderSelectAllCheckbox}
            format={value => (value ? "true" : "false")}
            options={this.props.scuListAll}
            disabled={disabled || active}
          />
        ) : (
          ""
        )}
        <Field
          required
          name="productIds"
          className={styles.select}
          component={this.renderCheckboxList}
          options={this.props.scuListAll}
          disabled={disabled || active}
        />
      </>
    );
  };

  renderMidPlusPart = () => {
    const { disabled, active, productIds } = this.props;
    return (
      <>
        <Field
          required
          disabled={disabled}
          component={InputFileMultiple}
          name="posMidPlus"
          id="posMidPlus"
          editMode
          onUpdate={this.touchPosMidPlus}
          label="Завантажити CSV *"
          limit={1}
          uploadType="posMidPlus"
          canDownload={true}
        />
        <Field
          required
          disabled={disabled}
          name="midPlusDescription"
          component={InputField}
          className={styles.inputField}
          label="Опис завдання"
          multiline
          normalize={normalizeLength(1000)}
        />
        <div className={styles.midPlusLabel}>
          <FormLabel component="legend" classes={{ root: styles.productLabel }}>
            Загальний список продукції *
          </FormLabel>
          {!active && !disabled ? (
            <Field
              name="selectAllProductIds"
              className={styles.withCounts}
              component={this.renderSelectAllCheckbox}
              format={value => (value ? "true" : "false")}
              options={this.props.scuListAll}
              disabled={disabled || active}
            />
          ) : (
            ""
          )}
          <Field
            required
            name="productIds"
            className={styles.select}
            component={this.renderCheckboxList}
            options={this.props.scuListAll}
            disabled={disabled || active}
          />
        </div>
        {!!productIds && !!productIds.length && (
          <div className={styles.midPlusLabel}>
            <FormLabel component="legend" classes={{ root: styles.productLabel }}>
              MID + продукцiя *
            </FormLabel>
            <Field
              required
              name="midPlusProductIds"
              className={styles.select}
              component={this.renderCheckboxList}
              options={productIds}
              disabled={disabled || active}
            />
          </div>
        )}
      </>
    );
  };

  renderSelectedTaskPart = taskType => {
    switch (taskType.value) {
      case 1:
        return this.renderOrderPart();
      case 2:
        return this.renderFoilPart();
      case 3:
        return this.renderTestPart();
      case 4:
        return this.renderInformationalPart();
      case 5:
        return this.renderQuestionnairePart();
      case 6:
        return this.renderPhotoPart();
      case 7:
        return this.renderTestFeedbackPart();
      case 8:
        return this.renderScanPart();
      case 9:
        return this.renderMidPlusPart();
      default:
        return null;
    }
  };

  render() {
    const {
      handleSubmit,
      loading,
      id,
      errorMessage,
      invalid,
      disabled,
      active,
      isChangeDateForm,
      selectedType,
      anyTouched,
      imageTransactionSuccess
    } = this.props;
    const label = !id ? "Створити завдання" : "Редагувати завдання";
    const tomorrow = moment().add(1, "days");
    const today = moment();
    const isTaskTypeFieldDisabled = !!id;

    const { startDate } = this.props.initialValues;
    return loading ? (
      <CircularProgress classes={classes} />
    ) : (
      <form onSubmit={handleSubmit(this.submitForm)} autoComplete="off" noValidate>
        <div className={styles.formTitle}>
          {isChangeDateForm ? "Для активації завдання потрібно змінити дату початку" : label}
        </div>
        <div className={styles.infoWrapper}>
          {!isChangeDateForm && (
            <Field
              name="taskTitle"
              component={InputField}
              className={styles.inputField}
              multiline
              disabled={disabled}
              required
              normalize={normalizeLength(100)}
            />
          )}
          <Field
            required
            name="startDate"
            label="Дата початку"
            component={InputDatePicker}
            className={styles.inputField}
            disabled={disabled}
            minDate={active ? undefined : tomorrow}
            maxDate={active ? startDate : undefined}
            onClose={this.touchEndDate}
          />

          <Field
            required
            name="endDate"
            label="Дата закінчення"
            component={InputDatePicker}
            className={styles.inputField}
            minDate={active ? today : tomorrow}
            disabled={disabled}
            onClose={this.touchStartDate}
          />
          {!isChangeDateForm && (
            <>
              <Field
                required
                name="completionType"
                component={Select}
                className={styles.inputField}
                disabled={disabled || active}
              />
              <Field
                required
                name="taskType"
                component={Select}
                className={styles.inputField}
                disabled={disabled || isTaskTypeFieldDisabled}
              />
              {selectedType && this.renderSelectedTaskPart(selectedType)}
            </>
          )}
        </div>

        <ContainedButton
          disabled={invalid || disabled || this.state.isSubmitting || (!anyTouched && !id) || !imageTransactionSuccess}
          type="submit"
          label={label}
          className={styles.button}
        />
        {errorMessage && <ErrorMessage error={errorMessage} />}
      </form>
    );
  }
}

const mapStateToProps = state => {
  const {
    tasksListSales: { loadingTask, taskCRUError }
  } = state;
  const selector = formValueSelector("TaskForm");
  const positions = selector(state, "positions");
  const selectedType = selector(state, "taskType");
  const isGeneralOrderTask = selector(state, "isGeneralOrderTask");
  const scuListAll = scuListSelectorAll(state);
  const imageTransactionSuccess = state.images && state.images.imageTransactionSuccess;
  const touchedFields = getFormMeta("TaskForm")(state);
  const products = selector(state, "products");
  const productIds = selector(state, "productIds");
  const foilToComplimentSelected = selector(state, "exchangeFoilToСompliment");
  const bonusChargeType = selector(state, "bonusChargeType");
  const foilPosPlan = selector(state, "foilPosPlan");
  return {
    initialValues: initialValuesSelector(state),
    errorMessage: taskCRUError,
    loading: loadingTask,
    positions,
    selectedType,
    scuListAll,
    isGeneralOrderTask,
    imageTransactionSuccess,
    touchedFields,
    products,
    productIds,
    foilToComplimentSelected,
    bonusChargeType,
    foilPosPlan
  };
};

const mapDispatchToProps = {
  getTaskData,
  createNewTask,
  editTask,
  clearTaskData,
  deleteImage
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  reduxForm({
    form: "TaskForm",
    enableReinitialize: true,
    validate
  })
)(TaskForm);
