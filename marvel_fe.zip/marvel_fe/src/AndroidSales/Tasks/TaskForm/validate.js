import moment from "moment";
import { validationErrorMessages } from "../../../constants";

export const validate = (values, { active, ...props }) => {
  const { required, minBonuses: minBonuses0, maxBonuses: maxBonuses1000 } = validationErrorMessages({
    maxBonuses: 1000,
    minBonuses: 0
  });

  const errors = {};
  if (!values.taskTitle) {
    errors.taskTitle = required;
  }
  if (!values.startDate) {
    errors.startDate = required;
  } else if (!active && moment(values.startDate).isBefore(moment())) {
    errors.startDate = `Мінімальна дата - ${moment()
      .add(1, "days")
      .startOf("day")
      .format("DD/MM/YYYY")}`;
  }
  if (!values.endDate) {
    errors.endDate = required;
  } else if (values.startDate && moment(values.endDate).isBefore(moment(values.startDate))) {
    errors.endDate = "Введіть корректну дату закінчення";
  } else if (
    !active &&
    values.endDate &&
    moment(values.endDate)
      .add(1, "days")
      .startOf("day")
      .isBefore(moment())
  ) {
    errors.endDate = `Мінімальна дата - ${moment()
      .add(1, "days")
      .startOf("day")
      .format("DD/MM/YYYY")}`;
  }

  if (!values.posCodes || !values.posCodes.length) {
    errors.posCodes = required;
  }

  if (!values.completionType) {
    errors.completionType = required;
  }

  if (!values.taskType) {
    errors.taskType = required;
  } else if (values.taskType.value === 1) {
    // Order Tasks
    if (!values.isGeneralOrderTask) {
      errors.isGeneralOrderTask = required;
    }
    if (!values.posCodesWithAmount || !values.posCodesWithAmount.length) {
      errors.posCodesWithAmount = required;
    }
    if (!!Number(values.isGeneralOrderTask) && !values.generalCount) {
      errors.generalCount = required;
    } else if (!!Number(values.isGeneralOrderTask) && values.generalCount < 5) {
      errors.generalCount = "Мінімальна кількість блоків - 5";
    } else if (!!Number(values.isGeneralOrderTask) && values.generalCount > 200) {
      errors.generalCount = "Максимальна кількість блоків - 200";
    }
    let positions = [];
    if (values.positions && values.positions.length) {
      values.positions.forEach((position, index) => {
        if (!Number(values.isGeneralOrderTask) && !position.count) {
          positions[index] = { count: required };
        } else if (position.count && position.count > 200) {
          positions[index] = { count: "Максимальна кількість блоків - 200" };
        }
      });
      if (positions.length) {
        errors.positions = positions;
      }
    } else {
      errors.positions = required;
    }
    if (!values.bonusPointsRewardOrder && Number(values.bonusPointsRewardOrder) !== 0) {
      errors.bonusPointsRewardOrder = required;
    } else if (Number(values.bonusPointsRewardOrder) < 0) {
      errors.bonusPointsRewardOrder = minBonuses0;
    } else if (Number(values.bonusPointsRewardOrder) > 1000) {
      errors.bonusPointsRewardOrder = maxBonuses1000;
    }
    if (!values.taskDescriptionOrder) {
      errors.taskDescriptionOrder = required;
    } else if (values.taskDescriptionOrder.length < 5) {
      const { tooShortName } = validationErrorMessages({ minLength: 5 });
      errors.taskDescriptionOrder = tooShortName;
    }
    if (!values.positions || !values.positions.length) {
      errors.positions = required;
    }
  } else if (values.taskType.value === 2) {
    // Foil Tasks
    if (!values.foilPosPlan || !values.foilPosPlan.length) {
      errors.foilPosPlan = required;
    }
    if (!values.taskDescriptionFoil) {
      errors.taskDescriptionFoil = required;
    } else if (values.taskDescriptionFoil.length < 5) {
      const { tooShortName } = validationErrorMessages({ minLength: 5 });
      errors.taskDescriptionFoil = tooShortName;
    }
    if (!values.foilCount && values.foilCount !== 0 && values.exchangeFoilToСompliment) {
      errors.foilCount = required;
    }
    if (!values.complimentCount && values.complimentCount !== 0 && values.exchangeFoilToСompliment) {
      errors.complimentCount = required;
    }
    if (!values.productIds || !values.productIds.length) {
      errors.productIds = required;
    }
  } else if (values.taskType.value === 3) {
    // Test Tasks
    errors.questions = [];
    if (!values.bonusPointsRewardTest && values.bonusPointsRewardTest !== 0) {
      errors.bonusPointsRewardTest = required;
    } else if (Number(values.bonusPointsRewardTest) < 0) {
      errors.bonusPointsRewardTest = minBonuses0;
    } else if (Number(values.bonusPointsRewardTest) > 1000) {
      errors.bonusPointsRewardTest = maxBonuses1000;
    }
    if (!values.taskDescriptionTest) {
      errors.taskDescriptionTest = required;
    } else if (values.taskDescriptionTest.length < 5) {
      const { tooShortName } = validationErrorMessages({ minLength: 5 });
      errors.taskDescriptionTest = tooShortName;
    }
    if (!values.questions || !values.questions.length) {
      errors.questions[0] = required;
    } else {
      values.questions.forEach((question, index) => {
        errors.questions[index] = {};
        errors.questions[index].answers = [];

        if (!question.title) {
          errors.questions[index].title = required;
        }
        if (question && question.answers && question.answers.length) {
          errors.questions[index].answers = [];
          question.answers.forEach((answer, idx) => {
            errors.questions[index].answers[idx] = {};
            const correctAnswers = question.answers.filter(answer => answer.isCorrect === true);
            if (!answer || !answer.title) {
              errors.questions[index].titleField = "Заповніть усі обов'язкові поля";
              props.touch(`questions[${index}].titleField`);
              errors.questions[index].answers[idx].title = required;
            } else if (answer.title && !correctAnswers.length) {
              errors.questions[index].titleField = "Як мінімум одна правильна відповідь має бути присутня";
              errors.questions[index].isCorrectAnswer = "Як мінімум одна правильна відповідь має бути присутня";
              props.touch(`questions[${index}].titleField`);
            }
          });
        }
      });
    }
  } else if (values.taskType.value === 4) {
    // Informational Tasks
    if (!values.taskDescriptionInformational) {
      errors.taskDescriptionInformational = required;
    } else if (values.taskDescriptionInformational.length < 5) {
      const { tooShortName } = validationErrorMessages({ minLength: 5 });
      errors.taskDescriptionInformational = tooShortName;
    }
    if (!values.bonusPointsRewardInformational && values.bonusPointsRewardInformational !== 0) {
      errors.bonusPointsRewardInformational = required;
    } else if (Number(values.bonusPointsRewardInformational) > 1000) {
      errors.bonusPointsRewardInformational = maxBonuses1000;
    }
  } else if (values.taskType.value === 5) {
    // Questionnaire Tasks
    if (!values.products || !values.products.length) {
      errors.products = required;
    }
    if (!values.taskDescriptionQuestionnaire) {
      errors.taskDescriptionQuestionnaire = required;
    } else if (values.taskDescriptionQuestionnaire.length < 5) {
      const { tooShortName } = validationErrorMessages({ minLength: 5 });
      errors.taskDescriptionQuestionnaire = tooShortName;
    }
    if (!values.bonusPointsRewardQuestionnaire && values.bonusPointsRewardQuestionnaire !== 0) {
      errors.bonusPointsRewardQuestionnaire = required;
    } else if (Number(values.bonusPointsRewardQuestionnaire) < 0) {
      errors.bonusPointsRewardQuestionnaire = minBonuses0;
    } else if (Number(values.bonusPointsRewardQuestionnaire) > 1000) {
      errors.bonusPointsRewardQuestionnaire = maxBonuses1000;
    }
  } else if (values.taskType.value === 6) {
    // Photo Tasks
    if (!values.taskDescriptionPhoto) {
      errors.taskDescriptionPhoto = required;
    } else if (values.taskDescriptionPhoto.length < 5) {
      const { tooShortName } = validationErrorMessages({ minLength: 5 });
      errors.taskDescriptionPhoto = tooShortName;
    }
    if (!values.bonusPointsRewardPhoto && values.bonusPointsRewardPhoto !== 0) {
      errors.bonusPointsRewardPhoto = required;
    } else if (Number(values.bonusPointsRewardPhoto) < 0) {
      errors.bonusPointsRewardPhoto = minBonuses0;
    } else if (Number(values.bonusPointsRewardPhoto) > 1000) {
      errors.bonusPointsRewardPhoto = maxBonuses1000;
    }
  } else if (values.taskType.value === 7) {
    // Test Tasks Feedback
    errors.questionsFeedback = [];
    if (!values.bonusPointsRewardTestFeedback && values.bonusPointsRewardTestFeedback !== 0) {
      errors.bonusPointsRewardTestFeedback = required;
    } else if (Number(values.bonusPointsRewardTestFeedback) < 0) {
      errors.bonusPointsRewardTestFeedback = minBonuses0;
    } else if (Number(values.bonusPointsRewardTestFeedback) > 1000) {
      errors.bonusPointsRewardTestFeedback = maxBonuses1000;
    }
    if (!values.taskDescriptionTestFeedback) {
      errors.taskDescriptionTestFeedback = required;
    } else if (values.taskDescriptionTestFeedback.length < 5) {
      const { tooShortName } = validationErrorMessages({ minLength: 5 });
      errors.taskDescriptionTestFeedback = tooShortName;
    }
    if (!values.questionsFeedback || !values.questionsFeedback.length) {
      errors.questionsFeedback[0] = required;
    } else {
      values.questionsFeedback.forEach((question, index) => {
        errors.questionsFeedback[index] = {};
        errors.questionsFeedback[index].answers = [];
        if (!question.title) {
          errors.questionsFeedback[index].title = required;
        }
        if (!question.answerType) {
          errors.questionsFeedback[index].answerType = required;
          errors.questionsFeedback[index].titleField = required;
        } else if (question.answerType.value === "1") {
          if (question && question.answers && question.answers.length) {
            errors.questionsFeedback[index].answers = [];
            question.answers.forEach((answer, idx) => {
              errors.questionsFeedback[index].answers[idx] = {};
              if (!answer || !answer.title) {
                errors.questionsFeedback[index].answers[idx].title = required;
                errors.questionsFeedback[index].titleField = required;
              }
            });
          } else {
            errors.questionsFeedback[index].titleField = required;
          }
        } else if (question.answerType.value === "2") {
          if (question && question.answersExtended && question.answersExtended.length) {
            errors.questionsFeedback[index].answersExtended = [];
            question.answersExtended.forEach((answer, idx) => {
              errors.questionsFeedback[index].answersExtended[idx] = {};
              if (!answer || !answer.title) {
                errors.questionsFeedback[index].answersExtended[idx].title = required;
                errors.questionsFeedback[index].titleField = required;
              }
            });
          }
        }
      });
    }
  } else if (values.taskType.value === 8) {
    if (!values.scanDescription) {
      errors.scanDescription = required;
    } else if (values.scanDescription.length < 5) {
      const { tooShortName } = validationErrorMessages({ minLength: 5 });
      errors.scanDescription = tooShortName;
    }
    if (!values.posPlan || !values.posPlan.length) {
      errors.posPlan = required;
    }
    if (!values.productIds || !values.productIds.length) {
      errors.productIds = required;
    }
  } else if (values.taskType.value === 9) {
    if (!values.midPlusDescription) {
      errors.midPlusDescription = required;
    }
    if (!values.posMidPlus || !values.posMidPlus.length) {
      errors.posMidPlus = required;
    }
    if (!values.productIds || !values.productIds.length) {
      errors.productIds = required;
    }
    const productIds = values.productIds && values.productIds.map(item => item.value);
    const midPlusProductIds =
      values.midPlusProductIds && values.midPlusProductIds.filter(item => productIds.includes(item.value));
    if (!midPlusProductIds || !midPlusProductIds.length) {
      errors.midPlusProductIds = required;
    }
  }

  return errors;
};

export const required = value => (value ? undefined : "Обов'язкове поле");
