// @flow
import React, { useState } from "react";
import { Field, FieldArray, formValueSelector } from "redux-form";
import { connect } from "react-redux";
import type { FormProps } from "redux-form";
import IconClose from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import IconDown from "@material-ui/icons/ArrowDropDown";
import IconUp from "@material-ui/icons/ArrowDropUp";
import ErrorMessage from "../../../components/ErrorMessage/ErrorMessage";
import InputFileMultiple from "../../../components/InputFileMultiple/InputFileMultiple";
import InputField from "../../../components/InputField/InputField";
import Select from "../../../components/Select/Select";
import AnswerField from "./AnswerField";
import AnswerWithDifferentTypes from "./AnswerWithDifferentTypes";
import { required } from "./validate";
import { normalizeLength } from "../../../utils/reduxFormNormalizers";
import { testTaskAnswerTypes, feedbackTaskAnswerTypes } from "../../../constants";
import styles from "./TaskForm.module.scss";

const radioAnswers = "1";
const mixedAnswers = "2";

type PropsT = {
  disabled: boolean,
  question: any,
  feedBack: boolean,
  questions: any,
  active: boolean
} & FormProps;

const Question = (props: PropsT) => {
  const [opened, toggleOpened] = useState(true);
  const { question, fields, disabled, index, feedBack, questions, active, isCloseIconDisabled } = props;
  const shouldRenderAnswers =
    !feedBack ||
    (questions &&
      questions[index] &&
      questions[index].answerType &&
      questions[index].answerType.value === radioAnswers);
  const shouldRenderDifferentAnswers =
    feedBack &&
    questions &&
    questions[index] &&
    questions[index].answerType &&
    questions[index].answerType.value === mixedAnswers;
  const notNewQuestion = questions && questions[index] && questions[index]._id;
  const answers = questions && questions[index] && questions[index].answers;

  const answersExtended = questions && questions[index] && questions[index].answersExtended;
  const options = feedBack ? feedbackTaskAnswerTypes : testTaskAnswerTypes;
  const additionalField = questions[index] && questions[index].additionalField;
  return (
    <li key={index} className={styles.blockWrapper}>
      <h4>Питання №{index + 1}</h4>
      <Field
        required
        name={`${question}.title`}
        className={styles.select}
        component={InputField}
        validate={[required]}
        multiline
        disabled={disabled || active}
        normalize={normalizeLength(1000)}
      />
      <div className={styles.questionWrapper}>
        <Field
          name={`${question}.titleField`}
          component={props => {
            const hasError = !opened && props.meta.touched && !!props.meta.error;
            return (
              <div className={styles.toggleWrapper}>
                <h4>{opened ? "Сховати відповіді" : "Показати відповіді"}</h4>
                {hasError && <ErrorMessage className={styles.errorStyles} error={props.meta.error} />}
              </div>
            );
          }}
        />
        <IconButton onClick={() => toggleOpened(!opened)}>{opened ? <IconUp /> : <IconDown />}</IconButton>
      </div>
      {opened && (
        <>
          <Field
            component={InputFileMultiple}
            name={`${question}.photo`}
            id={questions[index]._id || questions[index].imageId}
            withPreview
            bigPreview
            disabled={disabled || !props.imageTransactionSuccess || !!notNewQuestion}
            label="Додати картинку"
            configName="photo"
            limit={1}
          />

          {feedBack && (
            <Field
              component={Select}
              name={`${question}.answerType`}
              disabled={disabled || !!notNewQuestion}
              placeholder="Тип відповіді"
              options={options}
            />
          )}

          {shouldRenderAnswers && (
            <FieldArray
              name={`${question}.answers`}
              className={styles.select}
              component={AnswerField}
              validate={[required]}
              label="Відповідь"
              blockLabel="Введіть відповіді"
              disabled={disabled}
              feedBack={feedBack}
              isCloseIconDisabled={isCloseIconDisabled}
              active={active}
              answers={answers}
            />
          )}
          <Field
            name={`${question}.isCorrectAnswer`}
            component={props => {
              const hasError = !!props.meta.error;
              return hasError && <ErrorMessage className={styles.errorStyles} error={props.meta.error} />;
            }}
          />
          {shouldRenderDifferentAnswers && (
            <FieldArray
              name={`${question}.answersExtended`}
              className={styles.select}
              component={AnswerWithDifferentTypes}
              validate={[required]}
              label="Відповідь"
              blockLabel="Введіть відповіді"
              isCloseIconDisabled={isCloseIconDisabled}
              disabled={disabled || active}
              feedBack={feedBack}
              active={active}
              question={question}
              additionalField={additionalField}
              answers={answersExtended}
            />
          )}
        </>
      )}
      {fields.length > 1 && (!active || !notNewQuestion) && (
        <IconButton
          disabled={isCloseIconDisabled}
          className={styles.removeBlockButton}
          onClick={() => fields.remove(index)}
        >
          <IconClose />
        </IconButton>
      )}
    </li>
  );
};

const mapStateToProps = (state, ownProps) => {
  const selector = formValueSelector("TaskForm");
  const questionsFeedback = selector(state, "questionsFeedback");
  const questions = selector(state, "questions");
  const question = ownProps.feedBack ? questionsFeedback[ownProps.index] : questions[ownProps.index];
  const id = question._id || question.imageId;

  const imageTransactionSuccess =
    state.images && state.images[id] && state.images[id].imageTransactionSuccess === false ? false : true;
  return {
    imageTransactionSuccess,
    questions: ownProps.feedBack ? questionsFeedback : questions
  };
};

export default connect(mapStateToProps, null)(Question);
