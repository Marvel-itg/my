// @flow
import React from "react";
import { Field } from "redux-form";
import type { FormProps } from "redux-form";
import cx from "classnames";
// $FlowFixMe
import Fab from "@material-ui/core/Fab";
import IconClose from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import AddIcon from "@material-ui/icons/Add";
import InputField from "../../../components/InputField/InputField";
import Checkbox from "./Checkbox";
import { normalizeLength } from "../../../utils/reduxFormNormalizers";
import styles from "./TaskForm.module.scss";

type PropsT = {
  disabled: boolean,
  label: string,
  blockLabel: string,
  active: boolean,
  answers: any[]
} & FormProps;

const smallFabClasses = { root: cx(styles.addButton, styles.small) };

const AnswerField = (props: PropsT) => {
  const {
    fields,
    meta: { touched, error, submitFailed },
    disabled,
    label,
    blockLabel,
    feedBack,
    active,
    answers,
    isCloseIconDisabled
  } = props;

  const disableFeedbackAnswers = feedBack && fields.length > 19;

  return (
    <div className={props.hidden ? styles.hidden : styles.sectionWrapper}>
      <ul className={props.hidden ? styles.hidden : styles.sectionList}>
        <h4 className={styles.answerTitle}>{blockLabel}</h4>
        <div className={styles.answerSubtitle}>Виберіть правильні відподвіді</div>
        <li>{(touched || submitFailed) && error && <span>{error}</span>}</li>
        {fields.map((answer, index) => {
          const notNewAnswer = answers && answers[index] && answers[index]._id;
          return (
            <li key={index} className={styles.answerWrapper}>
              <Field
                required
                name={`${answer}.title`}
                className={styles.inputField}
                component={InputField}
                label={`${label} ${index + 1}`}
                disabled={disabled || active}
                multiline
                normalize={normalizeLength(1000)}
              />
              {!feedBack && (
                <Field
                  name={`${answer}.isCorrect`}
                  className={styles.inputField}
                  component={Checkbox}
                  disabled={disabled}
                  format={value => (value ? "true" : "false")}
                />
              )}
              {fields.length > 1 && (!active || !notNewAnswer) && (
                <IconButton
                  disabled={isCloseIconDisabled}
                  className={styles.removeButton}
                  onClick={() => fields.remove(index)}
                >
                  <IconClose />
                </IconButton>
              )}
            </li>
          );
        })}
      </ul>
      {!active && (
        <Fab
          size="small"
          color="secondary"
          aria-label="Add"
          onClick={() => fields.push({})}
          classes={smallFabClasses}
          disabled={disabled || disableFeedbackAnswers}
        >
          <AddIcon disabled={disabled || disableFeedbackAnswers} />
        </Fab>
      )}
    </div>
  );
};

export default AnswerField;
