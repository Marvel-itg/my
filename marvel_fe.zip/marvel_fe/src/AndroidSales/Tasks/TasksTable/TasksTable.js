// @flow
import React from "react";
import cx from "classnames";
import moment from "moment";
import {
  Grid,
  TableHeaderRow,
  Table,
  Toolbar,
  SearchPanel,
  TableBandHeader
} from "@devexpress/dx-react-grid-material-ui";
import { SearchState, IntegratedFiltering, PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import { withStyles } from "@material-ui/core/styles";
import SearchInput from "../../../components/SearchInput/SearchInputForIntegratedSearch";
import ToolbarRoot from "../../../components/TableComponents/ToolbarRoot";
import TabsHeader from "../../../components/TableComponents/TabsHeader";
import TableContainer from "../../../components/TableComponents/TableContainer";
import PagingPanel from "../../../components/TableComponents/PagingPanel";
import OutlinedButton from "../../../components/Buttons/OutlinedButton/OutlinedButton";
import GridRoot from "../../../components/TableComponents/GridRoot";
import {
  DateFormatProvider,
  DestructiveButtonProvider,
  TransparentButtonProvider,
  ToggleActiveProvider,
  TaskTypeProvider
} from "../../../components/FormattedData/FormattedData";
import DeleteRowDialog from "../../../components/DeleteRowDialog/DeleteRowDialog";
import { availableItemsPerPage, defaultItemsPerPage } from "../../../constants";
import styles from "./TasksTable.module.scss";
import TaskTypeForm from "../../StatisticByTasksSales/TaskTypeForm";

type PropsT = {
  data: TaskT[],
  changeTab: Function,
  openModal: Function,
  changeTaskState: Function,
  deleteTask: Function,
  classes?: any,
  activeTab: number | string,
  tabs: TabT[],
  columns: ColumnT[],
  changeCurrentPage: Function,
  changePageSize: Function,
  setSearchValue: Function,
  count: number,
  page: number,
  total: number,
  searchValue: string
};

type StateT = {
  tableColumnExtensions: TableColumnExtensionT[],
  deletingRowIds: number[]
};

const columnBands = [
  {
    title: "Тривалiсть",
    children: [{ columnName: "startDate" }, { columnName: "endDate" }]
  }
];

const forValues = {
  startDate: ["startDate"],
  endDate: ["endDate"],
  changeState: ["changeState"],
  delete: ["delete"],
  edit: ["edit"],
  editActive: ["editActive"],
  details: ["details"],
  taskType: ["taskType"]
};

const Cell = (tableProps: any) => {
  const { className } = tableProps;
  return <Table.Cell {...tableProps} className={cx({ className, [styles.disableRow]: !tableProps.row.isActive })} />;
};

class TasksTable extends React.Component<PropsT, StateT> {
  state = {
    tableColumnExtensions: [
      { columnName: "id", width: 120 },
      { columnName: "name", width: 480 },
      { columnName: "taskType", width: 280 },
      { columnName: "startDate", width: 100 },
      { columnName: "endDate", width: 100 },
      { columnName: "bonusPointsReward", width: 130 },
      { columnName: "edit", width: 130 },
      { columnName: "editActive", width: 130 },
      { columnName: "changeState", width: 170 },
      { columnName: "delete", width: 150 },
      { columnName: "details", width: 170 }
    ],
    deletingRowIds: []
  };

  saveIdForDelete = id => {
    this.setState({
      deletingRowIds: [id]
    });
  };

  openEditModal = (id, rowData) => {
    const taskType = rowData.taskType;
    this.props.openModal("edit", id, taskType);
  };

  openEditActiveModal = (id, rowData) => {
    const taskType = rowData.taskType;
    this.props.openModal("editActive", id, taskType);
  };

  openDetailsModal = (id, rowData) => {
    const taskType = rowData.taskType;
    this.props.openModal("details", id, taskType);
  };

  deleteTask = () => {
    this.props.deleteTask(this.state.deletingRowIds[0]);
    this.setState({
      deletingRowIds: []
    });
  };

  cancelDelete = () => {
    this.setState({
      deletingRowIds: []
    });
  };

  toggleActive = (taskTemplateId, taskIsActive, startDate, taskType) => {
    const data = { taskTemplateId, isActive: !taskIsActive };
    const tomorrow = moment()
      .add(1, "days")
      .startOf("day");
    if (!taskIsActive && moment(startDate).isBefore(tomorrow)) {
      this.props.openModal("changeDate", taskTemplateId, taskType);
    } else if (taskType === 8 && taskIsActive) {
      this.props.openModal("deactivateScan", taskTemplateId);
    } else {
      this.props.changeTaskState(data);
    }
  };

  renderDeleteDialog = () => (
    <DeleteRowDialog
      title="Видалити завдання"
      text="Ви впевнені що бажаете видалити це завдання?"
      deletingRows={this.state.deletingRowIds}
      rows={this.props.data}
      classes={this.props.classes}
      columns={this.props.columns}
      tableColumnExtensions={this.state.tableColumnExtensions}
      cancelDelete={this.cancelDelete}
      deleteRows={this.deleteTask}
    />
  );

  renderAddButton = () => (
    <OutlinedButton
      label="Додати завдання"
      clickHandler={() => this.props.openModal("add")}
      className={styles.addButton}
    />
  );

  renderSearchInput = props => {
    return <SearchInput {...props} placeholder="Пошук завдань" />;
  };

  render() {
    const { tableColumnExtensions } = this.state;
    const {
      activeTab,
      changeTab,
      tabs,
      columns,
      page,
      count,
      total,
      data,
      changeCurrentPage,
      changePageSize,
      searchValue,
      setSearchValue
    } = this.props;
    return (
      <>
        <Grid rows={data} columns={columns} rootComponent={GridRoot}>
          <SearchState onValueChange={setSearchValue} value={searchValue} />
          <PagingState
            currentPage={page || 0}
            onCurrentPageChange={changeCurrentPage}
            pageSize={count || defaultItemsPerPage}
            onPageSizeChange={changePageSize}
          />
          <CustomPaging totalCount={total} />
          <DateFormatProvider for={forValues.startDate} />
          <DateFormatProvider for={forValues.endDate} />
          <TaskTypeProvider for={forValues.taskType} />
          <TransparentButtonProvider for={forValues.edit} onClick={this.openEditModal} label="Редагувати" />
          <TransparentButtonProvider for={forValues.editActive} onClick={this.openEditActiveModal} label="Редагувати" />
          <TransparentButtonProvider for={forValues.details} onClick={this.openDetailsModal} label="Деталі завдання" />
          <ToggleActiveProvider for={forValues.changeState} onClick={this.toggleActive} />
          <DestructiveButtonProvider for={forValues.delete} onClick={this.saveIdForDelete} label="Видалити" />
          <IntegratedFiltering />

          <Toolbar rootComponent={ToolbarRoot} />

          <Table
            columnExtensions={tableColumnExtensions}
            height="auto"
            cellComponent={Cell}
            containerComponent={TableContainer}
          />
          <div className={styles.buttonWrapper}>{this.renderAddButton()}</div>
          <TableHeaderRow />
          <TabsHeader changeTab={changeTab} activeTab={activeTab} tabs={tabs}>
            <TaskTypeForm className={styles.selectTypes} />
          </TabsHeader>
          <TableBandHeader columnBands={columnBands} />

          <PagingPanel pageSizes={availableItemsPerPage} noData={!total} />
          <SearchPanel inputComponent={this.renderSearchInput} />
        </Grid>
        {this.renderDeleteDialog()}
      </>
    );
  }
}

export default withStyles(styles)(TasksTable);
