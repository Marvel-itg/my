// @flow
import React from "react";
import moment from "moment";
import { reduxForm, Field } from "redux-form";
import type { FormProps } from "redux-form";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import { connect } from "react-redux";
import { compose } from "redux";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import { changeAdvertisingStatus } from "../../store/actions/sales/advertising";
import Switch from "../../components/Switch/Switch";
import styles from "./InteractiveForm.module.scss";

type PropsT = {
  openEditForm: () => void,
  data: AdvertisingItemT,
  changingError: null | string,
  changeAdvertisingStatus: (params: ChangeAdvertisingStatusParams) => void
} & FormProps;
const InteractiveDetails = (props: PropsT) => {
  const { data, openEditForm, loading, changeAdvertisingStatus, changingError } = props;
  const handleChangeSwitch = (event, value) => {
    const params = {
      isActive: value,
      id: data.id
    };
    changeAdvertisingStatus(params);
  };
  return (
    <>
      {data ? (
        <form autoComplete="off" noValidate className={styles.interactiveDetailsForm}>
          <div className={styles.cardStyles}>
            <div className={styles.headerWrapper}>
              <h1 className={styles.title}>{data.name}</h1>
              <div className={styles.buttonsWrapper}>
                <Field
                  required
                  name="isActive"
                  component={Switch}
                  label=""
                  disabled={loading}
                  className={styles.switch}
                  onChange={handleChangeSwitch}
                />
                <ContainedButton type="button" label="Редагувати" handleClick={openEditForm} disabled={loading} />
                {changingError && <ErrorMessage error={changingError} />}
              </div>
            </div>
            <div className={styles.mediaDates}>
              <div className={styles.date}>
                <div className={styles.label}>Дата старту</div>
                <div className={styles.date}>{moment(data.startDate).format("DD/MM/YYYY")}</div>
              </div>
              <div className={styles.date}>
                <div className={styles.label}>Дата закінчення</div>
                <div className={styles.date}>{moment(data.endDate).format("DD/MM/YYYY")}</div>
              </div>
            </div>

            <div className={styles.mediaTitle}>Медіафайли</div>

            <div className={styles.mediaWrapper}>
              {data.interactives &&
                data.interactives.map(item => {
                  return (
                    <div className={styles.media} key={item.id}>
                      <div className={styles.mediaPreview}>
                        <img src={item.preview[0] && item.preview[0].imageUrl} alt={item.name} />
                      </div>
                      <div className={styles.mediaContent}>
                        <div className={styles.mediaHeader}>{item.name}</div>
                        <div
                          dangerouslySetInnerHTML={{
                            __html: item.description
                          }}
                        ></div>
                      </div>
                    </div>
                  );
                })}
            </div>
            <div className={styles.mediaTitle}>Банер</div>
            <div className={styles.mediaWrapper}>
              <div className={styles.media}>
                <img src={data.banner[0] && data.banner[0].imageUrl} alt={"Банер"} />
              </div>
            </div>
          </div>
        </form>
      ) : (
        <ContainedButton
          type="button"
          label="Додати"
          handleClick={openEditForm}
          className={styles.addInteractiveButton}
        />
      )}
    </>
  );
};

const mapStateToProps = state => {
  const {
    advertising: { changing, changingError }
  } = state;
  return {
    loading: changing,
    changingError
  };
};

const mapDispatchToProps = {
  changeAdvertisingStatus
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  reduxForm({
    form: "interactiveStatus",
    enableReinitialize: true
  })
)(InteractiveDetails);
