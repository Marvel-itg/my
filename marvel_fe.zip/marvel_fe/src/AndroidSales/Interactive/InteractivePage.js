// @flow
import React, { useEffect } from "react";
import { connect } from "react-redux";
import Paper from "@material-ui/core/Paper";
import InteractiveForm from "./InteractiveForm";
import InteractiveDetails from "./InteractiveDetails";
import Modal from "../../components/Modal/Modal";
import { getAdvertisingData } from "../../store/actions/sales/advertising";
import { initialValuesSelector } from "../../store/selectors/sales/advertising";
import { openModal } from "../../store/actions/common/modals";
import styles from "./InteractiveForm.module.scss";

type PropsT = {
  advertisingData: AdvertisingItemT,
  changed: boolean,
  submitted: boolean,
  openModal: () => void,
  getAdvertisingData: () => void
};

const InteractivePage = (props: PropsT) => {
  const { getAdvertisingData, advertisingData, changed, submitted } = props;

  useEffect(() => {
    getAdvertisingData();
  }, [changed, getAdvertisingData, submitted]);

  const initialValues = { isActive: advertisingData && advertisingData.isActive };
  const openModal = () => {
    props.openModal();
  };

  return (
    <Paper className={styles.pageContainer}>
      <InteractiveDetails openEditForm={openModal} data={advertisingData} initialValues={initialValues} />
      <Modal formName="addInteractive">
        <InteractiveForm initialValues={advertisingData} form="addInteractive" />
      </Modal>
    </Paper>
  );
};

const mapStateToProps = state => {
  const {
    advertising: { changing, changed, loading, submitted }
  } = state;
  return {
    loading: loading || changing,
    changed,
    submitted,
    advertisingData: initialValuesSelector(state)
  };
};

const mapDispatchToProps = {
  openModal,
  getAdvertisingData
};

export default connect(mapStateToProps, mapDispatchToProps)(InteractivePage);
