// @flow
import React from "react";
import cx from "classnames";
import moment from "moment";
import uniqueId from "lodash/uniqueId";
import type { FormProps } from "redux-form";
// $FlowFixMe
import Fab from "@material-ui/core/Fab";
import AddIcon from "@material-ui/icons/Add";
import InteractiveBlock from "./InteractiveBlock";
import { completionTypeOptions } from "./constants";
import styles from "./InteractiveForm.module.scss";

const fabClasses = { root: cx(styles.addButton, styles.big) };

type Props = {
  isActive: boolean
} & FormProps;

const InteractivesList = (props: Props) => {
  const { fields, isActive } = props;
  const isAddAnswerButtonDisabled = fields.length === 5;

  return (
    <>
      <ul className={styles.sectionList}>
        {fields.map((fileData, index) => {
          return <InteractiveBlock key={index} fields={fields} fileData={fileData} index={index} isActive={isActive} />;
        })}
      </ul>

      <Fab
        size="medium"
        color="secondary"
        classes={fabClasses}
        onClick={() =>
          fields.push({
            completionType: completionTypeOptions[0],
            previewId: `${moment().valueOf()}random${uniqueId()}`,
            contentId: `${moment().valueOf()}random${uniqueId()}`
          })
        }
        aria-label="Add"
        disabled={isAddAnswerButtonDisabled}
      >
        <AddIcon />
      </Fab>
    </>
  );
};

export default InteractivesList;
