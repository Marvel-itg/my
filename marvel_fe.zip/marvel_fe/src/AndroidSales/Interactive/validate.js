import moment from "moment";
import get from "lodash/get";
import { getHTMLContent } from "./helpers";
import { validationErrorMessages } from "../../constants";

export const validate = (values, { formMeta }) => {
  const { required, tooLongName } = validationErrorMessages({ maxLength: 100 });
  const errors = {};
  errors.interactives = [];

  if (!values.name) {
    errors.name = required;
  }

  if (!values.startDate) {
    errors.startDate = required;
  }

  if ((!values.id || !values.isActive) && moment(values.startDate).isBefore(moment().startOf("day"))) {
    errors.startDate = "Дата старту не може бути раніше поточної дати";
  }

  if (!values.endDate) {
    errors.endDate = required;
  } else if (moment(values.endDate).isBefore(moment().startOf("day"))) {
    errors.endDate = "Дата закінчення не може бути раніше поточної дати";
  } else if (values.startDate && moment(values.endDate).isBefore(moment(values.startDate).startOf("day"))) {
    errors.endDate = "Дата закінчення не може бути раніше дати старту";
  }

  if (!values.banner || !values.banner[0]) {
    errors.banner = required;
  }

  if (values.interactives && values.interactives.length) {
    values.interactives.forEach((interactive, index) => {
      errors.interactives[index] = {};
      if (!interactive.preview || !interactive.preview.length) {
        errors.interactives[index].preview = required;
      }
      if (!interactive.content || !interactive.content.length) {
        errors.interactives[index].content = required;
      }
      if (!interactive.name) {
        errors.interactives[index].name = required;
      } else if (interactive.name.length > 100) {
        errors.interactives[index].name = tooLongName;
      }

      if (!interactive.description) {
        errors.interactives[index].description = required;
      } else if (interactive.description) {
        const { tooLongName: tooLongName700 } = validationErrorMessages({ maxLength: 700 });
        const text = getHTMLContent(interactive.description);
        if (!text.length) {
          errors.interactives[index].description = required;
        } else if (text.length > 700) {
          errors.interactives[index].description = tooLongName700;
        }
      }

      if (!interactive.startDate) {
        errors.interactives[index].startDate = required;
      } else if (!isBetween(values.startDate, values.endDate, interactive.startDate)) {
        errors.interactives[index].startDate = "Дата початку інтерактиву не входить в період дії рекламної акції";
      } else if (
        (values.isActive &&
          get(formMeta, `interactives[${index}].startDate.visited`) &&
          moment(interactive.startDate).isBefore(moment().startOf("day"))) ||
        (!values.isActive && moment(interactive.startDate).isBefore(moment().startOf("day")))
      ) {
        errors.interactives[index].startDate = "Дата старту не може бути раніше поточної дати";
      } else {
        const crossed = getCrossing(values.interactives, interactive.startDate, index);
        if (crossed.length) {
          errors.interactives[
            index
          ].startDate = `Дата початку інтерактиву перетинається з періодом дії інтерактиву №${crossed.join(",")}`;
        }
      }

      if (!interactive.endDate) {
        errors.interactives[index].endDate = required;
      } else if (!isBetween(values.startDate, values.endDate, interactive.endDate)) {
        errors.interactives[index].endDate = "Дата закінчення інтерактиву не входить в період дії рекламної акції";
      } else if (
        (values.isActive &&
          get(formMeta, `interactives[${index}].endDate.visited`) &&
          moment(interactive.endDate).isBefore(moment().startOf("day"))) ||
        (!values.isActive && moment(interactive.endDate).isBefore(moment().startOf("day")))
      ) {
      } else if (
        interactive.startDate &&
        moment(interactive.endDate).isBefore(moment(interactive.startDate).startOf("day"))
      ) {
        errors.interactives[index].endDate = "Дата закінчення не може бути раніше дати старту";
      } else {
        const crossed = getCrossing(values.interactives, interactive.endDate, index);
        if (crossed.length) {
          errors.interactives[
            index
          ].endDate = `Дата закінчення інтерактиву перетинається з періодом дії інтерактиву №${crossed.join(",")}`;
        }
      }
    });
  }

  return errors;
};

const getCrossing = (interactives, currentDate, currentIndex) => {
  const crossed = [];
  interactives.forEach((item, idx) => {
    const { startDate, endDate } = item;
    if (idx !== currentIndex && startDate && endDate && isBetween(startDate, endDate, currentDate)) {
      crossed.push(idx + 1);
    }
  });
  return crossed;
};

const isBetween = (startDate, endDate, currentDate) => {
  const isBetween = moment(currentDate).isBetween(
    moment(startDate).startOf("day"),
    moment(endDate).endOf("day"),
    null,
    []
  );
  return isBetween;
};
