// @flow
import React from "react";
import { Field, formValueSelector } from "redux-form";
import { connect } from "react-redux";
import type { FormProps } from "redux-form";
import IconClose from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import FormControl from "@material-ui/core/FormControl";
import FormLabel from "@material-ui/core/FormLabel";
import TextField from "@material-ui/core/TextField";
import Select from "../../components/Select/Select";
import InputDatePicker from "../../components/InputField/InputDatePicker";
import InputFileMultiple from "../../components/InputFileMultiple/InputFileMultiple";
import EditorComponent from "../../components/EditorComponent/EditorComponent";
import InputField from "../../components/InputField/InputField";
import { completionTypeOptions } from "./constants";
import styles from "./InteractiveForm.module.scss";
import {
  videoSizeLimit,
  videoSizeErrorMessage,
  advertisingPreviewSizeLimit,
  advertisingPreviewErrorMessage
} from "../../constants";

type Props = {
  isActive: boolean,
  contentId: string,
  previewId: string,
  contentTransactionSuccess: boolean,
  previewTransactionSuccess: boolean,
  fileData: string,
  index: number
} & FormProps;

const InteractiveBlock = (props: Props) => {
  const {
    fileData,
    fields,
    isActive,
    contentId,
    previewId,
    contentTransactionSuccess,
    previewTransactionSuccess,
    index
  } = props;

  return (
    <li className={styles.blockWrapper}>
      <Field name="id" component={TextField} className={styles.hidden} />
      <div className={styles.datesWrapper}>
        <div className={styles.thirdPartField}>
          <Field
            component={InputFileMultiple}
            name={`${fileData}.content`}
            withPreview
            bigPreview
            limit={1}
            id={contentId}
            disabled={!contentTransactionSuccess}
            configName="content"
            maxSize={videoSizeLimit}
            maxSizeErrorMessage={videoSizeErrorMessage}
            uploadType="advertising"
          />
        </div>
        <div className={styles.thirdPartField}>
          <Field
            component={InputFileMultiple}
            name={`${fileData}.preview`}
            withPreview
            bigPreview
            limit={1}
            id={previewId}
            disabled={!previewTransactionSuccess}
            configName="preview"
            maxSize={advertisingPreviewSizeLimit}
            maxSizeErrorMessage={advertisingPreviewErrorMessage}
            uploadType="advertising"
          />
        </div>
        <div className={styles.thirdPartField}>
          <Field required name={`${fileData}.name`} component={InputField} label="Назва" />
        </div>
      </div>
      <FormControl required component="fieldset" className={styles.formInputWrapper}>
        <FormLabel component="legend">Опис</FormLabel>
        <Field name={`${fileData}.description`} component={EditorComponent} />
      </FormControl>

      <div className={styles.datesWrapper}>
        <Field
          required
          name={`${fileData}.startDate`}
          label="Дата початку"
          component={InputDatePicker}
          className={styles.thirdPartField}
        />
        <Field
          required
          name={`${fileData}.endDate`}
          label="Дата закінчення"
          component={InputDatePicker}
          className={styles.thirdPartField}
        />
        <Field
          required
          name={`${fileData}.completionType`}
          placeholder="Частота відтворення"
          options={completionTypeOptions}
          component={Select}
          className={styles.thirdPartField}
          disabled={isActive}
        />
      </div>

      <IconButton className={styles.removeBlockButton} onClick={() => fields.remove(index)}>
        <IconClose />
      </IconButton>
    </li>
  );
};

const mapStateToProps = (state, ownProps) => {
  const selector = formValueSelector("addInteractive");
  const interactives = selector(state, "interactives");
  const interactive = interactives && interactives[ownProps.index];
  const { contentId, previewId } = interactive;
  const contentTransactionSuccess =
    state.images && state.images[contentId] && state.images[contentId].imageTransactionSuccess === false ? false : true;
  const previewTransactionSuccess =
    state.images && state.images[previewId] && state.images[previewId].imageTransactionSuccess === false ? false : true;

  return {
    contentTransactionSuccess,
    previewTransactionSuccess,
    contentId,
    previewId
  };
};

export default connect(mapStateToProps, null)(InteractiveBlock);
