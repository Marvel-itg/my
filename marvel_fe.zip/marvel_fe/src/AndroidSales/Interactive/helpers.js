import htmlToDraft from "html-to-draftjs";
import moment from "moment";

export const getHTMLContent = html => {
  const contentBlock = htmlToDraft(html);
  const text = contentBlock.contentBlocks.reduce((acc, block) => {
    return (acc += block.getText());
  }, "");
  return text;
};

export const formatFormValues = values => {
  const { name, startDate, endDate, isActive, interactives, banner } = values;
  const formattedStartDate = moment(startDate).format("YYYY-MM-DD");
  const formattedEndDate = moment(endDate).format("YYYY-MM-DD");

  const formattedInteractives =
    interactives &&
    interactives.map(interactive => {
      const { name, startDate, endDate, description, id, content, preview, completionType } = interactive;
      const formattedStart = moment(startDate).format("YYYY-MM-DD");
      const formattedEnd = moment(endDate).format("YYYY-MM-DD");

      return {
        id,
        name,
        startDate: formattedStart,
        endDate: formattedEnd,
        description,
        descriptionOriginal: getHTMLContent(description),
        contentId: content[0] && content[0].id,
        previewId: preview && preview[0].id,
        frequency: completionType.value
      };
    });

  const formattedData = {
    name,
    startDate: formattedStartDate,
    endDate: formattedEndDate,
    isActive,
    bannerId: banner[0] && banner[0].id,
    interactives: formattedInteractives
  };

  return formattedData;
};
