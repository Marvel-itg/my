// @flow
import React from "react";
import { connect } from "react-redux";
import { compose } from "redux";
import InputLabel from "@material-ui/core/InputLabel";
import TextField from "@material-ui/core/TextField";
import { reduxForm, Field, FieldArray, getFormMeta } from "redux-form";
import type { FormProps } from "redux-form";

import InputField from "../../components/InputField/InputField";
import InputFileMultiple from "../../components/InputFileMultiple/InputFileMultiple";
import InputDatePicker from "../../components/InputField/InputDatePicker";
import InteractivesList from "./InteractivesList";

import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import { addAdvertising, editAdvertising } from "../../store/actions/sales/advertising";
import { extractionEditAdvertiseError } from "../../store/selectors/sales/advertising";
import { formatFormValues } from "./helpers";
import { validate } from "./validate";
import styles from "./InteractiveForm.module.scss";

type PropsT = {
  errorMessage?: string,
  imageTransactionSuccess: boolean,
  bannerTransactionSuccess: boolean,
  editAdvertising: (props: AdvertisingItemT) => void,
  addAdvertising: (props: AdvertisingItemT) => void
} & FormProps;

const InteractiveForm = (props: PropsT) => {
  const submitForm = values => {
    const id = props.initialValues && props.initialValues.id;
    const formattedValues = formatFormValues(values);
    id ? props.editAdvertising({ ...formattedValues, id }) : props.addAdvertising(formattedValues);
  };
  const { handleSubmit, errorMessage, initialValues, imageTransactionSuccess, bannerTransactionSuccess } = props;
  const id = initialValues && initialValues.id;
  const isActive = initialValues && initialValues.isActive;
  return (
    <form autoComplete="off" noValidate onSubmit={handleSubmit(submitForm)} className={styles.interactiveForm}>
      <div className={styles.formTitle}>{id ? "Редагування інтерактиву" : "Новий інтерактив"}</div>
      <Field name="isActive" component={TextField} className={styles.hidden} />
      <Field name="name" label="Назва інтерактиву" component={InputField} className={styles.inputField} />
      <div className={styles.datesWrapper}>
        <Field
          required
          name="startDate"
          label="Дата початку"
          component={InputDatePicker}
          className={styles.inputHalfField}
          disabled={isActive}
        />
        <Field
          required
          name="endDate"
          label="Дата закінчення"
          component={InputDatePicker}
          className={styles.inputHalfField}
        />
      </div>
      <Field
        component={InputFileMultiple}
        name="banner"
        id="advertisingBanner"
        disabled={!bannerTransactionSuccess}
        withPreview
        bigPreview
        limit={1}
        uploadType="advertising"
        className={styles.banner}
      />
      <InputLabel>Інтерактиви</InputLabel>

      <FieldArray name="interactives" component={InteractivesList} isActive={!!isActive} />

      <ContainedButton
        type="submit"
        label="Зберегти"
        className={styles.submitButton}
        disabled={!imageTransactionSuccess}
      />

      {errorMessage && <ErrorMessage error={errorMessage} />}
    </form>
  );
};

const mapStateToProps = state => {
  const {
    images: { imageTransactionSuccess, advertisingBanner }
  } = state;

  const bannerTransactionSuccess =
    advertisingBanner && advertisingBanner.imageTransactionSuccess === false ? false : true;
  const formMeta = getFormMeta("addInteractive")(state);

  return {
    errorMessage: extractionEditAdvertiseError(state),
    formMeta,
    imageTransactionSuccess,
    bannerTransactionSuccess
  };
};

const mapDispatchToProps = {
  addAdvertising,
  editAdvertising
};

export default compose(connect(mapStateToProps, mapDispatchToProps), reduxForm({ validate }))(InteractiveForm);
