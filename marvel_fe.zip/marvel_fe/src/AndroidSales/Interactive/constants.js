export const completionTypeOptions = [
  {
    value: 1,
    label: "1 раз у період"
  }
];
