// @flow
import React from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import CircularProgress from "@material-ui/core/CircularProgress";
import Paper from "@material-ui/core/Paper/Paper";
import AdminProfileForm from "../../AdminProfileForm/AdminProfileForm";
import ActivityTable from "../../../containers/ActivityHistoryTable/ActivityTable";
import {
  editCentralDepartmentProfile,
  receiveCentralDepartmentProfile,
  clearCentralDepartmentInfo
} from "../../../store/actions/sales/centralDepartmentProfile";
import { phoneWithCode } from "../../../utils/formatValues.js";
import { errorStateProfile, activityHistorySelector } from "../../../store/selectors/sales/centralDepartment";
import { classes } from "../../../helpers/spinner";
import { activityHistoryColumns } from "../../../constants.js";
import styles from "./CentralDepartmentProfile.module.scss";

type PropsT = {
  centralDepartmentProfile: CentralDepartmentT | null,
  receiveCentralDepartmentProfile: Function,
  editCentralDepartmentProfile: Function,
  clearCentralDepartmentInfo: Function,
  loading: boolean
};

type StateT = {
  isEditing: boolean
};

class CentralDepartmentProfile extends React.Component<PropsT & BrowserHistory, StateT> {
  state = { isEditing: false };

  componentDidMount() {
    const { id } = this.props.match.params;
    if (id) {
      this.props.receiveCentralDepartmentProfile(id);
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.submitted && !prevProps.submitted) {
      this.setState({
        isEditing: false
      });
    }
  }

  submitForm = data => {
    const { id } = this.props.match.params;
    const { firstName, lastName, middleName } = data;
    const phone = phoneWithCode(data.phone);
    const normalizeData = {
      accountId: id,
      firstName,
      lastName,
      middleName,
      phone
    };
    this.props.editCentralDepartmentProfile(normalizeData);
  };

  changeMode = event => {
    event.preventDefault();
    this.setState(prevState => ({ isEditing: !prevState.isEditing }));
  };

  render() {
    const { loading } = this.props;
    return loading ? (
      <CircularProgress classes={classes} />
    ) : (
      <Paper className="mainContent">
        <div className={styles.formWrapper}>
          <AdminProfileForm
            info={this.props.centralDepartmentProfile}
            isEditing={this.state.isEditing}
            submitForm={this.submitForm}
            changeMode={this.changeMode}
            clearDataHandler={this.props.clearCentralDepartmentInfo}
            editMode
            errorState={errorStateProfile}
            form="editCentralDepartmentAdmin"
          />
          <ActivityTable columns={activityHistoryColumns} data={this.props.activityHistoryData} />
        </div>
      </Paper>
    );
  }
}

const mapStateToProps = state => {
  const {
    centralDepartmentProfile: { centralDepartmentProfile, receivingProfile, submitted }
  } = state;
  return {
    centralDepartmentProfile: centralDepartmentProfile && centralDepartmentProfile.account,
    loading: receivingProfile,
    activityHistoryData: activityHistorySelector(state),
    submitted
  };
};

const mapDispatchToProps = {
  receiveCentralDepartmentProfile,
  editCentralDepartmentProfile,
  clearCentralDepartmentInfo
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(CentralDepartmentProfile);
