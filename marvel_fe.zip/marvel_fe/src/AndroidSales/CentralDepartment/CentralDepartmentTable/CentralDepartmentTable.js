// @flow
import React from "react";
import cx from "classnames";
import { Grid, Table, TableHeaderRow, Toolbar, SearchPanel } from "@devexpress/dx-react-grid-material-ui";
import { SearchState, PagingState, IntegratedPaging, IntegratedFiltering } from "@devexpress/dx-react-grid";
import { withStyles } from "@material-ui/core";
import type { BrowserHistory } from "history";
import {
  ButtonProvider,
  DateFormatProvider,
  PhoneProvider,
  TransparentButtonProvider,
  DestructiveButtonProvider,
  PersonInfoProvider
} from "../../../components/FormattedData/FormattedData";
import OutlinedButton from "../../../components/Buttons/OutlinedButton/OutlinedButton";
import GridRoot from "../../../components/TableComponents/GridRoot";
import TabsHeader from "../../../components/TableComponents/TabsHeader";
import TableContainer from "../../../components/TableComponents/TableContainer";
import PagingPanel from "../../../components/TableComponents/PagingPanel";
import SearchInput from "../../../components/SearchInput/SearchInputForIntegratedSearch";
import { columnExtensions } from "../../../constants";
import tableStyles from "./CentralDepartmentTable.module.scss";

type PropsT = {
  data: CentralDepartmentT[],
  changeTab: Function,
  activeTab: string,
  history: BrowserHistory,
  activate: Function,
  deactivate: Function,
  openModal: Function,
  tabs: TabT[],
  accountType: number
};

type StateT = {
  currentPage: number,
  pageSize: number,
  pageSizes: number[]
};

const centralDepartmentAndroidColumns = {
  "3": [
    { name: "id", title: "ID" },
    { name: "lastName", title: "Прiзвище" },
    { name: "firstName", title: "Ім'я" },
    { name: "middleName", title: "По батьковi" },
    { name: "phone", title: "Номер телефону" },
    { name: "createdBy", title: "Ким створений" },
    { name: "createdOn", title: "Коли створений" },
    { name: "profile", title: "Деталі профілю" }
  ],
  "4": [
    { name: "id", title: "ID" },
    { name: "lastName", title: "Прiзвище" },
    { name: "firstName", title: "Ім'я" },
    { name: "middleName", title: "По батьковi" },
    { name: "phone", title: "Номер телефону" },
    { name: "createdBy", title: "Ким створений" },
    { name: "createdOn", title: "Коли створений" },
    { name: "lastModifiedOn", title: "Дата деактивування" },
    { name: "lastModifiedBy", title: "Ким деактивовано" },
    { name: "comment", title: "Коментар" },
    { name: "profile", title: "Деталі профілю" }
  ],
  "5": [
    { name: "id", title: "ID" },
    { name: "lastName", title: "Прiзвище" },
    { name: "firstName", title: "Ім'я" },
    { name: "middleName", title: "По батьковi" },
    { name: "phone", title: "Номер телефону" },
    { name: "createdBy", title: "Ким створений" },
    { name: "createdOn", title: "Коли створений" },
    { name: "profile", title: "Деталі профілю" }
  ]
};

const superAdminColumns = {
  "3": [...centralDepartmentAndroidColumns[3], { name: "deactivate", title: "Деактивувати" }],
  "4": [...centralDepartmentAndroidColumns[4], { name: "activate", title: "Активувати" }],
  "5": [...centralDepartmentAndroidColumns[5]]
};

const styles = {
  customToolbar: {
    display: "flex",
    alignItems: "flex-end"
  }
};

const ToolbarRootBase = ({ classes, className, ...restProps }) => (
  <Toolbar.Root className={cx(className, classes.customToolbar)} {...restProps} />
);

const ToolbarRoot = withStyles(styles)(ToolbarRootBase);

const forValues = {
  phone: ["phone"],
  cities: ["cities"],
  createdBy: ["createdBy"],
  deactivate: ["deactivate"],
  activate: ["activate"],
  profile: ["profile"],
  lastModifiedOn: ["lastModifiedOn"],
  lastModifiedBy: ["lastModifiedBy"],
  createdOn: ["createdOn"]
};

const expandedColumnExtensions = [
  ...columnExtensions,
  { columnName: "createdBy", width: 270 },
  { columnName: "lastModifiedBy", width: 270 }
];

class CentralDepartmentTable extends React.Component<PropsT, StateT> {
  state = {
    currentPage: 0,
    pageSize: 10,
    pageSizes: [10, 25, 50]
  };

  changeCurrentPage = (currentPage: number) => this.setState({ currentPage });
  changePageSize = (pageSize: number) => this.setState({ pageSize });

  renderRow = (tableProps: any) => {
    return <tr>{tableProps.children}</tr>;
  };

  clickOnProfile = (value: any) => {
    this.props.history.push(`/sales/central-department/${value || 1}`);
  };

  renderHeaderButtons = () => (
    <OutlinedButton label="Додати менеджера ЦО" clickHandler={this.props.openModal} className={tableStyles.addButton} />
  );

  renderSearchInput = (props: any) => <SearchInput {...props} placeholder="Пошук менеджерів" />;

  render() {
    const { activeTab, changeTab, tabs, data, accountType } = this.props;
    const { currentPage, pageSize, pageSizes } = this.state;
    const columns = accountType === 1 ? superAdminColumns : centralDepartmentAndroidColumns;

    return (
      <Grid rows={data} columns={columns[activeTab]} rootComponent={GridRoot}>
        <SearchState />

        <PagingState
          currentPage={currentPage}
          onCurrentPageChange={this.changeCurrentPage}
          pageSize={pageSize}
          onPageSizeChange={this.changePageSize}
        />

        <IntegratedPaging />

        <IntegratedFiltering />
        <PhoneProvider for={forValues.phone} />

        <PersonInfoProvider for={forValues.createdBy} />

        <DestructiveButtonProvider for={forValues.deactivate} onClick={this.props.deactivate} label="Деактивувати" />

        <ButtonProvider for={forValues.activate} onClick={this.props.activate} label="Активувати" />

        <TransparentButtonProvider for={forValues.profile} onClick={this.clickOnProfile} label="Деталі профілю" />

        <DateFormatProvider for={forValues.createdOn} />

        <Table
          columnExtensions={expandedColumnExtensions}
          rowComponent={this.renderRow}
          height="auto"
          containerComponent={TableContainer}
        />

        <Toolbar rootComponent={ToolbarRoot} />
        <TableHeaderRow />

        <TabsHeader changeTab={changeTab} activeTab={activeTab} tabs={tabs || []}>
          {this.renderHeaderButtons()}
        </TabsHeader>

        <DateFormatProvider for={forValues.lastModifiedOn} />

        <PersonInfoProvider for={forValues.lastModifiedBy} />

        <SearchPanel inputComponent={this.renderSearchInput} />

        <PagingPanel pageSizes={pageSizes} noData={!data.length} />
      </Grid>
    );
  }
}

export default CentralDepartmentTable;
