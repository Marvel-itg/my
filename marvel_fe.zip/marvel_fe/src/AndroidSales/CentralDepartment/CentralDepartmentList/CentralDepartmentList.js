// @flow
import React from "react";
import { compose } from "redux";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import Paper from "@material-ui/core/Paper/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import get from "lodash/get";
import CentralDepartmentTable from "../CentralDepartmentTable/CentralDepartmentTable";
import Modal from "../../../components/Modal/Modal";
import AdminProfileForm from "../../AdminProfileForm/AdminProfileForm";
import DeactivateForm from "../../../components/DeactivateForm/DeactivateForm";
import type { BrowserHistory } from "history";
import { toolbarOptions } from "../../../constants";
import {
  activateCentralDepartment,
  deactivateCentralDepartment,
  receiveCentralDepartmentList
} from "../../../store/actions/sales/centralDepartmentList";
import {
  createCentralDepartmentManager,
  clearCentralDepartmentInfo
} from "../../../store/actions/sales/centralDepartmentProfile";
import { openModal, closeModal } from "../../../store/actions/common/modals";
import { phoneWithCode } from "../../../utils/formatValues.js";
import { classes } from "../../../helpers/spinner";
import { errorStateDeactivating, errorStateProfile } from "../../../store/selectors/sales/centralDepartment";

const tabs = Object.keys(toolbarOptions).map(keys => toolbarOptions[keys]);

type PropsT = {
  receiveCentralDepartmentList: Function,
  deactivateCentralDepartment: Function,
  activateCentralDepartment: Function,
  centralDepartmentList: CentralDepartmentT[],
  history: BrowserHistory,
  closeModal: Function,
  openModal: Function,
  loading: boolean,
  createCentralDepartmentManager: Function,
  clearCentralDepartmentInfo: Function,
  user: CurrentUserInfoT
};

type StateT = {
  value: string,
  modalBody: any,
  modalType: string,
  id: ?number
};

class CentralDepartmentList extends React.Component<PropsT, StateT> {
  state = {
    value: "3",
    modalBody: <div />,
    modalType: "",
    id: null
  };

  componentDidMount() {
    this.props.receiveCentralDepartmentList(this.state.value);
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.value !== this.state.value) {
      this.props.receiveCentralDepartmentList(this.state.value);
    }
  }

  changeTab = (event, value) => this.setState({ value });

  submitForm = values => {
    values.accountId = this.state.id;
    this.props.deactivateCentralDepartment(values);
  };

  submitNewManagerForm = values => {
    const phone = phoneWithCode(values.phone);
    const { firstName, lastName, middleName } = values;
    const normalizedValues = {
      firstName,
      lastName,
      middleName,
      phone
    };
    this.props.createCentralDepartmentManager(normalizedValues);
  };

  openModal = (type, id) => {
    switch (type) {
      case "add": {
        const modalBody = (
          <AdminProfileForm
            submitForm={this.submitNewManagerForm}
            errorState={errorStateProfile}
            clearDataHandler={this.props.clearCentralDepartmentInfo}
            formTitle="Новий  менеджер ЦО"
            form="addCentralDepartmentAdmin"
          />
        );
        this.setState({ modalBody, modalType: "", id });
        return this.props.openModal();
      }
      case "deactivate": {
        const modalBody = (
          <DeactivateForm
            submitForm={this.submitForm}
            form="DeactivateManagerTT"
            title="Деактивувати користувача?"
            textFieldLabel="Додати коментар"
            textFieldName="comment"
            submitButtonText="Деактивувати"
            cancelButtonText="Ні"
            errorState={errorStateDeactivating}
            cancelButtonHandler={this.props.closeModal}
          />
        );
        this.setState({ modalBody, modalType: "deactivate", id });
        return this.props.openModal();
      }
      default:
        return null;
    }
  };

  openAddModal = () => this.openModal("add");

  deactivateManager = id => {
    this.openModal("deactivate", id);
  };

  activateManager = id => {
    this.props.activateCentralDepartment(id);
  };

  render() {
    const { centralDepartmentList, loading, user } = this.props;
    return (
      <React.Fragment>
        <Paper square className="mainContent">
          <CentralDepartmentTable
            accountType={get(user, "accountType")}
            data={centralDepartmentList}
            activeTab={this.state.value}
            changeTab={this.changeTab}
            openModal={this.openAddModal}
            deactivate={this.deactivateManager}
            activate={this.activateManager}
            history={this.props.history}
            tabs={tabs}
          />
        </Paper>
        <Modal formName="addCentralDepartmentAdmin" type={this.state.modalType}>
          {this.state.modalBody}
        </Modal>
        {loading && <CircularProgress classes={classes} />}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    centralDepartmentReducer: { centralDepartmentList, loading, deactivating },
    centralDepartmentProfile: { creating },
    authenticationReducer: { user }
  } = state;
  return {
    centralDepartmentList,
    loading: loading || deactivating || creating,
    user
  };
};

const mapDispatchToProps = {
  receiveCentralDepartmentList,
  activateCentralDepartment,
  deactivateCentralDepartment,
  openModal,
  closeModal,
  createCentralDepartmentManager,
  clearCentralDepartmentInfo
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(CentralDepartmentList);
