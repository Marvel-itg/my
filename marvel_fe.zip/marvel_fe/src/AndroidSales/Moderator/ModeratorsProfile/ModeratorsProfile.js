// @flow
import React from "react";
import { compose } from "redux";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import { connect } from "react-redux";
import Paper from "@material-ui/core/Paper/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import AdminProfileForm from "../../AdminProfileForm/AdminProfileForm";
import ActivityTable from "../../../containers/ActivityHistoryTable/ActivityTable";
import {
  receiveModeratorProfile,
  editModerator,
  clearModeratorInfo
} from "../../../store/actions/sales/moderatorProfile";
import { errorStateProfile, activityHistorySelector } from "../../../store/selectors/sales/moderator";
import { activityHistoryColumns } from "../../../constants";
import { phoneWithCode } from "../../../utils/formatValues.js";
import { classes } from "../../../helpers/spinner";
import styles from "./ModeratorsProfile.module.scss";

type PropsT = {
  receiveModeratorProfile: Function,
  clearModeratorInfo: Function,
  moderatorProfile: ModeratorT,
  editModerator: Function,
  submitting: boolean,
  loading: boolean,
  errorMessage: string
};

type StateT = {
  isEditing: boolean
};

class ModeratorProfilePage extends React.Component<PropsT & BrowserHistory, StateT> {
  state = { isEditing: false };

  componentDidMount(): void {
    const { id } = this.props.match.params;
    if (id) {
      this.props.receiveModeratorProfile(id);
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.submitted && !prevProps.submitted) {
      this.setState({
        isEditing: false
      });
    }
  }

  changeMode = evt => {
    evt.preventDefault();
    this.setState(prevState => ({ isEditing: !prevState.isEditing }));
  };

  submitForm = data => {
    const { id } = this.props.match.params;
    const { firstName, lastName, middleName } = data;
    const phone = phoneWithCode(data.phone);
    const normalizeData = {
      accountId: id,
      firstName,
      lastName,
      middleName,
      phone
    };
    this.props.editModerator(normalizeData);
  };

  render() {
    const { loading } = this.props;
    return loading ? (
      <CircularProgress classes={classes} />
    ) : (
      <Paper className="mainContent">
        <div className={styles.formWrapper}>
          <AdminProfileForm
            info={this.props.moderatorProfile}
            isEditing={this.state.isEditing}
            submitForm={this.submitForm}
            changeMode={this.changeMode}
            clearDataHandler={this.props.clearModeratorInfo}
            errorState={errorStateProfile}
            editMode
            form="editModeratorForm"
          />
          <ActivityTable data={this.props.activityHistoryData} columns={activityHistoryColumns} />
        </div>
      </Paper>
    );
  }
}

const mapStateToProps = state => {
  const {
    moderatorProfile: { moderatorProfile, receivingProfile, submitted }
  } = state;
  return {
    moderatorProfile: moderatorProfile && moderatorProfile.account,
    activityHistoryData: activityHistorySelector(state),
    loading: receivingProfile,
    submitted
  };
};

const mapDispatchToProps = {
  receiveModeratorProfile,
  clearModeratorInfo,
  editModerator
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(ModeratorProfilePage);
