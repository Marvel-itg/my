import moment from "moment";
import {
  defaultItemsPerPage,
  bonusReportSearchOptions,
  photoTaskOptions,
  consultantsOptions,
  candidatesOptions,
  iosManagersOptions,
  supervisorsOptions,
  generalReportOptions,
  changesReportOptions,
  effectiveTimeReportOptions,
  ordersSearchOptions,
  offlineUsersOptions,
  listOfSalesUsersOptions,
  complimentsSearchOptions
} from "./constants";
// IOS promoters

const promoters = { path: "promoters", panelName: "Додаток для промоутерів" };
const team = { name: "team", menuItem: "Команда" };
const questionnaireReports = { name: "questionnaireReports", route: "reports", menuItem: "Звіти по анкетам" };
const reports = { name: "reports", menuItem: "Звіти" };
const centralDepartmentManagers = {
  name: "centralDepartmentManagers",
  route: "central-department-managers",
  menuItem: "Менеджери ЦО",
  defaultURLQuery: () => `?page=1&count=${defaultItemsPerPage}&tab=3&searchField=${iosManagersOptions[0].value}`
};
const regionManagers = {
  name: "regionManagers",
  route: "region-managers",
  menuItem: "Регіональні менеджери",
  defaultURLQuery: () => `?page=1&count=${defaultItemsPerPage}&tab=3&searchField=${iosManagersOptions[0].value}`
};
const supervisors = {
  name: "supervisors",
  route: "supervisors",
  menuItem: "Супервайзери",
  defaultURLQuery: () => `?page=1&count=${defaultItemsPerPage}&tab=3&searchField=${supervisorsOptions[0].value}`
};
const consultants = {
  name: "consultants",
  route: "consultants",
  menuItem: "Консультанти",
  defaultURLQuery: () => `?page=1&count=${defaultItemsPerPage}&tab=3&searchField=${consultantsOptions[0].value}`
};
const candidates = {
  name: "candidates",
  route: "candidates",
  menuItem: "Кандидати",
  defaultURLQuery: () => `?page=1&count=${defaultItemsPerPage}&tab=1&searchField=${candidatesOptions[0].value}`
};
// const status = { name: "status", route: "status", menuItem: "Статус" };
const shifts = {
  name: "shifts",
  route: "shifts",
  menuItem: "Маршрути",
  defaultURLQuery: () =>
    `?page=1&count=${defaultItemsPerPage}&tab=1&start=${moment()
      .subtract(3, "d")
      .format("DD/MM/YYYY")}&end=${moment()
      .endOf("day")
      .format("DD/MM/YYYY")}`
};
const materials = {
  name: "materials",
  route: "materials",
  menuItem: "Матеріали",
  defaultURLQuery: () => `?page=1&count=${defaultItemsPerPage}&tab=1`
};
const generalReport = {
  name: "generalReport",
  route: "general-report",
  menuItem: "Загальний звіт",
  //eslint-disable-next-line
  defaultURLQuery: () =>
    `?page=1&count=${defaultItemsPerPage}&start=${moment()
      .subtract(7, "d")
      .format("DD/MM/YYYY")}&end=${moment()
      .endOf("day")
      .format("DD/MM/YYYY")}&searchField=${generalReportOptions[0].value}`
};
// const brandsReport = { name: "brandsReport", route: "brands-report", menuItem: "Звіт по брендам" };
// const posReport = { name: "posReport", route: "pos-report", menuItem: "Звіт по TT" };
// const workspaceReport = { name: "workspaceReport", route: "workspace-report", menuItem: "Твоє робоче місце" };
const timeReport = {
  name: "timeReport",
  route: "time-report",
  menuItem: "Звіт ефективного часу",
  //eslint-disable-next-line
  defaultURLQuery: () =>
    `?page=1&count=${defaultItemsPerPage}&start=${moment()
      .subtract(7, "d")
      .format("DD/MM/YYYY")}&end=${moment()
      .endOf("day")
      .format("DD/MM/YYYY")}&searchField=${effectiveTimeReportOptions[0].value}`
};

const changesReport = {
  name: "changesReport",
  route: "changes-report",
  menuItem: "Звіт по змінам змін",
  //eslint-disable-next-line
  defaultURLQuery: () =>
    `?page=1&count=${defaultItemsPerPage}&start=${moment()
      .subtract(1, "months")
      .format("DD/MM/YYYY")}&end=${moment()
      .endOf("day")
      .format("DD/MM/YYYY")}&searchField=${changesReportOptions[0].value}`
};
// const consultantsReport =
// { name: "consultantsReport", route: "consultants-report", menuItem: "Звіт по консультантам" };
const questionnaire = {
  name: "questionnaire",
  route: "questionnaire",
  menuItem: "Анкетування",
  defaultURLQuery: () => `?page=1&count=${defaultItemsPerPage}&tab=1`
};
// const importData = { name: "importData", route: "importData", menuItem: "Імпортувати файли" };

// Sales
const sales = { path: "sales", panelName: "Додаток для продавців" };

const manageSalesAdmin = { name: "manageSalesAdmins", route: "manage-admins", menuItem: "Список адмінів" };
const listOfSalesUsers = {
  name: "listOfSalesUsers",
  route: "list-of-users",
  menuItem: "Список користувачів"
};
const listOfOnlineUsers = {
  name: "listOfOnlineUsers",
  route: "list-of-online-users",
  menuItem: "Онлайн продавці",
  defaultURLQuery: () => `?page=1&count=${defaultItemsPerPage}&tab=3&searchField=${listOfSalesUsersOptions[0].value}`
};
const listOfOfflineUsers = {
  name: "listOfOfflineUsers",
  route: "list-of-offline-users",
  menuItem: "Оффлайн продавці",
  //eslint-disable-next-line
  defaultURLQuery: () =>
    `?page=1&count=${defaultItemsPerPage}&start=${moment()
      .subtract(1, "months")
      .startOf("day")
      .format("DD/MM/YYYY")}&end=${moment()
      .endOf("day")
      .format("DD/MM/YYYY")}&searchField=${offlineUsersOptions[0].value}`
};
const centralDepartment = {
  name: "centralDepartment",
  route: "central-department",
  menuItem: "Центральний департамент"
};
const tradeProgramsManagers = {
  name: "tradeProgramsManagers",
  route: "trade-programs-managers",
  menuItem: "Менеджер торговельних програм"
};
const superAdmins = {
  name: "superAdmins",
  route: "super-admins",
  menuItem: "Супер адміни"
};
const orders = { name: "orders", route: "orders", menuItem: "Замовлення" };
const listOfOrders = {
  name: "listOfOrders",
  route: "list-of-orders",
  menuItem: "Список замовлень",
  defaultURLQuery: () =>
    `?page=1&count=${defaultItemsPerPage}&start=${moment()
      .subtract(1, "months")
      .startOf("day")
      .format("DD/MM/YYYY")}&end=${moment()
      .endOf("day")
      .format("DD/MM/YYYY")}&searchField=${ordersSearchOptions[0].value}` // eslint-disable-line
};
const manageOrders = { name: "manageOrders", route: "manage-orders", menuItem: "Керування відвантаженням" };
const chargeBonusesForOrders = {
  name: "manageBonuses",
  route: "manage-bonuses",
  menuItem: "Керування балами за замовлення"
};
// const actualPrices = { name: "actualPrices", route: "actual-prices", menuItem: "Актуальні ціни" };
const tasks = { name: "tasks", route: "tasks", menuItem: "Завдання" };
const listOfTasks = { name: "listOfTasks", route: "list-of-tasks", menuItem: "Список завдань" };
const uploadScanCodes = { name: "uploadScanCodes", route: "upload-scan-codes", menuItem: "Завантаження кодів" };
const generateScanCodes = {
  name: "generateScanCodes",
  route: "generate-scan-codes",
  menuItem: "Генерування кодів",
  defaultURLQuery: () =>
    `?page=1&count=${defaultItemsPerPage}&start=${moment()
      .subtract(1, "months")
      .startOf("day")
      .format("DD/MM/YYYY")}&end=${moment()
      .endOf("day")
      .format("DD/MM/YYYY")}` // eslint-disable-line
};
const compliments = {
  name: "compliments",
  route: "compliments",
  menuItem: "Компліменти"
};
const uploadCompliments = {
  name: "uploadCompliments",
  route: "upload-compliments",
  menuItem: "Оновлення статистики компліментів",
  defaultURLQuery: () => `?page=1&count=${defaultItemsPerPage}&tab=3&searchField=${complimentsSearchOptions[0].value}`
};

const midPlusProgress = {
  name: "midPlusProgress",
  route: "mid-plus-progress",
  menuItem: "Оновлення прогресу завдання MID+"
};
// const detailsByTasks = { name: "detailsByTasks", route: "details-by-tasks", menuItem: "Деталі по завданням" };
const exchangeRequests = {
  name: "exchangeRequest",
  route: "exchange-requests",
  menuItem: "Обмін балів"
};

const exchangeRequestsPhone = {
  name: "exchangeRequestsPhone",
  route: "exchange-requests-phone",
  menuItem: "Поповнення рахунку",
  defaultURLQuery: () =>
    `?page=1&count=${defaultItemsPerPage}&tab=1&start=${moment()
      .subtract(1, "months")
      .startOf("day")
      .format("DD/MM/YYYY")}&end=${moment()
      .endOf("day")
      .format("DD/MM/YYYY")}`
};
const certificates = {
  name: "certificates",
  route: "certificates",
  menuItem: "Подарункові сертифікати",
  defaultURLQuery: () => `?page=1&count=${defaultItemsPerPage}&tab=1`
};

const getCertificates = {
  name: "getCertificates",
  route: "get-certificates",
  menuItem: "Отримання нових сертифікатів",
  defaultURLQuery: () =>
    `?page=1&count=${defaultItemsPerPage}&start=${moment()
      .subtract(1, "months")
      .startOf("day")
      .format("DD/MM/YYYY")}&end=${moment()
      .endOf("day")
      .format("DD/MM/YYYY")}`
};
const exchangeToGiftRequests = {
  name: "exchangeToGiftRequests",
  route: "exchange-to-gift-requests",
  menuItem: "Обмін на подарунок",
  defaultURLQuery: () =>
    `?page=1&count=${defaultItemsPerPage}&tab=1&start=${moment()
      .subtract(1, "months")
      .startOf("day")
      .format("DD/MM/YYYY")}&end=${moment()
      .endOf("day")
      .format("DD/MM/YYYY")}`
};
const photoTask = {
  name: "photoTask",
  route: "photo-task",
  menuItem: "Перевірка завдання Фото",
  //eslint-disable-next-line
  defaultURLQuery: () =>
    `?page=1&count=${defaultItemsPerPage}&tab=1&start=${moment()
      .subtract(1, "months")
      .startOf("day")
      .format("DD/MM/YYYY")}&end=${moment()
      .endOf("day")
      .format("DD/MM/YYYY")}&searchField=${photoTaskOptions[0].value}`
};
const inbox = {
  name: "inbox",
  route: "inbox",
  menuItem: "Гаряча лінія",
  defaultURLQuery: () => `?page=1&count=${defaultItemsPerPage}&tab=1`
};
// const userInformation = {
//   name: "userInformation",
//   route: "user-information",
//   menuItem: "Інформація про користувачів"
// };
const bonusesReports = {
  name: "bonusesReports",
  menuItem: "Інформація про бали",
  route: "bonus-reports",
  //eslint-disable-next-line
  defaultURLQuery: () =>
    `?page=1&count=${defaultItemsPerPage}&start=${moment()
      .subtract(1, "months")
      .startOf("day")
      .format("DD/MM/YYYY")}&end=${moment()
      .endOf("day")
      .format("DD/MM/YYYY")}&searchField=${bonusReportSearchOptions[0].value}`
};
const statisticOfTasks = {
  name: "statisticOfTasks",
  route: "statistic-of-tasks",
  menuItem: "Статистика по завданням",
  //eslint-disable-next-line
  defaultURLQuery: () =>
    `?page=1&count=${defaultItemsPerPage}&start=${moment()
      .subtract(1, "months")
      .startOf("day")
      .format("DD/MM/YYYY")}&end=${moment()
      .endOf("day")
      .format("DD/MM/YYYY")}`
};

const complimentsReport = {
  name: "complimentsReport",
  menuItem: "Звіт по Компліментам",
  route: "compliments-report",
  //eslint-disable-next-line
  defaultURLQuery: () =>
    `?page=1&count=${defaultItemsPerPage}&start=${moment()
      .subtract(1, "months")
      .startOf("day")
      .format("DD/MM/YYYY")}&end=${moment()
      .endOf("day")
      .format("DD/MM/YYYY")}`
};
const analytics = { name: "analytics", route: "analytics", menuItem: "Аналітика" };
const brands = { name: "brands", route: "brands", menuItem: "Наші бренди" };
const brandsSettings = { name: "brandsSettings", route: "brands-settings", menuItem: "Налаштування Про Бренди" };
const advertising = { name: "advertising", route: "advertising", menuItem: "Рекламна акція" };
// const aboutCompany = { name: "aboutCompany", route: "aboutCompany", menuItem: "Про компанію" };

const superAdminConfig = {
  promoters: {
    ...promoters,
    items: [
      {
        ...team,
        subMenu: [
          { ...centralDepartmentManagers },
          { ...regionManagers },
          { ...supervisors },
          { ...consultants },
          { ...candidates }
          // { ...status }
        ]
      },
      { ...shifts },
      { ...materials },
      {
        ...reports,
        subMenu: [
          { ...generalReport },
          // { ...brandsReport },
          // { ...posReport },
          { ...timeReport },
          { ...changesReport }
          // { ...consultantsReport },
        ]
      },
      {
        ...questionnaireReports,
        subMenu: []
      },
      { ...questionnaire }
      // { ...importData}
    ]
  },
  sales: {
    ...sales,
    items: [
      {
        ...listOfSalesUsers,
        subMenu: [{ ...listOfOnlineUsers }, { ...listOfOfflineUsers }]
      },
      {
        ...manageSalesAdmin,
        subMenu: [{ ...superAdmins }, { ...tradeProgramsManagers }]
      },
      { ...orders, subMenu: [{ ...listOfOrders }, { ...manageOrders }, { ...chargeBonusesForOrders }] },
      /* { ...actualPrices}, */
      {
        ...tasks,
        subMenu: [
          { ...listOfTasks },
          { ...photoTask },
          { ...uploadScanCodes },
          { ...generateScanCodes },
          { ...midPlusProgress }
          // { ...detailsByTasks }
        ]
      },

      {
        ...compliments,
        subMenu: [{ ...uploadCompliments }]
      },

      {
        ...exchangeRequests,
        subMenu: [
          { ...certificates },
          { ...getCertificates },
          { ...exchangeRequestsPhone },
          { ...exchangeToGiftRequests }
        ]
      },

      { ...inbox },
      {
        ...analytics,
        subMenu: [/*{ ...userInformation }*/ { ...bonusesReports }, { ...statisticOfTasks }, { ...complimentsReport }]
      },
      {
        ...brands,
        subMenu: [{ ...brandsSettings }]
      },
      { ...advertising }
    ]
  }
};

const centralDepartmentIOSConfig = {
  promoters: {
    ...promoters,
    items: [
      {
        ...team,
        subMenu: [
          { ...regionManagers },
          { ...supervisors },
          { ...consultants },
          { ...candidates }
          // { ...status }
        ]
      },
      { ...shifts },
      { ...materials },
      {
        ...reports,
        subMenu: [
          { ...generalReport },
          // { ...brandsReport },
          // { ...posReport },
          { ...timeReport },
          { ...changesReport }
          // { ...consultantsReport },
        ]
      },
      {
        ...questionnaireReports,
        subMenu: []
      },
      { ...questionnaire }
      // { ...importData }
    ]
  }
};

const regionalManagerIOSConfig = {
  promoters: {
    ...promoters,
    items: [
      {
        ...team,
        subMenu: [
          { ...supervisors },
          { ...consultants },
          { ...candidates }
          // { ...status }
        ]
      },
      { ...shifts },
      { ...materials },
      {
        ...reports,
        subMenu: [
          { ...generalReport },
          // { ...brandsReport },
          // { ...posReport },
          { ...timeReport },
          { ...changesReport }
          // { ...consultantsReport },
        ]
      },
      {
        ...questionnaireReports,
        subMenu: []
      }
      // { ...importData }
    ]
  }
};

const supervisorIOSConfig = {
  promoters: {
    ...promoters,
    items: [
      {
        ...team,
        subMenu: [
          { ...consultants },
          { ...candidates }
          // { ...status }
        ]
      },
      { ...shifts },
      { ...materials },
      {
        ...reports,
        subMenu: [
          { ...generalReport },
          // { ...brandsReport },
          // { ...posReport },
          { ...timeReport },
          { ...changesReport }
          // { ...consultantsReport },
        ]
      },
      {
        ...questionnaireReports,
        subMenu: []
      }
      // {...importData}
    ]
  }
};

const centralDepartmentAndroidConfig = {
  sales: {
    ...sales,
    items: [
      {
        ...listOfSalesUsers,
        subMenu: [{ ...listOfOnlineUsers }, { ...listOfOfflineUsers }]
      },
      {
        ...manageSalesAdmin,
        subMenu: [{ ...centralDepartment }, { ...tradeProgramsManagers }]
      },
      { ...orders, subMenu: [{ ...listOfOrders }, { ...manageOrders }] },
      {
        ...tasks,
        subMenu: [
          { ...listOfTasks },
          { ...photoTask }
          //  { ...detailsByTasks }
        ]
      },
      { ...exchangeRequests, subMenu: [{ ...exchangeRequestsPhone }, { ...exchangeToGiftRequests }] },
      // temporarily hidden MRVL-1852
      /* {...actualPrices }, */
      { ...inbox },
      {
        ...analytics,
        subMenu: [/*{ ...userInformation }*/ { ...bonusesReports }, { ...statisticOfTasks }]
      },
      { ...brands, subMenu: [] }
      // { ...aboutCompany }
    ]
  }
};

const tradeProgramManagerAndroidConfig = {
  sales: {
    ...sales,
    items: [
      {
        ...listOfSalesUsers,
        subMenu: [{ ...listOfOnlineUsers }, { ...listOfOfflineUsers }]
      },
      { ...tasks, subMenu: [{ ...listOfTasks }, { ...photoTask }] },
      {
        ...compliments,
        subMenu: [{ ...uploadCompliments }]
      },
      { ...exchangeRequests, subMenu: [{ ...exchangeRequestsPhone }, { ...exchangeToGiftRequests }] },
      { ...inbox },
      {
        ...analytics,
        subMenu: [/*{ ...userInformation }*/ { ...bonusesReports }, { ...statisticOfTasks }, { ...complimentsReport }]
      },
      {
        ...brands,
        subMenu: []
      }
      // { ...aboutCompany }
    ]
  }
};

const moderatorAndroidConfig = {
  sales: {
    ...sales,
    items: [
      {
        ...listOfSalesUsers,
        subMenu: [{ ...listOfOnlineUsers }, { ...listOfOfflineUsers }]
      },
      // { ...tasks, subMenu: [{ ...photoTask }] },
      { ...inbox },
      { ...brands, subMenu: [] }
      // { ...aboutCompany }
    ]
  }
};

export const menuConfigByRoles = {
  "1": superAdminConfig,
  "2": centralDepartmentAndroidConfig,
  "3": tradeProgramManagerAndroidConfig,
  "4": moderatorAndroidConfig,
  "5": centralDepartmentIOSConfig,
  "6": regionalManagerIOSConfig,
  "7": supervisorIOSConfig,
  "8": {},
  "9": {},
  "10": {}
};
