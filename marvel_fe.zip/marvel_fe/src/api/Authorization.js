import axios from "./axiosConfig";

export function loginUser(data) {
  return axios.post("/Authorization", data);
}

export function renewToken(refreshToken) {
  return axios.post("/Authorization/RefreshToken", {
    refreshToken
  });
}

export function getUserInfo() {
  return axios.get("/AccountInfo/current");
}
