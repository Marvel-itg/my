import axios from "./axiosConfig";

export function getQuestionnaires() {
  return axios.get("Questionnaire");
}
