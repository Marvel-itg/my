import axios from "../axiosConfig";

export const imageUploadUrl = "Brands/Image";

export const getBrandsWithLines = () => axios.get("/Brands/WithLines");

export const postBrandsImage = file => axios.post("/Brands/Image", file);

export const postBrandsHtml = file => axios.post("/Brands/Html", file);

export const postProductLinesHtml = file => axios.post("/ProductLines/Html", file);

export const postBrands = data => axios.post("/Brands", data);
