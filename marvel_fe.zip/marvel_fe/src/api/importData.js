import axios from "./axiosConfig";

export function uploadExportFile(file) {
  const data = new FormData();
  data.append("file", file, file.name);
  return axios.post("/DataImport", data);
}
