import axios from "../axiosConfig";
import { downloadCsvFile } from "../../helpers/common";

export function fetchExchangeRequestsPhone(params) {
  return axios.post("/ExchangeRequests/Phone", params);
}

export function fetchExchangeRequestsGift(params) {
  return axios.post("/ExchangeRequests/Gift", params);
}

export async function exportToCSV(data, requestType) {
  const res = await axios({
    method: "post",
    url: `/ExchangeRequests/${requestType}`,
    responseType: "arraybuffer",
    data
  });

  downloadCsvFile(res, "export.csv");

  return res;
}

export function importCSVPhone(data) {
  return axios.post("ExchangeRequests/importPhoneRequests", data);
}
