import axios from "../axiosConfig";

export function uploadCompliments(data) {
  return axios.post("/Bonus/ComplimentActivity/upload", data);
}

export function getCompliments(params) {
  return axios.get("/Bonus/ComplimentActivity", { params });
}

export function getComplimentDetails(posCode) {
  return axios.get(`/Bonus/ComplimentActivity/${posCode}`);
}
