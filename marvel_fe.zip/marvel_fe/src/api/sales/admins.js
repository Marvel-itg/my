import axios from "../axiosConfig";

export function getAdminsList(status, adminType) {
  return axios.get(`/${adminType}/Status/${status}`);
}

export function getSuperAdminsList() {
  return axios.get("/AccountInfo/superadmins", { superadmins: [] });
}

export function blockAdmin(id) {
  return axios.post("/Admins/block", { id });
}

export function getAdminById(id, adminType) {
  return axios.get(`/${adminType}/${id}`);
}

export function registerAdmin(data, adminType) {
  return axios.post(`/${adminType}/Register`, data);
}

export function deactivateAdmin(data, adminType) {
  return axios.post(`/${adminType}/Deactivate`, data);
}

export function activateAdmin(data, adminType) {
  return axios.put(`/${adminType}/ChangeStatus`, {
    accountId: data,
    status: 3
  });
}

export function editAdmin(data, adminType) {
  return axios.put(`/${adminType}`, data);
}
