import axios from "../axiosConfig";

export function getManageBonusesData(type) {
  return axios.get(`/Bonus/${type}`);
}

export function setManageBonusesData(params) {
  return axios.post("/Bonus/Setup", params);
}

export function exportPosCodes() {
  return axios.get("/PointOfSales/ExportRewardedPointsOfSale");
}

export function exportToCSV() {
  return axios.get("/PointOfSales/ExportRewardedPointsOfSale");
}
