import axios from "../axiosConfig";

export function getAdvertising() {
  return axios.get("/Advertising");
}

export function createAdvertising(params) {
  return axios.post("/Advertising", params);
}

export function updateAdvertising(params) {
  return axios.post("/Advertising", params);
}

export function changeAdvertisingStatus(params) {
  return axios.put("/Advertising/changeState", params);
}
