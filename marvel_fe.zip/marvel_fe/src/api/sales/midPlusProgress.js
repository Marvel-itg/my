import axios from "../axiosConfig";

export function uploadMidPlusProgress(data) {
  return axios.post("/TaskTemplates/MidPlus/Progresses/Csv", data);
}

export function downloadMidPlusProgress() {
  return axios.get("/TaskTemplates/MidPlus/Progresses/Csv");
}
