import axios from "../axiosConfig";

export function answerInbox(data) {
  return axios.post("/Requests/AddAnswer", data);
}

export function fetchRequests(state, { page, count }) {
  return axios.get(`/Requests/ByState/${state}`, {
    params: {
      page,
      count
    }
  });
}
