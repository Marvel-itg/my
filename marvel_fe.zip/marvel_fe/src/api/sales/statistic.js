import axios from "../axiosConfig";

export function fetchRequests({ PageNumber, ItemsOnPage, SearchFieldName, SearchValue }) {
  return axios.get("Report/taskReports/", {
    params: {
      PageNumber,
      ItemsOnPage,
      SearchFieldName,
      SearchValue
    }
  });
}
