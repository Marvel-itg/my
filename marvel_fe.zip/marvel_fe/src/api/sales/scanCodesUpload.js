import axios from "../axiosConfig";

export function saveScanCodes(data) {
  return axios.post("/TaskTemplates/UploadScanCodes", data);
}
