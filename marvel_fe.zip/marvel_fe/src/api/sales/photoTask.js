import axios from "../axiosConfig";
import { downloadCsvFile } from "../../helpers/common";

export function getPhotoTasks(params) {
  return axios.post("/TaskPhoto/GetByFilter", params);
}

export function getPhotoTasksById(id) {
  return axios.get(`/TaskPhoto/${id}`);
}

export function changePhotoTaskStatus(params) {
  return axios.put("/TaskPhoto", params);
}

export async function exportToCSV(data) {
  const res = await axios({
    method: "post",
    url: "/TaskPhoto/exportTaskPhotos",
    responseType: "arraybuffer",
    data
  });

  downloadCsvFile(res, "export.csv");

  return res;
}
