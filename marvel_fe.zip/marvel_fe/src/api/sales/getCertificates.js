import axios from "../axiosConfig";

export function fetchCertificatesStatuses(params) {
  return axios.get("/Bonus/Certificate/Synchronizations", { params });
}

export function getNewCertificates(issuerId) {
  return axios.post(`/Bonus/Certificate/Synchronize/${issuerId}`);
}
