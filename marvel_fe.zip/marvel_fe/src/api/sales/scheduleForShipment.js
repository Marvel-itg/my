import axios from "../axiosConfig";
import { downloadCsvFile } from "../../helpers/common";

export async function exportScheduleShipment() {
  const res = await axios({
    method: "post",
    url: "/ScheduleShipment/Export",
    responseType: "arraybuffer"
  });

  downloadCsvFile(res, "scheduleForShipment.csv");
  return res;
}

export function importScheduleShipment(data) {
  return axios.post("/ScheduleShipment/Import", data);
}
