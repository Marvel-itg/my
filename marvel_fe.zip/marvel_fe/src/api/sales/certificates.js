import axios from "../axiosConfig";
import { downloadCsvFile } from "../../helpers/common";

export function fetchCertificates(params) {
  return axios.post("/Bonus/Certificate/GetByFilter", params);
}

export async function downloadCertificates(issuerId) {
  const res = await axios({
    method: "get",
    url: `/Bonus/Certificate/Download/${issuerId}`,
    responseType: "arraybuffer"
  });

  downloadCsvFile(res, "certificates.csv");

  return res;
}

export function getIssuers() {
  return axios.get("/Bonus/Certificate/GetIssuers");
}

export function getAccountIds() {
  return axios.get("/Sales/GetActiveSellerIds");
}

export function assignCertificate(data) {
  return axios.post("/Bonus/Certificate/Assign", data);
}

export function getCertificateDetails(id) {
  return axios.get(`/Bonus/Certificate/Details/${id}`);
}
