import axios from "../axiosConfig";

export function addUser(data) {
  return axios.post("/Sales/Register", data);
}

export function getUsers(params) {
  return axios.get("/Sales/GetByFilter", { params });
}

export function getUserById(id) {
  return axios.get(`/Sales/${id}`);
}

export function changeUserStatus({ id, status, comment }) {
  return axios.put("/Sales/ChangeStatus", { accountId: id, status, comment });
}

export function chargingBonuses(data) {
  return axios.post("/Bonus/importAdditionalBonuses", data);
}

export function bulkDeactivation(data) {
  return axios.post("/Sales/deactivate", data);
}

export function editUserSales(params) {
  return axios.put("/Sales/editInfo", params);
}

export function forceLogoutUsers() {
  return axios.post("/Sales/forceLogout", { userListIds: [] });
}

export function exportUsersReport() {
  return axios.get("/Sales/OnlineSellerReport");
}
