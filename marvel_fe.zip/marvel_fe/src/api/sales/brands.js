import axios from "../axiosConfig";

export function fetchBrands() {
  return axios.get("/Brands");
}
export function fetchBrandsFullInfo() {
  return axios.get("/Brands/FullInfo");
}

export function getSectionsByBrand(id) {
  return axios.get(`/Products/Sections/ByBrand/${id}`);
}

export function getPackFormats() {
  return axios.get("/PackFormat");
}

export function getFilterTypes() {
  return axios.get("/FilterTypes");
}

export function getProductTypes() {
  return axios.get("/ProductTypes");
}

export function createProduct(data) {
  return axios.post("/Products", data);
}

export function editProduct(data) {
  return axios.put("/Products", data);
}

export function deleteProduct(id) {
  return axios.delete(`/Products/${id}`);
}

export function createProductSection(data) {
  return axios.post("/Products/Sections/Add", data);
}

export function editProductSection(data) {
  return axios.put("/Products/Sections/Update", data);
}

export function deactivateProductSection(data) {
  return axios.put("/Products/Sections/Deactivate", data);
}

export function reorderProductSection(data) {
  return axios.put("/Products/Sections/Reorder", data);
}
