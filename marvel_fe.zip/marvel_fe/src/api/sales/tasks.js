import axios from "../axiosConfig";

const taskNamesConfig = {
  "1": "Order",
  "2": "Foil",
  "3": "Test",
  "4": "Info",
  "5": "Questionnaire",
  "6": "Photo",
  "7": "Feedback",
  "8": "Scan",
  "9": "MidPlus"
};

export function getTasks(status, params) {
  return axios.get(`/TaskTemplates/ByStatus/${status}`, { params });
}

export function getTaskDataById(id, taskType) {
  return axios.get(`/TaskTemplates/${taskNamesConfig[taskType]}/${id}`);
}

export function createNewTask(data, taskType) {
  return axios.post(`/TaskTemplates/${taskNamesConfig[taskType]}`, data);
}

export function editTask(data, taskType) {
  return axios.put(`/TaskTemplates/${taskNamesConfig[taskType]}`, data);
}

export function deleteTask(id) {
  return axios.delete(`/TaskTemplates/${id}`);
}

export function changeTaskState(data) {
  return axios.put("/TaskTemplates/ChangeState", data);
}
