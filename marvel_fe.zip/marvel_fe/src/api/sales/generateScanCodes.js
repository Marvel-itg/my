import axios from "../axiosConfig";

export function getScanCodesList(params) {
  return axios.get("/ScanCodeArchives", { params });
}

export async function downloadScanCodesZip(id) {
  const res = await axios({
    method: "get",
    url: `/ScanCodeArchives/${id}/archive`,
    responseType: "arraybuffer"
  });

  return res;
}

export function generateScanCodes(data) {
  return axios.post("/ScanCodeArchives", data);
}
