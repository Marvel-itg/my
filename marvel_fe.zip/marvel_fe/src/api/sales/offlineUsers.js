import axios from "../axiosConfig";
import { downloadCsvFile } from "../../helpers/common";

export function getOfflineUsersList(params) {
  return axios.post("/OfflineUsers/GetByFilter", params);
}

export async function exportOfflineUsers(data) {
  const res = await axios({
    method: "post",
    url: "/OfflineUsers/exportTransactions",
    responseType: "arraybuffer",
    data
  });

  downloadCsvFile(res, "offlineUsers.csv");
  return res;
}

export function importOfflineUsersCSV(data) {
  return axios.post("/OfflineUsers/importTransactions", data);
}
