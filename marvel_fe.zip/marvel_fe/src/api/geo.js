import axios from "./axiosConfig";

export const getCities = role => startsWith => {
  const string = encodeURIComponent(startsWith);
  return axios.get(`/${role}/AvailableGeos/${string}`);
};

export const getRegions = () => {
  return axios.get("/RegionalManagerIOS/AvailableGeos/");
};

export const getSpecifiedCities = (geoType = 5) => startsWith => {
  const string = encodeURIComponent(startsWith);
  return axios.get(`/Geo/GetSpecifiedFilteredGeos/${geoType}/${string}`);
};
