import axios from "./axiosConfig";

export function uploadImage(image, uploadUrl) {
  if (!uploadUrl) {
    return axios.post("/Images", image);
  }
  return axios.post(`/${uploadUrl}`, image);
}

export function deleteImage(imageId) {
  return axios.delete("/Images", { data: { imageId } });
}

export function deleteMaterial(fileId) {
  return axios.delete(`/Material/${fileId}`);
}

export function uploadPosCodes(image) {
  return axios.post("/Files/PosCodes", image);
}

export function uploadPosCodesWithAmount(image) {
  return axios.post("/Files/PosCodesWithAmount", image);
}

export function uploadPosFoil(image) {
  return axios.post("/Files/FoilPosPlan", image);
}

export function uploadPosPlan(image) {
  return axios.post("/Files/PosPlan", image);
}

export function uploadScanCodes(image) {
  return axios.post("/Files/ScanCodes", image);
}

export function uploadPosMidPlus(image) {
  return axios.post("/Files/Order/MidPlus/PosPlan", image);
}

export function uploadMaterials(file) {
  return axios.post("/Material/Upload", file);
}

export function uploadPosCodesForManageBonuses(file) {
  return axios.post("/PointOfSales/ImportRewardedPointsOfSale", file);
}

export function uploadAdvertisingContent(file) {
  return axios.post("/Advertising/content", file);
}

export function deleteAdvertisingContent(imageId) {
  return axios.delete("/Advertising/content", { data: { imageId } });
}
