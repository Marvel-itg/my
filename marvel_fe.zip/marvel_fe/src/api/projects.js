import axios from "./axiosConfig";

export function getProjects() {
  return axios.get("Projects");
}
