import axios from "../axiosConfig";
import { downloadCsvFile } from "../../helpers/common";

export const getPosCodesByGeoId = geoId => codeStartsWith => {
  return axios.post("/PointOfSales/ByFilter", {
    codeStartsWith,
    geoId
  });
};

export const getConsultantsByGeoId = geoId => startsWith => {
  const string = encodeURIComponent(startsWith);
  return axios.get(`/Consultants/ByCurrentChiefAndGeoId/${geoId}/${string}`);
};

export const getConsultantsByFilter = params => {
  return axios.post("/Consultants/GetByConsultantFilter/", params);
};

export const createShift = data => {
  return axios.post("/Shift", data);
};

export const editShift = data => {
  return axios.put("/Shift", data);
};

export const cancelShift = data => {
  return axios.put("/Shift/Cancel", data);
};

export const getShiftById = id => {
  return axios.get(`/Shift/${id}`);
};

export const fetchShifts = params => {
  return axios.post("/Shift/GetByFilter/", params);
};

export const getCityById = id => {
  return axios.get(`/Geo/GetCity/${id}`);
};

export const getAllRegions = () => {
  return axios.get("/Geo/Regions");
};

export const getConsultantById = id => {
  return axios.get(`/Accounts/${id}`);
};

export const getPlannedShiftsTime = params => {
  return axios.post("/Shift/GetPlannedHours", params);
};

export async function exportShiftsToCSV(data, requestType) {
  const res = await axios({
    method: "post",
    url: "/Shift/ExportByFilter",
    responseType: "arraybuffer",
    data
  });

  downloadCsvFile(res, "export.csv");

  return res;
}
