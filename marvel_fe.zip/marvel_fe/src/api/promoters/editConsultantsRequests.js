import axios from "../axiosConfig";

export function getEditRequestsList(params) {
  return axios.post("/ConsultantUpdateProfile/GetByFilter", params);
}

export function getEditRequestById(id) {
  return axios.get(`/ConsultantUpdateProfile/${id}`);
}

export function processEditRequest(params) {
  return axios.put("/ConsultantUpdateProfile/SetProcessed", { ...params });
}
