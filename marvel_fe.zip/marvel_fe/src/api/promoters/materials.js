import axios from "../axiosConfig";

export function addMaterial(data) {
  return axios.post("/Material/Save", data);
}

export const getMaterialsRoles = () => {
  return axios.get("/Material/Roles");
};

export const getMaterialsList = params => {
  return axios.post("/Material/GetByFilter", params);
};

export const getMaterialById = id => {
  return axios.get(`/Material/${id}`);
};

export const editMaterial = data => {
  return axios.put("/Material/Edit", data);
};

export const activateMaterial = params => {
  return axios.put("/Material/Activate", params);
};

export const deactivateMaterial = id => {
  return axios.put(`/Material/Deactivate/${id}`);
};
