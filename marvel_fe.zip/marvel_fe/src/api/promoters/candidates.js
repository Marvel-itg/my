import axios from "../axiosConfig";

export function addCandidate(data) {
  return axios.post("/Consultants/Register", data);
}

export function changeCandidateStatus(data) {
  return axios.put("/Consultants/ChangeStatus", data);
}

export function getCandidateById(id) {
  return axios.get(`/Consultants/${id}`);
}

export function getCityOptions(startsWith) {
  return axios.get(`/Consultants/AvailableGeos/${startsWith}`);
}

export function exportConsultantsCSV(params) {
  return axios.get("/Consultants/ExportByFilter", {
    params: {
      ...params
    }
  });
}
