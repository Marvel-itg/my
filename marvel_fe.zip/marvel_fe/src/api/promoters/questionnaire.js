import axios from "../axiosConfig";

export function createQuestionnaire(data) {
  return axios.post("/Questionnaire", data);
}

export function editQuestionnaire(data) {
  return axios.put("/Questionnaire/Update", data);
}

export function getQuestionnaireByFilter(params) {
  return axios.post("/Questionnaire/GetByFilter", params);
}

export function getQuestionnaireById(id) {
  return axios.get(`/Questionnaire/ByTemplateId/${id}`);
}

export function changeQuestionnaireStatus(data) {
  return axios.put("/Questionnaire/ChangeStatus", data);
}

export function activateWithNewDates(data) {
  return axios.put("/Questionnaire/ActivateWithNewDates", data);
}

export function validateDates(data) {
  return axios.post("/Questionnaire/ValidateDatesByStatus", data);
}
