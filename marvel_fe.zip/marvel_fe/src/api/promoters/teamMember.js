import axios from "../axiosConfig";

export function registerTeamMember(data, teamMemberType) {
  return axios.post(`/${teamMemberType}/Register`, data);
}

export function fetchTeamMembersList(params, teamMemberType) {
  return axios.get(`/${teamMemberType}/GetByFilter`, {
    params
  });
}

export function replacingAccounts(teamMemberType, params) {
  return axios.get(`/${teamMemberType}/ReplacingAccounts`, {
    params
  });
}

export function deactivateTeamMember(data, teamMemberType) {
  return axios.post(`/${teamMemberType}/Deactivate`, data);
}

export function activateTeamMember(data, teamMemberType) {
  return axios.put(`/${teamMemberType}/ChangeStatus`, {
    accountId: data,
    status: 3
  });
}

export function getTeamMemberById(accountId, teamMemberType) {
  return axios.get(`/${teamMemberType}/${accountId}`);
}

export function editTeamMember(data, teamMemberType) {
  return axios.put(`/${teamMemberType}`, { ...data });
}
