import axios from "axios";
import { getTokens, saveTokens } from "../utils/authorization";
import { renewToken } from "./Authorization";
import store from "../store/configureStore";
import { logout } from "../store/actions/common/authentication";
import { errorMessages } from "../constants";

const apiURL = () => {
  switch (process.env.NODE_ENV) {
    case "development":
      return "https://marvel-dev.itomy.ch/admin/api/v1";

    case "stage":
      return "https://marvel-stage.itomy.ch/admin/api/v1";

    case "production":
      return "https://api.marveltrade.biz/admin/api/v1";

    default:
      return "https://marvel-dev.itomy.ch/admin/api/v1";
  }
};

// eslint-disable-next-line no-console
console.log("test check env", process.env);

let isRefreshing = false;
let subscribers = [];

const instance = axios.create({
  baseURL: apiURL()
});

instance.interceptors.response.use(
  response => {
    return response.headers["content-type"] === "text/csv" || response.headers["content-type"] === "application/zip"
      ? response
      : response.data;
  },
  function(error) {
    if (!error.response) {
      return Promise.reject(error);
    }

    const { status, config } = error.response;

    if (errorMessages[error.response.data.errorCode]) {
      error.message = errorMessages[error.response.data.errorCode];
    }

    if (error.response.data.errorCode === 10116) {
      const data = error.response.data.errorData.join(", ");
      error.message = `${errorMessages[error.response.data.errorCode]} ${data}`;
    }

    if (error.response.data.errorCode === 10005 && error.response.data.errorMessage) {
      error.message = error.response.data.errorMessage;
    }

    const originalRequest = config;
    const { refreshToken } = getTokens();

    if (status === 403 || !refreshToken) {
      store.dispatch(logout());
    }

    if (status === 401) {
      if (!isRefreshing) {
        isRefreshing = true;
        instance.defaults.headers.common["Authorization"] = "";
        return renewToken(refreshToken)
          .then(response => {
            isRefreshing = false;
            saveTokens(response);

            const firstRequest = new Promise(resolve => {
              subscribeTokenRefresh(token => {
                originalRequest.headers.Authorization = `Bearer ${token}`;
                resolve(instance(originalRequest));
              });
            });

            onRefreshed(response.accessToken);
            return firstRequest;
          })
          .catch(error => {
            store.dispatch(logout());
            Promise.reject(error);
          });
      }

      const requestSubscribers = new Promise(resolve => {
        subscribeTokenRefresh(token => {
          originalRequest.headers.Authorization = `Bearer ${token}`;
          resolve(instance(originalRequest));
        });
      });

      return requestSubscribers;
    }
    return Promise.reject(error);
  }
);

function subscribeTokenRefresh(cb) {
  subscribers.push(cb);
}

function onRefreshed(token) {
  subscribers.map(cb => cb(token));
  subscribers = [];
}

export default instance;
