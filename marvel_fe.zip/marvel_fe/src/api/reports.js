import axios from "./axiosConfig";
import { downloadCsvFile } from "../helpers/common";

export function getReport(data, reportType) {
  return axios.post(`/Report/${reportType}`, data);
}

export async function exportReport(data, reportType) {
  const res = await axios({
    method: "post",
    url: `/Report/${reportType}`,
    responseType: "arraybuffer",
    data
  });

  downloadCsvFile(res, "report.csv");
  return res;
}

export async function exportCSVAgreedReport(params) {
  const res = await axios({
    method: "get",
    url: "/AgreedOrderTasksReport",
    responseType: "arraybuffer",
    params
  });

  downloadCsvFile(res, "report.csv");
  return res;
}

export async function sendSCVToTelegram(params) {
  return await axios.get("Report/exportOldFormatOrderReport", { params });
}
