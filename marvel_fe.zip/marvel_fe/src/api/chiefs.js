import axios from "./axiosConfig";

export const getChiefs = (role, data) => {
  return axios.post(`/${role}/AvailableChiefs/`, data);
};
