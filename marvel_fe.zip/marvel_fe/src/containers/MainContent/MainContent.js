// @flow
import React from "react";
import type { BrowserHistory } from "history";
import { Redirect } from "react-router-dom";
import { connect } from "react-redux";

// android sales
import ListOfUsersSales from "../../AndroidSales/ListOfUsersSales/ListOfUsersSales";
import ListOfUsersInfoSales from "../../AndroidSales/ListOfUsersInfoSales/ListOfUsersInfoSales";
import ListOfOrdersSales from "../../AndroidSales/ListOfOrdersSales/ListOfOrdersSales";
import Tasks from "../../AndroidSales/Tasks/TasksList";
import DetailsByTasks from "../../AndroidSales/DetailsByTasks/DetailsByTasksList";
import PhotoTask from "../../AndroidSales/PhotoTask/PhotoTaskList/PhotoTaskList";
import PhotoTaskDetails from "../../AndroidSales/PhotoTask/PhotoTaskDetails/PhotoTaskDetails";
import UploadScanCodes from "../../AndroidSales/ScanCodesUpload/ScanCodesUpload";
import GenerateScanCodes from "../../AndroidSales/GenerateScanCodes/ListOfScanCodes";
import ComplimentsUpload from "../../AndroidSales/ComplimentsUpload/ComplimentsUpload";
import InboxListSales from "../../AndroidSales/Inbox/InboxList/InboxList";
import AboutCompany from "../../AndroidSales/AboutCompany/AboutCompany";
import ScheduleForShipment from "../../AndroidSales/ScheduleForShipment/ScheduleForShipment";
import ManageBonusesForm from "../../AndroidSales/ManageBonusesForOrders/ManageBonusesForm";
// temporarily hidden MRVL-1852
// import ActualPrices from "../../AndroidSales/ListOfActualPrices/ListOfActualPrices";
import ExchangeRequestsListSales from "../../AndroidSales/ExchangeRequestsListSales/ExchangeRequestsListSales";
import ExchangeToGiftRequests from "../../AndroidSales/ExchangeToGiftRequests/ExchangeToGiftRequestsList";
import TradeProgramManagersList from "../../AndroidSales/TradeProgramManagers/TradeProgramManagersList/TradeProgramManagersList";
import ModeratorsList from "../../AndroidSales/ListOfModerators/ListOfModerators";
import ListOfOfflineUsers from "../../AndroidSales/ListOfOfflineUsers/ListOfOfflineUsers";
import ModeratorInfoPage from "../../AndroidSales/Moderator/ModeratorsProfile/ModeratorsProfile";
import CentralDepartmentList from "../../AndroidSales/CentralDepartment/CentralDepartmentList/CentralDepartmentList";
import CentralDepartmentProfile from "../../AndroidSales/CentralDepartment/CentralDepartmentProfile/CentralDepartmentProfile";
import UserProfile from "../../AndroidSales/ListOfUsersSales/UserProfile/UserProfile";
import BonusReports from "../../AndroidSales/BonusReports/BonusReportsList";
import BonusReportDetailsList from "../../AndroidSales/BonusReports/BonusReportDetailsList";
import ComplimentsReport from "../../AndroidSales/ComplimentsReport/ComplimentsReport";
import StatisticsByTasks from "../../AndroidSales/StatisticByTasksSales/StatisticByTasksSalesList";
import TaskDetailsList from "../../AndroidSales/StatisticByTasksSales/TaskDetailsList";
import Brand from "../../AndroidSales/Brands/Brand";
import BrandsSettings from "../../AndroidSales/BrandsSettings/BrandsSettings";
import Interactive from "../../AndroidSales/Interactive/InteractivePage";
import ListOfSuperAdmins from "../../AndroidSales/ListOfSuperAdmins/ListOfSuperAdmins";
import ListOfCertificates from "../../AndroidSales/Certificates/ListOfCertificates";
import GetCertificates from "../../AndroidSales/GetCertificates/GetCertificates";
import MidPlusProgress from "../../AndroidSales/MidPlusProgress/MidPlusProgress";
// ios promoters
import ListOfCandidates from "../../IOsPromoters/Candidates/ListOfCandidates/ListOfCandidates";
import CandidateInfoPage from "../../IOsPromoters/Candidates/CandidateInfoPage/CandidateInfoPage";
import ListOfConsultants from "../../IOsPromoters/Consultants/ListOfConsultants";
import RegionalManagerProfile from "../../IOsPromoters/RegionalManagerProfile/RegionalManagerPage";
import ListOfMaterials from "../../IOsPromoters/ListOfMaterials/ListOfMaterials";
import GeneralReportPromoters from "../../IOsPromoters/Reports/GeneralReportPromoters/GeneralReportPromoters";
// import TPReport from "../../IOsPromoters/Reports/TPReport/TPReport";
// import BrandsReport from "../../IOsPromoters/Reports/BrandsReport/BrandsReports";
import EffectiveTimeReport from "../../IOsPromoters/Reports/EffectiveTimeReportPromoters/EffectiveTimeReportPromoters";
import ChangesReport from "../../IOsPromoters/Reports/ChangesReport/ChangesReport";
// import ConsultantsReports from "../../IOsPromoters/Reports/ConsultantsReport/ConsultantsReport";
import Questionnaire from "../../IOsPromoters/Questionnaire/QuestionnaireList";
import QuestionnaireForm from "../../IOsPromoters/Questionnaire/QuestionnaireForm/QuestionnaireForm";
import QuestionnaireReportPromoters from "../../IOsPromoters/Reports/QuestionnaireReport/QuestionnaireReport";
import SupervisorsList from "../../IOsPromoters/Supervisors/SupervisorsList/SupervisorsList";
import ListOfRegionalManagers from "../../IOsPromoters/ListOfRegionalManagers/ListOfRegionalManagers";
import CentralDepartmentListPromoter from "../../IOsPromoters/CentralDepartmentManagers/CentralDepartmentManagersList/CentralDepartmentManagersList";
import CentralDepartmentProfilePromoter from "../../IOsPromoters/CentralDepartmentManagers/CentralDepartmentManagerProfile/CentralDepartmentManagerProfile";
import Status from "../../IOsPromoters/Status/Status";
import SupervisorProfile from "../../IOsPromoters/Supervisors/SupervisorProfile/SupervisorProfile";
import TradeProgramManagerProfile from "../../AndroidSales/TradeProgramManagers/TradeProgramManagerProfile/TradeProgramManagerProfile";
// import DataImport from "../../IOsPromoters/DataImport/DataImport";
import Shifts from "../../IOsPromoters/Shifts/Shifts";
import ShiftDetailedInfo from "../../IOsPromoters/Shifts/ShiftDetailedInfo";
import styles from "./MainContent.module.scss";

const config = {
  promoters: {
    regionManagers: ListOfRegionalManagers,
    centralDepartmentManagers: CentralDepartmentListPromoter,
    centralDepartmentManagersInfo: CentralDepartmentProfilePromoter,
    regionManagersInfo: RegionalManagerProfile,
    supervisors: SupervisorsList,
    supervisorsInfo: SupervisorProfile,
    consultants: ListOfConsultants,
    consultantsInfo: CandidateInfoPage,
    candidates: ListOfCandidates,
    candidatesInfo: CandidateInfoPage,
    status: Status,
    shifts: Shifts,
    shiftsInfo: ShiftDetailedInfo,
    materials: ListOfMaterials,
    generalReport: GeneralReportPromoters,
    // brandsReport: BrandsReport,
    // posReport: TPReport,
    timeReport: EffectiveTimeReport,
    changesReport: ChangesReport,
    // consultantsReport: ConsultantsReports,
    questionnairesReportInfo: QuestionnaireReportPromoters,
    questionnaire: Questionnaire,
    questionnaireInfo: QuestionnaireForm
    /* importData: DataImport */
  },
  sales: {
    listOfOnlineUsers: ListOfUsersSales,
    listOfOfflineUsers: ListOfOfflineUsers,
    listOfOnlineUsersInfo: UserProfile,
    superAdmins: ListOfSuperAdmins,
    centralDepartment: CentralDepartmentList,
    centralDepartmentInfo: CentralDepartmentProfile,
    moderators: ModeratorsList,
    moderatorsInfo: ModeratorInfoPage,
    tradeProgramsManagers: TradeProgramManagersList,
    tradeProgramsManagersInfo: TradeProgramManagerProfile,
    listOfOrders: ListOfOrdersSales,
    manageOrders: ScheduleForShipment,
    manageBonuses: ManageBonusesForm,
    /* actualPrices: ActualPrices, */
    listOfTasks: Tasks,
    detailsByTasks: DetailsByTasks,
    photoTask: PhotoTask,
    photoTaskInfo: PhotoTaskDetails,
    uploadScanCodes: UploadScanCodes,
    generateScanCodes: GenerateScanCodes,
    uploadCompliments: ComplimentsUpload,
    certificates: ListOfCertificates,
    getCertificates: GetCertificates,
    exchangeRequestsPhone: ExchangeRequestsListSales,
    exchangeToGiftRequests: ExchangeToGiftRequests,
    inbox: InboxListSales,
    userInformation: ListOfUsersInfoSales,
    bonusesReports: BonusReports,
    bonusesReportsInfo: BonusReportDetailsList,
    complimentsReport: ComplimentsReport,
    statisticOfTasks: StatisticsByTasks,
    statisticOfTasksInfo: TaskDetailsList,
    brandsInfo: Brand,
    aboutCompany: AboutCompany,
    advertising: Interactive,
    midPlusProgress: MidPlusProgress,
    brandsSettings: BrandsSettings
  }
};

type Props = {
  role: string,
  menuConfig: Object
};
type PropsT = BrowserHistory & Props;
const findItem = (menu, item, id) =>
  menu.find(menuItem => menuItem.route === item || menuItem.route === `${item}/${id}`);

const MainContent = (props: PropsT) => {
  const { id, adminPanel, menuItem } = props.match.params;

  const { path, items } = props.menuConfig[props.role];
  let routeParams;
  items.forEach(item => {
    if (item.subMenu) {
      let subMenuItem = findItem(item.subMenu, menuItem, id);
      if (
        subMenuItem &&
        (`/${path}/${subMenuItem.route}` === `/${adminPanel}/${menuItem}` ||
          `/${path}/${subMenuItem.route}` === `/${adminPanel}/${menuItem}/${id}`)
      ) {
        return (routeParams = subMenuItem);
      }
    } else if (`/${path}/${item.route}` === `/${adminPanel}/${menuItem}`) {
      return (routeParams = item);
    }
  });

  if (!routeParams) {
    return <Redirect to="/404" />;
  }

  const Component = id ? config[adminPanel][`${routeParams.name}Info`] : config[adminPanel][routeParams.name];

  return (
    <div className={styles.mainContentWrapper}>
      <Component {...props} />
    </div>
  );
};

const mapStateToProps = ({ authenticationReducer: { menuConfig } }) => ({ menuConfig });
export default connect(mapStateToProps)(MainContent);
