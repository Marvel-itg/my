// @flow
import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import { reduxForm, Field } from "redux-form";
import { loginRequest, logout } from "../../store/actions/common/authentication";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import InputField from "../../components/InputField/InputField";
import PasswordInputField from "../../components/InputField/PasswordInputField";
import { required, passwordFieldValidation } from "../../utils/reduxFormValidation";
import { normalizeWithTrim, normalizeLength } from "../../utils/reduxFormNormalizers";
import styles from "./AuthorizationPage.module.scss";
import { getTokens } from "../../utils/authorization";

type PropsT = {
  submitting: boolean,
  submitted: boolean,
  valid: boolean,
  loginRequest: Function,
  handleSubmit: Function,
  loginError: string
};

class AuthorizationPage extends Component<PropsT & BrowserHistory> {
  componentDidMount(): void {
    const { accessToken } = getTokens();
    if (accessToken) {
      this.props.logout();
    }
  }

  componentDidUpdate(prevProps: PropsT) {
    if (!prevProps.submitted && this.props.submitted) {
      this.props.history.push("/");
    }
  }

  submitForm = fields => this.props.loginRequest(fields);

  render() {
    return (
      <div className={styles.authPageWrapper}>
        <form
          className={styles.authFormWrapper}
          noValidate
          autoComplete="off"
          onSubmit={this.props.handleSubmit(this.submitForm)}
        >
          Введіть Ваш логін та пароль
          <Field name="login" component={InputField} validate={[required]} normalize={normalizeWithTrim} />
          <Field
            component={PasswordInputField}
            name="password"
            validate={[required, passwordFieldValidation]}
            normalize={normalizeLength(8)}
          />
          <div className={styles.errorMsg}>{this.props.loginError}</div>
          <ContainedButton type="submit" label="Увійти" disabled={!this.props.valid || this.props.submitting} />
        </form>
      </div>
    );
  }
}

const Form = reduxForm({
  form: "loginForm"
})(AuthorizationPage);

const mapStateToProps = ({ authenticationReducer: { submitting, submitted, error } }) => ({
  submitting,
  submitted,
  loginError: error
});

const mapDispatchToProps = { loginRequest, logout };

export default withRouter(
  connect(
    mapStateToProps,
    mapDispatchToProps
  )(Form)
);
