// @flow
import React from "react";
import { Grid, Table, TableHeaderRow } from "@devexpress/dx-react-grid-material-ui";
import Paper from "@material-ui/core/Paper/Paper";
import cx from "classnames";
import {
  DateFormatProvider,
  PersonInfoProvider,
  AdminStatusProvider,
  HistoryKeyProvider,
  ShiftStatusProvider,
  ShiftCancellationReasonProvider
} from "../../components/FormattedData/FormattedData";
import GridRoot from "../../components/TableComponents/GridRoot";
import styles from "./ActivityTable.module.scss";

type PropsT = {
  columns: ColumnT[],
  data: any[]
};

const forValues = {
  key: ["key"],
  changedBy: ["changedBy"],
  timeStamp: ["timeStamp"],
  changedOn: ["changedOn"],
  oldValue: ["oldValue"],
  newValue: ["newValue"],
  status: ["status"],
  reason: ["reason"],
  date: ["date"]
};

const columnExtensions = [{ columnName: "changedBy", width: 300 }];

const TableContainerComponent = ({ style, ...props }) => <Table.Container {...props} className={styles.table} />;

const wordWrapStyles = {
  whiteSpace: "normal",
  wordWrap: "break-word"
};

const CellComponent = ({ style, ...props }) => {
  return <Table.Cell style={wordWrapStyles} {...props} />;
};

const ActivityTable = (props: PropsT) => {
  return (
    <Paper classes={{ root: cx(styles.tableWrapper, { [styles.emptyTable]: !props.data.length }) }}>
      <Grid rows={props.data} columns={props.columns} rootComponent={GridRoot} className={styles.table}>
        <PersonInfoProvider for={forValues.changedBy} />
        <DateFormatProvider for={forValues.timeStamp} showTime />
        <DateFormatProvider for={forValues.changedOn} showTime />
        <DateFormatProvider for={forValues.date} showTime />
        <ShiftStatusProvider for={forValues.status} />
        <ShiftCancellationReasonProvider for={forValues.reason} />
        <HistoryKeyProvider for={forValues.key} />
        <AdminStatusProvider for={forValues.oldValue} />
        <AdminStatusProvider for={forValues.newValue} />
        <Table
          columnExtensions={columnExtensions}
          cellComponent={CellComponent}
          containerComponent={TableContainerComponent}
        />
        <TableHeaderRow />
      </Grid>
    </Paper>
  );
};

export default ActivityTable;
