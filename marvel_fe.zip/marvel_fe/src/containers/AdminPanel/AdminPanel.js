// @flow
import React from "react";
import get from "lodash/get";
import { Route, NavLink, Switch, Redirect } from "react-router-dom";
import { connect } from "react-redux";
import { compose } from "redux";
import type { BrowserHistory } from "history";
import cx from "classnames";
import { withStyles } from "@material-ui/core/styles";
import Drawer from "@material-ui/core/Drawer";
import CircularProgress from "@material-ui/core/CircularProgress";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import List from "@material-ui/core/List";
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
import ExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import ExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import Menu from "../../components/Menu/Menu";
import Logout from "../../components/Logout/Logout";
import SuccessModal from "../../components/SuccessModal/SuccessModal";
import ErrorModal from "../../components/ErrorModal/ErrorModal";
import MainContent from "../MainContent/MainContent";
import { getAuthUserInfo } from "../../store/actions/common/authentication";
import {
  roles,
  defaultItemsPerPage,
  consultantsOptions,
  iosManagersOptions,
  supervisorsOptions,
  listOfSalesUsersOptions
} from "../../constants";
import { classes as loaderClasses } from "../../helpers/spinner";
import Logo from "../../assets/images/marvel_logo.svg";
import styles from "./AdminPanel.module.scss";

const style = () => ({
  root: {
    display: "flex",
    flex: 1,
    height: "100%",
    width: "100vw",
    overflowX: "hidden"
  },
  toolbar: {
    backgroundColor: "#003A70",
    height: "70px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "0 8px 0 70px"
  },
  toolbarLeft: {
    display: "flex",
    alignItems: "center",
    flex: "1 0 auto"
  },
  drawerPaper: {
    width: "256px",
    zIndex: 0,
    position: "relative",
    flex: "1 0 auto"
  },
  list: {
    paddingTop: "90px",
    display: "flex",
    flexDirection: "column",
    flexShrink: 0
  },
  paper: {
    width: "256px",
    display: "flex",
    flexDirection: "column",
    height: "100%",
    justifyContent: "space-between"
  },
  content: {
    width: "100%",
    overflowX: "hidden"
  },
  buildNumber: {
    width: "100%",
    height: "70px",
    paddingLeft: "20px",
    paddingBottom: "20px"
  }
});

type PropsT = {
  classes: any,
  user: CurrentUserInfoT,
  getAuthUserInfo: Function,
  loadingUser: boolean,
  closeModal: Function,
  menuConfig: any
} & BrowserHistory;

type StateT = {
  role: string,
  expanded: ?string | false,
  activeTab: ?string | false,
  isFirstExpand: boolean
};

const matchWorkaround = path => (isMatch, location) => {
  return !!isMatch || location.pathname === path;
};

const styleClasses = {
  expansionPanel: {
    root: styles.expansionPanel,
    expanded: styles.expansionPanelExpanded
  },

  expansionPanelSummary: {
    root: styles.expansionPanelSummary,
    expanded: styles.expansionPanelSummaryExpanded
  },

  expansionPanelSummaryActive: {
    root: styles.expansionPanelSummaryActive,
    expanded: styles.expansionPanelSummaryExpanded
  }
};

class AdminPanel extends React.PureComponent<PropsT, StateT> {
  constructor(props: PropsT) {
    super(props);
    const adminPart = props.location.pathname.split("/")[1];
    this.state = {
      role: adminPart,
      expanded: null,
      isFirstExpand: true,
      activeTab: ""
    };
  }

  componentDidMount() {
    this.props.getAuthUserInfo();
  }

  componentDidUpdate(prevProps, prevState) {
    if (!prevProps.user && this.props.user && this.props.location.pathname === "/") {
      switch (this.props.user.accountType) {
        case 1:
        case 2:
        case 3: {
          // SUPER ADMIN
          // Central department manager (Android)
          // Trade PM (Android)
          this.setState({ role: "sales" });
          this.props.history.replace(
            `/sales/list-of-online-users?page=1&count=${defaultItemsPerPage}&tab=3&searchField=${listOfSalesUsersOptions[0].value}` // eslint-disable-line
          );
          break;
        }
        case 4: {
          // Moderator (Android)
          this.setState({ role: "sales" });
          this.props.history.replace(`/sales/inbox?page=1&count=${defaultItemsPerPage}&tab=1`);
          break;
        }

        case 5: {
          // Central department manager(IOS)
          this.setState({ role: "promoters" });
          this.props.history.replace(
            `/promoters/region-managers?page=1&count=${defaultItemsPerPage}&tab=3&searchField=${iosManagersOptions[0].value}` // eslint-disable-line
          );
          break;
        }
        case 6: {
          // Regional manager(IOS)
          this.setState({ role: "promoters" });
          this.props.history.replace(
            `/promoters/supervisors?page=1&count=${defaultItemsPerPage}&tab=3&searchField=${supervisorsOptions[0].value}` // eslint-disable-line
          );
          break;
        }
        case 7: {
          // Supervisor(IOS)
          this.setState({ role: "promoters" });
          this.props.history.replace(
            `/promoters/consultants?page=1&count=${defaultItemsPerPage}&tab=3&searchField=${consultantsOptions[0].value}` //eslint-disable-line
          );
          break;
        }

        default:
          this.props.history.replace("/login");
      }
    }
    if (prevProps.user && !this.props.user) {
      this.props.history.replace("/login");
    }

    if (prevState.role !== this.state.role) {
      this.setState({ isFirstExpand: true });
    }

    if (
      this.props.location.pathname !== prevProps.location.pathname ||
      prevState.expanded !== this.state.expanded ||
      this.state.isFirstExpand
    ) {
      this.highlightMenuItems();
    }
  }

  highlightMenuItems = () => {
    get(this, `props.menuConfig[${this.state.role}].items`, []).forEach(item => {
      if (item.subMenu) {
        item.subMenu.forEach(subMenuItem => {
          if (
            this.props.location.pathname.match(`/${this.props.menuConfig[this.state.role].path}/${subMenuItem.route}`)
          ) {
            this.setState({ activeTab: item.name });
            if (this.state.isFirstExpand) {
              this.setState({ expanded: item.name, isFirstExpand: false });
            }
          }
        });
      }
    });
  };

  getPath = () => {
    const { user } = this.props;
    switch (user.accountType) {
      case 1: {
        return "/:adminPanel(sales|promoters)/:menuItem/:menuSubRoute(edit-requests)?/:id?/:projectId?";
      }
      case 2:
      case 3:
      case 4: {
        return "/:adminPanel(sales)/:menuItem/:id?";
      }
      case 5:
      case 6:
      case 7: {
        return "/:adminPanel(promoters)/:menuItem/:menuSubRoute(edit-requests)?/:id?/:projectId?";
      }
      default:
        return "/notFound";
    }
  };
  changeRole = (role: string) => {
    const { menuConfig } = this.props;
    if (this.state.role !== role) {
      this.setState({ role });

      const menu = menuConfig[role].items[0];

      if (menu.subMenu) {
        var { route, defaultURLQuery = () => "" } = menu.subMenu[0];
      } else {
        route = menu.route;
        defaultURLQuery = menu.defaultURLQuery || (() => "");
      }

      this.props.history.replace(`/${menuConfig[role].path}/${route}${defaultURLQuery()}`);
    }
  };

  renderUserInfo = () => {
    const { user, classes } = this.props;
    if (!user) {
      return <div />;
    }

    return (
      <div className={cx(classes.toolbarRight, styles.userInfo)}>
        <div>
          <div>{`${user.firstName} ${user.middleName || ""} ${user.lastName}`}</div>
          <div className={styles.role}>{roles[user.accountType]}</div>
        </div>
      </div>
    );
  };

  handleAccordionExpanding = panel => (event, expanded) => {
    this.setState({
      expanded: expanded ? panel : false
    });
  };

  handleNavLinkClick = () => {
    this.setState({ activeTab: "" });
  };

  render() {
    const { classes, loadingUser, user, menuConfig } = this.props;

    return !user || loadingUser ? (
      <CircularProgress classes={loaderClasses} />
    ) : (
      <Switch>
        <React.Fragment>
          <div className={classes.root}>
            <AppBar position="fixed">
              <Toolbar className={classes.toolbar}>
                <div className={classes.toolbarLeft}>
                  <img src={Logo} alt="" className={styles.logo} />
                  <Menu
                    history={this.props.history}
                    changeRole={this.changeRole}
                    panelName={menuConfig && menuConfig[this.state.role] && menuConfig[this.state.role].panelName}
                    accountType={user.accountType}
                  />
                </div>
                {this.renderUserInfo()}
                <Logout />
              </Toolbar>
            </AppBar>
            <Drawer
              variant="permanent"
              classes={{
                root: classes.drawerPaper,
                paper: classes.paper
              }}
            >
              <List className={classes.list}>
                {menuConfig &&
                menuConfig[this.state.role] &&
                menuConfig[this.state.role].items.map(item => {
                  let path = `/${menuConfig[this.state.role].path}/${item.route}${
                    item.defaultURLQuery ? item.defaultURLQuery() : ""
                  }`;
                  return item.subMenu ? (
                    <ExpansionPanel
                      expanded={this.state.expanded === item.name}
                      onChange={this.handleAccordionExpanding(item.name)}
                      classes={styleClasses.expansionPanel}
                      key={item.name}
                    >
                      <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        classes={
                          this.state.activeTab === item.name && this.state.expanded !== this.state.activeTab
                            ? styleClasses.expansionPanelSummaryActive
                            : styleClasses.expansionPanelSummary
                        }
                      >
                        {item.menuItem}
                      </ExpansionPanelSummary>
                      <ExpansionPanelDetails className={styles.expansionPanelDetails}>
                        {item.subMenu.map(subMenuItem => {
                          path = `/${menuConfig[this.state.role].path}/${subMenuItem.route}${
                            subMenuItem.defaultURLQuery ? subMenuItem.defaultURLQuery() : ""
                          }`;

                          return (
                            <NavLink
                              className={styles.subMenuItem}
                              activeClassName={styles.activeSubMenuItem}
                              to={path}
                              key={subMenuItem.route}
                              isActive={matchWorkaround(`/${menuConfig[this.state.role].path}/${subMenuItem.route}`)}
                            >
                              {subMenuItem.menuItem}
                            </NavLink>
                          );
                        })}
                      </ExpansionPanelDetails>
                    </ExpansionPanel>
                  ) : (
                    <NavLink
                      className={styles.menuItem}
                      onClick={this.handleNavLinkClick}
                      activeClassName={styles.activeMenuItem}
                      to={path}
                      key={item.name}
                      isActive={matchWorkaround(`/${menuConfig[this.state.role].path}/${item.route}`)}
                    >
                      {item.menuItem}
                    </NavLink>
                  );
                })}
              </List>
              <div className={classes.buildNumber}>v {process.env.REACT_APP_BUILD_NUMBER}</div>
            </Drawer>
            <Route
              path={this.getPath()}
              render={props => (
                <main className={classes.content}>
                  <MainContent {...props} role={this.state.role} />
                </main>
              )}
            />
          </div>
          <SuccessModal />
          <ErrorModal />
        </React.Fragment>
        <Redirect to="/404" />
      </Switch>
    );
  }
}

const mapStateToProps = ({ authenticationReducer: { user, loadingUser, menuConfig } }) => ({
  user,
  loadingUser,
  menuConfig
});

const mapDispatchToProps = { getAuthUserInfo };

export default compose(withStyles(style), connect(mapStateToProps, mapDispatchToProps))(AdminPanel);
