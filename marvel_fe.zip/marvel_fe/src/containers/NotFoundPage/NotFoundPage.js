import React from "react";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import { Link } from "react-router-dom";
import Logo from "../../assets/images/marvel_logo.svg";
import styles from "./NotFoundPage.module.scss";

export default () => {
  return (
    <div>
      <AppBar position="fixed">
        <Toolbar>
          <Link to="/promoters/region-managers">
            <img src={Logo} alt="" className={styles.logo} />
          </Link>
        </Toolbar>
      </AppBar>
      <div className={styles.notFoundPage}>
        <div className={styles.label}>404</div>
        <div className={styles.title}>Oops! That page can't be found.</div>
      </div>
    </div>
  );
};
