// @flow
import moment from "moment";
import type { BrowserHistory } from "history";
import omit from "lodash/omit";
import isEqual from "lodash/isEqual";
import fileSaver from "file-saver";
import { defaultItemsPerPage } from "../constants";

export const capitalize = (string: string) => {
  if (typeof string !== "string") return "";
  return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
};

export const mapCityToOptionsOfCities = (city: CityT) => {
  const cityName = (city && city.cityName) || "";
  const districtName = (city && city.districtName) || "";
  const areaName = (city && city.areaName) || "";
  const id = (city && city.id) || "";
  const regionName = (city && city.regionName) || "";
  const geoType = (city && city.geoType) || "";
  return {
    label: cityName
      ? geoType === 2
        ? `${cityName}`
        : `${cityName}, ${capitalize(districtName)} район, ${capitalize(areaName)} область`
      : "",
    value: `${id}`,
    region: `${regionName}`,
    geoType: `${geoType}`
  };
};

export const formatObjectToFullName = (object: ChiefT) => {
  const firstName = object.firstName || "";
  const lastName = object.lastName || "";
  const middleName = object.middleName || "";
  return `${lastName} ${firstName} ${middleName}`;
};

export const mapRegionToOptionsOfRegions = (city: CityT) => {
  return {
    label: `${city.regionName}`,
    value: `${city.id}`
  };
};

export const getSearchQuery = (search: string) => {
  const params = new URLSearchParams(search);
  const tabValue = params.get("tab");
  const field = params.get("searchField");
  const value = params.get("searchValue");
  const startDate = params.get("start");
  const endDate = params.get("end");
  const pageValue = params.get("page");
  const countValue = params.get("count");
  const dateValue = params.get("date");
  const consultantIdValue = params.get("consultantId");
  const projectIdValue = params.get("projectId");
  const geoIdValue = params.get("geoId");
  const geoTypeValue = params.get("geoType");
  const notProcessedValue = params.get("notProcessed");
  const notDeliveredValue = params.get("notDelivered");
  const typeValue = params.get("type");
  const issuerIdValue = params.get("issuerId");
  const productIdValue = params.get("productId");

  const searchField = field ? `&searchField=${field}` : "";
  const searchValue = value ? `&searchValue=${encodeURIComponent(value)}` : "";
  const start = startDate ? `&start=${startDate}` : "";
  const end = endDate ? `&end=${endDate}` : "";
  const page = pageValue ? `page=${pageValue}` : "page=1";
  const count = countValue ? `&count=${countValue}` : `&count=${defaultItemsPerPage}`;
  const tab = tabValue ? `&tab=${tabValue}` : "";
  const date = dateValue ? `&date=${dateValue}` : "";
  const geoId = geoIdValue ? `&geoId=${geoIdValue}` : "";
  const geoType = geoTypeValue ? `&geoType=${geoTypeValue}` : "";
  const consultantId = consultantIdValue ? `&consultantId=${consultantIdValue}` : "";
  const projectId = projectIdValue ? `&projectId=${projectIdValue}` : "";
  const notProcessed = notProcessedValue ? "&notProcessed=true" : "";
  const notDelivered = notDeliveredValue ? "&notDelivered=true" : "";
  const type = typeValue ? `&type=${typeValue}` : "";
  const issuerId = issuerIdValue ? `&issuerId=${issuerIdValue}` : "";
  const productId = productIdValue ? `&productId=${productIdValue}` : "";

  return {
    searchField,
    searchValue,
    start,
    end,
    page,
    count,
    tab,
    projectId,
    consultantId,
    date,
    geoId,
    geoType,
    notDelivered,
    notProcessed,
    type,
    issuerId,
    productId
  };
};

export const getPaginationConfig = (search: string) => {
  const params = new URLSearchParams(search);
  return {
    page: params.get("page") ? +params.get("page") - 1 : 0,
    count: params.get("count") ? +params.get("count") : defaultItemsPerPage,
    tab: params.get("tab") ? params.get("tab") : "1"
  };
};

export const filterByDate = (rangeFilter: RangeFilterT, search: string, history: BrowserHistory, state: any) => {
  const { searchField, type, searchValue, count, tab, notProcessed, notDelivered, issuerId } = getSearchQuery(search);
  const start = rangeFilter.startDate
    ? moment(rangeFilter.startDate).format("DD/MM/YYYY")
    : moment()
        .subtract(1, "month")
        .format("DD/MM/YYYY");
  const end = rangeFilter.endDate
    ? moment(rangeFilter.endDate).format("DD/MM/YYYY")
    : moment()
        .endOf("day")
        .format("DD/MM/YYYY");

  history.push(
    // eslint-disable-next-line max-len
    `?page=1${count}${tab}&start=${start}&end=${end}${searchField}${searchValue}${notProcessed}${notDelivered}${type}${issuerId}`,
    { ...state }
  );
};

export const changeDateAndProductId = (filter: GenerateScanCodesFilterT, search: string, history: BrowserHistory) => {
  const { searchField, searchValue, count, tab } = getSearchQuery(search);
  const start = filter.startDate
    ? moment(filter.startDate).format("DD/MM/YYYY")
    : moment()
        .subtract(1, "month")
        .format("DD/MM/YYYY");
  const end = filter.endDate
    ? moment(filter.endDate).format("DD/MM/YYYY")
    : moment()
        .endOf("day")
        .format("DD/MM/YYYY");

  const product = filter.productId && filter.productId.value ? `&productId=${filter.productId.value}` : "";

  history.push(
    // eslint-disable-next-line max-len
    `?page=1${count}${tab}&start=${start}&end=${end}${searchField}${searchValue}${product}`
  );
};

export const changeCurrentPage = (currentPage: number, search: string, history: BrowserHistory, state: any) => {
  const {
    searchField,
    searchValue,
    start,
    end,
    count,
    tab,
    geoId,
    geoType,
    date,
    projectId,
    consultantId,
    notProcessed,
    notDelivered,
    type,
    issuerId,
    productId
  } = getSearchQuery(search);
  history.push(
    `?page=${currentPage +
      1}${count}${tab}${start}${end}${type}${searchField}${searchValue}${geoId}${geoType}${date}${projectId}${consultantId}${notProcessed}${notDelivered}${issuerId}${productId}`, // eslint-disable-line
    { ...state }
  );
};

export const changePageSize = (pageSize: number, search: string, history: BrowserHistory, state: any) => {
  const {
    searchField,
    searchValue,
    start,
    end,
    tab,
    geoId,
    geoType,
    date,
    projectId,
    consultantId,
    notProcessed,
    notDelivered,
    type,
    issuerId,
    productId
  } = getSearchQuery(search);
  history.push(
    `?page=1&count=${pageSize}${tab}${start}${end}${searchField}${searchValue}${type}${geoId}${geoType}${date}${projectId}${consultantId}${notProcessed}${notDelivered}${issuerId}${productId}`, // eslint-disable-line
    { ...state }
  );
};

export const changeTab = (tab: string, search: string, history: BrowserHistory) => {
  const {
    searchField,
    searchValue,
    start,
    end,
    count,
    geoId,
    geoType,
    date,
    projectId,
    consultantId,
    notProcessed,
    notDelivered,
    type,
    issuerId,
    productId
  } = getSearchQuery(search);
  history.push(
    `?page=${1}${count}&tab=${tab}${start}${end}${searchField}${searchValue}${type}${geoId}${geoType}${date}${projectId}${consultantId}${notProcessed}${notDelivered}${issuerId}${productId}` // eslint-disable-line
  );
};

export const onSearchChange = (searchValue: string, search: string, history: BrowserHistory, state: any) => {
  const {
    count,
    tab,
    geoId,
    geoType,
    date,
    projectId,
    searchField,
    consultantId,
    notProcessed,
    notDelivered,
    type,
    start,
    end,
    issuerId,
    productId
  } = getSearchQuery(search);
  history.push(
    `?page=1${count}${tab}${type}${start}${end}${searchField}&searchValue=${searchValue}${geoId}${geoType}${date}${projectId}${consultantId}${notProcessed}${notDelivered}${issuerId}${productId}`, // eslint-disable-line
    { ...state }
  );
};

export const onFieldChange = (searchField: string, search: string, history: BrowserHistory, state: any) => {
  const { count, start, end, tab, searchValue, notProcessed, notDelivered, type, issuerId, productId } = getSearchQuery(
    search
  );
  history.push(
    `?page=1${count}${tab}${type}${start}${end}&searchField=${searchField}${searchValue}${notProcessed}${notDelivered}${issuerId}${productId}`, // eslint-disable-line
    { ...state }
  );
};

export const changeShiftDate = (startDate: string, endDate: string, search: string, history: BrowserHistory) => {
  const startDateFormatted = startDate ? moment(startDate).format("DD/MM/YYYY") : "";
  const endDateFormatted = endDate ? moment(endDate).format("DD/MM/YYYY") : "";

  const { count, tab, geoId, geoType, consultantId, start, end, projectId } = getSearchQuery(search);
  const startDateValue = startDateFormatted ? `&start=${startDateFormatted}` : start;
  const endDateValue = endDateFormatted ? `&end=${endDateFormatted}` : end;
  history.push(`?page=1${count}${tab}${geoId}${geoType}${startDateValue}${endDateValue}${projectId}${consultantId}`);
};

export const changeShiftGeoId = (
  geoData: { label: string, value: string, region: string, geoType?: string },
  search: string,
  history: BrowserHistory
) => {
  const { count, tab, start, end, consultantId, projectId } = getSearchQuery(search);
  const geoId = geoData && geoData.value ? `&geoId=${geoData.value}` : "";
  const geoType = geoData && geoData.geoType ? `&geoType=${geoData.geoType}` : "";
  history.push(`?page=1${count}${tab}${geoId}${geoType}${start}${end}${projectId}${consultantId}`);
};

export const changeShiftProjectId = (project: number, search: string, history: BrowserHistory) => {
  const { count, tab, start, end, consultantId, geoId, geoType } = getSearchQuery(search);
  const projectId = project ? `&projectId=${project}` : "";
  history.push(`?page=1${count}${tab}${geoId}${geoType}${start}${end}${projectId}${consultantId}`);
};

export const changeShiftConsultantId = (consultant: number, search: string, history: BrowserHistory) => {
  const { count, tab, start, end, geoId, geoType, projectId } = getSearchQuery(search);
  const consultantId = consultant ? `&consultantId=${consultant}` : "";
  history.push(`?page=1${count}${tab}${geoId}${geoType}${start}${end}${projectId}${consultantId}`);
};

export const getCommonParams = (search: string) => {
  const params = new URLSearchParams(search);
  const dateStart = params.get("start")
    ? moment(params.get("start"), "DD/MM/YYYY").format("YYYY-MM-DD")
    : moment()
        .subtract(1, "months")
        .startOf("day");
  const dateEnd = params.get("end")
    ? moment(params.get("end"), "DD/MM/YYYY").format("YYYY-MM-DD")
    : moment().endOf("day");
  const date = params.get("date") ? moment(params.get("date"), "DD/MM/YYYY").format("YYYY-MM-DD") : "";
  const searchFieldName = params.get("searchField") || "";
  const searchValue = params.get("searchValue") || "";
  const itemsOnPage = params.get("count") || defaultItemsPerPage;
  const pageNumber = params.get("page") || "1";
  const tab = params.get("tab");
  const consultantId = params.get("consultantId") ? Number(params.get("consultantId")) : "";
  const projectId = params.get("projectId") ? Number(params.get("projectId")) : "";
  const geoId = params.get("geoId") ? Number(params.get("geoId")) : "";
  const geoType = params.get("geoType") ? Number(params.get("geoType")) : "";
  const notProcessed = params.get("notProcessed") ? true : false;
  const notDelivered = params.get("notDelivered") ? true : false;
  const type = params.get("type") ? params.get("type") : "";
  const issuerId = params.get("issuerId") ? Number(params.get("issuerId")) : "";
  const productId = params.get("productId") ? Number(params.get("productId")) : "";

  return {
    dateStart,
    dateEnd,
    searchFieldName,
    searchValue,
    itemsOnPage,
    pageNumber,
    tab,
    date,
    consultantId,
    projectId,
    geoId,
    geoType,
    notDelivered,
    notProcessed,
    type,
    issuerId,
    productId
  };
};

export const downloadCsvFile = (res: any, name: string) => {
  let blob = new Blob([res.data], { type: "text/csv" });
  let header = res.headers["content-disposition"];

  let filename = "file.csv";
  if (header) {
    filename = header.match(/filename="(.+)";/)
      ? header.match(/filename="(.+)";/)[1]
      : header.match(/filename=(.+);/)[1];
  }
  fileSaver.saveAs(blob, filename);
};

export const downloadZipFile = (res: any) => {
  let blob = new Blob([res.data], { type: "application/zip" });

  let header = res && res.headers && res.headers["content-disposition"];

  let filename = "file.zip";
  if (header) {
    filename = header.match(/filename="(.+)";/)
      ? header.match(/filename="(.+)";/)[1]
      : header.match(/filename=(.+);/)[1];
  }
  fileSaver.saveAs(blob, filename);
};

export const filterActivityHistoryWithoutCreatingRecord = (activityHistory: ActivityRecordT[]): ActivityRecordT[] => {
  if (activityHistory && activityHistory.length) {
    const filteredHistory = activityHistory.filter(item => item.activityType !== 1);
    return filteredHistory;
  }
  return [];
};

export const changeNotProcessed = (notProcessedValue: boolean, search: string, history: BrowserHistory) => {
  const { count, tab, start, end, searchField, searchValue, notDelivered } = getSearchQuery(search);
  const notProcessed = notProcessedValue ? "&notProcessed=true" : "";
  history.push(`?page=1${count}${tab}${start}${end}${searchField}${searchValue}${notProcessed}${notDelivered}`);
};

export const changeNotDelivered = (notDeliveredValue: boolean, search: string, history: BrowserHistory) => {
  const { count, tab, start, end, searchField, searchValue, notProcessed } = getSearchQuery(search);
  const notDelivered = notDeliveredValue ? "&notDelivered=true" : "";
  history.push(`?page=1${count}${tab}${start}${end}${searchField}${searchValue}${notProcessed}${notDelivered}`);
};

export const changeIssuerId = (issuerId: number, search: string, history: BrowserHistory) => {
  const { count, tab, searchField, searchValue } = getSearchQuery(search);
  history.push(`?page=1${count}${tab}${searchField}${searchValue}&issuerId=${issuerId}`);
};

export const shouldNotSendRequest = (prevSearch: string, currentSearch: string) => {
  const prevParams = getCommonParams(prevSearch);
  const currentParams = getCommonParams(currentSearch);
  const primitivePrevParams = omit(prevParams, ["dateStart", "dateEnd", "searchFieldName"]);
  const primitiveCurrentParams = omit(currentParams, ["dateStart", "dateEnd", "searchFieldName"]);
  const prevStartDate = prevParams.dateStart && moment(prevParams.dateStart).format("DD/MM/YYYY");
  const prevEndDate = prevParams.dateEnd && moment(prevParams.dateEnd).format("DD/MM/YYYY");
  const currentStartDate = currentParams.dateStart && moment(currentParams.dateStart).format("DD/MM/YYYY");
  const currentEndDate = currentParams.dateEnd && moment(currentParams.dateEnd).format("DD/MM/YYYY");
  const shouldNotSend =
    isEqual(primitivePrevParams, primitiveCurrentParams) &&
    prevStartDate === currentStartDate &&
    prevEndDate === currentEndDate &&
    !currentParams.searchValue &&
    prevParams.searchFieldName !== currentParams.searchFieldName;
  return shouldNotSend;
};
