import moment from "moment";

export const formatDateTimeToDateWithDash = dateTimeObject =>
  dateTimeObject && moment(dateTimeObject).format("YYYY-MM-DD");
