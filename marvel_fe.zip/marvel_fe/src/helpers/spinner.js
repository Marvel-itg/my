export const classes = { root: "spinner" };
export const classesPageCentered = { root: "spinner_page-centered" };
