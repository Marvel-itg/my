export const stringToOption = string => {
  return {
    label: string,
    value: string
  };
};

export const optionsToObject = array => array.map(stringToOption);

export const formatOptions = options => {
  if (options && options.length) {
    //here we assuming, that is first property is string - the rest as well
    return typeof options[0] === "string" ? optionsToObject(options) : options;
  } else {
    return options || null;
  }
};
