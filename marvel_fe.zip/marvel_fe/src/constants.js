import moment from "moment";

export const MIME_TYPES = {
  doc: "application/msword",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  xls: "application/vnd.ms-excel",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  pdf: "application/pdf",
  jpg: "image/jpeg",
  png: "image/png",
  ppt: " application/vnd.ms-powerpoint",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  mp4: "video/mp4"
};
export const TASK_TYPES = {
  order: 1,
  foil: 2,
  test: 3,
  informational: 4,
  questionnaire: 5,
  photo: 6,
  testFeedback: 7,
  scan: 8,
  midPlus: 9
};

export const genderFormat = {
  0: "Не вибрано",
  1: "Жінка",
  2: "Чоловік"
};

export const orderOptions = [
  {
    value: "0",
    label: "План по SKU"
  },
  {
    value: "1",
    label: "Загальний план"
  }
];

export const foilOptions = [
  {
    value: 1,
    label: "N балів за кожну фольгу"
  },
  {
    value: 2,
    label: `N балів за кожну фольгу при досягненні мінімального плану та додатково фіксована 
      Y кількість балів при досяганні порогу на ТТ`
  },
  {
    value: 3,
    label: `N балів за кожну фольгу при досягненні мінімального плану та Y балів за кожну 
      фольгу понад відповідний поріг`
  }
];
export const genderOptions = [
  { value: "1", label: "Жінка" },
  { value: "2", label: "Чоловік" }
];

export const positionFormat = {
  8: "Директор",
  9: "Продавець"
};

export const exchangeToGiftRequestStatus = {
  "2": "Виконано",
  "3": "Не виконано",
  "4": "Не виконано"
};

export const answerType = {
  notification: "Notification",
  sms: "SMS"
};

/* Tables constants */
export const columnExtensions = [
  { columnName: "id", width: 120 },
  { columnName: "photo", width: 90 },
  { columnName: "name", width: 90 },
  { columnName: "surname", width: 120 },
  { columnName: "email", width: 250 },
  { columnName: "phone", width: 180 },
  { columnName: "address", width: 250 },
  { columnName: "sizeTop", width: 70 },
  { columnName: "sizeBottom", width: 50 },
  { columnName: "sizeTop", width: 40 },
  { columnName: "sizeShoes", width: 60 },
  { columnName: "height", width: 120 },
  { columnName: "geos", width: 400 },
  { columnName: "weight", width: 120 },
  { columnName: "startOfWork", width: 120 },
  { columnName: "chest", width: 70 },
  { columnName: "waist", width: 70 },
  { columnName: "hips", width: 70 },
  { columnName: "gender", width: 110 },
  { columnName: "activate", width: 170 },
  { columnName: "details", width: 200 },
  { columnName: "approve", width: 150 },
  { columnName: "decline", width: 160 },
  { columnName: "chief", width: 270 },
  { columnName: "chestGirth", width: 70 },
  { columnName: "waistGirth", width: 70 },
  { columnName: "hipGirth", width: 70 },
  { columnName: "clothesTopSize", width: 150 },
  { columnName: "clothesBottomSize", width: 150 },
  { columnName: "shoeSize", width: 120 },
  { columnName: "deactivate", width: 180 },
  { columnName: "profile", width: 180 },
  { columnName: "regionalManager", width: 200 },
  { columnName: "deactivatedBy", width: 270 },
  { columnName: "lastName", width: 150 },
  { columnName: "middleName", width: 150 },
  { columnName: "firstName", width: 150 },
  { columnName: "photoPreview", width: 120 },
  { columnName: "distanceStatus", width: 250 },
  { columnName: "taskTemplateName", width: 200 },
  { columnName: "lastModified", width: 250 },
  { columnName: "failReason", width: 250 }
];

export const roles = {
  "1": "Супер адмін",
  "2": "Центральний офіс “Моя вигода”",
  "3": "Менеджер торгівельних програм",
  "4": "Модератор",
  "5": "Центральний офіс BTL",
  "6": "Регіональний менеджер",
  "7": "Супервайзер",
  "8": "Продовольчий директор",
  "9": "Продавець",
  "10": "Консультант"
};

export const rolesOptions = [
  { value: 1, label: "Супер адмін" },
  { value: 2, label: "Центральний офіс “Моя вигода”" },
  { value: 3, label: "Менеджер торгівельних програм" },
  { value: 4, label: "Модератор" },
  { value: 5, label: "Центральний офіс BTL" },
  { value: 6, label: "Регіональний менеджер" },
  { value: 7, label: "Супервайзер" },
  { value: 8, label: "Продовольчий директор" },
  { value: 9, label: "Продавець" },
  { value: 10, label: "Консультант" }
];

export const accessOptions = [
  { value: 1, label: "Супер адмін", isFixed: true },
  { value: 5, label: "Центральний офіс BTL", isFixed: true },
  { value: 6, label: "Регіональний менеджер" },
  { value: 7, label: "Супервайзер" },
  { value: 10, label: "Консультант" }
];

export const totalStatusLabel = "Україна (Всього)";
/* eslint-disable id-length */
export const clothesSizes = {
  XS: 1,
  S: 2,
  M: 3,
  L: 4,
  XL: 5,
  XXL: 6
};

export const clothesSizesByKeys = {
  1: "XS",
  2: "S",
  3: "M",
  4: "L",
  5: "XL",
  6: "XXL"
};

export const consultantStatus = { "Постійний штат": true, Резерв: false };

const validationDefaults = { minLength: 2, maxLength: 10, minBonuses: 1, maxBonuses: 1000 };

export const validationErrorMessages = (values = validationDefaults) => {
  return {
    required: "Обов'язкове поле",
    tooShortName: `Поле повинно містити не менше ${values.minLength} символів`,
    tooLongName: `Поле повинно містити не бiльш нiж ${values.maxLength} символів`,
    positive: "Число повинно бути більше 0",
    maxPrice: `Максимальна ціна - ${Number.parseFloat(values.maxPrice).toFixed(2)} грн`,
    minPrice: `Мінімальна ціна - ${Number.parseFloat(values.minPrice).toFixed(2)} грн`,
    maxAmountMilligrams: `Максимальна кількість - ${values.maxAmountMilligrams} мг`,
    minDuration: "Тривалість зміни не повинна бути менше 30 хвилин",
    maxDuration: "Тривалість зміни не повинна перевищувати 16 годин",
    minBonuses: `Мінімальна кількість бонусів - ${values.minBonuses}`,
    maxBonuses: `Максимальна кількість бонусів - ${values.maxBonuses}`,
    notCorrectData: "Введіть коректні дані",
    notCorrectItn: "Невірний IНН",
    notCorrectPhone: "Невірний номер телефону"
  };
};

export const availableItemsPerPage = [10, 25, 50];

export const defaultItemsPerPage = 10;

export const completionTypeOptions = [
  {
    value: 1,
    label: "Завдання доступно 1 раз на ТТ"
  },
  {
    value: 2,
    label: "Завдання доступно 1 раз для кожного продавця"
  },
  {
    value: 3,
    label: "Завдання доступно багато разів"
  }
];

export const completionAdvertisingOptions = [
  {
    value: 1,
    label: "1 раз у період"
  }
];

export const toolbarOptions = {
  active: {
    value: "3",
    label: "Активні"
  },
  phoneChanged: {
    value: "5",
    label: "Зміна телефону"
  },
  notActive: {
    value: "4",
    label: "Деактивовані"
  }
};

export const userStatus = {
  pending: {
    value: "1",
    label: "Потенційні"
  },
  declined: {
    value: "2",
    label: "Відхиленi"
  },
  works: {
    value: "3",
    label: "Прийнятий"
  },
  fired: {
    value: "4",
    label: "Звiльнений"
  }
};

export const answerTypes = {
  "1": "Application",
  "2": "SMS"
};

export const shiftStatusMap = {
  "1": "Старт",
  "2": "В процесі",
  "3": "Перенесено",
  "4": "Відмінено",
  "5": "Відпрацьовано",
  "6": "Не відпрацьовано",
  "7": "Відпрацьовано частково"
};

export const shiftCancellationReasons = [
  { value: 1, label: "Hаявність OOS" },
  { value: 2, label: "Pобота конкурентів" },
  { value: 3, label: "Погодні умови" },
  { value: 4, label: "Лікарняний" },
  { value: 5, label: "Особисті обставини" },
  { value: 6, label: "Відсутність домовленостей про роботу" },
  { value: 7, label: "Інше" }
];

export const shiftCancellationReasonsMap = {
  "1": "Hаявність OOS",
  "2": "Pобота конкурентів",
  "3": "Погодні умови",
  "4": "Лікарняний",
  "5": "Особисті обставини",
  "6": "Відсутність домовленостей про роботу",
  "7": "Інше"
};

export const activityHistoryColumns = [
  { name: "changedBy", title: "Ким змінено" },
  { name: "timeStamp", title: "Коли змінено" },
  { name: "key", title: "Поле" },
  { name: "oldValue", title: "Попереднє значення" },
  { name: "newValue", title: "Нове значення" }
];

export const configByHistoryKey = {
  Chief: "Відповідальний",
  MiddleName: "По батькові",
  FirstName: "Ім'я",
  LastName: "Прізвище",
  UserStatusId: "Статус",
  Phone: "Телефон",
  Geo: "Населений пункт",
  EstimatedMainStateCount: "Основний штат",
  EstimatedReservedStateCount: "Резерв",
  Projects: "Проекти",
  Birthday: "Дата народження",
  WaistGirth: "Талія",
  ShoeSize: "Розмір взуття",
  ClothesTopSize: "Розміри: Верх",
  ClothesBottomSize: "Розміри: Низ",
  Height: "Зріст",
  HipGirth: "Розміри: Стегна",
  ChestGirth: "Розміри: Груди",
  Weight: "Вага",
  IsMainState: "Робочий статус",
  Images: "Фото",
  Gender: "Стать",
  PlannedEndDate: "Дата закінчення план",
  PlannedStartDate: "Дата початку план",
  PlannedPosId: "Код ТТ план"
};

export const taskTypesOptions = [
  { value: 1, label: "Завдання Замовлення" },
  { value: 2, label: "Завдання Фольга" },
  { value: 3, label: "Завдання Тестове" },
  { value: 4, label: "Завдання Інформаційне" },
  { value: 5, label: "Завдання Анкета" },
  { value: 6, label: "Завдання Фото" },
  { value: 7, label: "Завдання Тестове - Зворотній зв'язок" },
  { value: 8, label: "Завдання Відскануй код" },
  { value: 9, label: "Замовлення MID+" }
];

export const taskPhotoStatusOptions = [
  { value: 1, label: "Віддаленість від ТТ більше 100м " },
  { value: 2, label: "Віддаленість від ТТ менше 100м" },
  { value: 3, label: "У ТТ немає координат " }
];

export const taskPhotoStatusFormat = {
  "1": "Віддаленість від ТТ більше 100м",
  "2": "Віддаленість від ТТ менше 100м",
  "3": "У ТТ немає координат"
};
export const taskTypeFormat = {
  "1": "Завдання Замовлення",
  "2": "Завдання Фольга",
  "3": "Завдання Тестове",
  "4": "Завдання Інформаційне",
  "5": "Завдання Анкета",
  "6": "Завдання Фото",
  "7": "Завдання Тестове - Зворотній зв'язок",
  "8": "Завдання Відскануй код",
  "9": "Завдання Замовлення MID+"
};

export const taskTypeStringKey = {
  "Завдання Замовлення": "1",
  "Завдання Фольга": "2",
  "Завдання Тестове": "3",
  "Завдання Інформаційне": "4",
  "Завдання Анкета": "5",
  "Завдання Фото": "6",
  "Тест-зворотнiй звязок": "7",
  "Завдання Відскануй код": "8",
  "Завдання Замовлення MID+": "9"
};

export const errorMessages = {
  10001: "Некоректні дані",
  10004: "Не знайдено",
  10005: "Товар з таким кодом вже існує",
  10021: "Як мінімум один код торгової точки не знайдено",
  10016: "Такий номер телефону вже існує",
  10032: "Файл містить помилкові дані",
  10038: "Акаунт не знайдено",
  10044: "Консультант не активний",
  10046: "Загальна тривалість змін за день перевищує 16 годин",
  10047: "Некоректна дата початку",
  10048: "Некоректна тривалість зміни",
  10057: "Неможливо відмінити зміну",
  10027: "This account is not active.",
  10146: "The account ID provided is not Seller",
  10089: "У продавця не може бути бiльше 400 торговельних точок.",
  10116: "Торговельної точки не існує:",
  11777: "Товар з таким Кодом вже існує"
};

export const configByRoles = {
  superAdminConfig: 1,
  centralDepartmentIOSConfig: 5,
  regionalManagerIOSConfig: 6,
  supervisorIOSConfig: 7,
  consultantIOSConfig: 10
};

export const consultantsOptions = [
  { value: "1", label: "ПІБ Консультанта" },
  { value: "2", label: "Населений пункт" },
  { value: "3", label: "Телефон" },
  { value: "4", label: "ПIБ Відповідального" }
];

export const editConsultantsRequestsOptions = [
  { value: "1", label: "ПІБ Консультанта" },
  { value: "2", label: "Телефон" }
];

export const candidatesOptions = [
  { value: "1", label: "ПІБ Кандидата" },
  { value: "2", label: "Населений пункт" },
  { value: "3", label: "Телефон" },
  { value: "4", label: "ПIБ Відповідального" }
];

export const supervisorsOptions = [
  { value: "1", label: "ПІБ" },
  { value: "2", label: "Населений пункт" },
  { value: "3", label: "Телефон" }
];

export const offlineUsersOptions = [
  { value: "1", label: "Номер телефону" },
  { value: "2", label: "Код ТТ" },
  { value: "3", label: "Прiзвище" }
];

export const iosManagersOptions = [
  { value: "1", label: "ПІБ" },
  { value: "3", label: "Телефон" }
];

export const generalReportOptions = [
  { value: "PosCode", label: "Код ТТ" },
  { value: "AccountName", label: "ПIБ Консультанта" }
];

export const effectiveTimeReportOptions = [
  { value: "1", label: "Код ТТ" },
  { value: "2", label: "ПIБ Консультанта" }
];

export const changesReportOptions = [
  { value: "1", label: "Код ТТ" },
  { value: "2", label: "Проект" },
  { value: "3", label: "ПIБ Консультанта" },
  { value: "4", label: "ПIБ Відповідального" }
];
export const photoTaskOptions = [
  { value: "1", label: "ID" },
  { value: "3", label: "Прiзвище" },
  { value: "2", label: "Ім'я" },
  { value: "4", label: "По батьковi" },
  { value: "5", label: "Номер телефону" },
  { value: "6", label: "Код ТТ" },
  { value: "7", label: "Населений пункт" },
  { value: "9", label: "Назва завдання" }
];

export const complimentsSearchOptions = [{ value: "1", label: "Код ТТ" }];

export const testTaskAnswerTypes = [
  { value: "1", label: "Варіанти відповідей" },
  { value: "4", label: "Відповідь з клавіатури" }
];

export const feedbackTaskAnswerTypes = [
  { value: "1", label: "Варіанти відповідей" },
  { value: "4", label: "Відповідь з клавіатури" },
  { value: "2", label: "Варіанти відповідей та відповідь з клавіатури" }
];

export const certificatesSearchOptions = [
  { value: "1", label: "ID" },
  { value: "2", label: "Баркод" },
  { value: "3", label: "Номер телефону" }
];

// eslint-disable-next-line
export const photoTaskDefaultUrl = `/sales/photo-task/?page=1&count=${defaultItemsPerPage}&tab=1&start=${moment()
  .subtract(1, "months")
  .startOf("day")
  .format("DD/MM/YYYY")}&end=${moment()
  .endOf("day")
  .format("DD/MM/YYYY")}&searchField=${photoTaskOptions[0].value}`;

export const questionnaireReportSearchOptions = [
  { value: "Project", label: "Проект" },
  { value: "City", label: "Населений пункт" },
  { value: "AccountName", label: "ПIБ Консультанта" }
];

export const photoTaskStatus = {
  pending: {
    value: "1",
    label: "Потенційні"
  },
  approved: {
    value: "2",
    label: "Завершені"
  },
  declined: {
    value: "3",
    label: "Новi"
  }
};

export const userStatusConfig = {
  1: "Потенційний кандидат",
  2: "Відхилений кандидат",
  3: "Активний",
  4: "Деактивований",
  5: "Зміна телефону"
};

export const bonusReportSearchOptions = [
  { value: "AccountId", label: "ID" },
  { value: "FullName", label: "ПІБ" },
  { value: "Phone", label: "Телефон" },
  { value: "PosCode", label: "Код ТТ" }
];

const googleMapApiKey =
  process.env.NODE_ENV === "production"
    ? "AIzaSyCYjSUqMXKtfI5hJF_DkpZS5axV8G51k3A"
    : "AIzaSyCPgdbnHj8JMiNOe6gBSfrcZ6Z81DNPJGA";

export const googleMapKey = `https://maps.googleapis.com/maps/api/js?key=${googleMapApiKey}&v=3.exp&libraries=geometry,drawing,places`;

export const ordersSearchOptions = [
  { value: "FullName", label: "ПІБ" },
  { value: "PosCode", label: "Код ТТ" },
  { value: "Phone", label: "Номер телефону" }
];

export const listOfSalesUsersOptions = [
  { value: "1", label: "ПІБ" },
  { value: "2", label: "Населений пункт" },
  { value: "3", label: "Код ТТ" },
  { value: "4", label: "Номер телефону" }
];

export const taskDetailsReportSearchOptions = [
  { value: "FullName", label: "ПІБ" },
  { value: "Phone", label: "Номер телефону" },
  { value: "PosCode", label: "Код ТТ" },
  { value: "AccountId", label: "ID користувача" }
];

export const warehouseTypeConfig = {
  "0": "Резервний",
  "1": "Основний",
  "2": "Додатковий"
};

export const imageSizeLimit = 10485760;
export const imageSizeErrorMessage = "Перевищено допустимий ліміт: 10Мб";

export const videoSizeLimit = 26214400;
export const videoSizeErrorMessage = "Перевищено допустимий ліміт: 25Мб";

export const advertisingPreviewSizeLimit = 2621440;
export const advertisingPreviewErrorMessage = "Перевищено допустимий ліміт: 2,5Мб";

export const taskQuestionnaireAnswerTypesConfig = {
  manualNumbers: 5,
  radio: 1
};

export const itemTypes = {
  Product: "Product",
  Section: "Section"
};
