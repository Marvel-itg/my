import { all, fork } from "redux-saga/effects";
// sales
import usersListSalesSaga from "./sales/usersListSales";
import offlineUsersListSaga from "./sales/offlineUsersList";
import ordersListSalesSaga from "./sales/ordersListSales";
import tasksListSalesSaga from "./sales/tasksListSales";
import scanCodesUploadSaga from "./sales/scanCodesUpload";
import detailsByTasksSaga from "./sales/detailsByTasks";
import photoTasksListSaga from "./sales/photoTasks";
import aboutCompanySaga from "./sales/aboutCompany";
import pricesSaga from "./sales/pricesListSales";
import exchangeRequestsSaga from "./sales/exchangeRequestsListSales";
import exchangeToGiftRequestsSaga from "./sales/exchangeToGiftRequests";
import tradeProgramManagersSaga from "./sales/tradeProgramManagersSaga";
import tradeProgramManagerProfileSaga from "./sales/managerProfile";
import moderatorsListSalesSaga from "./sales/moderatorsListSales";
import moderatorProfileSaga from "./sales/moderatorProfile";
import inboxListSalesSaga from "./sales/inboxListSales";
import bonusReportsSaga from "./sales/bonusReportsSales";
import complimentsReportSaga from "./sales/complimentsReport";
import usersInfoListSaga from "./sales/usersInfoList";
import statisticsByTasksSaga from "./sales/statisticsByTasksList";
import brands from "./sales/brands";
import centralDepartmentSaga from "./sales/centralDepartmentList";
import centralDepartmentProfileSaga from "./sales/centralDepartmentProfile";
import scheduleForShipmentSaga from "./sales/scheduleForShipment";
import manageBonusesSaga from "./sales/manageBonuses";
import advertisingSaga from "./sales/advertising";
import superAdminsSaga from "./sales/superAdminsList";
import uploadComplimentsSaga from "./sales/uploadCompliments";
import certificatesSaga from "./sales/certificates";
import generateScanCodesSaga from "./sales/generateScanCodes";
import midPlusProgressSaga from "./sales/midPlusProgress";
import getNewCertificatesSaga from "./sales/getCertificates";
import brandSettingsSaga from "./admin/brandSettings";
// promoters
import materialsListSaga from "./promoters/materialsList";
import reportSaga from "./promoters/report";
import generalReportSaga from "./promoters/generalReport";
import effectiveTimeReportSaga from "./promoters/effectiveTimeReport";
import candidatesSaga from "./promoters/candidatesList";
import statusSaga from "./promoters/status";
import supervisorsSaga from "./promoters/supervisorsList";
import managersSaga from "./promoters/regionalManagerProfile";
import regionalManagersList from "./promoters/regionalManagersList";
import supervisorProfileSaga from "./promoters/supervisorProfile";
import centralDepartmentListSaga from "./promoters/centralDepartmentManagersList";
import centralDepartmentProfilePromoterSaga from "./promoters/centralDepartmentProfile";
import shifts from "../sagas/promoters/shifts";
import questionnairesReportsSaga from "./promoters/questionnairesReports";
import expandedTables from "./promoters/expandedTables";
import questionnaireSaga from "./promoters/questionnaire";
import editRequestDetailsSaga from "./promoters/editRequestDetails";
import changesReportSaga from "./promoters/changesReport";

// common
import authenticationSaga from "./common/authenticationSaga";
import imagesSaga from "./common/images";
import geoSaga from "./common/geo";
import importData from "./common/import";
import projectsSaga from "./common/projects";

export default function* root() {
  yield all([
    fork(authenticationSaga),
    fork(usersListSalesSaga),
    fork(offlineUsersListSaga),
    fork(ordersListSalesSaga),
    fork(reportSaga),
    fork(aboutCompanySaga),
    fork(tasksListSalesSaga),
    fork(scanCodesUploadSaga),
    fork(detailsByTasksSaga),
    fork(inboxListSalesSaga),
    fork(materialsListSaga),
    fork(candidatesSaga),
    fork(supervisorsSaga),
    fork(imagesSaga),
    fork(statusSaga),
    fork(supervisorProfileSaga),
    fork(managersSaga),
    fork(regionalManagersList),
    fork(geoSaga),
    fork(pricesSaga),
    fork(exchangeRequestsSaga),
    fork(exchangeToGiftRequestsSaga),
    fork(tradeProgramManagersSaga),
    fork(tradeProgramManagerProfileSaga),
    fork(moderatorsListSalesSaga),
    fork(moderatorProfileSaga),
    fork(bonusReportsSaga),
    fork(complimentsReportSaga),
    fork(usersInfoListSaga),
    fork(statisticsByTasksSaga),
    fork(centralDepartmentSaga),
    fork(centralDepartmentProfileSaga),
    fork(brands),
    fork(centralDepartmentListSaga),
    fork(centralDepartmentProfilePromoterSaga),
    fork(importData),
    fork(projectsSaga),
    fork(shifts),
    fork(questionnairesReportsSaga),
    fork(photoTasksListSaga),
    fork(expandedTables),
    fork(questionnaireSaga),
    fork(editRequestDetailsSaga),
    fork(generalReportSaga),
    fork(effectiveTimeReportSaga),
    fork(scheduleForShipmentSaga),
    fork(manageBonusesSaga),
    fork(advertisingSaga),
    fork(superAdminsSaga),
    fork(changesReportSaga),
    fork(uploadComplimentsSaga),
    fork(certificatesSaga),
    fork(generateScanCodesSaga),
    fork(midPlusProgressSaga),
    fork(getNewCertificatesSaga),
    fork(brandSettingsSaga)
  ]);
}
