// @flow
import { combineReducers } from "redux";
import { reducer as formReducer } from "redux-form";
import { connectRouter } from "connected-react-router";
import type { BrowserHistory } from "history";

// sales
import usersListSales from "./sales/usersListSales";
import offlineUsersList from "./sales/offlineUsersList";
import ordersListSales from "./sales/ordersListSales";
import brands from "./sales/brands";
import exchangeRequestsList from "./sales/exchangeRequestsListSales";
import exchangeToGiftRequestsList from "./sales/exchangeToGiftRequests";
import tasksListSales from "./sales/tasksListSales";
import scanCodesUpload from "./sales/scanCodesUpload";
import detailsByTasksList from "./sales/detailsByTasks";
import photoTaskList from "./sales/photoTaskList";
import aboutCompanySales from "./sales/aboutCompanySales";
import inboxListSales from "./sales/inboxListSales";
import bonusReports from "./sales/bonusReportsSales";
import complimentsReport from "./sales/complimentsReport";
import usersInfoList from "./sales/usersInfoList";
import centralDepartmentReducer from "./sales/centralDepartmentList";
import centralDepartmentProfile from "./sales/centralDepartmentProfile";
import moderatorProfile from "./sales/moderatorProfile";
import moderatorsListSales from "./sales/moderatorsListSales";
import statisticsByTasks from "./sales/statisticsByTasksList";
import pricesList from "./sales/pricesListSales";
import tradeProgramManagerProfile from "./sales/tradeProgramManagerProfile";
import tradeProgramManagerReducer from "./sales/tradeProgramManagersListSales";
import scheduleForShipment from "./sales/scheduleForShipment";
import manageBonuses from "./sales/manageBonuses";
import advertising from "./sales/advertising";
import superAdminsReducer from "./sales/superAdminsList";
import uploadCompliments from "./sales/uploadCompliments";
import certificates from "./sales/certificates";
import generateScanCodes from "./sales/generateScanCodes";
import midPlusProgress from "./sales/midPlusProgress";
import getNewCertificates from "./sales/getCertificates";

// promoters
import materialsList from "./promoters/materialsList";
import candidatesListPromoters from "./promoters/candidatesList";
import supervisorsList from "./promoters/supervisorsList";
import statusList from "./promoters/status";
import managerProfile from "./promoters/regionalManager";
import supervisorProfile from "./promoters/supervisorProfile";
import regionalManagersList from "./promoters/regionalManagersList";
import report from "./promoters/report";
import generalReport from "./promoters/generalReport";
import effectiveTimeReport from "./promoters/effectiveTimeReport";
import centralDepartmentManagersList from "./promoters/centralDepartmentManagersList";
import centralDepartmentProfilePromoter from "./promoters/centralDepartmentProfile";
import expandedTablesReducer from "./promoters/expandedTables";
import shifts from "./promoters/shifts";
import questionnairesReports from "./promoters/questionnairesReports";
import questionnaire from "./promoters/questionnaire";
import editRequestDetails from "./promoters/editRequestsDetails";
import changesReport from "./promoters/changesReport";

// common
import authenticationReducer from "./common/authentication";
import images from "./common/images";
import geoReducer from "./common/geo";
import importData from "./common/import";
import modals from "./common/modals";
import projects from "./common/projects";
import brandSettings from "./admin/brandSettings";

// FixMe: need more specific type for result
const reducers = (history: BrowserHistory): any =>
  combineReducers({
    router: connectRouter(history),
    authenticationReducer,
    aboutCompanySales,
    usersListSales,
    offlineUsersList,
    inboxListSales,
    materialsList,
    ordersListSales,
    report,
    tasksListSales,
    detailsByTasksList,
    scanCodesUpload,
    candidatesListPromoters,
    supervisorsList,
    images,
    status: statusList,
    supervisorProfile,
    form: formReducer,
    managerProfile,
    regionalManagersList,
    geoReducer,
    brands,
    pricesList,
    exchangeRequestsList,
    exchangeToGiftRequestsList,
    tradeProgramManagerProfile,
    tradeProgramManagerReducer,
    moderatorProfile,
    bonusReports,
    complimentsReport,
    usersInfoList,
    statisticsByTasks,
    moderatorsListSales,
    centralDepartmentReducer,
    centralDepartmentProfile,
    modals,
    centralDepartmentManagersList,
    centralDepartmentProfilePromoter,
    importData,
    projects,
    shifts,
    questionnairesReports,
    questionnaire,
    photoTaskList,
    expandedTablesReducer,
    editRequestDetails,
    generalReport,
    effectiveTimeReport,
    scheduleForShipment,
    manageBonuses,
    advertising,
    superAdminsReducer,
    changesReport,
    uploadCompliments,
    certificates,
    generateScanCodes,
    midPlusProgress,
    getNewCertificates,
    brandSettings
  });

export default reducers;
