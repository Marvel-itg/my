// @flow
import React from "react";
import { connect } from "react-redux";
import type { BrowserHistory } from "history";
import CircularProgress from "@material-ui/core/CircularProgress";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import BackButton from "../../components/Buttons/BackButton/BackButton";
import DestructiveButton from "../../components/Buttons/DestructiveButton/DestructiveButton";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import DeactivateForm from "../../components/DeactivateForm/DeactivateForm";
import Modal from "../../components/Modal/Modal";
import EditRequestsTable from "./EditRequestTable";
import {
  receiveEditRequestDetails,
  approveEditRequest,
  declineEditRequest
} from "../../store/actions/promoters/editRequestsDetails";
import { openModal, closeModal } from "../../store/actions/common/modals";
import { errorDecliningState, editRequestChanges } from "../../store/selectors/promoters/editCandidatesRequests";
import { classes } from "../../helpers/spinner";
import styles from "./EditRequests.module.scss";

type PropsT = {
  openModal: Function,
  closeModal: Function
} & BrowserHistory;

type StateT = {
  modalType: string,
  modalBody: any
};

class EditRequestsPage extends React.Component<PropsT, StateT> {
  state = {
    isModalOpened: false,
    modalType: "",
    modalBody: <div />
  };

  componentDidMount() {
    const { id } = this.props.match.params;
    if (id) {
      this.props.receiveEditRequestDetails(id);
    }
  }

  approveRequest = () => {
    const { id } = this.props.match.params;
    if (id) {
      this.props.approveEditRequest({ id: this.props.match.params.id, isApproved: true });
    }
  };

  declineRequest = () => this.openModal("decline");

  submitDeclineForm = ({ comment }) => {
    const { id } = this.props.match.params;
    if (id) {
      this.props.declineEditRequest({ id, comment, isApproved: false });
    }
  };

  openModal = type => {
    switch (type) {
      case "decline": {
        const modalBody = (
          <DeactivateForm
            form="DeclineEditParamsRequest"
            title="Відхилити запит?"
            textFieldLabel="Додати коментар"
            textFieldName="comment"
            submitButtonText="Так"
            cancelButtonText="Ні"
            cancelButtonHandler={this.props.closeModal}
            submitForm={values => this.submitDeclineForm(values)}
            errorState={errorDecliningState}
          />
        );
        this.setState({ modalBody, modalType: "deactivate" });
        return this.props.openModal();
      }
      default:
        return null;
    }
  };

  goBack = () => this.props.history.goBack();

  render() {
    const { data, errorMessage, editedParams, loading } = this.props;
    return (
      <div className={styles.formWrapper}>
        <BackButton label="Повернутися назад" handleClick={this.goBack} className={styles.backButtonStyles} />
        <h3 className={styles.dialogTitle}>Деталі запиту</h3>
        <div className={styles.detailsWrapper}>
          <span className={styles.detailsTitle}>ПІБ консультанта: </span>
          <span className={styles.detailsDescription}>{data.fullName}</span>
        </div>
        <EditRequestsTable data={editedParams} />
        <form className={styles.buttonsWrapper}>
          <ContainedButton
            type="button"
            label="Підтвердити"
            className={styles.button}
            handleClick={this.approveRequest}
          />
          <DestructiveButton
            type="button"
            label="Відхилити"
            className={styles.button}
            handleClick={this.declineRequest}
          />
        </form>
        {errorMessage && <ErrorMessage error={errorMessage} />}
        {loading && <CircularProgress classes={classes} />}
        <Modal type={this.state.modalType}>{this.state.modalBody}</Modal>
      </div>
    );
  }
}

const mapStateToProps = state => {
  const {
    editRequestDetails: { data, error, loading }
  } = state;
  const editedParams = editRequestChanges(state);
  return {
    data,
    editedParams,
    errorMessage: error,
    loading
  };
};

const mapDispatchToProps = {
  openModal,
  closeModal,
  receiveEditRequestDetails,
  approveEditRequest,
  declineEditRequest
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(EditRequestsPage);
