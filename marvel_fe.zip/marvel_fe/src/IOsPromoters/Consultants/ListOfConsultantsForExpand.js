// @flow
import React from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper";
import Modal from "../../components/Modal/Modal";
import CandidatesTable from "../Candidates/CandidatesTableForExpand";
import DeactivateForm from "../../components/DeactivateForm/DeactivateForm";
import { deactivateConsultant } from "../../store/actions/promoters/expandedTablesActions.js";
import { openModal, closeModal } from "../../store/actions/common/modals";

type PropsT = {
  consultantsList: CandidateT[],
  deactivateCandidate: Function,
  openModal: Function,
  closeModal: Function
} & BrowserHistory;

type StateT = {
  modalType: string,
  modalBody: any
};

const commonColumns = [
  { name: "profilePicture", title: "Аватар" },
  { name: "id", title: "ID" },
  { name: "lastName", title: "Прiзвище" },
  { name: "firstName", title: "Ім'я" },
  { name: "middleName", title: "По батьковi" },
  { name: "geos", title: "Населений пункт" },
  { name: "birthday", title: "Дата народження" },
  { name: "phone", title: "Номер телефону" },
  { name: "gender", title: "Стать" },
  { name: "height", title: "Зріст" },
  { name: "clothesTopSize", title: "Розмір одягу(верх)" },
  { name: "shoeSize", title: "Розмір взуття" }
];

const managersColumns = [
  ...commonColumns,
  { name: "workStartedDate", title: "Старт роботи" },
  { name: "isMainState", title: "Cтатус" },
  { name: "projects", title: "Проект" },
  { name: "chief", title: "Відповідальний" },
  { name: "details", title: "Деталі профілю" },
  { name: "deactivate", title: "Деактивувати" }
];

class ListOfConsultants extends React.PureComponent<PropsT, StateT> {
  state = {
    modalType: "",
    modalBody: <div />
  };

  openDetails = (id: number) => {
    this.props.history.push(`/promoters/consultants/${id || 1}`);
  };

  submitDeactivateForm = ({ comment }, accountId) => {
    this.props.deactivateConsultant({ accountId, comment });
  };

  deactivateConsultant = id => {
    this.openModal("deactivate", id);
  };

  openModal = (type, id) => {
    switch (type) {
      case "deactivate": {
        const modalBody = (
          <DeactivateForm
            form="DeactivateConsultantPromoters"
            title="Деактивувати консультанта?"
            textFieldLabel="Додати коментар"
            textFieldName="comment"
            submitButtonText="Деактивувати"
            cancelButtonText="Ні"
            cancelButtonHandler={this.props.closeModal}
            submitForm={values => this.submitDeactivateForm(values, id)}
            errorState={this.props.errorDeactivating}
          />
        );
        this.setState({ modalBody, modalType: "deactivate" });
        return this.props.openModal(this.props.name);
      }
      default:
        return null;
    }
  };

  render() {
    const { consultantsList, user } = this.props;

    const columns = managersColumns;
    return (
      <React.Fragment>
        <Paper square className="mainContent">
          <CandidatesTable
            data={consultantsList}
            columns={columns}
            openModal={this.openModal}
            deactivate={this.deactivateConsultant}
            openDetails={this.openDetails}
            user={user}
          />
        </Paper>

        {this.props.name === this.props.modalName && <Modal type={this.state.modalType}>{this.state.modalBody}</Modal>}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    modals: { modalName },
    authenticationReducer: { user }
  } = state;
  return {
    user,
    modalName
  };
};

const mapDispatchToProps = {
  deactivateConsultant,
  openModal,
  closeModal
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(ListOfConsultants);
