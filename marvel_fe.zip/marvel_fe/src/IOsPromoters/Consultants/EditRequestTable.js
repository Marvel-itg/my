// @flow
import React from "react";
import { Grid, Table, TableHeaderRow } from "@devexpress/dx-react-grid-material-ui";
import Paper from "@material-ui/core/Paper";
import GridRoot from "../../components/TableComponents/GridRoot";
import { HistoryKeyProvider } from "../../components/FormattedData/FormattedData";
import styles from "./EditRequests.module.scss";

type PropsT = {
  data: EditedParamT[]
};

const columns = [
  { name: "key", title: "Параметр" },
  { name: "oldValue", title: "Попереднє значення" },
  { name: "newValue", title: "Нове значення" }
];

const forValues = {
  key: ["key"]
};

const EditRequestsTable = (props: PropsT) => {
  return (
    <Paper classes={{ root: styles.tableWrapper }}>
      <Grid rows={props.data} columns={columns} rootComponent={GridRoot}>
        <HistoryKeyProvider for={forValues.key} />
        <Table />
        <TableHeaderRow />
      </Grid>
    </Paper>
  );
};

export default EditRequestsTable;
