// @flow
import React from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import debounce from "es6-promise-debounce";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import Modal from "../../components/Modal/Modal";
import CandidatesTable from "../Candidates/CandidatesTable";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import DeactivateForm from "../../components/DeactivateForm/DeactivateForm";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import {
  receiveCandidates,
  editCandidate,
  activateCandidate,
  deactivateCandidate,
  exportToCsvConsultants
} from "../../store/actions/promoters/candidatesList.js";
import { openModal, closeModal } from "../../store/actions/common/modals";
import {
  candidatesListRowsCountSelector,
  candidatesListSelector,
  errorCandidatesListState
} from "../../store/selectors/promoters/candidates";
import { formatFormValues } from "../Candidates/helpers";
import { classes } from "../../helpers/spinner";
import { getCommonParams, getSearchQuery, shouldNotSendRequest } from "../../helpers/common";
import { defaultItemsPerPage, consultantsOptions, editConsultantsRequestsOptions } from "../../constants";
import styles from "../Candidates/ListOfCandidates/ListOfCandidates.module.scss";

type PropsT = {
  receiveCandidates: Function,
  candidatesList: CandidateT[],
  history: BrowserHistory,
  editCandidate: Function,
  activateCandidate: Function,
  deactivateCandidate: Function,
  submitted: boolean,
  loading: boolean,
  user: any,
  isExpandable?: boolean,
  columns: ColumnsT,
  withAdditions: boolean,
  openModal: Function,
  closeModal: Function,
  rowsCount: number
} & BrowserHistory;

type StateT = {
  modalType: string,
  modalBody: any
};

const tabs = [
  { label: "Активні", value: "3" },
  { label: "Зміна телефону", value: "5" },
  { label: "Деактивовані", value: "4" },
  { label: "Редагування параметрiв", value: "6" }
];

const commonColumns = [
  { name: "profilePicture", title: "Аватар" },
  { name: "id", title: "ID" },
  { name: "lastName", title: "Прiзвище" },
  { name: "firstName", title: "Ім'я" },
  { name: "middleName", title: "По батьковi" },
  { name: "geos", title: "Населений пункт" },
  { name: "birthday", title: "Дата народження" },
  { name: "phone", title: "Номер телефону" },
  { name: "gender", title: "Стать" },
  { name: "height", title: "Зріст" },
  { name: "clothesTopSize", title: "Розмір одягу(верх)" },
  { name: "clothesBottomSize", title: "Розмір одягу(низ)" },
  { name: "shoeSize", title: "Розмір взуття" }
];

const managersColumns = {
  "3": [
    ...commonColumns,
    { name: "workStartedDate", title: "Старт роботи" },
    { name: "isMainState", title: "Робочий статус" },
    { name: "projects", title: "Проект" },
    { name: "chief", title: "Відповідальний" },
    { name: "details", title: "Деталі профілю" },
    { name: "deactivate", title: "Деактивувати" }
  ],
  "4": [
    ...commonColumns,
    { name: "deactivationDate", title: "Дата деактивації" },
    { name: "deactivatedBy", title: "Дeaктивовано" },
    { name: "comment", title: "Коментар" },
    { name: "details", title: "Деталі профілю" },
    { name: "activate", title: "Aктивувати" }
  ],
  "5": [...commonColumns, { name: "details", title: "Деталі профілю" }],
  "6": [
    { name: "fullName", title: "ПІБ консультанта" },
    { name: "createdOn", title: "Дата та час запиту" },
    { name: "phone", title: "Номер телефону" },
    { name: "editRequestDetails", title: "Деталі" }
  ]
};

const modalName = "ConsultantForm";

class ListOfConsultants extends React.PureComponent<PropsT, StateT> {
  state = {
    modalType: "",
    modalBody: <div />
  };

  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;
    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }

    if (!prevProps.deactivated && this.props.deactivated) {
      this.props.history.push(`?page=1&count=${defaultItemsPerPage}&tab=3`);
    }
  }

  fetchData = debounce(() => {
    const { searchValue, searchFieldName, itemsOnPage, pageNumber, tab } = getCommonParams(this.props.location.search);
    let params = { ItemsOnPage: itemsOnPage, PageNumber: pageNumber, Status: tab };
    if (searchValue) {
      params = { ...params, SearchField: searchFieldName, SearchValue: searchValue };
    }
    this.props.receiveCandidates(params);
  }, 200);

  openDetails = (id: number) => {
    this.props.history.push(`/promoters/consultants/${id || 1}`);
  };

  submitForm = values => {
    const formatted = formatFormValues(values);
    this.props.editCandidate(formatted);
  };

  submitDeactivateForm = ({ comment }, accountId) => {
    this.props.deactivateCandidate({ accountId, comment });
  };

  exportToCsvConsultants = () => {
    const { searchFieldName, tab, searchValue } = getCommonParams(this.props.location.search);
    let params = { Status: tab };
    if (searchValue) {
      params = { ...params, SearchField: searchFieldName, SearchValue: searchValue };
    }
    this.props.exportToCsvConsultants(params);
  };

  changeTab = (event: any, tab: string) => {
    const { searchField, searchValue, start, end, count } = getSearchQuery(this.props.location.search);
    const { tab: prevTab } = getCommonParams(this.props.location.search);
    if (prevTab === "6" || tab === "6") {
      this.props.history.push(
        // eslint-disable-next-line
        `?page=${1}${count}&tab=${tab}${start}${end}&searchField=${consultantsOptions[0].value}`
      );
    } else {
      this.props.history.push(
        // eslint-disable-next-line
        `?page=${1}${count}&tab=${tab}${start}${end}${searchField}${searchValue}`
      );
    }
  };

  openEditRequestDetails = id => this.props.history.push(`/promoters/consultants/edit-requests/${id || 1}`);

  deactivateCandidate = id => {
    this.openModal("deactivate", id);
  };

  activateCandidate = id => this.props.activateCandidate(id, "Consultant");

  openModal = (type, id) => {
    switch (type) {
      case "deactivate": {
        const modalBody = (
          <DeactivateForm
            form="DeactivateConsultantPromoters"
            title="Деактивувати консультанта?"
            textFieldLabel="Додати коментар"
            textFieldName="comment"
            submitButtonText="Деактивувати"
            cancelButtonText="Ні"
            cancelButtonHandler={this.props.closeModal}
            submitForm={values => this.submitDeactivateForm(values, id)}
            errorState={errorCandidatesListState}
          />
        );
        this.setState({ modalBody, modalType: "deactivate" });
        return this.props.openModal(modalName);
      }
      default:
        return null;
    }
  };

  render() {
    const { loading, candidatesList, rowsCount, user, uploading, uploadingError } = this.props;
    const { tab } = getCommonParams(this.props.location.search);
    const filterOptions = tab === "6" ? editConsultantsRequestsOptions : consultantsOptions;
    // const columns = user && user.accountType === 5 ? managersColumns : supervisorsColumns;
    const columns = managersColumns;
    return (
      <React.Fragment>
        {tab === "3" && (
          <>
            <ContainedButton
              type="button"
              label="Вивантажити CSV"
              className={styles.uploadButton}
              handleClick={this.exportToCsvConsultants}
              loading={uploading}
              disabled={uploading || loading}
            />
            {uploadingError && (
              <ErrorMessage error={uploadingError} textAlign="right" className={styles.errorMessage} />
            )}
          </>
        )}
        <Paper square className="mainContent">
          <CandidatesTable
            data={candidatesList}
            rowsCount={rowsCount}
            activeTab={tab || "3"}
            columns={columns[tab || "3"]}
            changeTab={this.changeTab}
            openModal={this.openModal}
            activate={this.activateCandidate}
            deactivate={this.deactivateCandidate}
            openDetails={this.openDetails}
            filterOptions={filterOptions}
            tabs={tabs}
            user={user}
            openEditRequestDetails={this.openEditRequestDetails}
          />
        </Paper>

        {loading && <CircularProgress classes={classes} />}
        {modalName === this.props.modalName && (
          <Modal type={this.state.modalType} formName="ConsultantForm">
            {this.state.modalBody}
          </Modal>
        )}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    candidatesListPromoters: { submitting, loading, activating, deactivating, deactivated, uploading, uploadingError },
    authenticationReducer: { user },
    modals: { modalName }
  } = state;
  return {
    candidatesList: candidatesListSelector(state),
    rowsCount: candidatesListRowsCountSelector(state),
    deactivated,
    loading: loading || submitting || deactivating || activating,
    user,
    modalName,
    uploading,
    uploadingError
  };
};

const mapDispatchToProps = {
  receiveCandidates,
  editCandidate,
  activateCandidate,
  deactivateCandidate,
  openModal,
  closeModal,
  exportToCsvConsultants
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(ListOfConsultants);
