// @flow
import React from "react";
import { SummaryState, IntegratedSummary, PagingState, IntegratedPaging } from "@devexpress/dx-react-grid";
import { Grid, Table, TableHeaderRow, TableSummaryRow } from "@devexpress/dx-react-grid-material-ui";
import TableContainerComponent from "../../../components/TableComponents/TableContainerComponent";
import PagingPanel from "../../../components/TableComponents/PagingPanel";
import GridRoot from "../../../components/TableComponents/GridRoot";
import { totalStatusLabel, availableItemsPerPage, defaultItemsPerPage } from "../../../constants";
import styles from "./StatusTable.module.scss";

type PropsT = {
  data: StatusT[]
};

type SummaryT = {
  columnName: string,
  type: string
};

type StateT = {
  totalSummaryItems: Array<SummaryT>,
  currentPage: number,
  pageSize: number,
  pageSizes: Array<number>
};

const columns = [
  { name: "supervisor", title: "Супевайзер" },
  { name: "regionalManager", title: "Регіональний менеджер" },
  { name: "region", title: "Регіон" },
  { name: "city", title: "Населений пункт" },
  { name: "planPermanentHeadquarters", title: "План: постійний штат" },
  { name: "planReserve", title: "План: резерв" },
  { name: "factPermanentHeadquarters", title: "Факт: постійний штат" },
  { name: "factReserve", title: "Факт: резерв" }
];

const formatlessSummaryType = "totalLabel";

const summaryCalculator = (type, rows, getValue) => {
  if (type === formatlessSummaryType) {
    return totalStatusLabel;
  }
  return IntegratedSummary.defaultCalculator(type, rows, getValue);
};

const renderSummaryItem = props => {
  const { children } = props;

  if (children[2]) {
    return <span className={styles.totalRow}>{children[2]}</span>;
  }
  return <TableSummaryRow.Item {...props} />;
};

const formatlessSummaryTypes = [formatlessSummaryType];

export default class StatusTable extends React.Component<PropsT, StateT> {
  state = {
    totalSummaryItems: [
      { columnName: "supervisor", type: formatlessSummaryType },
      { columnName: "planPermanentHeadquarters", type: "sum" },
      { columnName: "planReserve", type: "sum" },
      { columnName: "factPermanentHeadquarters", type: "sum" },
      { columnName: "factReserve", type: "sum" }
    ],
    pageSize: defaultItemsPerPage,
    pageSizes: availableItemsPerPage,
    currentPage: 0
  };

  changeCurrentPage = (currentPage: number) => this.setState({ currentPage });

  changePageSize = (pageSize: number) => this.setState({ pageSize });

  render() {
    const { pageSize, pageSizes, currentPage } = this.state;
    return (
      <Grid rows={this.props.data} columns={columns} rootComponent={GridRoot}>
        <SummaryState totalItems={this.state.totalSummaryItems} />
        <PagingState
          currentPage={currentPage}
          onCurrentPageChange={this.changeCurrentPage}
          pageSize={pageSize}
          onPageSizeChange={this.changePageSize}
        />

        <IntegratedPaging />
        <IntegratedSummary calculator={summaryCalculator} />

        <Table containerComponent={TableContainerComponent} />
        <TableHeaderRow />
        <TableSummaryRow formatlessSummaryTypes={formatlessSummaryTypes} itemComponent={renderSummaryItem} />

        <PagingPanel pageSizes={pageSizes} noData={!this.props.data.length} />
      </Grid>
    );
  }
}
