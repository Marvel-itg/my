// @flow
import React from "react";
import moment from "moment";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { compose } from "redux";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import StatusTable from "./StatusTable/StatusTable";
import Toolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import { fetchStatus, exportStatusCSV } from "../../store/actions/promoters/status";
import { classes } from "../../helpers/spinner";

type PropsT = {
  fetchStatus: Function,
  exportStatusCSV: Function,
  status: StatusT[],
  history: BrowserHistory,
  loading: boolean,
  uploading: boolean
};

class Status extends React.Component<PropsT> {
  componentDidMount() {
    this.props.fetchStatus();
  }

  filterByDate = rangeFilter => {
    this.props.fetchStatus(rangeFilter);
  };

  exportCSV = () => {
    // pass data as param for export
    this.props.exportStatusCSV();
  };

  render() {
    const { loading, uploading } = this.props;
    const spinner = loading || uploading;
    const rangeFilterInitial = {
      startDate: moment()
        .subtract(1, "months")
        .startOf("day")
        .format("DD/MM/YYYY"),
      endDate: moment()
        .endOf("day")
        .format("DD/MM/YYYY")
    };
    return (
      <React.Fragment>
        <Toolbar
          form="statusDateFilter"
          initialValues={rangeFilterInitial}
          filterData={this.filterByDate}
          loadHandler={this.exportCSV}
        />
        <Paper square className="mainContent">
          <StatusTable data={this.props.status || []} />
        </Paper>
        {spinner && <CircularProgress classes={classes} />}
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({ status: { status, loading, uploading } }) => ({
  status,
  loading,
  uploading
});

const mapDispatchToProps = {
  fetchStatus,
  exportStatusCSV
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(Status);
