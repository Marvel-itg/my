// @flow
import React from "react";
import { withRouter } from "react-router-dom";
import { Grid, Table, TableHeaderRow, TableBandHeader, TableRowDetail } from "@devexpress/dx-react-grid-material-ui";
import { RowDetailState } from "@devexpress/dx-react-grid";
import { memoize } from "lodash";

import {
  PhoneProvider,
  CityProvider,
  PersonInfoProvider,
  TransparentButtonProvider,
  DestructiveButtonProvider
} from "../../../components/FormattedData/FormattedData";
import { columnExtensions } from "../../../constants";
import type { BrowserHistory } from "history";
import GridRoot from "../../../components/TableComponents/GridRoot";
import TableContainer from "../../../components/TableComponents/TableContainer";
import ExpandedRowComponent from "../../../components/TableComponents/ExpandedRow";

type PropsT = {
  data: SupervisorT[],
  deactivate: Function,
  accountType: number,
  expandComponent?: Node
} & BrowserHistory;

type StateT = {
  expandedRowIds: Array<number>
};

const regionalManagerColumns = [
  { name: "id", title: "ID" },
  { name: "lastName", title: "Прiзвище" },
  { name: "firstName", title: "Ім'я" },
  { name: "middleName", title: "По батьковi" },
  { name: "phone", title: "Номер телефону" },
  { name: "cities", title: "Населений пункт" },
  { name: "chief", title: "Відповідальний" },
  { name: "estimatedMainStateCount", title: "Основний штат" },
  { name: "estimatedReservedStateCount", title: "Резерв" },
  { name: "profile", title: "Профіль" }
];

const columnsAll = [...regionalManagerColumns, { name: "deactivate", title: "Деактивувати" }];

const columnBands = [
  {
    title: "Планові KPI по комплектації штату",
    children: [{ columnName: "estimatedMainStateCount" }, { columnName: "estimatedReservedStateCount" }]
  }
];

const forValues = {
  phone: ["phone"],
  cities: ["cities"],
  chief: ["chief"],
  deactivateButton: ["deactivate"],
  profileButton: ["profile"]
};

const columnExtensionsSupervisors = [...columnExtensions, { columnName: "cities", width: 400 }];

class SupervisorsTable extends React.Component<PropsT, StateT> {
  state = {
    expandedRowIds: []
  };

  onRowClick: Function = memoize((tableProps: any) => (event: SyntheticEvent<HTMLButtonElement>) => {
    event.stopPropagation();
    // FixMe: Refactor that code
    let newElements = [];
    const rowIndex = tableProps.tableRow.rowId;
    const find = this.state.expandedRowIds.filter(item => item === rowIndex);

    if (find.length) {
      newElements = [...this.state.expandedRowIds.filter(item => item !== rowIndex)];
    } else {
      newElements = [...this.state.expandedRowIds, rowIndex];
    }

    this.changeExpandedRowIds(newElements);
  });

  cursor = { cursor: "pointer" };

  renderRow = (tableProps: any) => {
    return (
      <tr style={this.cursor} onClick={this.onRowClick(tableProps)}>
        {tableProps.children}
      </tr>
    );
  };

  renderCell: Function = memoize((cellProps: any) => {
    return <td>{cellProps.children}</td>;
  });

  clickOnProfile = (value: any) => {
    this.props.history.push(`/promoters/supervisors/${value || 1}`);
  };

  changeExpandedRowIds = (ids: Array<number>) => {
    const newIds = ids.filter(id => !this.state.expandedRowIds.includes(id));
    this.setState({ expandedRowIds: newIds });
  };

  render() {
    const { data, accountType } = this.props;
    const columns = accountType === 6 ? regionalManagerColumns : columnsAll;
    return (
      <Grid rows={data} columns={columns} rootComponent={GridRoot}>
        <PhoneProvider for={forValues.phone} />
        <CityProvider for={forValues.cities} />
        <PersonInfoProvider for={forValues.chief} />
        <DestructiveButtonProvider
          for={forValues.deactivateButton}
          onClick={this.props.deactivate}
          label="Деактивувати"
        />
        <TransparentButtonProvider for={forValues.profileButton} onClick={this.clickOnProfile} label="Деталі профілю" />

        <RowDetailState expandedRowIds={this.state.expandedRowIds} onExpandedRowIdsChange={this.changeExpandedRowIds} />

        <Table
          columnExtensions={columnExtensionsSupervisors}
          rowComponent={this.renderRow}
          height="auto"
          containerComponent={TableContainer}
        />

        <TableHeaderRow />
        <TableBandHeader columnBands={columnBands} />

        <TableRowDetail rowComponent={ExpandedRowComponent} contentComponent={this.props.expandComponent} />
      </Grid>
    );
  }
}

export default withRouter(SupervisorsTable);
