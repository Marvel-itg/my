// @flow
import React from "react";
import { withRouter } from "react-router-dom";
import {
  Grid,
  Table,
  TableHeaderRow,
  TableColumnVisibility,
  TableBandHeader,
  Toolbar,
  TableRowDetail
} from "@devexpress/dx-react-grid-material-ui";
import { RowDetailState, PagingState, CustomPaging } from "@devexpress/dx-react-grid";

import {
  PhoneProvider,
  DateFormatProvider,
  ButtonProvider,
  CityProvider,
  PersonInfoProvider,
  TransparentButtonProvider,
  DestructiveButtonProvider
} from "../../../components/FormattedData/FormattedData";
import { columnExtensions } from "../../../constants";
import SearchForm from "../../../components/TableComponents/SearchForm/SearchForm";
import type { BrowserHistory } from "history";
import GridRoot from "../../../components/TableComponents/GridRoot";
import PagingPanel from "../../../components/TableComponents/PagingPanel";
import ExpandedRowComponent from "../../../components/TableComponents/ExpandedRow";
import TabsHeader from "../../../components/TableComponents/TabsHeader";
import { ToolBarRootStyled } from "../../../components/TableComponents/ToolbarRoot";
import WithStickyBandsTable from "../../../HOCs/withStickyBandsTable";
import { availableItemsPerPage, supervisorsOptions } from "../../../constants";
import styles from "../../ListOfRegionalManagers/RegionalManagers.module.scss";

type PropsT = {
  data: SupervisorT[],
  changeTab: Function,
  changeCurrentPage: Function,
  changePageSize: Function,
  openModal: Function,
  activateManager: Function,
  deactivateManager: Function,
  rowComponent: Node,
  expandedRowIds: Array<number>,
  changeExpandedRowIds: Function,
  headerButtons?: any,
  expandComponent?: Node,
  page: number,
  count: number,
  tab: any,
  rowsCount: number
} & BrowserHistory;

const commonColumns = [
  { name: "id", title: "ID" },
  { name: "lastName", title: "Прiзвище" },
  { name: "firstName", title: "Ім'я" },
  { name: "middleName", title: "По батьковi" },
  { name: "phone", title: "Номер телефону" },
  { name: "cities", title: "Населений пункт" },
  { name: "chief", title: "Відповідальний" },
  { name: "estimatedMainStateCount", title: "Основний штат" },
  { name: "estimatedReservedStateCount", title: "Резерв" }
];

const columnsAll = {
  "3": [...commonColumns, { name: "profile", title: "Профіль" }, { name: "deactivate", title: "Деактивувати" }],
  "4": [
    ...commonColumns,
    { name: "deactivationDate", title: "Дата деактивування" },
    { name: "deactivatedBy", title: "Ким деактивовано" },
    { name: "comment", title: "Коментар" },
    { name: "profile", title: "Профіль" },
    { name: "activate", title: "Активувати" }
  ],
  "5": [...commonColumns, { name: "profile", title: "Профіль" }]
};

const tabs = [
  { label: "Активні", value: "3" },
  { label: "Зміна телефону", value: "5" },
  { label: "Деактивовані", value: "4" }
];

const columnBands = [
  {
    title: "Планові KPI по комплектації штату",
    children: [{ columnName: "estimatedMainStateCount" }, { columnName: "estimatedReservedStateCount" }]
  }
];

const columnExtensionsSupervisors = [{ columnName: "cities", width: 400 }];

const mergeColumnExtensions = [...columnExtensionsSupervisors, ...columnExtensions];

const forValues = {
  phone: ["phone"],
  cities: ["cities"],
  chief: ["chief"],
  deactivatedBy: ["deactivatedBy"],
  deactivationDate: ["deactivationDate"],
  deactivateButton: ["deactivate"],
  activateButton: ["activate"],
  profileButton: ["profile"]
};

class SupervisorsTable extends React.Component<PropsT> {
  clickOnProfile = (value: any) => {
    this.props.history.push(`/promoters/supervisors/${value || 1}`);
  };

  render() {
    const {
      headerButtons,
      data,
      changeCurrentPage,
      changePageSize,
      changeTab,
      page,
      count,
      tab,
      rowsCount,
      deactivateManager,
      activateManager
    } = this.props;
    const isActiveTab = Number.parseInt(tab) === 3 ? true : false;
    return (
      <Grid rows={data} columns={columnsAll[tab || "3"]} rootComponent={GridRoot}>
        <PagingState
          currentPage={page}
          onCurrentPageChange={changeCurrentPage}
          pageSize={count}
          onPageSizeChange={changePageSize}
        />
        <CustomPaging totalCount={rowsCount} />

        <PhoneProvider for={forValues.phone} />
        <CityProvider for={forValues.cities} />
        <PersonInfoProvider for={forValues.chief} />
        <PersonInfoProvider for={forValues.deactivatedBy} />
        <DateFormatProvider for={forValues.deactivationDate} />
        <DestructiveButtonProvider for={forValues.deactivateButton} onClick={deactivateManager} label="Деактивувати" />
        <ButtonProvider for={forValues.activateButton} onClick={activateManager} label="Активувати" />
        <TransparentButtonProvider for={forValues.profileButton} onClick={this.clickOnProfile} label="Деталі профілю" />

        {isActiveTab && (
          <RowDetailState
            expandedRowIds={this.props.expandedRowIds}
            onExpandedRowIdsChange={this.props.changeExpandedRowIds}
          />
        )}

        {isActiveTab ? (
          <Table columnExtensions={mergeColumnExtensions} rowComponent={this.props.rowComponent} />
        ) : (
          <Table columnExtensions={mergeColumnExtensions} />
        )}

        <Toolbar rootComponent={ToolBarRootStyled(styles.headerStyles)} />

        <TableHeaderRow />
        <TableColumnVisibility />
        {isActiveTab && (
          <TableRowDetail rowComponent={ExpandedRowComponent} contentComponent={this.props.expandComponent} />
        )}
        <TableBandHeader columnBands={columnBands} />

        <TabsHeader changeTab={changeTab} activeTab={tab} tabs={tabs}>
          {headerButtons && headerButtons()}
        </TabsHeader>

        <SearchForm selectOptions={supervisorsOptions} className={styles.searchFormStyles} placeholder="Пошук" />

        <PagingPanel pageSizes={availableItemsPerPage} noData={!data.length} />
      </Grid>
    );
  }
}

export default WithStickyBandsTable(withRouter(SupervisorsTable));
