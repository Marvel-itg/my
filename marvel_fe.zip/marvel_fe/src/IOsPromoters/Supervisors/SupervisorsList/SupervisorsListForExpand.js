// @flow
import React from "react";
import { connect } from "react-redux";
import { compose } from "redux";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper/Paper";
import SupervisorsTable from "../SupervisorsTable/SupervisorsTableForExpand";
import Modal from "../../../components/Modal/Modal";
import DeactivateIOSForm from "../../../components/DeactivateForm/DeactivateIOSForm";
import { deactivateSupervisor } from "../../../store/actions/promoters/expandedTablesActions";
import { openModal, closeModal } from "../../../store/actions/common/modals";

type PropsT = {
  deactivateSupervisor: Function,
  supervisors: SupervisorT[],
  expandComponent: Node,
  openModal: Function,
  closeModal: Function
} & BrowserHistory;

type StateT = {
  modalType: string,
  modalBody: any
};

const modalName = "ExpandedSupervisorComponent";

class SupervisorsList extends React.PureComponent<PropsT, StateT> {
  state = {
    modalType: "",
    modalBody: <div />
  };

  submitDeactivateForm = (data, accountId) => {
    const {
      comment,
      responsibleManager: { value: newChiefAccountId }
    } = data;
    const params = {
      accountId,
      comment,
      newChiefAccountId
    };
    this.props.deactivateSupervisor(params);
  };

  openModal = (type, id) => {
    switch (type) {
      case "deactivate": {
        const modalBody = (
          <DeactivateIOSForm
            form="DeactivateNestedSupervisor"
            submitForm={values => this.submitDeactivateForm(values, id)}
            title="Деактивувати супервайзера?"
            textFieldLabel="Додати коментар"
            textFieldName="comment"
            memberType="SupervisorIOS"
            submitButtonText="Деактивувати"
            cancelButtonText="Ні"
            cancelButtonHandler={this.props.closeModal}
            errorState={this.props.errorDeactivating}
            targetAccountId={id}
          />
        );
        this.setState({ modalBody, modalType: "deactivate" });
        return this.props.openModal(modalName);
      }
      default:
        return null;
    }
  };

  deactivateSupervisor = id => this.openModal("deactivate", id);

  render() {
    const { supervisors } = this.props;
    return (
      <React.Fragment>
        <Paper square className="mainContent">
          <SupervisorsTable
            data={supervisors}
            history={this.props.history}
            deactivate={this.deactivateSupervisor}
            expandComponent={this.props.expandComponent}
          />
        </Paper>

        {modalName === this.props.modalName && <Modal type={this.state.modalType}>{this.state.modalBody}</Modal>}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    modals: { modalName }
  } = state;
  return {
    modalName
  };
};

const mapDispatchToProps = {
  deactivateSupervisor,
  openModal,
  closeModal
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(SupervisorsList);
