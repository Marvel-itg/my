// @flow
import React from "react";
import { connect } from "react-redux";
import { compose } from "redux";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper/Paper";
import debounce from "es6-promise-debounce";
import CircularProgress from "@material-ui/core/CircularProgress";
import { memoize } from "lodash";
import SupervisorsTable from "../SupervisorsTable/SupervisorsTable";
import Modal from "../../../components/Modal/Modal";
import DeactivateIOSForm from "../../../components/DeactivateForm/DeactivateIOSForm";
import SupervisorForm from "../SupervisorForm/SupervisorForm";
import OutlinedButton from "../../../components/Buttons/OutlinedButton/OutlinedButton";
import ExpandedConsultants from "../../ListOfRegionalManagers/ExpandedConsultants";
import {
  receiveSupervisors,
  deactivateSupervisor,
  activateSupervisor,
  createSupervisorProfile
} from "../../../store/actions/promoters/supervisorsList";
import { openModal, closeModal } from "../../../store/actions/common/modals";
import { classes } from "../../../helpers/spinner";
import {
  getPaginationConfig,
  getCommonParams,
  changeCurrentPage,
  changePageSize,
  changeTab,
  onSearchChange,
  shouldNotSendRequest
} from "../../../helpers/common";
import { formatFormValues } from "../SupervisorProfile/helpers";
import {
  supervisorsListSelector,
  supervisorsRowsCountSelector,
  errorStateDeactivating
} from "../../../store/selectors/promoters/supervisors";
import styles from "../../Candidates/ListOfCandidates/ListOfCandidates.module.scss";

type PropsT = {
  receiveSupervisors: Function,
  deactivateSupervisor: Function,
  activateSupervisor: Function,
  createSupervisorProfile: Function,
  supervisors: SupervisorT[],
  loading: boolean,
  openModal: Function,
  closeModal: Function
} & BrowserHistory;

type StateT = {
  modalType: string,
  formName: string,
  modalBody: any,
  expandedRowIds: Array<number>
};

const modalName = "SupervisorForm";

const cursorStyle = {
  cursor: "pointer"
};

class SupervisorsList extends React.PureComponent<PropsT, StateT> {
  state = {
    modalType: "",
    formName: "",
    modalBody: <div />,
    expandedRowIds: []
  };

  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;
    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.setState({ expandedRowIds: [] });
        this.fetchData();
      }
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  changeTab = (event: any, tab: string) => changeTab(tab, this.props.location.search, this.props.history);

  onSearchChange = (searchValue: string) => onSearchChange(searchValue, this.props.location.search, this.props.history);

  fetchData = debounce(() => {
    const { searchValue, searchFieldName, itemsOnPage, pageNumber, tab } = getCommonParams(this.props.location.search);
    const paginationConfig = { count: itemsOnPage, page: pageNumber, searchValue, searchFieldName };
    const params = { status: tab, paginationConfig };
    this.props.receiveSupervisors(params);
  }, 200);

  submitDeactivateForm = (data, accountId) => {
    const {
      comment,
      responsibleManager: { value: newChiefAccountId }
    } = data;
    const params = {
      accountId,
      comment,
      newChiefAccountId
    };
    this.props.deactivateSupervisor(params);
  };

  submitAddForm = data => {
    this.props.createSupervisorProfile(formatFormValues(data));
  };

  openModal = (type, id) => {
    switch (type) {
      case "deactivate": {
        const modalBody = (
          <DeactivateIOSForm
            form="DeactivateSupervisor"
            submitForm={this.submitDeactivateForm}
            title="Деактивувати супервайзера?"
            textFieldLabel="Додати коментар"
            textFieldName="comment"
            memberType="SupervisorIOS"
            submitButtonText="Деактивувати"
            cancelButtonText="Ні"
            cancelButtonHandler={this.props.closeModal}
            errorState={errorStateDeactivating}
            targetAccountId={id}
          />
        );
        this.setState({ modalBody, modalType: "deactivate" });
        return this.props.openModal(modalName);
      }
      case "add": {
        const modalBody = <SupervisorForm submitForm={this.submitAddForm} accountType={this.props.accountType} />;
        this.setState({ modalBody, modalType: "" });
        return this.props.openModal(modalName);
      }
      default:
        return null;
    }
  };

  renderHeaderButtons = () => (
    <OutlinedButton
      label="Додати супервайзера"
      clickHandler={() => this.openModal("add")}
      className={styles.addButton}
    />
  );

  changeExpandedRowIds = (ids: Array<number>) => {
    const newIds = ids.filter(id => !this.state.expandedRowIds.includes(id));
    this.setState({ expandedRowIds: newIds });
  };

  onRowClick: Function = memoize((tableProps: any) => (event: SyntheticEvent<HTMLButtonElement>) => {
    event.stopPropagation();
    // FixMe: Refactor that code
    let newElements = [];
    const rowIndex = tableProps.tableRow.rowId;
    const find = this.state.expandedRowIds.filter(item => item === rowIndex);

    if (find.length) {
      newElements = [...this.state.expandedRowIds.filter(item => item !== rowIndex)];
    } else {
      newElements = [...this.state.expandedRowIds, rowIndex];
    }

    this.changeExpandedRowIds(newElements);
  });

  renderRow = (tableProps: any) => {
    return (
      <tr style={cursorStyle} onClick={this.onRowClick(tableProps)}>
        {tableProps.children}
      </tr>
    );
  };

  activateSupervisor = id => this.props.activateSupervisor(id);

  deactivateSupervisor = id => this.openModal("deactivate", id);

  openAddModal = () => this.openModal("add");

  render() {
    const { loading, supervisorsList, rowsCount, accountType } = this.props;
    const { page, count } = getPaginationConfig(this.props.location.search);
    const { tab } = getCommonParams(this.props.location.search);
    return (
      <React.Fragment>
        <Paper square className="mainContent">
          <SupervisorsTable
            data={supervisorsList}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            changeTab={this.changeTab}
            onSearchChange={this.onSearchChange}
            history={this.props.history}
            deactivateManager={this.deactivateSupervisor}
            activateManager={this.activateSupervisor}
            openModal={this.openModal}
            headerButtons={this.renderHeaderButtons}
            rowsCount={rowsCount}
            page={page}
            count={count}
            accountType={accountType}
            tab={tab || "3"}
            expandComponent={ExpandedConsultants}
            rowComponent={this.renderRow}
            changeExpandedRowIds={this.changeExpandedRowIds}
            expandedRowIds={this.state.expandedRowIds}
          />
        </Paper>

        {loading && <CircularProgress classes={classes} />}

        {modalName === this.props.modalName && (
          <Modal type={this.state.modalType} formName="NewSupervisorForm">
            {this.state.modalBody}
          </Modal>
        )}
      </React.Fragment>
    );
  }
}
const mapStateToProps = state => {
  const {
    supervisorsList: { loading, deactivating, activating, deactivated },
    modals: { modalName },
    authenticationReducer: {
      user: { accountType }
    }
  } = state;
  return {
    supervisorsList: supervisorsListSelector(state),
    rowsCount: supervisorsRowsCountSelector(state),
    loading: loading || deactivating || activating,
    modalName,
    accountType,
    deactivated
  };
};

const mapDispatchToProps = {
  receiveSupervisors,
  deactivateSupervisor,
  activateSupervisor,
  createSupervisorProfile,
  openModal,
  closeModal
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(SupervisorsList);
