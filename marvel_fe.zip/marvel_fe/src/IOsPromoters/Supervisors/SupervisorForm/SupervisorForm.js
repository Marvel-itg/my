// @flow
import React, { useRef, useEffect, useState } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { reduxForm, Field, formValueSelector } from "redux-form";
import type { FormProps } from "redux-form";
import cx from "classnames";
import FormLabel from "@material-ui/core/FormLabel";
import CircularProgress from "@material-ui/core/CircularProgress";
import { isEqual } from "lodash";
import BackButton from "../../../components/Buttons/BackButton/BackButton";
import ContainedButton from "../../../components/Buttons/ContainedButton/ContainedButton";
import InputField from "../../../components/InputField/InputField";
import ChiefsSelect from "../../../components/Select/ChiefsSelect";
import ProfileDisabledInfo from "../../../components/ProfileDisabledInfo/ProfileDisabledInfo";
import ErrorMessage from "../../../components/ErrorMessage/ErrorMessage";
import AsyncCitiesSelect from "../../../components/Select/AsyncCitiesSelect";
import { normalizeCyrillicName, phoneMask, normalizeStaff } from "../../../utils/reduxFormNormalizers";
import validate from "./validate";
import { configByRoles } from "../../../constants";
import { getChiefs } from "../../../api/chiefs";
import { classes } from "../../../helpers/spinner";
import styles from "./SupervisorForm.module.scss";

type PropsT = {
  geoValue: CityT[],
  changeMode: Function,
  editMode: boolean,
  errorEditing: string,
  isEditing: boolean,
  regionalManagers: RegionalManagerT[],
  submitForm: Function,
  loading: boolean,
  errorMessage: string,
  accountType: number,
  chief: ChiefT
} & FormProps;

const chiefData = {
  targetAccountType: configByRoles.supervisorIOSConfig
};

function usePrevious(value) {
  const ref = useRef();
  useEffect(() => {
    ref.current = value;
  });
  return ref.current;
}

const SupervisorForm = (props: PropsT) => {
  const [defaultOptions, setDefaultOptions] = useState([]);

  const { handleSubmit, submitForm, changeMode, editMode, isEditing, loading, invalid, geoValue, chief } = props;
  const isGeoValue = Array.isArray(geoValue) && geoValue.length ? false : true;
  let prevGeoIds = usePrevious(geoValue);
  let prevChief = usePrevious(chief);

  useEffect(() => {
    // use isSubscribed for prevent setState of unmounted component and memory leak as result
    let isSubscribed = true;
    async function loadDefaultOptions() {
      const userRole = props.accountType;
      if (!isEqual(prevGeoIds, geoValue)) {
        let targetGeoIds = geoValue.map(id => id.value);
        const defaultOptions = await getChiefs("RegionalManagerIOS", {
          ...chiefData,
          currentAccountType: userRole,
          targetGeoIds
        });
        if (isSubscribed) {
          setDefaultOptions(defaultOptions);
          if (prevChief && prevGeoIds) {
            props.change("responsibleManager", null);
          }
        }
      }
    }
    loadDefaultOptions();
    return () => {
      isSubscribed = false;
    };
  }, [geoValue]);

  const goBack = () => props.history.goBack();

  const disableFieldsExceptPhone = props.status === 5 ? true : false;
  const isDisabledEditFields = (editMode && !isEditing) || disableFieldsExceptPhone;
  const isEditButtonHidden = props.status === 4;
  const errorMessage = props.errorMessage || props.errorEditing;
  return (
    <>
      {loading && <CircularProgress classes={classes} />}
      <form
        autoComplete="off"
        noValidate
        onSubmit={handleSubmit(submitForm)}
        className={styles.newSupervisorFormWrapper}
      >
        {!editMode && <div className={styles.formTitle}>Новий супервайзер</div>}
        {editMode && <BackButton label="Повернутися назад" handleClick={goBack} className={styles.backButtonStyles} />}
        <Field
          required
          name="lastName"
          component={InputField}
          normalize={normalizeCyrillicName}
          disabled={isDisabledEditFields}
        />
        <Field
          required
          name="firstName"
          component={InputField}
          normalize={normalizeCyrillicName}
          disabled={isDisabledEditFields}
        />
        <Field
          required
          name="middleName"
          component={InputField}
          normalize={normalizeCyrillicName}
          disabled={isDisabledEditFields}
        />
        <Field
          required
          name="phone"
          component={InputField}
          type="tel"
          disabled={editMode && !isEditing}
          {...phoneMask}
        />
        <Field
          required
          roleName="SupervisorIOS"
          component={AsyncCitiesSelect}
          isMulti={true}
          name="city"
          className={styles.inputField}
          disabled={isDisabledEditFields}
        />
        <Field
          required
          options={defaultOptions}
          name="responsibleManager"
          component={ChiefsSelect}
          disabled={isDisabledEditFields || isGeoValue}
        />

        <FormLabel className={styles.formLabel} disabled={isDisabledEditFields} component="legend">
          Планові KPI по комплектації штату
        </FormLabel>

        <div className={styles.inputsFlexWrapper}>
          <Field
            required
            type="text"
            name="estimatedMainStateCount"
            component={InputField}
            className={cx(styles.inputFieldMarginSmall, styles.inputFieldHalf)}
            disabled={isDisabledEditFields}
            normalize={normalizeStaff}
          />

          <Field
            required
            type="text"
            name="estimatedReservedStateCount"
            component={InputField}
            className={cx(styles.inputFieldMarginSmall, styles.inputFieldHalf)}
            disabled={isDisabledEditFields}
            normalize={normalizeStaff}
          />
        </div>
        {editMode && <ProfileDisabledInfo />}
        {editMode &&
          !isEditButtonHidden &&
          (isEditing ? (
            <ContainedButton type="submit" disabled={invalid} label="Зберегти" className={styles.editButton} />
          ) : (
            <ContainedButton type="button" label="Редагувати" className={styles.editButton} handleClick={changeMode} />
          ))}
        {!editMode && (
          <ContainedButton disabled={invalid} type="submit" label="Додати" className={styles.createButton} />
        )}
        {errorMessage && <ErrorMessage error={errorMessage} />}
      </form>
    </>
  );
};

const selector = formValueSelector("SupervisorForm");

const mapStateToProps = state => {
  const {
    supervisorsList: { error, submitting }
  } = state;
  const geoValue = selector(state, "city");
  const chief = selector(state, "responsibleManager");
  return {
    geoValue,
    errorMessage: error,
    loading: submitting,
    chief
  };
};

export default compose(
  withRouter,
  connect(mapStateToProps),
  reduxForm({
    form: "SupervisorForm",
    validate,
    enableReinitialize: true,
    keepDirtyOnReinitialize: true
  })
)(SupervisorForm);
