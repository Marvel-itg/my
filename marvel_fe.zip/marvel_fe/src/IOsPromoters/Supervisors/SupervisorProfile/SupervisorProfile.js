// @flow
import React from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import CircularProgress from "@material-ui/core/CircularProgress";
import Paper from "@material-ui/core/Paper/Paper";
import SupervisorForm from "../SupervisorForm/SupervisorForm";
import ActivityTable from "../../../containers/ActivityHistoryTable/ActivityTable";
import {
  receiveSupervisorProfile,
  editSupervisorProfile,
  clearSupervisorInfo
} from "../../../store/actions/promoters/supervisorProfile";
import { classes } from "../../../helpers/spinner";
import { activityHistoryColumns } from "../../../constants";
import styles from "./SupervisorProfile.module.scss";
import {
  supervisorActivityHistorySelector,
  supervisorProfileSelector
} from "../../../store/selectors/promoters/supervisors";
import { formatFormValues } from "./helpers";

type PropsT = {
  receiveSupervisorProfile: Function,
  supervisor: SupervisorT,
  editSupervisorProfile: Function,
  clearSupervisorInfo: Function,
  loading: boolean
};

type StateT = {
  isEditing: boolean
};

class SupervisorProfile extends React.PureComponent<PropsT & BrowserHistory, StateT> {
  state = { isEditing: false };

  componentDidMount() {
    const { id } = this.props.match.params;
    if (id) {
      this.props.receiveSupervisorProfile(id);
    }
  }

  componentDidUpdate(oldProps) {
    if (this.props.submitted && !oldProps.submitted) {
      this.setState({
        isEditing: false
      });
    }
  }

  submitForm = data => {
    this.props.editSupervisorProfile(formatFormValues(data));
  };

  changeMode = event => {
    event.preventDefault();
    this.setState(prevState => ({ isEditing: !prevState.isEditing }));
  };

  componentWillUnmount() {
    this.props.clearSupervisorInfo();
  }

  render() {
    return (
      <Paper className="mainContent">
        <div className={styles.formWrapper}>
          {this.props.loading && !this.props.supervisor ? (
            <CircularProgress classes={classes} />
          ) : (
            <SupervisorForm
              initialValues={this.props.supervisor}
              isEditing={this.state.isEditing}
              submitForm={this.submitForm}
              changeMode={this.changeMode}
              accountType={this.props.accountType}
              editMode
              status={this.props.status}
              userId={this.props.userId}
              errorEditing={this.props.errorMessage}
            />
          )}
          <ActivityTable columns={activityHistoryColumns} data={this.props.activityHistory} />
        </div>
      </Paper>
    );
  }
}

const mapStateToProps = state => {
  const {
    supervisorProfile: { submitted, receivingProfile, submitting, supervisorProfile, error },
    authenticationReducer: {
      user: { accountType, id }
    }
  } = state;
  const status = supervisorProfile && supervisorProfile.account && supervisorProfile.account.status;
  return {
    supervisor: supervisorProfileSelector(state),
    activityHistory: supervisorActivityHistorySelector(state),
    accountType,
    submitted,
    loading: receivingProfile || submitting,
    status,
    userId: id,
    errorMessage: error
  };
};

const mapDispatchToProps = {
  receiveSupervisorProfile,
  editSupervisorProfile,
  clearSupervisorInfo
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(SupervisorProfile);
