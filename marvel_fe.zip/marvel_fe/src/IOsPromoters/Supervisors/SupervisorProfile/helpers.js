// @flow
import isEmpty from "lodash/isEmpty";
import omit from "lodash/omit";
import { mapCityToOptionsOfCities, formatObjectToFullName } from "../../../helpers/common";
import { userStatusConfig } from "../../../constants";
import { formatDate } from "../../../utils/formatValues";

export const formatFormValues = (values: any) => {
  const phone = values.phone && `+380${values.phone}`;
  const accountId = values.id;
  const chiefAccountId = values.responsibleManager.value;
  const geoIds = values.city && values.city.map(id => id.value);
  const firstName = values.firstName.trim();
  const lastName = values.lastName.trim();
  const middleName = values.middleName.trim();
  values = omit(values, ["responsibleManager", "id", "city"]);
  const formatted = {
    ...values,
    firstName,
    middleName,
    lastName,
    accountId,
    chiefAccountId,
    phone,
    geoIds
  };
  return formatted;
};

export const formatInitialValues = (data: SupervisorT) => {
  if (!isEmpty(data)) {
    const phone = data.phone && data.phone.substr(4);
    const responsibleManager =
      data.chief && data.chief.id
        ? {
            value: data.chief.id,
            label: formatObjectToFullName(data.chief)
          }
        : null;
    const status = userStatusConfig[data.status];
    const creator = data.creator && data.creator.id && formatObjectToFullName(data.creator);
    const createdAt = data.creationDate && formatDate(data.creationDate);
    const city: OptionT[] = data.cities && data.cities.map(mapCityToOptionsOfCities);
    data = omit(data, ["comment", "deactivatedBy", "deactivationDate", "chief"]);

    const initialValues = {
      ...data,
      phone,
      responsibleManager,
      city,
      createdBy: creator,
      createdAt,
      status
    };
    return initialValues;
  }
  return null;
};

export const filterActivityHistory = (activityHistory: ActivityRecordT[]): ActivityRecordT[] => {
  if (activityHistory && activityHistory.length) {
    const filteredHistory = activityHistory
      .filter(item => item.activityType !== 1)
      .map(item => {
        if (item.key === "Chief") {
          return {
            ...item,
            oldValue: item.oldValue && JSON.parse(item.oldValue)["fullName"],
            newValue: item.newValue && JSON.parse(item.newValue)["fullName"]
          };
        }
        if (item.key === "Geo") {
          const oldRegions = JSON.parse(item.oldValue);
          const newRegions = JSON.parse(item.newValue);
          return {
            ...item,
            oldValue: oldRegions && oldRegions.map(mapCityToOptionsOfCities),
            newValue: newRegions && newRegions.map(mapCityToOptionsOfCities)
          };
        }
        return item;
      });
    return filteredHistory;
  }
  return [];
};
