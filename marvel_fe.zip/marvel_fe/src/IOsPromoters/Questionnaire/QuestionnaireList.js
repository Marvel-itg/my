// @flow
import React from "react";
import { connect } from "react-redux";
import debounce from "es6-promise-debounce";
import type { BrowserHistory } from "history";
import moment from "moment";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import OutlinedButton from "../../components/Buttons/OutlinedButton/OutlinedButton";
import QuestionnaireTable from "./QuestionnaireTable";
import ChangeEndDateForm from "./ChangeEndDateForm";
import Modal from "../../components/Modal/Modal";
import {
  fetchQuestionnaire,
  activateQuestionnaire,
  deactivateQuestionnaire
} from "../../store/actions/promoters/questionnaire";
import {
  getPaginationConfig,
  getCommonParams,
  changeCurrentPage,
  changePageSize,
  changeTab
} from "../../helpers/common";
import { openModal } from "../../store/actions/common/modals";
import styles from "./Questionnaire.module.scss";
import { classes } from "../../helpers/spinner";

type PropsT = {
  loading: boolean,
  questionnaireList: QuestionnaireDataProjectT[],
  activated: boolean,
  deactivated: boolean,
  total: number,
  fetchQuestionnaire: Function,
  activateQuestionnaire: Function,
  deactivateQuestionnaire: Function
} & BrowserHistory;

type StateT = {
  modalBody: any
};

const tabs = [
  { label: "Активні", value: "1" },
  { label: "В очікуванні", value: "3" },
  { label: "Завершені", value: "2" }
];

class QuestionnaireList extends React.Component<PropsT, StateT> {
  state = {
    modalBody: <div />
  };

  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;
    if (
      prevProps.location.key !== key ||
      (!prevProps.deactivated && this.props.deactivated) ||
      (!prevProps.activated && this.props.activated)
    ) {
      this.fetchData();
    }
  }

  fetchData = debounce(() => {
    const { itemsOnPage, pageNumber, tab } = getCommonParams(this.props.location.search);
    const params = { itemsOnPage, pageNumber, status: tab };
    this.props.fetchQuestionnaire(params);
  }, 200);

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  changeTab = (event: any, tab: string) => changeTab(tab, this.props.location.search, this.props.history);

  editQuestionnaire = (id, data) => {
    this.props.history.push(`/promoters/questionnaire/${id}/${data.questionnaireId}`);
  };

  openFormHandler = () => this.props.history.push("/promoters/questionnaire/new");

  openModal = (type, data) => {
    switch (type) {
      case "activate": {
        const modalBody = (
          <ChangeEndDateForm
            initialValues={{ endDate: data.endDate }}
            questionnaireData={data}
            activateQuestionnaire={this.activateQuestionnaire}
          />
        );
        this.setState({ modalBody });
        return this.props.openModal();
      }
      default:
        return null;
    }
  };

  checkEndDate = (id, data) => {
    if (moment(data.endDate).isBefore(moment().endOf("day"))) {
      this.openModal("activate", data);
    } else {
      this.activateQuestionnaire(data);
    }
  };

  activateQuestionnaire = (data, newEndDate) => {
    const params = {
      questionnaireId: data.questionnaireId,
      questionnaireTemplateId: data.questionnaireTemplateId,
      projectId: data.project.id,
      status: 1,
      startDate: moment(data.startDate).format("YYYY-MM-DD"),
      endDate: newEndDate ? moment(newEndDate).format("YYYY-MM-DD") : moment(data.endDate).format("YYYY-MM-DD")
    };
    this.props.activateQuestionnaire(params, { withNewDates: true });
  };

  deactivateQuestionnaire = (id, data) => {
    const params = {
      questionnaireId: data.questionnaireId,
      questionnaireTemplateId: data.questionnaireTemplateId,
      projectId: data.project.id,
      status: 2,
      startDate: moment(data.startDate).format("YYYY-MM-DD"),
      endDate: moment(data.endDate).format("YYYY-MM-DD")
    };
    this.props.deactivateQuestionnaire(params);
  };

  renderAddButton = () => (
    <OutlinedButton label="Додати анкету" clickHandler={this.openFormHandler} className={styles.addButton} />
  );

  render() {
    const { questionnaireList, total } = this.props;
    const { page, count } = getPaginationConfig(this.props.location.search);
    const { tab } = getCommonParams(this.props.location.search);
    return (
      <React.Fragment>
        <Paper square className="mainContent">
          <QuestionnaireTable
            data={questionnaireList}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            changeTab={this.changeTab}
            total={total}
            page={page}
            count={count}
            tab={tab || "1"}
            tabs={tabs}
            deactivateQuestionnaire={this.deactivateQuestionnaire}
            activateQuestionnaire={this.checkEndDate}
            editQuestionnaire={this.editQuestionnaire}
            renderAddButton={this.renderAddButton}
          />
        </Paper>
        {this.props.loading && <CircularProgress classes={classes} />}
        <Modal>{this.state.modalBody}</Modal>
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({ questionnaire: { questionnaireList, total, loading, deactivated, activated } }) => {
  return { questionnaireList, loading, total, deactivated, activated };
};

const mapDispatchToProps = {
  fetchQuestionnaire,
  activateQuestionnaire,
  deactivateQuestionnaire,
  openModal
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(QuestionnaireList);
