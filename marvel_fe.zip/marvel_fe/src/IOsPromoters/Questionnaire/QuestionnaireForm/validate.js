import moment from "moment";
import { validationErrorMessages } from "../../../constants";

const checkProject = potentialProject => {
  return (
    potentialProject &&
    potentialProject.projectId &&
    potentialProject.startDate &&
    potentialProject.endDate &&
    ((potentialProject.geos && potentialProject.geos.length) || potentialProject.allGeos)
  );
};

const compareProjectDates = (currentProject, project) => {
  const isBetween =
    moment(currentProject.startDate).isBetween(project.startDate, project.endDate, null, []) ||
    moment(currentProject.endDate).isBetween(project.startDate, project.endDate, null, []) ||
    moment(project.startDate).isBetween(currentProject.startDate, currentProject.endDate, null, []) ||
    moment(project.endDate).isBetween(currentProject.startDate, currentProject.endDate, null, []);
  return isBetween;
};

const compareProjectGeos = (currentProject, project) => {
  const currentGeos = currentProject.geos;
  const projectGeos = project.geos && project.geos.length && project.geos.map(city => city.value);
  const sameGeos =
    projectGeos && currentGeos && currentGeos.length && currentGeos.find(city => projectGeos.includes(city.value));
  return currentProject.allGeos || project.allGeos || sameGeos;
};

export const validate = (values, props) => {
  const { required, tooLongName: tooLongName150, tooShortName } = validationErrorMessages({
    maxLength: 150,
    minLength: 2
  });
  const errors = {};
  errors.questions = [];
  errors.projects = [];
  if (!values.title) {
    errors.title = required;
  } else if (values.title.length < 2) {
    errors.title = tooShortName;
  } else if (values.title.length > 150) {
    errors.title = tooLongName150;
  }

  const validateGeos = (currentProject, currentIndex) => {
    const { projects } = values;

    if (checkProject(currentProject)) {
      const currentProjects =
        currentProject &&
        projects &&
        projects.length > 1 &&
        projects
          .map((item, idx) => ({ ...item, idx: idx + 1 }))
          .filter(
            (item, itemIndex) =>
              currentIndex !== itemIndex &&
              item &&
              item.projectId &&
              item.projectId.value === currentProject.projectId.value &&
              checkProject(item) &&
              compareProjectDates(currentProject, item) &&
              compareProjectGeos(currentProject, item)
          );

      if (currentProjects && currentProjects.length) {
        let errorMessage = "Населені пункти та період активності анкети перетинаються у проектах";
        currentProjects.forEach((item, index) => {
          errorMessage += ` № ${item.idx}${index === currentProjects.length - 1 ? "." : ","}`;
          props.touch(`projects[${item.idx - 1}].geos`);
        });
        errors.projects[currentIndex].geos = errorMessage;
        props.touch(`projects[${currentIndex}].geos`);
      }
    }
  };

  // Project block validations
  if (!values.projects) {
    errors.projects[0] = required;
  } else {
    values.projects.forEach((project, index) => {
      errors.projects[index] = {};
      if (!project.projectId) {
        errors.projects[index].projectId = required;
      }
      if ((!project.geos || !project.geos.length) && !project.allGeos) {
        errors.projects[index].geos = required;
      } else {
        validateGeos(project, index);
      }
      if (!project.startDate) {
        errors.projects[index].startDate = required;
      }
      if (!project.endDate) {
        errors.projects[index].endDate = required;
      } else if (moment(project.endDate).isBefore(moment().startOf("day"))) {
        errors.projects[index].endDate = `Мінімальна дата - ${moment()
          .startOf("day")
          .format("DD/MM/YYYY")}`;
      } else if (project.startDate && moment(project.endDate).isBefore(moment(project.startDate))) {
        errors.projects[index].endDate = "Введіть корректну дату закінчення";
      }
      if (!project.fillingType) {
        errors.projects[index].fillingType = required;
      }
      if (!project.countOfFilling) {
        errors.projects[index].countOfFilling = required;
      } else if (project.countOfFilling > 100) {
        errors.projects[index].countOfFilling = "Максимальна кількість заповнень - 100";
      }
    });
  }

  // Questions validation

  const validateQuestions = (values, link, titleLink = {}) => {
    const titleErrorMessage = "Заповніть усі обов'язкові поля у залежних питаннях";
    titleLink.titleField = "";
    if (!values.questions || !values.questions.length) {
      link[0] = required;
    } else if (!values.questions.find(question => question.status)) {
      link[0] = {};
      link[0].title = "Хоча б одне питання має бути активним";
      titleLink.titleField = "Хоча б одне залежне питання має бути активним";
    } else {
      const { tooLongName: tooLongName250, tooShortName: tooShortName5 } = validationErrorMessages({
        maxLength: 250,
        minLength: 5
      });
      values.questions.forEach((question, index) => {
        if (question) {
          link[index] = {};
          link[index].answers = [];
          if (!question.title) {
            link[index].title = required;
            titleLink.titleField = titleErrorMessage;
          } else if (question.title.length < 5) {
            link[index].title = tooShortName5;
            titleLink.titleField = titleErrorMessage;
          } else if (question.title.length > 250) {
            link[index].title = tooLongName250;
            titleLink.titleField = titleErrorMessage;
          }

          if (!question.questionType) {
            link[index].questionType = required;
            titleLink.titleField = titleErrorMessage;
          } else if (
            question.questionType.value !== "text" &&
            question.questionType.value !== "number" &&
            (!question[question.questionType.value] ||
              !question[question.questionType.value].answers ||
              !question[question.questionType.value].answers.length)
          ) {
            link[index][question.questionType.value] = {};
            link[index][question.questionType.value].answers = [];
            link[index][question.questionType.value].answers[0] = {};
            link[index][question.questionType.value].answers[0].title = required;
            titleLink.titleField = titleErrorMessage;
          } else {
            link[index][question.questionType.value] = {};
            link[index][question.questionType.value].answers = [];
            if (question.questionType.value !== "text" && question.questionType.value !== "number") {
              question[question.questionType.value].answers.forEach((answer, answerIndex) => {
                link[index][question.questionType.value].answers[answerIndex] = {};
                if (!answer.title) {
                  link[index][question.questionType.value].answers[answerIndex].title = required;
                  titleLink.titleField = titleErrorMessage;
                }
              });
            }
          }

          if (
            question.questionType &&
            question[question.questionType.value] &&
            question[question.questionType.value].dependencies &&
            question[question.questionType.value].dependencies.length
          ) {
            const type = question.questionType.value;
            link[index][type].dependencies = [];
            question[question.questionType.value].dependencies.forEach((dependency, dependencyIndex) => {
              link[index][type].dependencies[dependencyIndex] = {};
              link[index][type].dependencies[dependencyIndex].questions = [];
              if (dependency && dependency.questions) {
                validateQuestions(
                  dependency,
                  link[index][type].dependencies[dependencyIndex].questions,
                  link[index][type].dependencies[dependencyIndex]
                );
              }
            });
          }
        }
      });
    }
  };
  errors.questions = [];
  validateQuestions(values, errors.questions);

  return errors;
};

export const required = value => (value ? undefined : "Обов'язкове поле");
