// @flow
import React from "react";
import { connect } from "react-redux";
import moment from "moment";
import { Field, FieldArray, formValueSelector, change } from "redux-form";
import type { FormProps } from "redux-form";
import isEqual from "lodash/isEqual";
import get from "lodash/get";
import uniqueId from "lodash/uniqueId";
import IconDelete from "@material-ui/icons/Delete";
import IconButton from "@material-ui/core/IconButton";
import Select from "../../../components/Select/Select";
import InputField from "../../../components/InputField/InputField";
import Switch from "../../../components/Switch/Switch";
import AnswersList from "./AnswersList";
import DependenciesList from "./DependenciesList";
import { questionTypes } from "./constants";
import { normalizeLength } from "../../../utils/reduxFormNormalizers";
import styles from "../Questionnaire.module.scss";

type PropsT = {
  questions: any[]
} & FormProps;

const yesNoOptions = [
  { title: "Так", value: "1", status: true },
  { title: "Ні", value: "2", status: true }
];

const yesSkipOptions = [
  { title: "Так", value: "1", status: true },
  { title: "Пропустити", value: "2", status: true }
];

class QuestionField extends React.PureComponent<PropsT> {
  componentDidUpdate(prevProps) {
    const { question } = this.props;
    const prevType = get(prevProps, `${question}.questionType.value`);
    const currentType = get(this.props, `${question}.questionType.value`);
    const prevAnswers = get(prevProps, `${question}.${prevType}.answers`);
    const currentAnswers = get(this.props, `${question}.${currentType}.answers`);
    const currentDependencies = get(this.props, `${question}.${currentType}.dependencies`);
    const prevCanFailedQuestionnaire = get(prevProps, `${question}.${prevType}.canFailedQuestionnaire`);
    const currentCanFailedQuestionnaire = get(this.props, `${question}.${currentType}.canFailedQuestionnaire`);

    if (prevType !== currentType && (currentType === "radio" || currentType === "scan") && !currentAnswers) {
      const answersFieldName = `${question}.${currentType}.answers`;
      const canFailedQuestionnaire = `${question}.${currentType}.canFailedQuestionnaire`;
      const options = currentType === "radio" ? yesNoOptions : yesSkipOptions;
      this.props.change("QuestionnaireForm", answersFieldName, options);
      this.props.change("QuestionnaireForm", canFailedQuestionnaire, { value: "0", label: "Всі відповіді успішні" });
    }

    if (prevType !== currentType && (currentType === "dropDown" || currentType === "checkbox") && !currentAnswers) {
      const fieldName = `${question}.${currentType}.answers`;
      this.props.change("QuestionnaireForm", fieldName, [{ status: true }]);
    }

    if (!isEqual(prevAnswers, currentAnswers)) {
      const dependencies =
        currentAnswers &&
        currentAnswers.map((item, index) => {
          const dependency = currentDependencies && currentDependencies[index];
          if (dependency && dependency.questions) {
            return {
              ...dependency,
              leadsToQuestion: item.leadsToQuestion,
              title: item.title,
              status: item.status && dependency.status
            };
          } else if (dependency && !dependency.questions && item.leadsToQuestion) {
            return {
              ...dependency,
              leadsToQuestion: true,
              questions: [{ tempId: `${moment().valueOf()}random${uniqueId()}`, status: item.status && true }]
            };
          } else if (!dependency && item.leadsToQuestion) {
            return {
              ...item,
              tempId: `${moment().valueOf()}random${uniqueId()}`,
              leadsToQuestion: true,
              questions: [{ tempId: `${moment().valueOf()}random${uniqueId()}`, status: item.status && true }]
            };
          } else {
            return { ...item, tempId: `${moment().valueOf()}random${uniqueId()}`, status: item.status && true };
          }
        });

      const fieldName = `${question}.${currentType}.dependencies`;
      this.props.change("QuestionnaireForm", fieldName, dependencies);
    }

    if (
      !isEqual(prevCanFailedQuestionnaire, currentCanFailedQuestionnaire) &&
      currentCanFailedQuestionnaire &&
      currentDependencies &&
      currentDependencies.length
    ) {
      const answersFieldName = `${question}.${currentType}.answers`;

      const answers =
        currentAnswers &&
        currentAnswers.map(answer => {
          if (answer.value === currentCanFailedQuestionnaire.value) {
            return { ...answer, canFailedQuestionnaire: true };
          } else {
            return { ...answer, canFailedQuestionnaire: false };
          }
        });

      this.props.change("QuestionnaireForm", answersFieldName, answers);
    }
  }

  removeQuestion = () => {
    const { fields, index } = this.props;
    return fields.remove(index);
  };

  render() {
    const { fields, index, question, questions, editMode, disabled: disabledQuestion } = this.props;
    const questionType = get(this.props, `${question}.questionType.value`);
    const dependencies = get(this.props, `${question}.${questionType}.dependencies`);
    const status = get(this.props, `${question}.status`);
    const answers = get(this.props, `${question}.${questionType}.answers`);
    const currentQuestion = get(this.props, question);
    const isNewQuestion = currentQuestion && !currentQuestion.id;
    const disabled = (editMode && !isNewQuestion && !status) || disabledQuestion;

    return (
      <li key={index} className={styles.questionWrapper}>
        <div className={styles.questionBlock}>
          {editMode && !isNewQuestion && (
            <div className={styles.deactivateField}>
              <Field
                label={disabled ? "Активувати питання" : "Деактивувати питання"}
                name={`${question}.status`}
                placeholder="Проект"
                className={styles.inputField}
                component={Switch}
                disabled={disabledQuestion}
              />
            </div>
          )}
          <Field
            required
            name={`${question}.title`}
            label="Введіть питання"
            component={InputField}
            className={styles.inputFieldTitle}
            normalize={normalizeLength(250)}
            disabled={disabled}
          />
          <Field
            required
            name={`${question}.questionType`}
            placeholder="Виберіть тип питання"
            component={Select}
            isGrey
            options={questionTypes}
            className={styles.inputField}
            disabled={disabled || (editMode && !isNewQuestion)}
          />
          {questionType && answers && (
            <FieldArray
              name={`${question}.${questionType}.answers`}
              key={`${question}.${questionType}.answers`}
              component={AnswersList}
              question={question}
              questions={questions}
              questionIndex={index}
              answers={answers}
              questionType={questionType}
              disabled={disabled}
              editMode={editMode}
            />
          )}
        </div>
        {dependencies && (
          <FieldArray
            name={`${question}.${questionType}.dependencies`}
            component={DependenciesList}
            question={question}
            questions={questions}
            questionIndex={index}
            dependencies={dependencies}
            answers={answers}
            disabled={disabled}
            editMode={editMode}
          />
        )}
        {fields.length > 1 && (isNewQuestion || !editMode) && (
          <>
            <IconButton className={styles.removeButton} onClick={this.removeQuestion}>
              <IconDelete color="error" />
            </IconButton>
          </>
        )}
      </li>
    );
  }
}

const mapStateToProps = state => {
  const selector = formValueSelector("QuestionnaireForm");
  const questions = selector(state, "questions");
  return {
    questions
  };
};

const mapDispatchToProps = {
  change
};
export default connect(mapStateToProps, mapDispatchToProps)(QuestionField);
