// @flow
import React from "react";
import { FieldArray } from "redux-form";
import type { FormProps } from "redux-form";
import QuestionsList from "./QuestionsList";
import styles from "../Questionnaire.module.scss";

type PropsT = {
  questionIndex: string,
  dependencies: any[],
  editMode: boolean
} & FormProps;

const DependenciesList = (props: PropsT) => {
  return (
    <div>
      {props.fields.map((answer, index) => {
        const disabled = (props.editMode && props.answers[index] && !props.answers[index].status) || props.disabled;
        return props.answers &&
          props.answers[index] &&
          props.answers[index].leadsToQuestion &&
          !props.answers[index].canFailedQuestionnaire ? (
          <div className={styles.answerWrapper} key={index}>
            <FieldArray
              name={`${answer}.questions`}
              component={QuestionsList}
              index={props.questionIndex}
              answer={props.dependencies[index].title}
              titleFieldName={`${answer}.titleField`}
              editMode={props.editMode}
              disabled={disabled}
            />
          </div>
        ) : null;
      })}
    </div>
  );
};

export default DependenciesList;
