const no = "Ні";
const yes = "Так";
const skip = "Пропустити";

export const canFailOptions = {
  radio: [
    { value: "0", label: "Всі відповіді успішні" },
    { value: "1", label: `При відповіді "${yes}"` },
    { value: "2", label: `При відповіді "${no}"` }
  ],
  scan: [
    { value: "0", label: "Всі відповіді успішні" },
    { value: "1", label: `При відповіді "${yes}"` },
    { value: "2", label: `При відповіді "${skip}"` }
  ]
};

export const questionTypes = [
  {
    value: "radio",
    label: "Так/Ні",
    icon: "radio_button_checked",
    id: 1
  },
  {
    value: "dropDown",
    label: "Випадаючий список",
    icon: "arrow_drop_down_circle",
    id: 2
  },
  {
    value: "text",
    label: "Текст",
    addon: "Abc",
    id: 4
  },
  {
    value: "number",
    label: "Число",
    addon: "123",
    id: 5
  },
  {
    value: "scan",
    label: "Сканування коду",
    id: 6,
    icon: "center_focus_weak"
  }
];

export const completionTypesQuestionnaire = [
  { value: 1, label: "Заповнення за годину" },
  { value: 2, label: "Заповнення за зміну" }
];
