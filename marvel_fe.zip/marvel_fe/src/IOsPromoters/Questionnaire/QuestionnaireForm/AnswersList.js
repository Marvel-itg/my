// @flow
import React from "react";
import { Field } from "redux-form";
import type { FormProps } from "redux-form";
import cx from "classnames";
import get from "lodash/get";
import IconClose from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import InputField from "../../../components/InputField/InputField";
import Switch from "../../../components/Switch/Switch";
import Select from "../../../components/Select/Select";
import { normalizeLength } from "../../../utils/reduxFormNormalizers";
import { canFailOptions } from "./constants";
import styles from "../Questionnaire.module.scss";

type PropsT = {
  type: string,
  questions: any[],
  editMode: boolean,
  disabled: boolean
} & FormProps;

const AnswersList = (props: PropsT) => {
  const { answers, questionType, fields, question, editMode, disabled } = props;
  const currentQuestion = get(props, question);
  const arrayType = questionType === "dropDown" || questionType === "checkbox";
  const addAnswer = () => fields.push({ status: true });
  const canFailedQuestionnaireValue =
    (questionType === "radio" || questionType === "scan") &&
    currentQuestion &&
    currentQuestion[questionType] &&
    currentQuestion[questionType].canFailedQuestionnaire &&
    currentQuestion[questionType].canFailedQuestionnaire.value;

  return (
    <div className={styles.answer}>
      {fields.map((answer, index) => {
        const disableDependencies =
          (questionType === "radio" || questionType === "scan") && answers[index].value === canFailedQuestionnaireValue;
        const isNewAnswer = editMode && !answers[index].id;

        if (questionType === "text" || questionType === "number") {
          return null;
        }
        if (questionType === "radio" || questionType === "scan") {
          return (
            <div className={styles.answerWrapper} key={index}>
              <span className={cx(styles.decor, styles[questionType])}>{answers[index].title}</span>
              <Field
                name={`${answer}.leadsToQuestion`}
                label="Залежність питання"
                component={Switch}
                disabled={
                  (arrayType && !answers[index].title) ||
                  disableDependencies ||
                  disabled ||
                  (editMode && !answers[index].status)
                }
              />
            </div>
          );
        }
        return (
          <div className={styles.answerWrapper} key={index}>
            <div className={cx(styles.answerField, { [styles.decor]: questionType === "checkbox" })}>
              {questionType === "dropDown" && <span className={styles.answerNumber}>{index + 1}.</span>}
              <Field
                name={`${answer}.title`}
                component={InputField}
                label="Введіть відповідь"
                normalize={normalizeLength(250)}
                disabled={disabled || (editMode && !answers[index].status)}
              />
              {fields.length > 1 && (!editMode || isNewAnswer) && (
                <IconButton className={styles.removeButton} onClick={() => fields.remove(index)}>
                  <IconClose />
                </IconButton>
              )}
              {editMode && !isNewAnswer && (
                <Field
                  label={!answers[index].status ? "Активувати" : "Деактивувати"}
                  name={`${answer}.status`}
                  className={styles.inputField}
                  component={Switch}
                  disabled={disabled}
                />
              )}
            </div>
            <Field
              name={`${answer}.leadsToQuestion`}
              label="Залежність питання"
              component={Switch}
              disabled={
                (arrayType && !answers[index].title) ||
                disableDependencies ||
                disabled ||
                (editMode && !answers[index].status)
              }
            />
          </div>
        );
      })}
      {(questionType === "radio" || questionType === "scan") && (
        <div className={styles.controlsWrapper}>
          <span className={styles.control}>Неуспішне завершення анкети:</span>
          <Field
            name={`${question}${questionType}.canFailedQuestionnaire`}
            label="Неуспішне завершення"
            component={Select}
            isGrey
            options={canFailOptions[questionType]}
            disabled={disabled}
          />
        </div>
      )}
      {arrayType && (
        <div className={styles.addField} onClick={addAnswer}>
          + Додати ще
        </div>
      )}
    </div>
  );
};

export default AnswersList;
