//@flow
import moment from "moment";

export const changeQuestionsTempIds = (questions: FormFormattedQuestionT[]): QuestionsPostModelT[] => {
  const ids = {};
  const questionsWithCorrectQuestionsIds = questions.map((question, index) => {
    ids[question.tempId] = index;
    const { id } = question;
    return {
      title: question.title,
      tempId: index,
      answers: question.answers,
      answerType: question.answerType,
      questionLeadsToQuestionIds: question.questionLeadsToQuestionIds,
      id,
      status: question.status
    };
  });

  const questionsWithCorrectAnswersAndQuestionsIds = questionsWithCorrectQuestionsIds.map(question => {
    return {
      title: question.title,
      id: question.id,
      status: question.status,
      tempId: question.tempId,
      questionLeadsToQuestionIds:
        question.questionLeadsToQuestionIds && question.questionLeadsToQuestionIds.length
          ? Array.from(new Set(question.questionLeadsToQuestionIds.map(id => ids[id]).filter(id => id >= 0)))
          : [],
      answers: question.answers.map(answer => ({
        ...answer,
        answerType: question.answerType,
        leadsToQuestionIds:
          answer.leadsToQuestionIds && answer.leadsToQuestionIds[0]
            ? Array.from(new Set(answer.leadsToQuestionIds.map(id => ids[id]).filter(id => id >= 0)))
            : []
      }))
    };
  });

  return questionsWithCorrectAnswersAndQuestionsIds;
};

export const formatQuestionsForSaving = (questions: FormQuestionT[]) => {
  const formattedQuestions = [];
  const formatQuestions = (questionsUnfiltered, nextQuestionId, disabled) => {
    const questionsArray = questionsUnfiltered.filter(question => question.hasOwnProperty("title"));
    questionsArray &&
      questionsArray.forEach((question, questionIndex) => {
        const { id } = question;
        let formattedQuestion = {
          title: question.title,
          answers: [],
          answerType: question.questionType && question.questionType.id,
          tempId: question.tempId,
          questionLeadsToQuestionIds: [],
          id,
          status: question.status && !disabled ? 1 : 2
        };

        const questionTypeValue = question && question.questionType && question[question.questionType.value];
        const answers = questionTypeValue && questionTypeValue.answers;
        const dependencies = questionTypeValue && questionTypeValue.dependencies;

        const nextActiveQuestion = questionsArray.find((item, index) => {
          return index > questionIndex && item.status && item.tempId;
        });

        // next active question
        const next = (nextActiveQuestion && nextActiveQuestion.tempId) || nextQuestionId;

        // next question
        const nextQuestion = questionsArray[questionIndex + 1] && questionsArray[questionIndex + 1].tempId;

        if (nextQuestion !== nextQuestionId && nextQuestion) {
          formattedQuestion.questionLeadsToQuestionIds = [nextQuestion];
        }

        const formattedAnswers = answers
          ? answers.map((answer, index) => {
              const { id } = answer;
              const formattedAnswer = {
                value: answer.title,
                id,
                tempId: index,
                leadsToQuestionIds: answer.leadsToQuestionIds || [],
                canFailedQuestionnaire: !!answer.canFailedQuestionnaire,
                hasDependency: false,
                status: answer.status ? 1 : 2
              };

              const dependency = dependencies && dependencies[index];
              const firstActiveQuestion =
                dependency && dependency.questions && dependency.questions.find(question => question.status);

              if (firstActiveQuestion) {
                formattedAnswer.leadsToQuestionIds = dependency.questions.map(question => question.tempId);
              }
              if (answer.leadsToQuestion) {
                formattedAnswer.hasDependency = true;
              } else if (dependency && dependency.questions && !!dependency.questions.find(item => !!item.id)) {
                /* if parent question was deactivated (answer.leadsToQuestion === false )
                  but it has dependencies -> deactivate all branch,
                  but add hasDependency - true to build dependencies again if question will be activated */
                formattedAnswer.hasDependency = true;
                dependencies[index].questions = dependencies[index].questions.map(question => ({
                  ...question,
                  status: false
                }));
              } else {
                formattedAnswer.leadsToQuestionIds.push(next);
              }

              return formattedAnswer;
            })
          : [
              {
                value: null,
                tempId: 0,
                leadsToQuestionIds: [next],
                canFailedQuestionnaire: false,
                status: 1,
                hasDependency: false
              }
            ];
        formattedQuestion.answers = formattedAnswers;
        formattedQuestions.push(formattedQuestion);

        if (dependencies && dependencies.length) {
          dependencies.forEach(item => {
            if (
              item.questions &&
              item.questions.length &&
              (item.leadsToQuestion || item.hasDependency || (item.id && item.questions.find(question => question.id)))
            ) {
              const dependencyQuestions =
                item.hasDependency || item.leadsToQuestion ? item.questions : item.questions.filter(item => item.id);

              const isDisabled = formattedQuestion.status === 2 || disabled || !item.status;
              formatQuestions(dependencyQuestions, next, isDisabled);
            }
          });
        }
      });
  };
  formatQuestions(questions);
  const formattedQuestionsWithIds = changeQuestionsTempIds(formattedQuestions);
  return formattedQuestionsWithIds;
};

export const formatProjectsForSaving = (projects: QuestionnaireProjectT[]): QuestionnaireInfosPostModelT[] =>
  projects &&
  projects.map((project: QuestionnaireProjectT) => {
    const { questionnaireId } = project;
    return {
      countOfFilling: project.countOfFilling && Number(project.countOfFilling),
      fillingType: project.fillingType && project.fillingType.value,
      projectId: project.projectId && project.projectId.value,
      startDate: moment(project.startDate).format("YYYY-MM-DD"),
      endDate: moment(project.endDate).format("YYYY-MM-DD"),
      geoIds: project.allGeos ? [] : project.geos && project.geos.map(item => item.value),
      questionnaireId,
      status: project.status ? 1 : 2
    };
  });
