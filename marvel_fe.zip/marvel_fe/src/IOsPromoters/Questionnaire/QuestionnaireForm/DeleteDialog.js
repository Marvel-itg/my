// @flow
import React from "react";
import Button from "@material-ui/core/Button";
import IconClose from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import DialogActions from "@material-ui/core/DialogActions";
import DialogTitle from "@material-ui/core/DialogTitle";
import DestructiveButton from "../../../components/Buttons/DestructiveButton/DestructiveButton";
import styles from "../Questionnaire.module.scss";

type PropsT = {
  deleteHandler: Function,
  onClose: Function
};

const dialogStyles = { root: styles.dialogButtonsWrapper };

const DeleteDialog = (props: PropsT) => {
  const { deleteHandler, onClose } = props;

  return (
    <div className={styles.deleteProjectWrapper}>
      <div className={styles.deleteProjectModal}>
        <DialogTitle id="alert-dialog-title">Видалити проект?</DialogTitle>
        <DialogActions classes={dialogStyles}>
          <Button onClick={onClose} color="primary">
            Відміна
          </Button>
          <DestructiveButton handleClick={deleteHandler} label="Видалити" className={styles.deleteButton} />
        </DialogActions>
        <IconButton className={styles.closeButton} onClick={onClose}>
          <IconClose />
        </IconButton>
      </div>
    </div>
  );
};

export default DeleteDialog;
