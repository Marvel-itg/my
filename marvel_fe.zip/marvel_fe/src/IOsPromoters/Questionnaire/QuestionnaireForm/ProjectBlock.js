// @flow
import React from "react";
import { Field, formValueSelector, change } from "redux-form";
import cx from "classnames";
import moment from "moment";
import isEqual from "lodash/isEqual";
import type { FormProps } from "redux-form";
import { connect } from "react-redux";
import FormLabel from "@material-ui/core/FormLabel";
import IconDelete from "@material-ui/icons/Delete";
import IconButton from "@material-ui/core/IconButton";
import Checkbox from "@material-ui/core/Checkbox";
import FormGroup from "@material-ui/core/FormGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import InputField from "../../../components/InputField/InputField";
import Select from "../../../components/Select/Select";
import Switch from "../../../components/Switch/Switch";
import AsyncCitiesSelect from "../../../components/Select/AsyncCitiesSelect.js";
import InputDatePicker from "../../../components/InputField/InputDatePicker";
import DeleteDialog from "./DeleteDialog";
import { projectsSelector } from "../../../store/selectors/common";
import { normalizeInteger } from "../../../utils/reduxFormNormalizers";
import { completionTypesQuestionnaire } from "./constants";
import styles from "../Questionnaire.module.scss";

type PropsT = {
  projectsList: any[],
  currentProjectId: string
} & FormProps;

type StateT = {
  openedIndex: number | null
};

const CustomCheckbox = props => {
  return (
    <FormGroup row>
      <FormControlLabel
        control={
          <Checkbox color="primary" {...props.input} checked={props.input.value === "true"} disabled={props.disabled} />
        }
        label={props.label}
      />
    </FormGroup>
  );
};

class ProjectBlock extends React.Component<PropsT, StateT> {
  state = {
    openedIndex: null
  };

  componentDidUpdate = prevProps => {
    if (!isEqual(prevProps.projects, this.props.projects)) {
      this.props.projects.forEach((project, index) => {
        const shouldClearProjectGeos =
          (!prevProps.projects || !prevProps.projects[index] || !prevProps.projects[index].allGeos) &&
          project &&
          project.allGeos &&
          project.geos &&
          project.geos.length;
        if (shouldClearProjectGeos) {
          const fieldName = `projects[${index}].geos`;
          this.props.change("QuestionnaireForm", fieldName, []);
        }
      });
    }
  };

  openDialogHandler = index => this.setState({ openedIndex: index });
  closeDialogHandler = () => this.setState({ openedIndex: null });

  render() {
    const today = moment().startOf("day");
    const { fields, index, project, projectsList, projects, editMode, currentProjectId } = this.props;
    const disabled = editMode && !projects[index].status;
    const isNewProject = editMode && !projects[index].questionnaireId;
    const startDateHasCome =
      projects[index].startDate && moment(projects[index].startDate).isSameOrBefore(today, "day");
    const activeProject = editMode && startDateHasCome && !isNewProject;
    const isCurrentProject =
      editMode &&
      projects[index] &&
      projects[index].questionnaireId === Number(currentProjectId) &&
      projects.length > 1;

    return (
      <li key={index} className={cx(styles.blockWrapper, { [styles.activeBlock]: isCurrentProject })}>
        <div className={styles.projectTitle}>
          <h3>Проект №{index + 1}</h3>
          {editMode && !isNewProject && (
            <Field
              label={disabled ? "Активувати проект" : "Деактивувати проект"}
              name={`${project}.status`}
              placeholder="Проект"
              className={styles.inputField}
              component={Switch}
            />
          )}
          {fields.length > 1 && (!editMode || isNewProject) && (
            <>
              <IconButton className={styles.removeButton} onClick={() => this.openDialogHandler(index)}>
                <IconDelete color="error" />
              </IconButton>
              {this.state.openedIndex === index && (
                <DeleteDialog
                  onClose={this.closeDialogHandler}
                  deleteHandler={evt => {
                    fields.remove(index);
                    this.closeDialogHandler();
                  }}
                />
              )}
            </>
          )}
        </div>
        <Field
          required
          name={`${project}.projectId`}
          placeholder="Проект"
          className={styles.inputField}
          component={Select}
          options={projectsList}
          disabled={disabled || (editMode && !isNewProject && startDateHasCome)}
        />
        <FormLabel className={styles.formLabel} component="legend">
          Період активності анкети
        </FormLabel>
        <div className={styles.activityPeriodWrapper}>
          <Field
            required
            keyboard
            disableOpenOnEnter
            className={styles.inputHalfField}
            name={`${project}.startDate`}
            minDate={today}
            label="Дата початку"
            component={InputDatePicker}
            disabled={disabled || activeProject}
          />
          <Field
            required
            keyboard
            disableOpenOnEnter
            className={styles.inputHalfField}
            name={`${project}.endDate`}
            label="Дата кінця"
            minDate={today}
            component={InputDatePicker}
            disabled={disabled}
          />
        </div>
        <FormLabel className={styles.formLabel} component="legend">
          Населені пункти
        </FormLabel>
        <Field
          name={`${project}.allGeos`}
          label="Всі населені пункти"
          className={styles.inputField}
          component={CustomCheckbox}
          format={value => (value ? "true" : "false")}
          disabled={disabled}
        />
        <Field
          required
          name={`${project}.geos`}
          placeholder="Виберіть населені пункти"
          className={styles.inputField}
          withoutRegions
          component={AsyncCitiesSelect}
          disabled={projects[index].allGeos || disabled}
          geoType={5}
          isMulti
        />
        <Field
          required
          name={`${project}.fillingType`}
          placeholder="Тип заповнення"
          className={styles.countCompletions}
          component={Select}
          options={completionTypesQuestionnaire}
          disabled={disabled || activeProject}
        />
        <Field
          name={`${project}.countOfFilling`}
          label="Кількість заповнень"
          component={InputField}
          className={styles.countCompletions}
          normalize={normalizeInteger}
          required
          disabled={disabled || activeProject}
        />
      </li>
    );
  }
}

const mapStateToProps = state => {
  const selector = formValueSelector("QuestionnaireForm");
  const projects = selector(state, "projects");
  return {
    projectsList: projectsSelector(state),
    projects
  };
};

const mapDispatchToProps = {
  change
};
export default connect(mapStateToProps, mapDispatchToProps)(ProjectBlock);
