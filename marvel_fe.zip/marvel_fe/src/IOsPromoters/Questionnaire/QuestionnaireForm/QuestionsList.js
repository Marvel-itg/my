// @flow
import React, { useState } from "react";
import cx from "classnames";
import moment from "moment";
import type { FormProps } from "redux-form";
import { Field } from "redux-form";
import IconButton from "@material-ui/core/IconButton";
import IconDown from "@material-ui/icons/KeyboardArrowDown";
import IconRight from "@material-ui/icons/KeyboardArrowRight";
import OutlinedButton from "../../../components/Buttons/OutlinedButton/OutlinedButton";
import QuestionField from "./QuestionField";
import styles from "../Questionnaire.module.scss";

type PropsT = {
  answer: string,
  withTitle: boolean,
  editMode: boolean,
  disables: boolean
} & FormProps;

const QuestionsList = (props: PropsT) => {
  const { fields, withTitle, answer, editMode, disabled } = props;
  const [opened, toggleOpened] = useState(withTitle);
  const toggleHandler = () => toggleOpened(!opened);
  const addHandler = () => fields.push({ tempId: moment().valueOf(), status: true });

  return (
    <div className={withTitle ? styles.sectionWrapper : styles.dependencyWrapper}>
      {withTitle ? (
        <h3>Питання</h3>
      ) : (
        <div className={cx(styles.answerField, { [styles.disabled]: disabled })}>
          {" "}
          <IconButton onClick={toggleHandler} disabled={disabled}>
            {opened && !disabled ? <IconDown /> : <IconRight />}
          </IconButton>
          <Field
            name={props.titleFieldName}
            component={props => {
              const hasError = !opened && props.meta.touched && !!props.meta.error;
              return (
                <div>
                  <span className={cx(styles.answerTitle, { [styles.error]: hasError, [styles.disabled]: disabled })}>
                    Якщо відповідь {`"${answer}"`}
                  </span>
                  {hasError && <div className={styles.errorMessage}>{props.meta.error}</div>}
                </div>
              );
            }}
          />
        </div>
      )}
      {opened && !disabled && (
        <div className={cx({ [styles.questionBlock]: !withTitle })}>
          <ul className={styles.questionsList}>
            {fields &&
              fields.map((question, index) => (
                <QuestionField question={question} index={index} fields={fields} key={question} editMode={editMode} />
              ))}
          </ul>

          <OutlinedButton color="primary" label="+ Додати питання" aria-label="Add" clickHandler={addHandler} />
        </div>
      )}
    </div>
  );
};

export default QuestionsList;
