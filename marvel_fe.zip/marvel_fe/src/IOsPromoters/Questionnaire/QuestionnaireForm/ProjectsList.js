// @flow
import React from "react";
import type { FormProps } from "redux-form";
import OutlinedButton from "../../../components/Buttons/OutlinedButton/OutlinedButton";
import ProjectBlock from "./ProjectBlock";
import styles from "../Questionnaire.module.scss";

type PropsT = {
  disabled: boolean,
  editMode: boolean,
  currentProjectId: string
} & FormProps;

const ProjectsList = (props: PropsT) => {
  const { fields, editMode, currentProjectId } = props;
  const addProject = () => fields.push({ status: true });
  const isAddProjectButtonDisabled = fields.length === 100;
  return (
    <div className={styles.sectionWrapper}>
      <h3>Проекти</h3>
      <div className={styles.listWrapper}>
        <ul className={styles.sectionList}>
          {fields.map((project, index) => (
            <ProjectBlock
              project={project}
              index={index}
              fields={fields}
              key={index}
              editMode={editMode}
              currentProjectId={currentProjectId}
            />
          ))}
        </ul>
      </div>
      <OutlinedButton
        color="primary"
        label="+ Додати проект"
        aria-label="Add"
        clickHandler={addProject}
        disabled={isAddProjectButtonDisabled}
      />
    </div>
  );
};

export default ProjectsList;
