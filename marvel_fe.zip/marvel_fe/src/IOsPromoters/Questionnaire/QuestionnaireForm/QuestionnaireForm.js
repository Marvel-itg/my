// @flow
import React from "react";
import { Field, reduxForm, FieldArray } from "redux-form";
import type { FormProps } from "redux-form";
import { connect } from "react-redux";
import { compose } from "redux";
import { withRouter } from "react-router-dom";
import cx from "classnames";
import Paper from "@material-ui/core/Paper";
import KeyboardBackspaceIcon from "@material-ui/icons/KeyboardBackspace";
import IconButton from "@material-ui/core/IconButton";
import ContainedButton from "../../../components/Buttons/ContainedButton/ContainedButton";
import InputField from "../../../components/InputField/InputField";
import ErrorMessage from "../../../components/ErrorMessage/ErrorMessage";
import ProjectsList from "./ProjectsList";
import QuestionsList from "./QuestionsList";
import CircularProgress from "@material-ui/core/CircularProgress";
import {
  createQuestionnaire,
  getQuestionnaireData,
  editQuestionnaire
} from "../../../store/actions/promoters/questionnaire";
import { initialValuesSelector } from "../../../store/selectors/promoters/questionnaire";
import { normalizeLength } from "../../../utils/reduxFormNormalizers";
import { formatQuestionsForSaving, formatProjectsForSaving } from "./helpers";
import { validate } from "./validate";
import { classes } from "../../../helpers/spinner";
import styles from "../Questionnaire.module.scss";

type PropsT = {
  errorMessage: string
} & FormProps;

type StateT = {
  isSubmitting: boolean
};

class QuestionnaireForm extends React.PureComponent<PropsT, StateT> {
  state = {
    isSubmitting: false
  };

  componentDidMount() {
    const { id } = this.props.match.params;
    this.props.getQuestionnaireData(id);
  }

  componentDidUpdate(prevProps) {
    if (!prevProps.errorMessage && this.props.errorMessage) {
      this.setState({ isSubmitting: false });
    }
  }

  submitForm = values => {
    const { questions, projects, title } = values;
    const formattedQuestions = formatQuestionsForSaving(questions);
    const questionnaireInfos = formatProjectsForSaving(projects);
    const id = this.props.match.params.id !== "new" && Number(this.props.match.params.id);
    const data = { questionnaireTemplate: { title, id, questions: formattedQuestions }, questionnaireInfos };
    const editMode = this.props.match.params.id && this.props.match.params.id !== "new";
    if (!this.state.isSubmitting) {
      editMode ? this.props.editQuestionnaire(data) : this.props.createQuestionnaire(data);
      this.setState({ isSubmitting: true });
    }
  };

  goBack = () => this.props.history.goBack();

  render() {
    const { handleSubmit, errorMessage, loading, loaded } = this.props;
    const editMode = this.props.match.params.id && this.props.match.params.id !== "new";
    const currentProjectId = this.props.match.params.projectId;

    return (
      <Paper square className={cx("mainContent", styles.formWrapper)}>
        {loading || (editMode && !loaded) ? (
          <CircularProgress classes={classes} />
        ) : (
          <form onSubmit={handleSubmit(this.submitForm)} autoComplete="off" noValidate className={styles.formStyles}>
            <div>
              <IconButton onClick={this.goBack} className={styles.backButton}>
                <KeyboardBackspaceIcon className={styles.backIcon} />
              </IconButton>
            </div>
            <div className={styles.headerWrapper}>
              <Field
                name="title"
                label="Назва анкети"
                component={InputField}
                className={styles.title}
                multiline
                required
                normalize={normalizeLength(150)}
              />
              <ContainedButton
                type="submit"
                label="Зберегти анкету"
                className={styles.saveButton}
                disabled={this.state.isSubmitting}
              />
            </div>
            <FieldArray
              name="projects"
              component={ProjectsList}
              editMode={editMode}
              currentProjectId={currentProjectId}
            />
            <FieldArray name="questions" component={QuestionsList} withTitle editMode={editMode} />
            {errorMessage && <ErrorMessage error={errorMessage} />}
            <div className={styles.formFooter}>
              <ContainedButton
                type="submit"
                label="Зберегти анкету"
                className={styles.saveButton}
                disabled={this.state.isSubmitting}
              />
            </div>
          </form>
        )}
      </Paper>
    );
  }
}

const mapDispatchToProps = {
  createQuestionnaire,
  editQuestionnaire,
  getQuestionnaireData
};

const mapStateToProps = (state, ownProps) => {
  let preparedValues = initialValuesSelector(state);
  const { projectId } = ownProps.match.params;
  const projects = preparedValues && preparedValues.projects;

  if (projects && projects.length > 1) {
    const currentProject = projects.find(project => project.questionnaireId === Number(projectId));
    const filteredProjects = projects.filter(project => project.questionnaireId !== Number(projectId));
    preparedValues = { ...preparedValues, projects: [{ ...currentProject }, ...filteredProjects] };
  }

  return {
    initialValues: preparedValues,
    errorMessage: state.questionnaire.error,
    loading: state.questionnaire.loadingData,
    loaded: state.questionnaire.loadedData
  };
};

export default compose(
  withRouter,
  connect(mapStateToProps, mapDispatchToProps),
  reduxForm({
    form: "QuestionnaireForm",
    enableReinitialize: true,
    keepDirtyOnReinitialize: true,
    validate
  })
)(QuestionnaireForm);
