//@flow
import React from "react";
import { Field, reduxForm } from "redux-form";
import moment from "moment";
import { compose } from "redux";
import type { FormProps } from "redux-form";
import { connect } from "react-redux";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import InputDatePicker from "../../components/InputField/InputDatePicker";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import { validateDates } from "../../api/promoters/questionnaire";
import styles from "./Questionnaire.module.scss";

type PropsT = {
  questionnaireData: QuestionnaireDataProjectT,
  activateQuestionnaire: Function,
  initialValues: { endDate: Date }
} & FormProps;

type StateT = {
  errorMessage: null | string,
  isSubmitDisabled: boolean,
  isMounted: boolean
};

class ChangeEndDateForm extends React.Component<PropsT, StateT> {
  state = { errorMessage: null, isSubmitDisabled: true, isMounted: true };

  componentWillUnmount() {
    this.setState({ isMounted: false });
  }

  onEndDateChange = async endDate => {
    this.setState({ errorMessage: null });
    this.props.change("endDate", endDate);
    try {
      const {
        questionnaireId,
        questionnaireTemplateId,
        project: { id: projectId },
        startDate
      } = this.props.questionnaireData;
      await validateDates({
        questionnaireId,
        questionnaireTemplateId,
        projectId,
        status: 1,
        startDate: moment(startDate).format("YYYY-MM-DD"),
        endDate: moment(endDate).format("YYYY-MM-DD")
      });
      if (this.state.isMounted) {
        this.setState({ isSubmitDisabled: false });
      }
    } catch (error) {
      this.setState({
        errorMessage: error.message
      });
    }
  };

  submitActivate = ({ endDate }) => {
    this.props.activateQuestionnaire(this.props.questionnaireData, endDate);
  };

  render() {
    const { errorMessage, isSubmitDisabled } = this.state;
    const { handleSubmit, activatingError } = this.props;
    const today = moment();

    return (
      <form onSubmit={handleSubmit(this.submitActivate)}>
        <div className={styles.formTitle}>Відредагуйте дату закінчення</div>
        <Field
          required
          name="endDate"
          label="Дата закінчення"
          component={InputDatePicker}
          onChange={this.onEndDateChange}
          minDate={today}
        />
        {errorMessage && <ErrorMessage error={errorMessage} />}
        <ContainedButton disabled={isSubmitDisabled} type="submit" label="Активувати" className={styles.button} />
        {activatingError && <ErrorMessage error={activatingError} />}
      </form>
    );
  }
}

const mapStateToProps = ({ questionnaire: { error } }) => {
  return { activatingError: error };
};

export default compose(
  connect(mapStateToProps),
  reduxForm({
    form: "ChangeEndDateForm"
  })
)(ChangeEndDateForm);
