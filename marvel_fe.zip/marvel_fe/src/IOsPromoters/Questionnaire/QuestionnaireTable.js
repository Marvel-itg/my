// @flow
import React from "react";
import type { BrowserHistory } from "history";
import { Grid, TableHeaderRow, Table, Toolbar, TableBandHeader } from "@devexpress/dx-react-grid-material-ui";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import ToolbarRoot from "../../components/TableComponents/ToolbarRoot";
import TabsHeader from "../../components/TableComponents/TabsHeader";
import TableContainer from "../../components/TableComponents/TableContainer";
import PagingPanel from "../../components/TableComponents/PagingPanel";
import GridRoot from "../../components/TableComponents/GridRoot";
import WithStickyBandsTable from "../../HOCs/withStickyBandsTable";
import {
  DateFormatProvider,
  TransparentButtonProvider,
  DestructiveButtonProvider,
  PersonInfoProvider,
  ButtonProvider,
  CityProvider
} from "../../components/FormattedData/FormattedData";
import { availableItemsPerPage, defaultItemsPerPage } from "../../constants";

type PropsT = {
  data: QuestionnaireDataProjectT[],
  tab: number | string,
  tabs: TabT[],
  page: number,
  count: number,
  total: number,
  changeTab: Function,
  changeCurrentPage: Function,
  changePageSize: Function,
  activateQuestionnaire: Function,
  editQuestionnaire: Function,
  deactivateQuestionnaire: Function,
  renderAddButton: Function
} & BrowserHistory;

const commonColumns = [
  { name: "questionnaireTitle", title: "Назва анкети" },
  { name: "project", title: "Проект", getCellValue: row => row && row.project && row.project.name },
  { name: "geos", title: "Населений пункт" },
  { name: "startDate", title: "Дата старту" },
  { name: "endDate", title: "Дата кінця" },
  { name: "createdOn", title: "Дата та час створення" },
  { name: "createdByAccount", title: "Ким створено" },
  { name: "lastModifiedOn", title: "Дата та час редагування" },
  { name: "lastModifiedByAccount", title: "Ким редаговано" },
  { name: "edit", title: "Редагувати" }
];

const columns = {
  "1": [...commonColumns, { name: "deactivate", title: "Деактивувати" }],
  "2": [...commonColumns, { name: "activate", title: "Активувати" }],
  "3": [...commonColumns, { name: "deactivate", title: "Деактивувати" }]
};

const columnBands = [
  {
    title: "Період активності анкети",
    children: [{ columnName: "startDate" }, { columnName: "endDate" }]
  }
];

const forValues = {
  geos: ["geos"],
  startDate: ["startDate"],
  endDate: ["endDate"],
  createdOn: ["createdOn"],
  createdByAccount: ["createdByAccount"],
  lastModifiedOn: ["lastModifiedOn"],
  lastModifiedByAccount: ["lastModifiedByAccount"],
  edit: ["edit"],
  deactivate: ["deactivate"],
  activate: ["activate"]
};

const wrapStyles = {
  whiteSpace: "normal",
  wordWrap: "break-word"
};

const tableColumnExtensions = [
  { columnName: "geos", width: 400 },
  { columnName: "questionnaireTitle", width: 200 },
  { columnName: "project", width: 200 },
  { columnName: "createdOn", width: 180 },
  { columnName: "lastModifiedOn", width: 180 },
  { columnName: "edit", width: 130 },
  { columnName: "createdByAccount", width: 270 },
  { columnName: "lastModifiedByAccount", width: 270 },
  { columnName: "deactivate", width: 180 },
  { columnName: "activate", width: 170 }
];

const Cell = (tableProps: any) => {
  return <Table.Cell {...tableProps} style={wrapStyles} />;
};

const QuestionnaireTable = (props: PropsT) => {
  const {
    data,
    page,
    count,
    total,
    tab,
    tabs,
    changeTab,
    changeCurrentPage,
    changePageSize,
    activateQuestionnaire,
    editQuestionnaire,
    deactivateQuestionnaire,
    renderAddButton
  } = props;
  return (
    <>
      <Grid rows={data} columns={columns[tab]} rootComponent={GridRoot}>
        <PagingState
          currentPage={page || 0}
          onCurrentPageChange={changeCurrentPage}
          pageSize={count || defaultItemsPerPage}
          onPageSizeChange={changePageSize}
        />
        <CustomPaging totalCount={total} />

        <DateFormatProvider for={forValues.createdOn} showTime />
        <DateFormatProvider for={forValues.lastModifiedOn} showTime />

        <DateFormatProvider for={forValues.startDate} />
        <DateFormatProvider for={forValues.endDate} />
        <PersonInfoProvider for={forValues.lastModifiedByAccount} />
        <PersonInfoProvider for={forValues.createdByAccount} />
        <CityProvider for={forValues.geos} withAllValue />
        <TransparentButtonProvider for={forValues.edit} label="Редагувати" onClick={editQuestionnaire} />
        <DestructiveButtonProvider for={forValues.deactivate} onClick={deactivateQuestionnaire} label="Деактивувати" />
        <ButtonProvider for={forValues.activate} onClick={activateQuestionnaire} label="Активувати" />

        <Toolbar rootComponent={ToolbarRoot} />

        <Table
          columnExtensions={tableColumnExtensions}
          height="auto"
          cellComponent={Cell}
          containerComponent={TableContainer}
        />

        <TableHeaderRow />
        <TabsHeader changeTab={changeTab} activeTab={tab} tabs={tabs}>
          {renderAddButton()}
        </TabsHeader>

        <TableBandHeader columnBands={columnBands} />

        <PagingPanel pageSizes={availableItemsPerPage} noData={!total} />
      </Grid>
    </>
  );
};

export default WithStickyBandsTable(QuestionnaireTable);
