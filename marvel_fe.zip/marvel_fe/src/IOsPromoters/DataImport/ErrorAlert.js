// @flow
import React from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";

type PropsT = {
  open: boolean,
  close: Function
};

class ErrorAlert extends React.PureComponent<PropsT> {
  render() {
    return (
      <div>
        <Dialog open={this.props.open} onClose={this.props.close} aria-describedby="alert-dialog-description">
          <DialogTitle id="alert-dialog-title">Сталася помилка</DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">Сталася помилка при обробці данних.</DialogContentText>
          </DialogContent>
          <Button onClick={this.props.close} color="primary" autoFocus>
            Добре
          </Button>
        </Dialog>
      </div>
    );
  }
}

export default ErrorAlert;
