// @flow
import React from "react";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import cx from "classnames";
import { compose } from "redux";
import Dropzone from "react-dropzone";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import AddIcon from "@material-ui/icons/AddCircle";
import Button from "@material-ui/core/Button";
import { uploadExportFile } from "../../store/actions/common/import";
import ErrorAlert from "./ErrorAlert";
import { classes } from "../../helpers/spinner";
import styles from "../../components/InputFileMultiple/InputFileMultiple.module.scss";
import importStyles from "./DataImport.module.scss";

type PropsT = {
  uploadExportFile: Function,
  error: null | string,
  importing: boolean,
  imported: boolean
};

type StateT = {
  file: File[],
  isShowErrorAlert: boolean
};

const acceptedTypes = [".zip"];

const processMessage = <div>Будь ласка, дочекайтесь завершення операції. Обробка даних потребує деякий час.</div>;
const successMessage = <div>Імпорт даних завершено успішно.</div>;

const sendButton = (disabled, sendFile) => (
  <div className={importStyles.buttonWrapper}>
    <Button variant="outlined" color="primary" disabled={disabled} onClick={sendFile}>
      Завантажити
    </Button>
  </div>
);

class BrandsReport extends React.PureComponent<PropsT, StateT> {
  state = {
    file: [],
    isShowErrorAlert: false
  };

  componentDidUpdate(props) {
    if (!props.error && this.props.error) {
      this.setState({
        isShowErrorAlert: true
      });
    }
  }

  sendFile = () => this.props.uploadExportFile(this.state.file[0]);

  onDrop = filesToUpload => this.setState({ file: filesToUpload });

  hideAlert = () => this.setState({ isShowErrorAlert: false });

  render() {
    const { importing, error, imported } = this.props;
    const isDisableSendButton = !this.state.file.length || importing;
    return (
      <Paper square className="mainContent">
        <Dropzone
          accept={acceptedTypes}
          activeClassName={styles.dropzoneActive}
          rejectClassName={styles.dropzoneReject}
          onDrop={this.onDrop}
        >
          {({ getRootProps, getInputProps }) => (
            <div
              {...getRootProps()}
              className={cx(importStyles.dropzone, {
                [styles.dropzoneReject]: !!error
              })}
            >
              <AddIcon color="primary" className={styles.addIcon} />
              <input {...getInputProps()} />
              {importing && <CircularProgress classes={classes} />}
            </div>
          )}
        </Dropzone>
        {sendButton(isDisableSendButton, this.sendFile)}
        <div className={importStyles.buttonWrapper}>{importing && processMessage}</div>
        <div className={importStyles.buttonWrapper}>{imported && successMessage}</div>
        <ErrorAlert open={this.state.isShowErrorAlert} close={this.hideAlert} />
      </Paper>
    );
  }
}

const mapStateToProps = ({ importData: { error, importing, imported } }) => ({
  error,
  importing,
  imported
});

const mapDispatchToProps = {
  uploadExportFile
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(BrandsReport);
