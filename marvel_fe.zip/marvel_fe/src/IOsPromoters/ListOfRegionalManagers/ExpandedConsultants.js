// @flow
import React from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core";
import ListOfConsultants from "../Consultants/ListOfConsultantsForExpand";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import { getConsultantsByChief } from "../../store/actions/promoters/expandedTablesActions";
import { supervisorConsultantSelector, errorDeactivatingState } from "../../store/selectors/promoters/expandedTables";

type PropsT = {
  row: {
    id: number
  },
  classes: { [name: string]: string },
  getConsultantsByChief: Function,
  loading: boolean,
  consultantsByChief: CandidateT[],
  error: string,
  chiefAccountId?: number,
  deactivated: boolean
};

class ExpandedConsultants extends React.Component<PropsT> {
  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    if (!prevProps.deactivated && this.props.deactivated) {
      this.fetchData();
    }
  }

  fetchData = () => {
    const chiefAccountId = this.props.chiefAccountId || this.props.row.id;
    this.props.getConsultantsByChief(chiefAccountId, "supervisorConsultants");
  };

  render() {
    const { loading, consultantsByChief, error } = this.props;
    return (
      <React.Fragment>
        {!!consultantsByChief.length && (
          <div className={this.props.classes.wrapper}>
            <div className={this.props.classes.title}>Консультанти</div>
            <ListOfConsultants
              name="ExpandedConsultantComponent"
              consultantsList={consultantsByChief}
              errorDeactivating={errorDeactivatingState}
            />
          </div>
        )}
        {error && <ErrorMessage error={error} />}
        {!consultantsByChief.length && !loading && !error && <div>Немає команди</div>}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    expandedTablesReducer: { getSupervisorConsultantsError, deactivatedConsultant }
  } = state;
  return {
    consultantsByChief: supervisorConsultantSelector(state),
    error: getSupervisorConsultantsError,
    deactivated: deactivatedConsultant
  };
};

const mapDispatchToProps = {
  getConsultantsByChief
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  withStyles({
    title: {
      margin: "10px 0",
      color: "#003a70",
      fontSize: "16px",
      fontWeight: "bold"
    },
    wrapper: {
      marginBottom: "20px"
    }
  })
)(ExpandedConsultants);
