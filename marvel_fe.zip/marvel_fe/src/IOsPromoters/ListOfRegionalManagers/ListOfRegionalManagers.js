// @flow
import React from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import Paper from "@material-ui/core/Paper";
import debounce from "es6-promise-debounce";
import CircularProgress from "@material-ui/core/CircularProgress";
import type { BrowserHistory } from "history";
import RegionalManagersTable from "./RegionalManagersTable";
import Modal from "../../components/Modal/Modal";
import RegionalManagersProfileForm from "../RegionalManagerProfile/RegionalManagerInfoForm";
import DeactivateIOSForm from "../../components/DeactivateForm/DeactivateIOSForm";
import {
  receiveRegionalManagers,
  activateRegionalManager,
  deactivateRegionalManager
} from "../../store/actions/promoters/regionalManagersList";
import { createManagerProfile } from "../../store/actions/promoters/regionalManagerProfile";
import { openModal, closeModal } from "../../store/actions/common/modals";
import {
  regionalManagersListSelector,
  regionalManagersRowsCountSelector,
  errorStateDeactivating
} from "../../store/selectors/promoters/regionalManagers";
import { classes } from "../../helpers/spinner";
import {
  getPaginationConfig,
  getCommonParams,
  changeCurrentPage,
  changePageSize,
  changeTab,
  onSearchChange,
  shouldNotSendRequest
} from "../../helpers/common";
import { formatFormValues } from "../RegionalManagerProfile/helpers";

type PropsT = {
  changeTab: Function,
  loading: boolean,
  receiveRegionalManagers: Function,
  regionalManagersList: RegionalManagerT[],
  activateRegionalManager: Function,
  deactivateRegionalManager: Function,
  openModal: Function,
  closeModal: Function
} & BrowserHistory;

type StateT = {
  modalType: string,
  formName: string,
  modalBody: any,
  expandedRowIds: any[]
};

const cursorStyle = {
  cursor: "pointer"
};

const modalName = "RegionalManagerForm";

class ListOfRegionalManagers extends React.PureComponent<PropsT, StateT> {
  state = {
    modalType: "",
    formName: "",
    modalBody: <div />,
    expandedRowIds: []
  };

  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;
    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.setState({ expandedRowIds: [] });
        this.fetchData();
      }
    }
  }

  changeExpandedRowIds = ids => {
    const newIds = ids.filter(id => !this.state.expandedRowIds.includes(id));
    this.setState({ expandedRowIds: newIds });
  };

  renderRow = (tableProps: any) => {
    return (
      <tr
        style={cursorStyle}
        onClick={event => {
          event.stopPropagation();
          // FixMe: Refactor that code
          let newElements = [];
          const rowIndex = tableProps.tableRow.rowId;
          const find = this.state.expandedRowIds.filter(item => item === rowIndex);

          if (find.length) {
            newElements = [];
          } else {
            newElements = [rowIndex];
          }

          this.setState({ expandedRowIds: newElements });
        }}
      >
        {tableProps.children}
      </tr>
    );
  };

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  changeTab = (event: any, tab: string) => changeTab(tab, this.props.location.search, this.props.history);

  onSearchChange = (searchValue: string) => onSearchChange(searchValue, this.props.location.search, this.props.history);

  fetchData = debounce(() => {
    const { searchFieldName, searchValue, itemsOnPage, pageNumber, tab } = getCommonParams(this.props.location.search);
    const paginationConfig = { count: itemsOnPage, page: pageNumber, searchValue, searchFieldName };
    const params = { status: tab, paginationConfig };
    this.props.receiveRegionalManagers(params);
  }, 200);

  openAddModal = () => this.openModal("add");

  submitDeactivateForm = (data, accountId) => {
    const {
      comment,
      responsibleManager: { value: newChiefAccountId }
    } = data;
    const params = {
      accountId,
      comment,
      newChiefAccountId
    };
    this.props.deactivateRegionalManager(params);
  };

  submitAddForm = values => {
    this.props.createManagerProfile(formatFormValues(values));
  };

  openModal = (type, id) => {
    switch (type) {
      case "add": {
        const modalBody = (
          <RegionalManagersProfileForm accountType={this.props.accountType} submitForm={this.submitAddForm} />
        );
        this.setState({ modalBody, modalType: "", formName: "editRegionalManagerForm" });
        return this.props.openModal(modalName);
      }
      case "deactivate": {
        const modalBody = (
          <DeactivateIOSForm
            form="DeactivateRegionalManager"
            title="Деактивувати регіонального менеджера?"
            textFieldLabel="Додати коментар"
            textFieldName="comment"
            submitButtonText="Деактивувати"
            cancelButtonText="Ні"
            memberType="RegionalManagerIOS"
            cancelButtonHandler={this.props.closeModal}
            submitForm={this.submitDeactivateForm}
            errorState={errorStateDeactivating}
            targetAccountId={id}
          />
        );
        this.setState({ modalBody, modalType: "deactivate", formName: "" });
        return this.props.openModal(modalName);
      }
      default:
        return null;
    }
  };

  deactivateRegionalManager = id => this.openModal("deactivate", id);

  activateRegionalManager = id => this.props.activateRegionalManager(id);

  render() {
    const { page, count } = getPaginationConfig(this.props.location.search);
    const { tab } = getCommonParams(this.props.location.search);
    const { RManagerList, rowsCount } = this.props;
    return (
      <React.Fragment>
        {this.props.loading && <CircularProgress classes={classes} />}
        <Paper square className="mainContent">
          <RegionalManagersTable
            data={RManagerList}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            changeTab={this.changeTab}
            activateManager={this.activateRegionalManager}
            deactivateManager={this.deactivateRegionalManager}
            openModal={this.openAddModal}
            onSearchChange={this.onSearchChange}
            rowsCount={rowsCount}
            page={page}
            count={count}
            tab={tab || "3"}
            rowComponent={this.renderRow}
            expandedRowIds={this.state.expandedRowIds}
            changeExpandedRowIds={this.changeExpandedRowIds}
          />
        </Paper>
        {modalName === this.props.modalName && (
          <Modal formName={this.state.formName} type={this.state.modalType}>
            {this.state.modalBody}
          </Modal>
        )}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    regionalManagersList: { loading, activating, deactivating, deactivated },
    modals: { modalName },
    authenticationReducer: {
      user: { accountType }
    }
  } = state;
  return {
    RManagerList: regionalManagersListSelector(state),
    rowsCount: regionalManagersRowsCountSelector(state),
    loading: loading || activating || deactivating,
    modalName,
    deactivated,
    accountType
  };
};

const mapDispatchToProps = {
  receiveRegionalManagers,
  activateRegionalManager,
  deactivateRegionalManager,
  openModal,
  closeModal,
  createManagerProfile
};

export default compose(connect(mapStateToProps, mapDispatchToProps))(ListOfRegionalManagers);
