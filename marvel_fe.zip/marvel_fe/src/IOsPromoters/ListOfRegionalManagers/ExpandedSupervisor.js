// @flow
import React from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core";
import CircularProgress from "@material-ui/core/CircularProgress";
import SupervisorsList from "../Supervisors/SupervisorsList/SupervisorsListForExpand";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import ListOfConsultantsForExpand from "../Consultants/ListOfConsultantsForExpand";
import { getSupervisorsByChief, getConsultantsByChief } from "../../store/actions/promoters/expandedTablesActions";
import {
  regionalManagerConsultantSelector,
  errorDeactivatingState
} from "../../store/selectors/promoters/expandedTables";
import ExpandedConsultants from "./ExpandedConsultants";
import { classes } from "../../helpers/spinner";

type PropsT = {
  row: {
    id: number
  },
  classes: { [name: string]: string },
  getSupervisorsByChief: Function,
  getConsultantsByChief: Function,
  loading: boolean,
  error: string,
  supervisorsByChief: SupervisorT[],
  consultantsByChief: CandidateT[],
  deactivated: boolean
};

class ExpandedSupervisors extends React.Component<PropsT> {
  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    if (!prevProps.deactivated && this.props.deactivated) {
      this.fetchData();
    }
  }

  fetchData = () => {
    this.props.getSupervisorsByChief(this.props.row.id);
    this.props.getConsultantsByChief(this.props.row.id, "regionalManagerConsultants");
  };

  render() {
    const { supervisorsByChief, loading, error, consultantsByChief } = this.props;
    return (
      <React.Fragment>
        {!!supervisorsByChief.length && (
          <>
            <div className={this.props.classes.title}>Супервайзери</div>
            <SupervisorsList
              chiefAccountId={this.props.row.id}
              supervisors={supervisorsByChief}
              expandComponent={ExpandedConsultants}
              errorDeactivating={errorDeactivatingState}
            />
          </>
        )}
        {!!consultantsByChief.length && (
          <>
            <div className={this.props.classes.title}>Консультанти</div>
            <ListOfConsultantsForExpand
              name="SupervisorsConsultant"
              consultantsList={consultantsByChief}
              errorDeactivating={errorDeactivatingState}
            />
          </>
        )}
        {!supervisorsByChief.length && !consultantsByChief.length && !loading && !error && <div>Немає команди</div>}
        {error && <ErrorMessage error={error} />}
        {loading && <CircularProgress classes={classes} />}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    expandedTablesReducer: {
      supervisorsByChief,
      loadingSupervisors,
      loadingConsultants,
      deactivatedSupervisor,
      deactivatedConsultant,
      getSupervisorsByChiefError,
      getConsultantsByChiefError
    }
  } = state;
  return {
    consultantsByChief: regionalManagerConsultantSelector(state),
    supervisorsByChief,
    loading: loadingSupervisors || loadingConsultants,
    error: getSupervisorsByChiefError || getConsultantsByChiefError,
    deactivated: deactivatedConsultant || deactivatedSupervisor
  };
};

const mapDispatchToProps = {
  getSupervisorsByChief,
  getConsultantsByChief
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  withStyles({
    title: {
      margin: "10px 0 30px",
      color: "#003a70",
      fontSize: "16px",
      fontWeight: "bold"
    }
  })
)(ExpandedSupervisors);
