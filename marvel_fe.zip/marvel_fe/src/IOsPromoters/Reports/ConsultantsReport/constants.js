export const columns = [
  { name: "week", title: "Неділя" },
  { name: "region", title: "Регіон" },
  { name: "city", title: "Населений пункт" },
  { name: "codeTT", title: "Код ТТ" },
  { name: "titleTT", title: "Назва ТТ" },
  { name: "addressTT", title: "Адреса ТТ" },
  { name: "supervisor", title: "Супервайзер" },
  { name: "consultant", title: "Консультант" },
  { name: "workDate", title: "Дата праці" },
  { name: "contactTime", title: "Час контакту" },
  {
    name: "question1",
    title: "Чи ви курите марку сигарет компанії Marvel-ITG?"
  },
  {
    name: "question2",
    title: "Яку марку сигарет компаії Marvel-ITG Ви курите?"
  },
  {
    name: "question3",
    title: "Яка марка сигарет компанії Marvel-ITG була презентована?"
  },
  { name: "question4", title: "Чи була проведена додаткова активність?" },
  {
    name: "question5",
    title: "Чи купив споживач марку сигарет компанії Marvel-ITG?"
  },
  { name: "question6", title: "Яку марку сигарет купив споживач?" },
  { name: "question7", title: "Яку марку сигарет Ви курите? " },
  {
    name: "question8",
    title: "Яка марка сигарет компанії Marvel-ITG була презентована?"
  },
  { name: "question9", title: "Чи була проведена додаткова активність?" },
  {
    name: "question10",
    title: "Чи купив споживач марку сигарет компанії Marvel-ITG?"
  },
  { name: "question11", title: "Яку марку сигарет купив споживач? " }
];

export const columnExtensions = [
  { columnName: "week", width: 90 },
  { columnName: "region", width: 80 },
  { columnName: "city", width: 90 },
  { columnName: "codeTT", width: 75 },
  { columnName: "titleTT", width: 100 },
  { columnName: "addressTT", width: 100 },
  { columnName: "supervisor", width: 100 },
  { columnName: "consultant", width: 100 },
  { columnName: "workDate", width: 100 },
  { columnName: "contactTime", width: 100 },
  {
    columnName: "question1",
    width: 310
  },
  {
    columnName: "question2",
    width: 300
  },
  {
    columnName: "question3",
    width: 380
  },
  { columnName: "question4", width: 300 },
  {
    columnName: "question5",
    width: 370
  },
  { columnName: "question6", width: 230 },
  { columnName: "question7", width: 220 },
  {
    columnName: "question8",
    width: 370
  },
  { columnName: "question9", width: 220 },
  {
    columnName: "question10",
    width: 350
  },
  { columnName: "question11", width: 230 }
];

export const defaultHiddenColumnNames = [
  "question1",
  "question2",
  "question3",
  "question4",
  "question5",
  "question6",
  "question7",
  "question8",
  "question9",
  "question10",
  "question11"
];
