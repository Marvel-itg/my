// @flow
import React from "react";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { compose } from "redux";
import type { BrowserHistory } from "history";
import CircularProgress from "@material-ui/core/CircularProgress";
import Paper from "@material-ui/core/Paper";
import ReportTable from "../ReportTable/ReportTable";
import ReportToolbar from "../../../components/ExportTablesToolbar/ExportTablesToolbar";
import { fetchConsultantsReport, exportConsultantsReportCSV } from "../../../store/actions/promoters/report";
import { columns, columnExtensions, defaultHiddenColumnNames } from "./constants";
import { classes } from "../../../helpers/spinner";

type PropsT = {
  fetchConsultantsReport: Function,
  exportConsultantsReportCSV: Function,
  report: ConsultantsReportT[],
  history: BrowserHistory,
  uploading: boolean,
  loading: boolean
};

class ConsultantsReport extends React.Component<PropsT> {
  componentDidMount() {
    this.props.fetchConsultantsReport();
  }

  filterByDate = rangeFilter => {
    this.props.fetchConsultantsReport(rangeFilter);
  };

  exportCSV = () => {
    // pass data as param for export
    this.props.exportConsultantsReportCSV();
  };

  render() {
    const { uploading, loading } = this.props;
    const spinner = loading || uploading;
    return (
      <React.Fragment>
        <ReportToolbar filterData={this.filterByDate} loadHandler={this.exportCSV} />
        <Paper square className="mainContent">
          <ReportTable
            data={this.props.report || []}
            history={this.props.history}
            columns={columns}
            columnExtensions={columnExtensions}
            defaultHiddenColumnNames={defaultHiddenColumnNames}
          />
        </Paper>
        {spinner && <CircularProgress classes={classes} />}
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({ report: { report, loading, uploading } }) => ({
  report,
  uploading,
  loading
});

const mapDispatchToProps = {
  fetchConsultantsReport,
  exportConsultantsReportCSV
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(ConsultantsReport);
