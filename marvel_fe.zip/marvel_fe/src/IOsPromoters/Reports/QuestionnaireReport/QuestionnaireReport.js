// @flow
import React from "react";
import { connect } from "react-redux";
import { compose } from "redux";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import debounce from "es6-promise-debounce";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import QuestionnairesTable from "../QuestionnairesTable/QuestionnairesTable";
import ReportToolbar from "../../../components/ExportTablesToolbar/ExportTablesToolbar";
import { getQuestionnaireReport } from "../../../store/actions/promoters/questionnairesReports";
import {
  questionnaireSelector,
  questionnaireReportSelector
} from "../../../store/selectors/promoters/questionnairesReports";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  filterByDate,
  getCommonParams,
  shouldNotSendRequest
} from "../../../helpers/common";
import { classes } from "../../../helpers/spinner";
import { exportCSVQuestionnaireReport } from "../../../store/actions/promoters/questionnairesReports";

type PropsT = {
  loading: boolean,
  uploading: boolean,
  getQuestionnaireReport: Function,
  questionnaireReport: { data: QuestionnaireReportDataT[], rowsCount: number },
  columns: ColumnT[],
  additionalColumns?: string[],
  errorMessage: string
} & BrowserHistory;

class QuestionnaireReportPromoters extends React.Component<PropsT> {
  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;
    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  filterByDate = (rangeFilter: RangeFilterT) =>
    filterByDate(rangeFilter, this.props.location.search, this.props.history);

  getSearchData = () => {
    const params = getCommonParams(this.props.location.search);
    const questionnaireId = this.props.match.params.id;
    return { ...params, questionnaireId };
  };

  fetchData = debounce(() => {
    this.props.getQuestionnaireReport(this.getSearchData());
  }, 200);

  exportCSV = () => {
    const { dateStart, dateEnd, searchFieldName, searchValue } = getCommonParams(this.props.location.search);
    const questionnaireId = this.props.match.params.id;
    const params = { dateStart, dateEnd, searchFieldName, searchValue, questionnaireId };
    this.props.exportCSVQuestionnaireReport(params);
  };

  render() {
    const {
      columns,
      additionalColumns,
      additionalExtensions,
      loading,
      questionnaireReport,
      uploading,
      errorMessage
    } = this.props;
    const { page, count } = getPaginationConfig(this.props.location.search);
    const { dateStart, dateEnd } = getCommonParams(this.props.location.search);
    const initialValues = { startDate: dateStart, endDate: dateEnd };

    return (
      <React.Fragment>
        <ReportToolbar
          hasExportButton
          form="questionnaireDateFilter"
          filterData={this.filterByDate}
          loadHandler={this.exportCSV}
          initialValues={initialValues}
          uploading={uploading}
          disabled={loading || uploading}
          errorMessage={errorMessage}
        />
        <Paper square className="mainContent">
          <QuestionnairesTable
            data={questionnaireReport}
            columns={columns}
            additionalColumns={additionalColumns}
            additionalExtensions={additionalExtensions}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            page={page}
            count={count}
          />
        </Paper>
        {loading && <CircularProgress classes={classes} />}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    questionnairesReports: { loading, error, uploading }
  } = state;

  const { columns, additionalColumns, additionalExtensions } = questionnaireSelector(state);

  return {
    questionnaireReport: questionnaireReportSelector(state),
    columns,
    additionalColumns,
    additionalExtensions,
    loading,
    uploading,
    errorMessage: error
  };
};

const mapDispatchToProps = {
  getQuestionnaireReport,
  exportCSVQuestionnaireReport
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(QuestionnaireReportPromoters);
