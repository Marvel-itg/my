// @flow
import React from "react";
import { Plugin } from "@devexpress/dx-react-core";
import { Grid, Table, TableHeaderRow, Toolbar } from "@devexpress/dx-react-grid-material-ui";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import { DateFormatProvider, DurationProvider, ListProvider } from "../../../components/FormattedData/FormattedData";
import GridRoot from "../../../components/TableComponents/GridRoot";
import TableContainer from "../../../components/TableComponents/TableContainer";
import HeaderWrap from "../../../components/TableComponents/HeaderWrap";
import PagingPanel from "../../../components/TableComponents/PagingPanel";
import SearchForm from "../../../components/TableComponents/SearchForm/SearchForm";
import {
  availableItemsPerPage,
  defaultItemsPerPage,
  questionnaireReportSearchOptions,
  columnExtensions
} from "../../../constants";

const wordWrapStyles = {
  whiteSpace: "normal",
  wordWrap: "break-word"
};

const CellComponent = ({ style, ...props }) => {
  return <Table.Cell style={wordWrapStyles} {...props} />;
};

type PropsT = {
  data: { data: QuestionnaireReportDataT[], rowsCount: number },
  columns: ColumnT[],
  additionalColumns?: string[],
  additionalExtensions: any[],
  page: number,
  count: number,
  changeCurrentPage: Function,
  changePageSize: Function
};

const forValues = {
  startDate: ["startDate"],
  endDate: ["endDate"],
  dateOfWork: ["dateOfWork"],
  plannedStartDate: ["plannedStartDate"],
  factualStartDate: ["factualStartDate"],
  plannedEndDate: ["plannedEndDate"],
  factualEndDate: ["factualEndDate"],
  city: ["city"],
  breaksDuration: ["breaksDuration"]
};

const commonColumnExtensions = [
  ...columnExtensions,
  { columnName: "answeredDate", width: 170 },
  { columnName: "startTime", width: 120 },
  { columnName: "endTime", width: 120 },
  { columnName: "project", width: 120 },
  { columnName: "city", width: 300 },
  { columnName: "accountName", width: 300 },
  { columnName: "posAddress", width: 200 },
  { columnName: "posName", width: 200 },
  { columnName: "posAddress", width: 200 },
  { columnName: "posLawName", width: 150 },
  { columnName: "factualStartDate", width: 120 },
  { columnName: "plannedStartDate", width: 120 },
  { columnName: "plannedEndDate", width: 120 },
  { columnName: "factualEndDate", width: 120 },
  { columnName: "posCode", width: 120 }
];

const QuestionnairesTable = (props: PropsT) => {
  const {
    data,
    columns,
    additionalColumns = [],
    additionalExtensions = [],
    page,
    count,
    changeCurrentPage,
    changePageSize
  } = props;

  return (
    <Grid rows={data.data || []} columns={columns} rootComponent={GridRoot}>
      <PagingState
        currentPage={page || 0}
        onCurrentPageChange={changeCurrentPage}
        pageSize={count || defaultItemsPerPage}
        onPageSizeChange={changePageSize}
      />
      <CustomPaging totalCount={data.rowsCount} />
      <Plugin name="providers">
        {additionalColumns.map(item => (
          <ListProvider for={[item]} key={item} />
        ))}
      </Plugin>
      <DateFormatProvider for={forValues.dateOfWork} />
      <DateFormatProvider for={forValues.plannedStartDate} timeWithSeconds />
      <DateFormatProvider for={forValues.factualStartDate} timeWithSeconds />
      <DateFormatProvider for={forValues.plannedEndDate} timeWithSeconds />
      <DateFormatProvider for={forValues.factualEndDate} timeWithSeconds />
      <DateFormatProvider for={forValues.startDate} timeWithSeconds />
      <DateFormatProvider for={forValues.endDate} timeWithSeconds />
      <DurationProvider for={forValues.breaksDuration} />
      <Table
        height="auto"
        columnExtensions={[...commonColumnExtensions, ...additionalExtensions]}
        containerComponent={TableContainer}
        cellComponent={CellComponent}
      />
      <TableHeaderRow cellComponent={HeaderWrap} />
      <Toolbar />
      <PagingPanel pageSizes={availableItemsPerPage} noData={!data.rowsCount} />
      <SearchForm selectOptions={questionnaireReportSearchOptions} placeholder="Пошук" />
    </Grid>
  );
};

export default QuestionnairesTable;
