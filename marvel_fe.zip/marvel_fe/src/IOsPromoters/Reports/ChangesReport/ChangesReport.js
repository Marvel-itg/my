// @flow
import React from "react";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { compose } from "redux";
import debounce from "es6-promise-debounce";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import ReportTable from "../ReportTable/ReportTable";
import ReportToolbar from "../../../components/ExportTablesToolbar/ExportTablesToolbar";
import { fetchChangesReport, exportChangesReportCSV } from "../../../store/actions/promoters/changesReport";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  filterByDate,
  getCommonParams,
  shouldNotSendRequest
} from "../../../helpers/common";
import { columnExtensions, changesReportOptions } from "../../../constants";
import { columns } from "./constants";
import { classes } from "../../../helpers/spinner";

type PropsT = {
  fetchReport: Function,
  report: GeneralReportT[],
  exportChangesReportCSV: Function,
  uploading: boolean,
  loading: boolean
} & BrowserHistory;

const expandedColumnExtensions = [
  ...columnExtensions,
  { columnName: "region", width: 150 },
  { columnName: "locality", width: 300 },
  { columnName: "accountName", width: 270 },
  { columnName: "shiftAuthor", width: 270 },
  { columnName: "posLawName", width: 200 },
  { columnName: "posAddress", width: 270 },
  { columnName: "consultant", width: 270 },
  { columnName: "totalCount", width: 200 },
  { columnName: "projectName", width: 200 },
  { columnName: "shiftStatus", width: 140 }
];

class ChangesReport extends React.Component<PropsT> {
  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;
    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  filterByDate = (rangeFilter: RangeFilterT) =>
    filterByDate(rangeFilter, this.props.location.search, this.props.history);

  exportCSV = () => {
    const { dateStart, dateEnd, searchFieldName, searchValue } = getCommonParams(this.props.location.search);
    let params = { dateStart, dateEnd };
    if (searchValue) {
      params = { ...params, searchField: searchFieldName, searchValue };
    }
    this.props.exportChangesReportCSV(params);
  };

  fetchData = debounce(() => {
    const { searchValue, searchFieldName, itemsOnPage, pageNumber, dateStart, dateEnd } = getCommonParams(
      this.props.location.search
    );
    let params = { itemsOnPage, pageNumber, endDate: dateEnd, startDate: dateStart };
    if (searchValue) {
      params = { ...params, searchField: searchFieldName, searchValue };
    }
    this.props.fetchChangesReport(params);
  }, 200);

  render() {
    const { uploading, loading } = this.props;
    const spinner = loading || uploading;
    const { dateStart, dateEnd } = getCommonParams(this.props.location.search);
    const { page, count } = getPaginationConfig(this.props.location.search);
    const initialValues = { startDate: dateStart, endDate: dateEnd };
    return (
      <React.Fragment>
        <ReportToolbar
          filterData={this.filterByDate}
          form="changesReport"
          initialValues={initialValues}
          disabled={spinner}
          uploading={uploading}
          errorMessage={this.props.errorMessage}
        />
        <Paper square className="mainContent">
          <ReportTable
            filterOptions={changesReportOptions}
            data={this.props.report || []}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            columns={columns}
            page={page}
            count={count}
            total={this.props.total}
            columnExtensions={expandedColumnExtensions}
          />
        </Paper>
        {spinner && <CircularProgress classes={classes} />}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    changesReport: { report, loading, uploading, total, exportError }
  } = state;
  return {
    report,
    loading,
    uploading,
    total,
    errorMessage: exportError
  };
};

const mapDispatchToProps = {
  fetchChangesReport,
  exportChangesReportCSV
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(ChangesReport);
