// @flow
import React from "react";
import {
  Grid,
  Table,
  TableBandHeader,
  TableHeaderRow,
  Toolbar,
  TableSummaryRow
} from "@devexpress/dx-react-grid-material-ui";
import { PagingState, CustomPaging, SummaryState } from "@devexpress/dx-react-grid";
import { DateFormatProvider, DurationProvider } from "../../../components/FormattedData/FormattedData";
import HeaderWrap from "../../../components/TableComponents/HeaderWrap";
import GridRoot from "../../../components/TableComponents/GridRoot";
import TableContainer from "../../../components/TableComponents/TableContainer";
import SearchForm from "../../../components/TableComponents/SearchForm/SearchForm";
import PagingPanel from "../../../components/TableComponents/PagingPanel";
import WithStickyBandsTable from "../../../HOCs/withStickyBandsTable";
import { availableItemsPerPage, defaultItemsPerPage } from "../../../constants";
import { generalReportCells } from "../GeneralReportPromoters/constants";

type PropsT = {
  data: ReportT[],
  columns: ColumnT[],
  page: number,
  count: number,
  total: number,
  changeCurrentPage: Function,
  changePageSize: Function,
  summary: ReportT[],
  filterOptions: OptionT[],
  summaryRowClassName?: string,
  columnBands?: any[],
  columnExtensions?: TableColumnExtensionT[]
};

const forValues = {
  dateOfWork: ["dateOfWork", "date"],
  dateWithTime: ["startDate", "endDate", "plannedStartDate", "factualStartDate", "plannedEndDate", "factualEndDate"],
  breaksDuration: ["breaksDuration", "plannedShiftDuration", "factualShiftDuration", "technicalBreaksDuration"]
};

const wordWrapStyles = {
  whiteSpace: "normal",
  wordWrap: "break-word"
};

const CellComponent = ({ style, ...props }) => {
  return <Table.Cell style={wordWrapStyles} {...props} />;
};

class AnalyticsTablePromoters extends React.Component<PropsT> {
  RowComponent = props => {
    return (
      <>
        {this.props.summary.map((item, index) => {
          return (
            <Table.Row {...props} key={index}>
              {generalReportCells.map(cell => {
                return (
                  <Table.Cell className={this.props.summaryRowClassName || ""} key={cell}>
                    {(typeof item[cell] === "number" || typeof item[cell] === "string") && String(item[cell])}
                  </Table.Cell>
                );
              })}
            </Table.Row>
          );
        })}
      </>
    );
  };

  render() {
    const {
      data,
      columns,
      page,
      count,
      changeCurrentPage,
      changePageSize,
      total,
      columnBands,
      columnExtensions
    } = this.props;
    return (
      <Grid rows={data} columns={columns} rootComponent={GridRoot}>
        <PagingState
          currentPage={page}
          onCurrentPageChange={changeCurrentPage}
          pageSize={count || defaultItemsPerPage}
          onPageSizeChange={changePageSize}
        />
        <SummaryState />

        <DateFormatProvider for={forValues.dateWithTime} timeWithSeconds />
        <DateFormatProvider for={forValues.dateOfWork} />
        <DurationProvider for={forValues.breaksDuration} />

        <CustomPaging totalCount={total} />

        <Table
          height="auto"
          columnExtensions={columnExtensions || []}
          containerComponent={TableContainer}
          cellComponent={CellComponent}
        />
        <TableHeaderRow cellComponent={HeaderWrap} />
        {this.props.summary && this.props.summary.length > 0 && (
          <TableSummaryRow totalRowComponent={this.RowComponent} className={this.props.summaryRowClassName} />
        )}
        <Toolbar />

        <TableBandHeader columnBands={columnBands || []} />

        <PagingPanel pageSizes={availableItemsPerPage} noData={!total} />
        <SearchForm selectOptions={this.props.filterOptions} placeholder="Пошук" />
      </Grid>
    );
  }
}

export default WithStickyBandsTable(AnalyticsTablePromoters);
