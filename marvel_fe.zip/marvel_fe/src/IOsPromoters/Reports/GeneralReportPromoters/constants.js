import { formatDurationFromMinutesToHours } from "../../../utils/formatValues";

export const columns = [
  { name: "region", title: "Регіон" },
  { name: "city", title: "Населений пункт" },
  { name: "chief", title: "Відповідальний" },
  { name: "accountName", title: "Консультант" },
  { name: "projectName", title: "Проект зміни" },
  { name: "posCode", title: "Код ТТ зміни" },
  { name: "weekNumber", title: "Тиждень" },
  { name: "dateOfWork", title: "Дата змiни", getCellValue: row => row.startDate },
  { name: "startDate", title: "Час початку (факт)" },
  { name: "endDate", title: "Час завершення (факт)" },
  { name: "workedOutTotalHours", title: "Всього відпрацьовано годин" },
  { name: "breaksDuration", title: "Технічна перерва" },
  { name: "totalCount", title: "Інфо контакти з курцями: Загальні контакти з курцями" },
  {
    name: "infoMarvelCount",
    title: "Інфо контакти з курцями марок компанії Marvel-ITG"
  },
  {
    name: "infoOtherCount",
    title: "Інфо контакти з курцями марок інших компаній"
  },
  {
    name: "resultMarvelCount",
    title: "Результативні контакти з курцями марок компанії Marvel-ITG"
  },
  {
    name: "resultMarvelPurchaseCount",
    title: "Загальна кількість проданих пачок курцям Marvel-ITG"
  },
  {
    name: "resultOtherCount",
    title: "Результативні контакти з курцями марок інших компаній"
  },
  {
    name: "resultOtherPurchaseCount",
    title: "Загальна кількість проданих пачок курцям інших компаній"
  },
  {
    name: "switchingLevel",
    title: "Результативні контакти з курцями з покупками: рівень перемикань"
  },
  {
    name: "purchasedPacksTotalAmount",
    title: "Загальна кількість проданих пачок"
  },
  {
    name: "soldPacksTMMarvel",
    title: "Загальна кіл-ть проданих пачок TM Marvel"
  },
  {
    name: "scannedTMMarvelCodes",
    title: "Кількість відсканованих кодів ТМ Marvel в рамках зміни"
  },
  {
    name: "plannedDuration",
    title: "Робочий час: План",
    getCellValue: row => row.plannedDuration && formatDurationFromMinutesToHours(row.plannedDuration)
  },
  {
    name: "factualDuration",
    title: "Робочий час: Всього відпрацьованих годин",
    getCellValue: row => row.factualDuration && formatDurationFromMinutesToHours(row.factualDuration)
  },
  { name: "percentageCompletion", title: "Робочий час: % виконання" },
  { name: "cph", title: "CPH" }
];

export const generalReportCells = columns.map(item => item.name);
