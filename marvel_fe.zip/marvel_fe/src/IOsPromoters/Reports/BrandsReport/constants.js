export const columns = [
  { name: "week", title: "Неділя" },
  { name: "region", title: "Регіон" },
  { name: "city", title: "Населений пункт" },
  { name: "codeTT", title: "Код ТТ" },
  { name: "titleTT", title: "Назва ТТ" },
  { name: "addressTT", title: "Адреса ТТ" },
  { name: "supervisor", title: "Супевайзер" },
  { name: "consultant", title: "Консультант" },
  { name: "workDate", title: "Дата праці" },
  { name: "workTime", title: "Час роботи" },
  { name: "workHours", title: "Робочі години" },
  { name: "cph", title: "CPH" },
  {
    name: "marvelKsSGeneralContracts",
    title: "Загальні контакти з курцями"
  },
  {
    name: "marvelKsSInfoContractsMarvel",
    title: "Інфо контакти з курцями марок компанії Marvel-ITG"
  },
  {
    name: "marvelKsSInfoContractsOther",
    title: "Інфо контакти з курцями марок інших компаній"
  },
  {
    name: "marvelKsSResultContractsOther",
    title: "Результативні контакти з курцями марок інших компаній"
  },
  {
    name: "generalContracts",
    title: "Загальні контакти з курцями"
  },
  {
    name: "infoContractsMarvel",
    title: "Інфо контакти з курцями марок компанії Marvel-ITG"
  },
  {
    name: "infoContractsOther",
    title: "Інфо контакти з курцями марок інших компаній"
  },
  {
    name: "resultContractsOther",
    title: "Результативні контакти з курцями марок інших компаній"
  },
  {
    name: "marvelKsGeneralContracts",
    title: "Загальні контакти з курцями"
  },
  {
    name: "marvelKsInfoContractsMarvel",
    title: "Інфо контакти з курцями марок компанії Marvel-ITG"
  },
  {
    name: "marvelKsInfoContractsOther",
    title: "Інфо контакти з курцями марок інших компаній"
  },
  {
    name: "marvelKsResultContractsOther",
    title: "Результативні контакти з курцями марок інших компаній"
  }
];

export const columnBands = [
  {
    title: "Marvel KS",
    children: [
      { columnName: "marvelKsGeneralContracts" },
      { columnName: "marvelKsInfoContractsMarvel" },
      { columnName: "marvelKsInfoContractsOther" },
      { columnName: "marvelKsResultContractsOther" }
    ]
  },
  {
    title: "Marvel KS S",
    children: [
      { columnName: "marvelKsSGeneralContracts" },
      { columnName: "marvelKsSInfoContractsMarvel" },
      { columnName: "marvelKsSInfoContractsOther" },
      { columnName: "marvelKsSResultContractsOther" }
    ]
  }
];

export const columnExtensions = [
  { columnName: "week", width: 90 },
  { columnName: "region", width: 80 },
  { columnName: "city", width: 90 },
  { columnName: "codeTT", width: 75 },
  { columnName: "titleTT", width: 100 },
  { columnName: "addressTT", width: 100 },
  { columnName: "supervisor", width: 100 },
  { columnName: "consultant", width: 100 },
  { columnName: "workDate", width: 100 },
  { columnName: "workTime", width: 90 },
  { columnName: "workHours", width: 100 },
  { columnName: "cph", width: 60 },
  {
    columnName: "generalContracts",
    width: 190
  },
  {
    columnName: "infoContractsMarvel",
    width: 320
  },
  {
    columnName: "infoContractsOther",
    width: 310
  },
  {
    columnName: "resultContractsOther",
    width: 350
  }
];

export const defaultHiddenColumnNames = [
  "marvelKsSGeneralContracts",
  "marvelKsSInfoContractsMarvel",
  "marvelKsSInfoContractsOther",
  "marvelKsSResultContractsOther",
  "generalContracts",
  "infoContractsMarvel",
  "infoContractsOther",
  "resultContractsOther",
  "marvelKsGeneralContracts",
  "marvelKsInfoContractsMarvel",
  "marvelKsInfoContractsOther",
  "marvelKsResultContractsOther"
];
