// @flow
import React from "react";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { compose } from "redux";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import ReportTable from "../ReportTable/ReportTable";
import ReportToolbar from "../../../components/ExportTablesToolbar/ExportTablesToolbar";
import { fetchBrandsReport, exportBrandsReportCSV } from "../../../store/actions/promoters/report";
import { columns, columnBands, columnExtensions, defaultHiddenColumnNames } from "./constants";
import { classes } from "../../../helpers/spinner";

type PropsT = {
  fetchBrandsReport: Function,
  exportBrandsReportCSV: Function,
  report: BrandsReportT[],
  history: BrowserHistory,
  uploading: boolean,
  loading: boolean
};

class BrandsReport extends React.Component<PropsT> {
  componentDidMount() {
    this.props.fetchBrandsReport();
  }

  filterByDate = rangeFilter => {
    this.props.fetchBrandsReport(rangeFilter);
  };

  exportCSV = () => {
    // pass data as param for export
    this.props.exportBrandsReportCSV();
  };

  render() {
    const { uploading, loading } = this.props;
    const spinner = loading || uploading;
    return (
      <React.Fragment>
        <ReportToolbar filterData={this.filterByDate} loadHandler={this.exportCSV} />
        <Paper square className="mainContent">
          <ReportTable
            data={this.props.report || []}
            columnBands={columnBands}
            history={this.props.history}
            columns={columns}
            columnExtensions={columnExtensions}
            defaultHiddenColumnNames={defaultHiddenColumnNames}
          />
        </Paper>
        {spinner && <CircularProgress classes={classes} />}
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({ report: { report, loading, uploading } }) => ({
  report,
  uploading,
  loading
});

const mapDispatchToProps = {
  fetchBrandsReport,
  exportBrandsReportCSV
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(BrandsReport);
