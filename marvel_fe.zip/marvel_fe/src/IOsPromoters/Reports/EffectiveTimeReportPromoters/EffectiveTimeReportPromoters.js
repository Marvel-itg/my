// @flow
import React from "react";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { compose } from "redux";
import debounce from "es6-promise-debounce";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import ReportTable from "../ReportTable/ReportTable";
import ReportToolbar from "../../../components/ExportTablesToolbar/ExportTablesToolbar";
import {
  fetchEffectiveTimeReport,
  exportEffectiveTimeReportCSV
} from "../../../store/actions/promoters/effectiveTimeReport";
import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  filterByDate,
  getCommonParams,
  shouldNotSendRequest
} from "../../../helpers/common";
import { columnExtensions, effectiveTimeReportOptions } from "../../../constants";
import { columns } from "./constants";
import { classes } from "../../../helpers/spinner";

type PropsT = {
  fetchEffectiveTimeReport: Function,
  exportEffectiveTimeReportCSV: Function,
  report: EffectiveTimeReportT[],
  uploading: boolean,
  loading: boolean
} & BrowserHistory;

const expandedColumnExtensions = [
  ...columnExtensions,
  { columnName: "posRegion", width: 150 },
  { columnName: "posCity", width: 300 },
  { columnName: "chief", width: 270 },
  { columnName: "posAddress", width: 270 },
  { columnName: "posName", width: 200 },
  { columnName: "posLawName", width: 200 },
  { columnName: "accountName", width: 270 },
  { columnName: "consultant", width: 270 }
];

class EffectiveTimeReportPromoters extends React.Component<PropsT> {
  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;
    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  filterByDate = (rangeFilter: RangeFilterT) =>
    filterByDate(rangeFilter, this.props.location.search, this.props.history);

  exportCSV = () => {
    const { dateStart, dateEnd, searchFieldName, searchValue } = getCommonParams(this.props.location.search);
    let params = { dateStart, dateEnd };
    if (searchValue) {
      params = { ...params, searchField: searchFieldName, searchValue };
    }
    this.props.exportEffectiveTimeReportCSV(params);
  };

  fetchData = debounce(() => {
    const { searchValue, searchFieldName, itemsOnPage, pageNumber, dateStart, dateEnd } = getCommonParams(
      this.props.location.search
    );
    let params = { itemsOnPage, pageNumber, dateEnd, dateStart };
    if (searchValue) {
      params = { ...params, searchField: searchFieldName, searchValue };
    }
    this.props.fetchEffectiveTimeReport(params);
  }, 200);

  render() {
    const { uploading, loading } = this.props;
    const spinner = loading || uploading;
    const { page, count } = getPaginationConfig(this.props.location.search);
    const { dateStart, dateEnd } = getCommonParams(this.props.location.search);
    const initialValues = { startDate: dateStart, endDate: dateEnd };

    return (
      <React.Fragment>
        <ReportToolbar
          hasExportButton
          filterData={this.filterByDate}
          form="effectiveTimeReport"
          loadHandler={this.exportCSV}
          initialValues={initialValues}
          disabled={spinner}
          uploading={uploading}
          errorMessage={this.props.errorMessage}
        />
        <Paper square className="mainContent">
          <ReportTable
            filterOptions={effectiveTimeReportOptions}
            data={this.props.report || []}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            history={this.props.history}
            columns={columns}
            page={page}
            count={count}
            total={this.props.total}
            columnExtensions={expandedColumnExtensions}
          />
        </Paper>
        {loading && <CircularProgress classes={classes} />}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    effectiveTimeReport: { report, loading, uploading, total, uploadingError }
  } = state;
  return {
    report,
    loading,
    uploading,
    total,
    errorMessage: uploadingError
  };
};

const mapDispatchToProps = {
  fetchEffectiveTimeReport,
  exportEffectiveTimeReportCSV
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(EffectiveTimeReportPromoters);
