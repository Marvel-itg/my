export const columns = [
  { name: "week", title: "Неділя" },
  { name: "region", title: "Регіон" },
  { name: "city", title: "Населений пункт" },
  { name: "codeTT", title: "Код ТТ" },
  { name: "titleTT", title: "Назва ТТ" },
  { name: "addressTT", title: "Адреса ТТ" },
  { name: "supervisor", title: "Супервайзер" },
  { name: "consultant", title: "Консультант" },
  { name: "workDate", title: "Дата праці" },
  { name: "workTime", title: "Час роботи" },
  { name: "workHours", title: "Робочі години" },
  { name: "cph", title: "CPH" },
  { name: "presentedBrandTP", title: "Бренд,який будо презентовано ТП" },
  {
    name: "presentationOfTradingPrograms",
    title: "Презентація Торгової програми"
  }
];

export const columnExtensions = [
  { columnName: "week", width: 90 },
  { columnName: "region", width: 80 },
  { columnName: "city", width: 90 },
  { columnName: "codeTT", width: 75 },
  { columnName: "titleTT", width: 100 },
  { columnName: "addressTT", width: 100 },
  { columnName: "supervisor", width: 100 },
  { columnName: "consultant", width: 100 },
  { columnName: "workDate", width: 100 },
  { columnName: "workTime", width: 90 },
  { columnName: "workHours", width: 100 },
  { columnName: "cph", width: 60 },
  { columnName: "presentedBrandTP", width: 230 }
];
