// @flow
import React from "react";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { compose } from "redux";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import ReportTable from "../ReportTable/ReportTable";
import ReportToolbar from "../../../components/ExportTablesToolbar/ExportTablesToolbar";
import { fetchTPReport, exportTPReportCSV } from "../../../store/actions/promoters/report";
import { columns, columnExtensions } from "./constants";
import { classes } from "../../../helpers/spinner";

type PropsT = {
  fetchTPReport: Function,
  exportTPReportCSV: Function,
  report: TPReportT[],
  history: BrowserHistory,
  uploading: boolean,
  loading: boolean
};

class TradingPrograms extends React.Component<PropsT> {
  componentDidMount() {
    this.props.fetchTPReport();
  }

  filterByDate = rangeFilter => {
    this.props.fetchTPReport(rangeFilter);
  };

  exportCSV = () => {
    // pass data as param for export
    this.props.exportTPReportCSV();
  };

  render() {
    const { uploading, loading } = this.props;
    const spinner = loading || uploading;
    return (
      <React.Fragment>
        <ReportToolbar filterData={this.filterByDate} loadHandler={this.exportCSV} />
        <Paper square className="mainContent">
          <ReportTable
            data={this.props.report || []}
            history={this.props.history}
            columns={columns}
            columnExtensions={columnExtensions}
          />
        </Paper>
        {spinner && <CircularProgress classes={classes} />}
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({ report: { report, loading, uploading } }) => ({
  report,
  loading,
  uploading
});

const mapDispatchToProps = {
  fetchTPReport,
  exportTPReportCSV
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(TradingPrograms);
