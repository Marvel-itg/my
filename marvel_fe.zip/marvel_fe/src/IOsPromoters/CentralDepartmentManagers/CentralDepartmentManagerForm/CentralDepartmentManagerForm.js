// @flow
import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { compose } from "redux";
import { reduxForm, Field } from "redux-form";
import CircularProgress from "@material-ui/core/CircularProgress";
import type { FormProps } from "redux-form";
import { withRouter } from "react-router-dom";
import ContainedButton from "../../../components/Buttons/ContainedButton/ContainedButton";
import InputField from "../../../components/InputField/InputField";
import ChiefsSelect from "../../../components/Select/ChiefsSelect";
import BackButton from "../../../components/Buttons/BackButton/BackButton";
import ErrorMessage from "../../../components/ErrorMessage/ErrorMessage";
import ProfileDisabledInfo from "../../../components/ProfileDisabledInfo/ProfileDisabledInfo";
import { normalizeCyrillicName, phoneMask } from "../../../utils/reduxFormNormalizers";
import validate from "./../../Supervisors/SupervisorForm/validate";
import { configByRoles } from "../../../constants";
import { classes } from "../../../helpers/spinner";
import { getChiefs } from "../../../api/chiefs";
import styles from "./../../Supervisors/SupervisorForm/SupervisorForm.module.scss";

type PropsT = {
  changeMode: Function,
  editMode: boolean,
  isEditing: boolean,
  submitForm: Function,
  loading: boolean,
  errorMessage: string,
  accountType: number
} & FormProps;

const chiefData = {
  targetAccountType: configByRoles.centralDepartmentIOSConfig
};

const CentralDepartmentManagerForm = (props: PropsT) => {
  const [defaultOptions, setDefaultOptions] = useState([]);

  useEffect(() => {
    // use isSubscribed for prevent setState of unmounted component and memory leak as result
    let isSubscribed = true;
    async function loadDefaultOptions() {
      const userRole = props.accountType;
      const defaultOptions = await getChiefs("CentralDepartmentIOS", {
        ...chiefData,
        currentAccountType: userRole
      });
      if (isSubscribed) {
        setDefaultOptions(defaultOptions);
      }
    }
    loadDefaultOptions();
    return () => {
      isSubscribed = false;
    };
  }, []);

  const goBack = () => props.history.goBack();

  const { handleSubmit, submitForm, changeMode, editMode, isEditing, invalid } = props;
  const generalError = props.creatingError || props.errorMessage;
  const loading = props.creatingLoading || props.loading;
  const isEditButtonHidden = props.status === 4 ? true : false;
  const disableFieldsExceptPhone = props.status === 5 ? true : false;

  return (
    <>
      {loading && <CircularProgress classes={classes} />}
      <form
        autoComplete="off"
        noValidate
        onSubmit={handleSubmit(submitForm)}
        className={styles.newSupervisorFormWrapper}
      >
        {!editMode && <div className={styles.formTitle}>Новий менеджер ЦО</div>}
        {editMode && <BackButton label="Повернутися назад" handleClick={goBack} className={styles.backButtonStyles} />}
        <Field
          required
          name="lastName"
          component={InputField}
          normalize={normalizeCyrillicName}
          disabled={(editMode && !isEditing) || disableFieldsExceptPhone}
        />
        <Field
          required
          name="firstName"
          component={InputField}
          normalize={normalizeCyrillicName}
          disabled={(editMode && !isEditing) || disableFieldsExceptPhone}
        />
        <Field
          required
          name="middleName"
          component={InputField}
          normalize={normalizeCyrillicName}
          disabled={(editMode && !isEditing) || disableFieldsExceptPhone}
        />
        <Field
          required
          name="phone"
          component={InputField}
          type="tel"
          disabled={editMode && !isEditing}
          {...phoneMask}
        />
        <Field
          required
          options={defaultOptions}
          name="responsibleManager"
          component={ChiefsSelect}
          disabled={(editMode && !isEditing) || disableFieldsExceptPhone}
        />
        {editMode && <ProfileDisabledInfo />}

        {editMode &&
          !isEditButtonHidden &&
          (isEditing ? (
            <ContainedButton type="submit" disabled={invalid} label="Зберегти" className={styles.editButton} />
          ) : (
            <ContainedButton type="button" label="Редагувати" className={styles.editButton} handleClick={changeMode} />
          ))}
        {!editMode && (
          <ContainedButton disabled={invalid} type="submit" label="Додати" className={styles.createButton} />
        )}
        {generalError && <ErrorMessage error={generalError} />}
      </form>
    </>
  );
};

const mapStateToProps = state => {
  const {
    centralDepartmentManagersList: { error, submitting }
  } = state;
  return {
    creatingError: error,
    creatingLoading: submitting
  };
};

export default compose(
  withRouter,
  connect(mapStateToProps),
  reduxForm({
    form: "NewCDMPromoters",
    validate,
    enableReinitialize: true,
    keepDirtyOnReinitialize: true
  })
)(CentralDepartmentManagerForm);
