// @flow
import React from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import Paper from "@material-ui/core/Paper";
import debounce from "es6-promise-debounce";
import CircularProgress from "@material-ui/core/CircularProgress";
import type { BrowserHistory } from "history";
import CentralDepartmentManagersTable from "../CentralDepartmentManagersTable/CentralDepartmentManagersTable";
import DeactivateIOSForm from "../../../components/DeactivateForm/DeactivateIOSForm";
import CentralDepartmentManagerForm from "../CentralDepartmentManagerForm/CentralDepartmentManagerForm";
import Modal from "../../../components/Modal/Modal";
import {
  getPaginationConfig,
  getCommonParams,
  changeCurrentPage,
  changePageSize,
  changeTab,
  onSearchChange,
  shouldNotSendRequest
} from "../../../helpers/common";
import { classes } from "../../../helpers/spinner";
import {
  receiveCDManagers,
  activateCDManager,
  deactivateCDManager,
  createCDManager
} from "../../../store/actions/promoters/centralManagersList";
import {
  CDManagersListSelector,
  CDManagersRowsCountSelector,
  errorStateDeactivating
} from "../../../store/selectors/promoters/centralDepartmentManagers";
import { openModal, closeModal } from "../../../store/actions/common/modals";
import { defaultItemsPerPage } from "../../../constants";
import { formatFormValues } from "../CentralDepartmentManagerProfile/helpers";

type PropsT = {
  activeTab: string,
  changeTab: Function,
  loading: boolean,
  receiveCDManagers: Function,
  centralDepartmentManagersList: CentralDepartmentManagerT[],
  activateCDManager: Function,
  deactivateCDManager: Function,
  createCDManager: Function,
  openModal: Function,
  closeModal: Function
} & BrowserHistory;

type StateT = {
  modalType: string,
  modalBody: any
};

class ListOfCDManagers extends React.PureComponent<PropsT, StateT> {
  state = {
    modalType: "",
    modalBody: <div />
  };

  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;
    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }

    if (!prevProps.deactivated && this.props.deactivated) {
      this.props.history.push(`?page=1&count=${defaultItemsPerPage}&tab=3`);
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  changeTab = (event: any, tab: string) => changeTab(tab, this.props.location.search, this.props.history);

  onSearchChange = (searchValue: string) => onSearchChange(searchValue, this.props.location.search, this.props.history);

  fetchData = debounce(() => {
    const { searchFieldName, searchValue, itemsOnPage, pageNumber, tab } = getCommonParams(this.props.location.search);
    const paginationConfig = { count: itemsOnPage, page: pageNumber, searchValue, searchFieldName };
    const params = { status: tab, paginationConfig };
    this.props.receiveCDManagers(params);
  }, 200);

  submitDeactivateForm = (data, accountId) => {
    const {
      comment,
      responsibleManager: { value: newChiefAccountId }
    } = data;
    const params = {
      accountId,
      comment,
      newChiefAccountId
    };
    this.props.deactivateCDManager(params);
  };

  submitAddForm = values => {
    this.props.createCDManager(formatFormValues(values));
  };

  openModal = (type, id) => {
    switch (type) {
      case "add": {
        const modalBody = (
          <CentralDepartmentManagerForm
            formTitle="Новий менеджер ЦО"
            submitForm={this.submitAddForm}
            accountType={this.props.accountType}
          />
        );
        this.setState({ modalBody, modalType: "" });
        return this.props.openModal();
      }
      case "deactivate": {
        const modalBody = (
          <DeactivateIOSForm
            form="DeactivateCDManager"
            title="Деактивувати менеджера ЦО?"
            textFieldLabel="Додати коментар"
            textFieldName="comment"
            submitButtonText="Деактивувати"
            cancelButtonText="Ні"
            memberType="CentralDepartmentIOS"
            cancelButtonHandler={this.props.closeModal}
            errorState={errorStateDeactivating}
            submitForm={this.submitDeactivateForm}
            targetAccountId={id}
          />
        );
        this.setState({ modalBody, modalType: "deactivate" });
        return this.props.openModal();
      }
      default:
        return null;
    }
  };

  deactivateCDManager = id => this.openModal("deactivate", id);

  activateCDManager = id => this.props.activateCDManager(id);

  openAddModal = () => this.openModal("add");

  render() {
    const { CDManagerList, rowsCount } = this.props;
    const { page, count } = getPaginationConfig(this.props.location.search);
    const { tab } = getCommonParams(this.props.location.search);
    return (
      <React.Fragment>
        {this.props.loading && <CircularProgress classes={classes} />}
        <Paper square className="mainContent">
          <CentralDepartmentManagersTable
            data={CDManagerList}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            changeTab={this.changeTab}
            activateManager={this.activateCDManager}
            deactivateManager={this.deactivateCDManager}
            openAddModal={this.openAddModal}
            rowsCount={rowsCount}
            page={page}
            count={count}
            tab={tab || "3"}
          />
        </Paper>
        <Modal type={this.state.modalType} formName="NewCDMPromoters">
          {this.state.modalBody}
        </Modal>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    centralDepartmentManagersList: { loading, activating, deactivating, deactivated, error },
    authenticationReducer: {
      user: { accountType }
    }
  } = state;
  return {
    CDManagerList: CDManagersListSelector(state),
    rowsCount: CDManagersRowsCountSelector(state),
    loading: loading || activating || deactivating,
    deactivated,
    accountType,
    errorMessage: error
  };
};

const mapDispatchToProps = {
  receiveCDManagers,
  activateCDManager,
  deactivateCDManager,
  createCDManager,
  openModal,
  closeModal
};

export default compose(connect(mapStateToProps, mapDispatchToProps))(ListOfCDManagers);
