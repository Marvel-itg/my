// @flow
import React from "react";
import { withRouter } from "react-router-dom";
import { compose } from "redux";
import { Grid, Table, Toolbar, TableHeaderRow } from "@devexpress/dx-react-grid-material-ui";
import { withStyles } from "@material-ui/core/styles";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import type { BrowserHistory } from "history";
import {
  ButtonProvider,
  FullNameProvider,
  PhoneProvider,
  TransparentButtonProvider,
  DestructiveButtonProvider,
  DateFormatProvider,
  PersonInfoProvider
} from "../../../components/FormattedData/FormattedData";
import SearchForm from "../../../components/TableComponents/SearchForm/SearchForm";
import GridRoot from "../../../components/TableComponents/GridRoot";
import { ToolBarRootStyled } from "../../../components/TableComponents/ToolbarRoot";
import OutlinedButton from "../../../components/Buttons/OutlinedButton/OutlinedButton";
import TableContainerComponent from "../../../components/TableComponents/TableContainerComponent";
import PagingPanel from "../../../components/TableComponents/PagingPanel";
import TabsHeader from "../../../components/TableComponents/TabsHeader";
import { availableItemsPerPage, columnExtensions, iosManagersOptions } from "../../../constants";
import styles from "./CentralDepartmentManagersTable.module.scss";

type PropsT = {
  data: CentralDepartmentManagerT[],
  changeTab: Function,
  changePageSize: Function,
  activeTab: string,
  page: number,
  count: number,
  tab: string,
  openModal: Function,
  classes: { [string]: string },
  deactivateManager: Function,
  activateManager: Function,
  openAddModal: Function,
  changeCurrentPage: Function
} & BrowserHistory;

type StateT = {
  currentPage: number,
  pageSize: number,
  pageSizes: Array<number>
};

const commonColumns = [
  { name: "id", title: "ID" },
  { name: "lastName", title: "Прізвище" },
  { name: "firstName", title: "Ім'я" },
  { name: "middleName", title: "По батькові" },
  { name: "phone", title: "Номер телефону" }
];

const tabs = [
  { label: "Активні", value: "3" },
  { label: "Зміна телефону", value: "5" },
  { label: "Деактивовані", value: "4" }
];

const columns = {
  "3": [...commonColumns, { name: "profile", title: "Деталі профілю" }, { name: "deactivate", title: "Деактивувати" }],
  "4": [
    ...commonColumns,
    { name: "deactivationDate", title: "Дата деактивування" },
    { name: "deactivatedBy", title: "Ким деактивовано" },
    { name: "comment", title: "Коментар" },
    { name: "profile", title: "Деталі профілю" },
    { name: "activate", title: "Активувати" }
  ],
  "5": [...commonColumns, { name: "profile", title: "Деталі профілю" }]
};

const style = () => ({
  addButton: {
    order: 1,
    alignSelf: "flex-end",
    margin: "20px !important",
    width: "230px"
  }
});

const centralDepartmentsManagersColumnExtensions = [
  ...columnExtensions,
  { columnName: "deactivate", width: 180 },
  { columnName: "id", width: 100 },
  { columnName: "profile", width: 200 }
];

const forValues = {
  fullName: ["fullName"],
  phone: ["phone"],
  created: ["created"],
  deactivationDate: ["deactivationDate"],
  deactivatedBy: ["deactivatedBy"],
  activate: ["activate"],
  deactivate: ["deactivate"],
  profile: ["profile"]
};

class CentralDepartmentManagersTable extends React.Component<PropsT, StateT> {
  renderAddButton = () => (
    <OutlinedButton
      label="Додати менеджера ЦО"
      clickHandler={this.props.openAddModal}
      className={this.props.classes.addButton}
    />
  );

  render() {
    const {
      data,
      changeCurrentPage,
      changePageSize,
      changeTab,
      page,
      count,
      tab,
      rowsCount,
      deactivateManager,
      activateManager
    } = this.props;

    return (
      <Grid rows={data} columns={columns[tab || 3]} rootComponent={GridRoot}>
        <PagingState
          currentPage={page}
          onCurrentPageChange={changeCurrentPage}
          pageSize={count}
          onPageSizeChange={changePageSize}
        />
        <CustomPaging totalCount={rowsCount} />
        <FullNameProvider for={forValues.fullName} />
        <PhoneProvider for={forValues.phone} />
        <DateFormatProvider for={forValues.created} />
        <DateFormatProvider for={forValues.deactivationDate} />
        <PersonInfoProvider for={forValues.deactivatedBy} />
        <ButtonProvider for={forValues.activate} label="Активувати" onClick={activateManager} />
        <DestructiveButtonProvider for={forValues.deactivate} label="Деактивувати" onClick={deactivateManager} />
        <TransparentButtonProvider
          for={forValues.profile}
          label="Деталі Профілю"
          onClick={id => this.props.history.push(`/promoters/central-department-managers/${id}`)}
        />
        <Table
          columnExtensions={centralDepartmentsManagersColumnExtensions}
          height="auto"
          containerComponent={TableContainerComponent}
        />
        <TableHeaderRow />
        <Toolbar rootComponent={ToolBarRootStyled(styles.headerStyles)} />
        <TabsHeader changeTab={changeTab} activeTab={tab} tabs={tabs}>
          {this.renderAddButton()}
        </TabsHeader>
        <SearchForm selectOptions={iosManagersOptions} className={styles.searchFormStyles} placeholder="Пошук" />
        <PagingPanel pageSizes={availableItemsPerPage} noData={!data.length} />
      </Grid>
    );
  }
}

export default compose(withRouter, withStyles(style))(CentralDepartmentManagersTable);
