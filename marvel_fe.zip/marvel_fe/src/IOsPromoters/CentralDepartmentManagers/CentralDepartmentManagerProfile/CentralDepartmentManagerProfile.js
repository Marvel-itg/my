// @flow
import React from "react";
import Paper from "@material-ui/core/Paper/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import { receiveCDManager, editCDManager } from "../../../store/actions/promoters/centralManagerProfile";
import ActivityTable from "../../../containers/ActivityHistoryTable/ActivityTable";
import CentralDepartmentManagerForm from "../CentralDepartmentManagerForm/CentralDepartmentManagerForm";
import { classes } from "../../../helpers/spinner";
import { activityHistoryColumns } from "../../../constants";
import { formatFormValues } from "./helpers";
import {
  CDMProfileSelector,
  CDMActivityHistorySelector
} from "../../../store/selectors/promoters/centralDepartmentManagers";
import styles from "./CentralDepartmentManagerProfile.module.scss";

type PropsT = {
  isEditing: boolean,
  loading: boolean,
  editCDManager: Function,
  manager: CentralDepartmentManagerT | null,
  submitted: boolean,
  receiveCDManager: Function,
  errorMessage: string,
  classes: { [string]: string },
  activityHistory: ActivityRecordT[]
};

type StateT = {
  isEditing: boolean
};

class CentralDepartmentManagerProfile extends React.Component<PropsT & BrowserHistory, StateT> {
  state = { isEditing: false };

  componentDidMount() {
    const { id } = this.props.match.params;

    if (id) {
      this.props.receiveCDManager(id);
    }
  }

  componentDidUpdate(oldProps) {
    if (this.props.submitted && !oldProps.submitted) {
      this.setState({
        isEditing: false
      });
    }
  }

  submitForm = values => {
    this.props.editCDManager(formatFormValues(values));
  };

  changeMode = event => {
    event && event.preventDefault();
    this.setState(state => ({ isEditing: !state.isEditing }));
  };

  render() {
    const { loading, errorMessage, manager } = this.props;
    return (
      <Paper className="mainContent">
        <div className={styles.formWrapper}>
          {loading && !manager ? (
            <CircularProgress classes={classes} />
          ) : (
            <CentralDepartmentManagerForm
              initialValues={manager}
              isEditing={this.state.isEditing}
              submitForm={this.submitForm}
              changeMode={this.changeMode}
              errorMessage={errorMessage}
              loading={this.props.submitting}
              accountType={this.props.accountType}
              form="editCentralDepartmentManagerForm"
              editMode
              status={this.props.status}
            />
          )}
          <ActivityTable columns={activityHistoryColumns} data={this.props.activityHistory} />
        </div>
      </Paper>
    );
  }
}

const mapStateToProps = state => {
  const {
    centralDepartmentProfilePromoter: { loading, submitting, submitted, error, manager },
    authenticationReducer: {
      user: { accountType }
    }
  } = state;
  const status = manager && manager.account && manager.account.status;
  return {
    manager: CDMProfileSelector(state),
    activityHistory: CDMActivityHistorySelector(state),
    loading,
    submitting,
    submitted,
    accountType,
    errorMessage: error,
    status
  };
};

const mapDispatchToProps = {
  receiveCDManager,
  editCDManager
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(CentralDepartmentManagerProfile);
