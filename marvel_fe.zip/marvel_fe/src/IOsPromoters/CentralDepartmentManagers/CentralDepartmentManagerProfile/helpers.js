// @flow
import isEmpty from "lodash/isEmpty";
import omit from "lodash/omit";
import { formatObjectToFullName } from "../../../helpers/common";
import { formatDate } from "../../../utils/formatValues";
import { userStatusConfig } from "../../../constants";

export const formatFormValues = (values: any) => {
  const phone = values.phone && `+380${values.phone}`;
  const accountId = values.id;
  const chiefAccountId = values.responsibleManager.value;
  const firstName = values.firstName.trim();
  const lastName = values.lastName.trim();
  const middleName = values.middleName.trim();
  values = omit(values, ["responsibleManager", "chief", "id"]);
  const formatted = {
    ...values,
    geoIds: [],
    firstName,
    lastName,
    middleName,
    accountId,
    chiefAccountId,
    phone
  };
  return formatted;
};

export const formatInitialValues = (data: CentralDepartmentManagerT) => {
  data = omit(data, ["comment", "deactivatedBy", "deactivationDate", "gender"]);
  if (!isEmpty(data)) {
    const phone = data.phone && data.phone.substr(4);
    const creator = data.creator && formatObjectToFullName(data.creator);
    const createdAt = data.creationDate && formatDate(data.creationDate);
    const status = userStatusConfig[data.status];
    const responsibleManager =
      data.chief && data.chief.id
        ? {
            value: data.chief.id,
            label: formatObjectToFullName(data.chief)
          }
        : null;

    const initialValues = {
      ...data,
      phone,
      status,
      createdAt,
      createdBy: creator,
      responsibleManager
    };
    return initialValues;
  }
  return null;
};

export const filterActivityHistoryWithoutCreatingRecord = (activityHistory: ActivityRecordT[]): ActivityRecordT[] => {
  if (activityHistory && activityHistory.length) {
    const filteredHistory = activityHistory
      .filter(item => item.activityType !== 1)
      .map(item => {
        if (item.key === "Chief") {
          return {
            ...item,
            oldValue: item.oldValue && JSON.parse(item.oldValue)["fullName"],
            newValue: item.newValue && JSON.parse(item.newValue)["fullName"]
          };
        }
        return item;
      });
    return filteredHistory;
  }
  return [];
};
