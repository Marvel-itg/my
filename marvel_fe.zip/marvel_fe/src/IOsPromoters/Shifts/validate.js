import moment from "moment";
import { validationErrorMessages } from "../../constants";
import { calculateDuration } from "./helpers";

const checkIfDateIfBeforeCurrentTime = (date, time) => {
  const dateValue = moment(date).format("DD/MM/YYYY");
  const timeValue = moment(time).format("HH:mm");
  const string = `${dateValue} ${timeValue}`;
  return moment(string, "DD/MM/YYYY HH:mm").isBefore(moment());
};

const checkIfEndDateIfBeforeStartDate = (startTime, endTime) => moment(endTime).isBefore(moment(startTime));

export const shiftFormValidate = values => {
  const { required, minDuration, maxDuration } = validationErrorMessages();
  const errors = {};

  if (!values.posId) {
    errors.posId = required;
  }
  if (!values.consultant) {
    errors.consultant = required;
  }
  if (!values.date) {
    errors.date = required;
  }
  if (!values.startTime) {
    errors.startTime = required;
  }
  if (!values.endTime) {
    errors.endTime = required;
  }

  if (values.date && values.startTime) {
    if (checkIfDateIfBeforeCurrentTime(values.date, values.startTime)) {
      errors.startTime = "Час старту не може бути раніше ніж поточний час";
    }
  }
  if (values.date && values.endTime) {
    if (checkIfDateIfBeforeCurrentTime(values.date, values.endTime)) {
      errors.endTime = "Час завершення не може бути раніше ніж поточний час";
    }
  }

  if (values.startTime && values.endTime) {
    if (checkIfEndDateIfBeforeStartDate(values.startTime, values.endTime)) {
      errors.endTime = "Неможливо обрати час менший за час початку";
    } else {
      const { milliseconds, hours } = calculateDuration(values.startTime, values.endTime);
      if (hours > 16) {
        errors.duration = maxDuration;
      }
      if (milliseconds < 1800000) {
        errors.duration = minDuration;
      }
    }
  }
  if (!values.project) {
    errors.project = required;
  }
  return errors;
};

export const cancelShiftFormValidate = values => {
  const { required } = validationErrorMessages();
  const errors = {};

  if (!values.cancellationReason) {
    errors.cancellationReason = required;
  }

  return errors;
};
