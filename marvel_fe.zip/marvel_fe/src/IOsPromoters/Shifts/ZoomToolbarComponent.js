// @flow
import React from "react";
import { Template } from "@devexpress/dx-react-core";
import ZoomOutMap from "@material-ui/icons/ZoomOutMap";
import CallMade from "@material-ui/icons/CallMade";
import CallReceived from "@material-ui/icons/CallReceived";
import styles from "./Shifts.module.scss";

type PropsT = {
  zoomButtonHandler: Function,
  expandIconIsVisible: string,
  reduceIconIsVisible: string
};

const ZoomToolbarComponent = (props: PropsT) => {
  return (
    <Template name="toolbarContent">
      <div className={styles.tableResize} onClick={props.zoomButtonHandler}>
        <ZoomOutMap color="primary" className={props.expandIconIsVisible} />

        <div className={props.reduceIconIsVisible}>
          <CallMade color="primary" />
          <CallReceived color="primary" />
        </div>
      </div>
    </Template>
  );
};

export default ZoomToolbarComponent;
