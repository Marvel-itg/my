// @flow
import React from "react";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import OutlinedButton from "../../components/Buttons/OutlinedButton/OutlinedButton";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import styles from "./Shifts.module.scss";

type PropsT = {
  activeTab: string,
  exportShiftsReport: Function,
  changeTab: Function,
  openModal: Function,
  isExportButtonDisabled: boolean,
  tabs: any,
  errorMessage: string
};

const ShiftsHeader = (props: PropsT) => {
  const { openModal, changeTab, activeTab, tabs, exportShiftsReport, isExportButtonDisabled, errorMessage } = props;
  return (
    <div className={styles.routesHeader}>
      <Tabs value={activeTab} indicatorColor="primary" textColor="primary" onChange={changeTab}>
        {tabs.map(tab => (
          <Tab key={tab.value} label={tab.label} value={tab.value} />
        ))}
      </Tabs>
      <div className={styles.addNewShift}>
        <ContainedButton
          label="Вивантажити СSV"
          handleClick={exportShiftsReport}
          className={styles.exportCsvButton}
          disabled={isExportButtonDisabled}
        />
        {errorMessage && <ErrorMessage error={errorMessage} textAlign="right" className={styles.errorMessage} />}
        <OutlinedButton label="Додати зміну" clickHandler={() => openModal("add")} />
      </div>
    </div>
  );
};

export default ShiftsHeader;
