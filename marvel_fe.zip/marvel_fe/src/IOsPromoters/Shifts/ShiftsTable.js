// @flow
import React, { useState, useEffect } from "react";
import moment from "moment";
import { Grid, Table, TableHeaderRow, Toolbar } from "@devexpress/dx-react-grid-material-ui";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import GridRoot from "../../components/TableComponents/GridRoot";
import TableContainer from "../../components/TableComponents/TableContainer";
import PagingPanel from "../../components/TableComponents/PagingPanel";
import { ToolBarRootStyled } from "../../components/TableComponents/ToolbarRoot";
import ZoomToolbarComponent from "./ZoomToolbarComponent";
import styles from "./Shifts.module.scss";

import {
  ButtonProvider,
  PersonInfoProvider,
  ShiftStatusProvider,
  DateFormatProvider,
  DestructiveButtonProvider,
  EditRouteProvider,
  ChiefInfoProvider,
  ShiftDateProvider
} from "../../components/FormattedData/FormattedData";
import { columnExtensions, availableItemsPerPage, defaultItemsPerPage } from "../../constants";

const columnExtensionsRoutes = [
  { columnName: "city", width: 140 },
  { columnName: "details", width: 215 },
  { columnName: "address", width: 300 },
  { columnName: "cancel", width: 200 },
  { columnName: "consultant", width: 350 },
  { columnName: "chief", width: 350 },
  { columnName: "startDateTime", width: 150 },
  { columnName: "endDateTime", width: 150 },
  { columnName: "status", width: 200 }
];

const mergeColumnExtensions = [...columnExtensions, ...columnExtensionsRoutes];
type PropsT = {
  data: any[],
  openModal: Function,
  columns: ColumnT[],
  openDetails: Function,
  changeCurrentPage: Function,
  changePageSize: Function,
  openCancel: Function,
  openHistory: Function,
  openEditForm: Function,
  expandIconIsVisible: string,
  reduceIconIsVisible: string,
  zoomButtonHandler: Function,
  page: number,
  count: number,
  total: number,
  user: CurrentUserInfoT
};

const forValues = {
  consultant: ["consultant"],
  startDate: ["startDate"],
  endDate: ["endDate"],
  cancel: ["cancel"],
  details: ["details"],
  status: ["status"],
  edit: ["edit"],
  chief: ["chief"],
  date: ["date"]
};

const ShiftsTable = (props: PropsT) => {
  const {
    data,
    columns,
    changeCurrentPage,
    changePageSize,
    page,
    count,
    total,
    openDetails,
    openEditForm,
    openCancel,
    user
  } = props;
  const [currentTime, setTime] = useState(moment().startOf("minute"));
  useEffect(() => {
    const interval = setInterval(() => {
      setTime(moment());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const checkIfButtonIsHidden = row => {
    const offset = moment().utcOffset();
    const endDate = moment
      .utc(row.endDate)
      .startOf("minute")
      .utcOffset(offset);
    const expiredDate = moment(endDate).isBefore(currentTime);
    const chiefAccountId = row && row.consultant && row.consultant.chief && row.consultant.chief.accountId;
    const canDeactivate = user && (user.accountType === 1 || user.id === chiefAccountId);
    return row && (row.status === 2 || row.status >= 4 || !canDeactivate || expiredDate);
  };

  return (
    <Grid rows={data} columns={columns} rootComponent={GridRoot}>
      <PagingState
        currentPage={page || 0}
        onCurrentPageChange={changeCurrentPage}
        pageSize={count || defaultItemsPerPage}
        onPageSizeChange={changePageSize}
      />
      <CustomPaging totalCount={total} />
      <PersonInfoProvider for={forValues.consultant} />
      <ChiefInfoProvider for={forValues.chief} path="consultant.chief" />
      <ShiftDateProvider for={forValues.date} />
      <DateFormatProvider for={forValues.startDate} onlyTime />
      <DateFormatProvider for={forValues.endDate} onlyTime />
      <ShiftStatusProvider for={forValues.status} />
      <ButtonProvider for={forValues.details} onClick={openDetails} label="Деталі зміни" />
      <EditRouteProvider
        for={forValues.edit}
        onClick={openEditForm}
        label="Редагувати"
        checkHidden={checkIfButtonIsHidden}
      />
      <DestructiveButtonProvider
        for={forValues.cancel}
        onClick={openCancel}
        label="Відмінити зміну"
        checkHidden={checkIfButtonIsHidden}
      />
      <Table columnExtensions={mergeColumnExtensions} containerComponent={TableContainer} height="auto" />
      <TableHeaderRow />
      <Toolbar rootComponent={ToolBarRootStyled(styles.toolbarStyles)} />

      <ZoomToolbarComponent
        expandIconIsVisible={props.expandIconIsVisible}
        reduceIconIsVisible={props.reduceIconIsVisible}
        zoomButtonHandler={props.zoomButtonHandler}
      />
      <PagingPanel pageSizes={availableItemsPerPage} noData={!total} />
    </Grid>
  );
};
export default ShiftsTable;
