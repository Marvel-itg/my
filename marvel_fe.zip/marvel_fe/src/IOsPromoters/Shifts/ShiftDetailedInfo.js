// @flow
import React from "react";
import { connect } from "react-redux";
import type { BrowserHistory } from "history";
import CircularProgress from "@material-ui/core/CircularProgress";
import Paper from "@material-ui/core/Paper";
import Typography from "@material-ui/core/Typography";
import ActivityTable from "../../containers/ActivityHistoryTable/ActivityTable";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import BackButton from "../../components/Buttons/BackButton/BackButton";
import { getShiftData } from "../../store/actions/promoters/shifts";
import { shiftDetailedInfoSelector } from "../../store/selectors/promoters/shifts";
import styles from "./Shifts.module.scss";
import { classes } from "../../helpers/spinner";

export type ShiftDataLineT = { id?: string, label: string, value: any };

type PropsT = {
  shiftData: ShiftDataLineT[],
  loadingShift: boolean
} & BrowserHistory;

const activityHistoryColumns = [
  { name: "changedBy", title: "Ким змінено" },
  { name: "changedOn", title: "Коли змінено" },
  { name: "key", title: "Поле" },
  { name: "oldValue", title: "Попереднє значення" },
  { name: "newValue", title: "Нове значення" }
];

const statusesHistoryColumns = [
  { name: "changedBy", title: "Ким змінено" },
  { name: "date", title: "Коли змінено" },
  { name: "status", title: "Статус" },
  { name: "reason", title: "Причина" },
  { name: "comment", title: "Коментар" }
];
class ShiftDetailedInfo extends React.Component<PropsT> {
  componentDidMount() {
    const { id } = this.props.match.params;
    this.props.getShiftData(id);
  }

  goBack = () => this.props.history.goBack();

  renderFields = () => {
    const { shiftData } = this.props;
    return (
      shiftData &&
      shiftData.length &&
      shiftData.map(item => {
        if (item.id === "questionnaires") {
          return (
            <div key={item.label}>
              <b className={styles.subtitle}>{item.label}</b>
              <ul>{item.value && item.value.map(questionnaire => <li key={questionnaire}>{questionnaire}</li>)}</ul>
            </div>
          );
        }
        if (item.id === "image") {
          return (
            <div key={item.label}>
              <b className={styles.subtitle}>{item.label}</b>
              <img alt="Фото" src={item.value} className={styles.shiftDetailsImage} />
            </div>
          );
        }
        return (
          <div className={styles.shiftDetailsLine} key={item.label}>
            <b className={styles.subtitle}>{item.label}</b>
            <span>{item.value}</span>
          </div>
        );
      })
    );
  };

  render() {
    const { updateHistory, shiftStatusHistory, errorMessage, shiftData, loadingShift } = this.props;
    return (
      <Paper className={styles.shiftDetailsWrapper}>
        <div className={styles.backButtonWrapper}>
          <BackButton label="Повернутися назад" handleClick={this.goBack} />
        </div>
        <Typography variant="h5">Деталі зміни</Typography>
        {errorMessage && <ErrorMessage error={errorMessage} />}
        <div className={styles.shiftDetailsInfo}>{this.renderFields()}</div>
        {shiftData && (
          <>
            <Typography variant="h6">Історія редагування</Typography>
            <ActivityTable columns={activityHistoryColumns} data={updateHistory} />
            <Typography variant="h6">Історія зміни статусів</Typography>
            <ActivityTable columns={statusesHistoryColumns} data={shiftStatusHistory} />
          </>
        )}

        {loadingShift && <CircularProgress classes={classes} />}
      </Paper>
    );
  }
}

const mapStateToProps = state => {
  return {
    shiftData: shiftDetailedInfoSelector(state),
    updateHistory: (state.shifts.shiftData && state.shifts.shiftData.updateHistory) || [],
    shiftStatusHistory: (state.shifts.shiftData && state.shifts.shiftData.shiftStatusHistory) || [],
    errorMessage: state.shifts.error,
    loadingShift: state.shifts.loadingShift
  };
};

const mapDispatchToProps = {
  getShiftData
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ShiftDetailedInfo);
