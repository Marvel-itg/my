// @flow
import React from "react";
import { connect } from "react-redux";
import { Field, reduxForm, formValueSelector } from "redux-form";
import type { FormProps } from "redux-form";
import Button from "@material-ui/core/Button";
import DestructiveButton from "../../components/Buttons/DestructiveButton/DestructiveButton";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import Select from "../../components/Select/Select";
import InputField from "../../components/InputField/InputField";
import { cancelShift } from "../../store/actions/promoters/shifts";
import { commentFieldValidation } from "../../utils/reduxFormValidation";
import { normalizeDescription } from "../../utils/reduxFormNormalizers";
import { cancelShiftFormValidate } from "./validate";
import styles from "./Shifts.module.scss";

type PropsT = {
  selectedReason: OptionT,
  closeModal: Function,
  cancelShift: Function,
  errorMessage: string,
  id: string
} & FormProps;

const CancelShiftForm = (props: PropsT) => {
  const { handleSubmit, cancelShift, closeModal, valid, selectedReason, id, errorMessage } = props;
  const submitForm = values => {
    const reason = values && values.cancellationReason && values.cancellationReason.value;
    const comment = values.anotherReason;
    const data = { id, reason, comment };
    cancelShift(data);
  };

  const isAnotherReasonSelected = selectedReason && selectedReason.value === 7;
  return (
    <form onSubmit={handleSubmit(submitForm)} className={styles.formWrapper}>
      <div className={styles.formTitle}>Вкажіть причину відміни зміни</div>
      <Field name="cancellationReason" component={Select} />
      {isAnotherReasonSelected && (
        <Field
          name="anotherReason"
          component={InputField}
          multiline
          label="Вказати причину"
          validate={[commentFieldValidation]}
          normalize={normalizeDescription}
        />
      )}
      <div className={styles.buttonsWrapper}>
        <Button onClick={closeModal} color="primary">
          Назад
        </Button>
        <DestructiveButton
          disabled={!valid}
          label="Відмінити зміну"
          className={styles.button}
          handleClick={handleSubmit(submitForm)}
        />
      </div>
      {errorMessage && <ErrorMessage error={errorMessage} />}
    </form>
  );
};

const Form = reduxForm({ form: "CancelShiftForm", validate: cancelShiftFormValidate })(CancelShiftForm);

const selector = formValueSelector("CancelShiftForm");
const mapStateToProps = state => {
  const selectedReason = selector(state, "cancellationReason");
  return {
    selectedReason,
    errorMessage: state.shifts.error
  };
};

const mapDispatchToProps = {
  cancelShift
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Form);
