import React from "react";
import { compose } from "redux";
import { withScriptjs, withGoogleMap, GoogleMap, Marker } from "react-google-maps";
import MarkerInfoWindow from "./MarkerInfoWindow";
import pinOpen from "./Pin_open.png";
import pinCancelled from "./Pin_cancelled.png";
import pinFinished from "./Pin_finished.png";
import pinMulti from "./Pin_open_multy.png";
import pinProgress from "./Pin_progress.png";

const defaultMapCenter = { lat: 50.45, lng: 30.52 };

const markerIcons = {
  "1": pinOpen,
  "2": pinProgress,
  "3": pinOpen,
  "4": pinCancelled,
  "5": pinFinished,
  "6": pinCancelled,
  "7": pinMulti
};

const MapWithAMarker = compose(
  withScriptjs,
  withGoogleMap
)(props => {
  return (
    <GoogleMap
      defaultZoom={8}
      center={defaultMapCenter}
      defaultOptions={{
        scaleControl: false,
        mapTypeControl: false,
        panControl: false,
        fullscreenControl: false
      }}
      ref={map => {
        if (map) {
          if (props.markers && props.markers.length) {
            let bounds = new window.google.maps.LatLngBounds();

            props.markers.forEach((marker, index) => {
              if (marker.latitude && marker.longitude) {
                const position = new window.google.maps.LatLng(marker.latitude, marker.longitude);
                bounds.extend(position);
              }
            });
            map.fitBounds(bounds);
          }
        }
      }}
    >
      {props.markers.map((marker, index) => {
        const onClick = props.onClick.bind(this, marker.id);
        const markerUrl = marker.markersInfo.length > 1 ? markerIcons[7] : markerIcons[marker.markersInfo[0].status];
        const markerIcon = { url: markerUrl, scaledSize: new window.google.maps.Size(30, 35) };

        return (
          <Marker
            key={marker.id}
            onClick={onClick}
            position={{ lat: marker.latitude, lng: marker.longitude }}
            icon={markerIcon}
          >
            {props.selectedMarker === marker.id && (
              <MarkerInfoWindow marker={marker} closeInfoWindow={props.closeInfoWindow} />
            )}
          </Marker>
        );
      })}
    </GoogleMap>
  );
});

export default MapWithAMarker;
