import React, { useEffect, useRef } from "react";
import moment from "moment";
import { InfoWindow } from "react-google-maps";
import { formatObjectToFullName } from "../../../helpers/common";
import { formatPhone } from "../../../utils/reduxFormNormalizers";
import { shiftStatusMap } from "../../../constants";
import viberIcon from "./viber.svg";
import styles from "../Shifts.module.scss";

const MarkerInfoWindow = ({ marker, closeInfoWindow }) => {
  const myRef = useRef();

  const handleClickOutside = event => {
    if (!myRef.current.contains(event.target)) {
      closeInfoWindow();
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  });

  return (
    <InfoWindow>
      <div className={styles.markerWrapper} ref={myRef}>
        {marker.markersInfo.map(marker => {
          var offset = moment().utcOffset();

          const startTime = moment
            .utc(marker.startDate)
            .utcOffset(offset)
            .format("HH:mm");
          const endTime = moment
            .utc(marker.endDate)
            .utcOffset(offset)
            .format("HH:mm");
          const shiftTime = `${startTime} - ${endTime}`;

          const date = moment
            .utc(marker.startDate)
            .utcOffset(offset)
            .format("DD/MM/YYYY");

          const consultant = formatObjectToFullName(marker.consultant);

          return (
            <div>
              <h3>Iнформацiя про змiну</h3>
              <div className={styles.markersInfo}>
                <div className={styles.pinInfoWrapper}>
                  <span className={styles.pinLabel}>Юридична назва ТТ</span> <span>{marker.pointOfSale.lawName}</span>
                </div>
                <div className={styles.pinInfoWrapper}>
                  <span className={styles.pinLabel}>Фiзична назва ТТ</span> <span>{marker.pointOfSale.name}</span>
                </div>
                <div className={styles.pinInfoWrapper}>
                  <span className={styles.pinLabel}>Проект</span> <span>{marker.projectName}</span>
                </div>
                <div className={styles.pinInfoWrapper}>
                  <span className={styles.pinLabel}>Дата зміни</span> <span>{date}</span>
                </div>
                <div className={styles.pinInfoWrapper}>
                  <span className={styles.pinLabel}>Час зміни</span> <span>{shiftTime}</span>
                </div>
                <div className={styles.pinInfoWrapper}>
                  <span className={styles.pinLabel}>Статус</span> <span>{shiftStatusMap[marker.status]}</span>
                </div>
                <div className={styles.pinInfoWrapper}>
                  <span className={styles.pinLabel}>Консультант</span> <span>{consultant}</span>
                </div>
                <div className={styles.pinInfoWrapper}>
                  <span className={styles.pinLabel}>Телефон</span>{" "}
                  <a href={`viber://chat?number=${marker.consultant.phone}`}>
                    {formatPhone(marker.consultant.phone)}{" "}
                    <img alt="viber" src={viberIcon} width="15" height="15" className={styles.viberIcon} />
                  </a>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </InfoWindow>
  );
};

export default MarkerInfoWindow;
