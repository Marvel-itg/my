// @flow
import React from "react";
import { connect } from "react-redux";
import { formValueSelector } from "redux-form";
import type { BrowserHistory } from "history";
import CircularProgress from "@material-ui/core/CircularProgress";
import Paper from "@material-ui/core/Paper";
import Typography from "@material-ui/core/Typography";
import ZoomOutMap from "@material-ui/icons/ZoomOutMap";
import CallMade from "@material-ui/icons/CallMade";
import CallReceived from "@material-ui/icons/CallReceived";
import Modal from "../../components/Modal/Modal";
import ShiftsTable from "./ShiftsTable";
import ShiftsFilters from "./ShiftsFilters";
import ShiftForm from "./ShiftForm";
import CancelShiftForm from "./CancelShiftForm";
import ShiftsHeader from "./ShiftsHeader";
import MapWithAMarker from "./Map/GoogleMap";
import MapShiftForm from "./MapShiftForm";
import { projectsSelector } from "../../store/selectors/common";
import { filtersInitialValuesSelector, markersListSelector } from "../../store/selectors/promoters/shifts";
import { fetchShifts } from "../../store/actions/promoters/shifts";
import { openModal, closeModal } from "../../store/actions/common/modals";
import {
  getCityInitialData,
  getConsultantInitialData,
  clearShiftsList,
  exportShiftsReport
} from "../../store/actions/promoters/shifts";
import { googleMapKey } from "../../constants";
import { classes } from "../../helpers/spinner";

import {
  getPaginationConfig,
  changeCurrentPage,
  changePageSize,
  changeShiftConsultantId,
  changeShiftGeoId,
  changeShiftProjectId,
  getCommonParams,
  changeTab,
  changeShiftDate
} from "../../helpers/common";
import styles from "./Shifts.module.scss";

type PropsT = {
  selectedCity: { label: string, value: string, region: string, geoType?: string },
  selectedDate: string,
  selectedProject: number,
  submitted: boolean,
  loading: boolean,
  fetchShifts: Function,
  openModal: Function,
  closeModal: Function,
  cancelShift: Function,
  exportShiftsReport: Function,
  shiftsList: ShiftT[],
  user: CurrentUserInfoT,
  total: number,
  uploading: boolean,
  uploadingError: string
} & BrowserHistory;

type StateT = {
  modalBody: any,
  formName: string,
  modalType: string,
  value: number,
  mapExpand: boolean,
  tableExpand: boolean,
  selectedMarker: string | null,
  isExportButtonDisabled: boolean,
  shelters: []
};

const mapContainerStyle = { height: "100%", overflow: "hidden" };
const commonColumns = [
  {
    name: "city",
    title: "Населений пункт",
    getCellValue: row => row.pointOfSale && row.pointOfSale.address && row.pointOfSale.address.split(",")[0]
  },
  { name: "posId", title: "Код TT(план)", getCellValue: row => row.pointOfSale && row.pointOfSale.code },
  { name: "consultant", title: "ПІБ консультанта" },
  { name: "chief", title: "Відповідальний" },
  { name: "date", title: "Дата зміни" },
  { name: "startDate", title: "Час початку зміни(план)" },
  { name: "endDate", title: "Час закінчення зміни(план)" },
  { name: "status", title: "Статус зміни" },
  { name: "edit", title: "Редагування" },
  { name: "details", title: "Деталі зміни" },
  { name: "cancel", title: "Відмінити зміну" }
];

const tabs = [{ label: "Актуальні зміни", value: "1" }];

class Shifts extends React.Component<PropsT, StateT> {
  state = {
    formName: "",
    modalBody: <div />,
    modalType: "",
    value: 0,
    mapExpand: false,
    tableExpand: false,
    selectedMarker: null,
    shelters: [],
    isExportButtonDisabled: true
  };

  componentDidMount() {
    const { geoId, geoType, consultantId } = getCommonParams(this.props.location.search);
    if (geoId && (!this.props.filtersValues || !this.props.filtersValues.city)) {
      this.props.getCityInitialData(Number(geoId), Number(geoType));
    }
    if (consultantId && (!this.props.filtersValues || !this.props.filtersValues.consultant)) {
      this.props.getConsultantInitialData(Number(consultantId));
    }

    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      submitted,
      selectedProject,
      selectedCity,
      selectedDateStart,
      selectedDateEnd,
      selectedConsultant
    } = this.props;

    if (prevProps.selectedProject !== selectedProject) {
      changeShiftProjectId(selectedProject, this.props.location.search, this.props.history);
    }

    if (prevProps.selectedCity !== selectedCity) {
      changeShiftGeoId(selectedCity, this.props.location.search, this.props.history);
    }

    if (prevProps.selectedDateStart !== selectedDateStart || prevProps.selectedDateEnd !== selectedDateEnd) {
      changeShiftDate(selectedDateStart, selectedDateEnd, this.props.location.search, this.props.history);
    }

    if (prevProps.selectedConsultant !== selectedConsultant) {
      changeShiftConsultantId(selectedConsultant, this.props.location.search, this.props.history);
    }
    if (prevProps.location.key !== this.props.location.key || (!prevProps.submitted && submitted)) {
      this.fetchData();
    }
  }

  closeInfoWindow = () => this.setState({ selectedMarker: null });
  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);
  changeTab = (event: any, tab: string) => changeTab(tab, this.props.location.search, this.props.history);

  fetchData = () => {
    const { geoId, projectId, dateStart, dateEnd, consultantId, pageNumber, itemsOnPage } = getCommonParams(
      this.props.location.search
    );
    const params = { geoId, projectId, dateStart, dateEnd, consultantId, pageNumber, itemsOnPage };
    if (dateStart && dateEnd) {
      this.props.fetchShifts(params);
      this.setState({ isExportButtonDisabled: false });
    } else {
      this.props.clearShiftsList();
      this.setState({ isExportButtonDisabled: true });
    }
  };

  openModal = (type, id) => {
    switch (type) {
      case "add":
      case "edit": {
        const modalBody = <ShiftForm id={id} />;
        this.setState({ modalBody, formName: "ShiftForm", modalType: "" });
        return this.props.openModal();
      }
      case "cancel": {
        const modalBody = <CancelShiftForm id={id} closeModal={this.props.closeModal} />;
        this.setState({ modalBody, formName: "CancelShiftForm", modalType: "" });
        return this.props.openModal();
      }
      default:
        return null;
    }
  };

  mapExpanding = () => {
    this.setState({ mapExpand: !this.state.mapExpand, selectedMarker: null });
  };

  tableExpanding = () => {
    this.setState({ tableExpand: !this.state.tableExpand });
  };

  handleMarkerClick = (marker, event) => {
    this.setState({ selectedMarker: marker });
  };

  handleExportButtonClick = () => {
    const { geoId, projectId, dateStart, dateEnd, consultantId } = getCommonParams(this.props.location.search);
    const params = { geoId, projectId, dateStart, dateEnd, consultantId };
    if (geoId && projectId && dateStart && dateEnd) {
      this.props.exportShiftsReport({ ...params });
    }
  };

  openCancel = (id: number) => this.openModal("cancel", id);
  openHistory = (id: number) => this.openModal("history", id);
  openEditForm = (id: number) => this.openModal("edit", id);
  openDetails = id => this.props.history.push(`/promoters/shifts/${id}`);

  render() {
    const { loading, shiftsList, user, total, projects, filtersValues, statistic } = this.props;
    const { page, count } = getPaginationConfig(this.props.location.search);
    const { dateStart, dateEnd, tab, geoId, consultantId, projectId } = getCommonParams(this.props.location.search);
    const project = projects && projects.find(project => project.value === Number(projectId));
    const { mapExpand, tableExpand } = this.state;
    const columns = commonColumns;
    const tableIsVisible = mapExpand ? styles.tableContentFadeOut : styles.tableContent;
    const expandTableIconIsVisible = tableExpand ? styles.iconHide : styles.expandIconShow;
    const reduceTableIconIsVisible = tableExpand ? styles.reduceIconShow : styles.iconHide;
    const mapIsVisible = tableExpand ? styles.mapFadeOut : styles.mapContent;
    const expandIconIsVisible = mapExpand ? styles.iconHide : styles.expandIconShow;
    const reduceIconIsVisible = mapExpand ? styles.reduceIconShow : styles.iconHide;
    const city =
      geoId && filtersValues && filtersValues.city && Number(filtersValues.city.value) === geoId && filtersValues.city;
    const consultant =
      consultantId &&
      filtersValues &&
      filtersValues.consultant &&
      filtersValues.consultant.value === consultantId &&
      filtersValues.consultant;

    const initialValues = {};
    if (city) {
      initialValues.city = city;
    }
    if (consultant) {
      initialValues.consultant = consultant;
    }
    if (project) {
      initialValues.project = project;
    }
    if (dateStart) {
      initialValues.dateStart = dateStart;
    }
    if (dateEnd) {
      initialValues.dateEnd = dateEnd;
    }

    return (
      <React.Fragment>
        <div className={styles.mainWrapper}>
          <Paper square className={styles.routesHeaderContent}>
            <ShiftsHeader
              activeTab={tab || "1"}
              tabs={tabs}
              user={user}
              exportShiftsReport={this.handleExportButtonClick}
              isExportButtonDisabled={this.state.isExportButtonDisabled || this.props.uploading}
              openModal={this.openModal}
              changeTab={this.changeTab}
              errorMessage={this.props.uploadingError}
            />
            <ShiftsFilters
              initialValues={initialValues}
              defaultOptionsCity={filtersValues && filtersValues.geoId && [filtersValues.city]}
              defaultOptionsConsultant={filtersValues && filtersValues.geoId && [filtersValues.consultant]}
            />
          </Paper>

          <Paper square className={`${tableIsVisible}`}>
            <ShiftsTable
              expandIconIsVisible={expandTableIconIsVisible}
              reduceIconIsVisible={reduceTableIconIsVisible}
              zoomButtonHandler={this.tableExpanding}
              data={shiftsList}
              columns={columns}
              openModal={this.openModal}
              openDetails={this.openDetails}
              openEditForm={this.openEditForm}
              changeCurrentPage={this.changeCurrentPage}
              changePageSize={this.changePageSize}
              openCancel={this.openCancel}
              openHistory={this.openHistory}
              page={page}
              count={count}
              total={total}
              user={user}
            />
          </Paper>

          <Paper square className={`${mapIsVisible}`}>
            <div className={styles.mapHeader}>
              <Typography variant="h6">Звiт про змiни</Typography>

              <div className={styles.mapIconsResize} onClick={this.mapExpanding}>
                <ZoomOutMap color="primary" className={`${expandIconIsVisible}`} />

                <div className={`${reduceIconIsVisible}`}>
                  <CallMade color="primary" />
                  <CallReceived color="primary" />
                </div>
              </div>
            </div>
            <MapShiftForm initialValues={statistic} />

            <MapWithAMarker
              selectedMarker={this.state.selectedMarker}
              markers={this.props.markersList}
              onClick={this.handleMarkerClick}
              closeInfoWindow={this.closeInfoWindow}
              googleMapURL={googleMapKey}
              loadingElement={<div style={mapContainerStyle} />}
              containerElement={<div style={mapContainerStyle} />}
              mapElement={<div style={mapContainerStyle} />}
            />
          </Paper>
        </div>

        {loading && <CircularProgress classes={classes} />}
        <Modal formName={this.state.formName} type={this.state.modalType}>
          {this.state.modalBody}
        </Modal>
      </React.Fragment>
    );
  }
}

const selector = formValueSelector("ShiftsFilters");
const mapStateToProps = state => {
  let selectedDateStart = selector(state, "dateStart");
  const selectedDateEnd = selector(state, "dateEnd");
  const project = selector(state, "project");
  const city = selector(state, "city");
  const consultant = selector(state, "consultant");
  return {
    loading: state.shifts.loading,
    shiftsList: state.shifts.shiftsList,
    statistic: state.shifts.statistic,
    total: state.shifts.total,
    submitted: state.shifts.submitted,
    selectedDateStart,
    selectedDateEnd,
    selectedProject: project && project.value,
    selectedCity: city,
    selectedConsultant: consultant && consultant.value,
    user: state.authenticationReducer.user,
    projects: projectsSelector(state),
    filtersValues: filtersInitialValuesSelector(state),
    markersList: markersListSelector(state),
    uploadingError: state.shifts.uploadingError,
    uploading: state.shifts.uploading
  };
};

const mapDispatchToProps = {
  openModal,
  closeModal,
  fetchShifts,
  getCityInitialData,
  getConsultantInitialData,
  clearShiftsList,
  exportShiftsReport
};

export default connect(mapStateToProps, mapDispatchToProps)(Shifts);
