// @flow
import React from "react";
import { connect } from "react-redux";
import { Field, reduxForm, formValueSelector } from "redux-form";
import InputDatePicker from "../../components/InputField/InputDatePicker";
import Select from "../../components/Select/Select";
import AsyncCitiesSelect from "../../components/Select/AsyncCitiesSelect";
import AsyncConsultantsSelect from "../../components/Select/AsyncConsultantsSelect";
import { projectsSelector } from "../../store/selectors/common";
import { getConsultantsByFilter } from "../../api/promoters/shifts";
import styles from "./Shifts.module.scss";

type PropsT = {
  projects: OptionT[],
  projectId: number,
  dateStart: Date,
  dateEnd: Date,
  geoId: number,
  defaultOptionsCity: OptionT[],
  defaultOptionsConsultant: OptionT[]
};

const ShiftsFilters = (props: PropsT) => {
  const { projectId, dateStart, dateEnd, geoId } = props;

  const loadOptions = startsWith => {
    const params = { projectId, dateStart, dateEnd, geoId, startsWith };
    return getConsultantsByFilter(params);
  };

  const disableConsultantsSelect = !projectId || !dateStart || !dateEnd || !geoId;

  return (
    <div className={styles.filters}>
      <form className={styles.filtersFormWrapper}>
        <Field name="city" placeholder="Населений пункт" component={AsyncCitiesSelect} geoType={5} />
        <Field name="project" component={Select} options={props.projects} isSearchable isClearable />
        <Field name="dateStart" label="Дата початку" component={InputDatePicker} maxDate={dateEnd} required />
        <Field name="dateEnd" label="Дата закінчення" component={InputDatePicker} minDate={dateStart} required />
        <Field
          name="consultant"
          component={AsyncConsultantsSelect}
          loadOptions={loadOptions}
          disabled={disableConsultantsSelect}
        />
      </form>
    </div>
  );
};

const ShiftsFiltersForm = reduxForm({
  form: "ShiftsFilters",
  enableReinitialize: true,
  keepDirtyOnReinitialize: true
})(ShiftsFilters);

const selector = formValueSelector("ShiftsFilters");
const mapStateToProps = state => {
  const dateStart = selector(state, "dateStart");
  const dateEnd = selector(state, "dateEnd");
  const project = selector(state, "project");
  const city = selector(state, "city");
  return {
    projects: projectsSelector(state),
    geoId: city && city.value,
    projectId: project && project.value,
    dateStart,
    dateEnd
  };
};
export default connect(mapStateToProps)(ShiftsFiltersForm);
