// @flow
import React from "react";
import { connect } from "react-redux";
import cx from "classnames";
import { compose } from "redux";
import moment from "moment";
import { reduxForm, Field, formValueSelector } from "redux-form";
import type { FormProps } from "redux-form";
import CircularProgress from "@material-ui/core/CircularProgress";
import InputDatePicker from "../../components/InputField/InputDatePicker";
import InputTimePicker from "../../components/InputField/InputTimePicker";
import InputField from "../../components/InputField/InputField";
import Select from "../../components/Select/Select";
import AsyncCitiesSelect from "../../components/Select/AsyncCitiesSelect";
import AsyncPosCodesSelect from "../../components/Select/AsyncPosCodesSelect";
import AsyncConsultantsSelect from "../../components/Select/AsyncConsultantsSelect";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import {
  getShiftData,
  createShift,
  editShift,
  getPlannedShiftsTime,
  clearPlannedShiftsTime
} from "../../store/actions/promoters/shifts";
import { initialValuesSelector } from "../../store/selectors/promoters/shifts";
import { shiftFormValidate } from "./validate";
import { calculateDuration, formatPlannedTime } from "./helpers";
import { classes } from "../../helpers/spinner";
import styles from "./Shifts.module.scss";

type PropsT = {
  submitForm: Function,
  changeMode: Function,
  editMode: boolean,
  isEditing: boolean,
  change: Function,
  id: string,
  getShiftInfo: Function,
  clearShiftInfo: Function,
  createShift: Function,
  editShift: Function,
  projects: ProjectT[],
  addressList: string[],
  loadingShift: boolean,
  errorMessage: string,
  posName?: string,
  submittingShift: boolean
} & FormProps;

type StateT = {
  isSubmitting: boolean
};

class ShiftForm extends React.Component<PropsT, StateT> {
  state = {
    isSubmitting: false
  };

  componentDidMount() {
    if (this.props.id) {
      this.props.getShiftData(this.props.id);
    } else {
      this.props.clearPlannedShiftsTime();
    }
  }

  componentDidUpdate(prevProps) {
    if (prevProps.duration !== this.props.duration) {
      this.props.touch("duration");
      this.props.change("duration", this.props.duration);
    }
    if (!prevProps.errorMessage && this.props.errorMessage) {
      this.setState({ isSubmitting: false });
    }

    const { geoId, posId, consultant, date } = this.props;
    if (prevProps.geoId && prevProps.geoId !== geoId) {
      if (this.props.consultant) {
        this.props.change("consultant", null);
      }
      if (posId) {
        this.props.change("posId", null);
      }
    }

    const prevDate = prevProps.date && moment(prevProps.date).format("DD/MM/YYYY");
    const currentDate = date && moment(date).format("DD/MM/YYYY");
    if (prevProps.consultant !== consultant || prevDate !== currentDate) {
      if (date && consultant) {
        this.props.getPlannedShiftsTime({ date, consultantId: consultant });
      } else {
        this.props.clearPlannedShiftsTime();
      }
    }
  }

  submitForm = values => {
    if (!this.state.isSubmitting) {
      this.setState({ isSubmitting: true });
      const consultantId = values.consultant && values.consultant.value;
      const posId = values.posId && values.posId.value;
      const projectId = values.project && values.project.value;
      const geoId = values.geoId && values.geoId.value;
      const startHour = moment(values.startTime).get("hour");
      const startMinute = moment(values.startTime).get("minute");
      const endHour = moment(values.endTime).get("hour");
      const endMinute = moment(values.endTime).get("minute");
      const startDate = moment(values.date)
        .set("hour", startHour)
        .set("minute", startMinute);
      const endDate = moment(values.date)
        .set("hour", endHour)
        .set("minute", endMinute);
      const createValues = { consultantId, posId, projectId, startDate, endDate, geoId };
      const editValues = { id: this.props.id, startDate, endDate, posId };
      this.props.id ? this.props.editShift(editValues) : this.props.createShift(createValues);
    }
  };

  render() {
    const {
      handleSubmit,
      loadingShift,
      errorMessage,
      invalid,
      id,
      geoId,
      consultant,
      posName,
      submittingShift,
      plannedTime
    } = this.props;
    const editMode = !!id;
    const today = moment();

    return loadingShift ? (
      <CircularProgress classes={classes} />
    ) : (
      <form autoComplete="off" noValidate onSubmit={handleSubmit(this.submitForm)} className={styles.formWrapper}>
        <div className={styles.formTitle}>{editMode ? "Редагувати зміну" : "Створити зміну"}</div>

        <Field
          required
          name="geoId"
          placeholder="Населений пункт"
          className={styles.inputField}
          component={AsyncCitiesSelect}
          geoType={5}
          withoutRegions
          disabled={editMode}
        />

        <Field
          required
          name="posId"
          component={AsyncPosCodesSelect}
          className={styles.inputField}
          disabled={!geoId}
          geoId={geoId}
        />
        {posName && <span className={styles.posName}>{posName}</span>}

        <Field
          required
          name="consultant"
          placeholder="Консультант"
          component={AsyncConsultantsSelect}
          className={styles.inputField}
          disabled={!geoId || editMode}
          geoId={geoId}
        />

        <Field
          required
          className={styles.inputField}
          name="date"
          label="Дата"
          component={InputDatePicker}
          disabled={editMode}
          minDate={today}
        />
        {plannedTime && (
          <div className={styles.plannedTime}>
            Заплановано змін {plannedTime.planned} годин з {plannedTime.all} годин
          </div>
        )}

        <Field
          required
          className={styles.inputField}
          name="startTime"
          label="Час початку"
          component={InputTimePicker}
        />

        <Field
          required
          className={styles.inputField}
          name="endTime"
          label="Час завершення"
          component={InputTimePicker}
        />

        <Field
          required
          className={cx(styles.durationField, styles.inputField)}
          name="duration"
          label="Тривалість"
          component={InputField}
        />

        <Field
          required
          name="project"
          component={Select}
          className={styles.inputField}
          options={this.props.projects}
          disabled={editMode || !consultant}
        />

        <ContainedButton
          type="submit"
          disabled={invalid || submittingShift}
          label={editMode ? "Редагувати" : "Додати"}
          className={styles.createButton}
        />

        {errorMessage && <ErrorMessage error={errorMessage} />}
      </form>
    );
  }
}

const selector = formValueSelector("ShiftForm");
const mapStateToProps = state => {
  const {
    shifts: { error, loadingShift, submitting, plannedTime }
  } = state;
  const startTime = selector(state, "startTime");
  const endTime = selector(state, "endTime");
  const geoId = selector(state, "geoId");
  const date = selector(state, "date");
  const posId = selector(state, "posId");
  const consultant = selector(state, "consultant");

  const { formattedDuration } = calculateDuration(startTime, endTime);

  return {
    initialValues: initialValuesSelector(state),
    projects: consultant && consultant.projects ? consultant.projects : [],
    errorMessage: error,
    duration: formattedDuration,
    geoId: geoId && geoId.value,
    consultant: consultant && consultant.value,
    posId: posId && posId.value,
    posName: posId && posId.name,
    loadingShift,
    submittingShift: submitting,
    date,
    plannedTime: formatPlannedTime(plannedTime)
  };
};

const mapDispatchToProps = {
  getShiftData,
  createShift,
  editShift,
  getPlannedShiftsTime,
  clearPlannedShiftsTime
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  reduxForm({
    form: "ShiftForm",
    validate: shiftFormValidate,
    enableReinitialize: true,
    keepDirtyOnReinitialize: true
  })
)(ShiftForm);
