import moment from "moment";

export const calculateDuration = (startTime, endTime) => {
  if (startTime && endTime) {
    const duration = moment.duration(
      moment(endTime)
        .startOf("minute")
        .diff(moment(startTime).startOf("minute"))
    );
    return formatDuration(duration);
  }
  return {};
};

export const formatDuration = duration => {
  const formattedData = {};
  const hours = duration && duration.get("hours");
  const minutes = duration && duration.get("minutes");
  formattedData.milliseconds = duration && duration.as("milliseconds");
  if (Math.sign(hours) !== -1 && Math.sign(minutes) !== -1) {
    formattedData.hours = hours < 10 ? `0${hours}` : hours;
    formattedData.minutes = minutes < 10 ? `0${minutes}` : minutes;
    formattedData.formattedDuration = duration && `${formattedData.hours}:${formattedData.minutes}`;
  } else {
    formattedData.formattedDuration = 0;
  }
  return formattedData;
};

export const formatPlannedTime = plannedTimeValue => {
  if (plannedTimeValue) {
    const { totalPlannedMinutes, totalAvailableMinutesPerDay } = plannedTimeValue;

    const plannedDuration = moment.duration(totalPlannedMinutes, "minutes");
    const availableDuration = moment.duration(totalAvailableMinutesPerDay, "minutes");
    const { formattedDuration: planned } = formatDuration(plannedDuration);
    const { formattedDuration: all } = formatDuration(availableDuration);
    const formattedData = {
      planned,
      all
    };

    return formattedData;
  }
};
