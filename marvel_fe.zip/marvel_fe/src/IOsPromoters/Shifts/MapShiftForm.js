// @flow

import React from "react";
import { connect } from "react-redux";
import { compose } from "redux";
import { reduxForm, Field } from "redux-form";
// import CustomLabelDatePicker from "../../components/InputField/CustomLabelDatePicker";
import CustomLabelInput from "../../components/InputField/CustomLabelInput";
import styles from "./Shifts.module.scss";

type PropsT = {};

class MapShiftForm extends React.Component<PropsT> {
  render() {
    return (
      <form autoComplete="off" noValidate className={styles.formMapWrapper}>
        {/* <Field
          required
          className={styles.inputField}
          name="date"
          component={CustomLabelDatePicker}
          customlabel="Дата"
          disabled
        /> */}
        <Field
          required
          className={styles.inputField}
          name="countPlan"
          component={CustomLabelInput}
          customlabel="Заплановано змiн"
          disabled
        />
        <Field
          required
          className={styles.inputField}
          name="countWorked"
          component={CustomLabelInput}
          customlabel="Вiдпрацьовано змiн"
          disabled
        />
        <Field
          required
          className={styles.inputField}
          name="countCanceled"
          component={CustomLabelInput}
          customlabel="Вiдмiнено змiн"
          disabled
        />
      </form>
    );
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = {};

export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  reduxForm({
    form: "MapShiftForm",
    enableReinitialize: true,
    keepDirtyOnReinitialize: true
  })
)(MapShiftForm);
