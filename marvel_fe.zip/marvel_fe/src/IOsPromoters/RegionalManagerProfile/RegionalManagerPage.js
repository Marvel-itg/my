// @flow
import React from "react";
import Paper from "@material-ui/core/Paper";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import CircularProgress from "@material-ui/core/CircularProgress";
import RegionalManagerInfoForm from "./RegionalManagerInfoForm";
import ActivityTable from "../../containers/ActivityHistoryTable/ActivityTable";
import { activityHistoryColumns } from "../../constants";
import { classes } from "../../helpers/spinner";
import { receiveRManager, editManagerProfile } from "../../store/actions/promoters/regionalManagerProfile";
import { formatFormValues } from "./helpers";
import { RMActivityHistorySelector, RMProfileSelector } from "../../store/selectors/promoters/regionalManagers";
import styles from "../Candidates/CandidateInfoPage/CandidateInfoPage.module.scss";

type PropsT = {
  receiveRManager: Function,
  editManagerProfile: Function,
  manager: RegionalManagerT,
  activityHistory: ActivityRecordT[],
  loading: boolean,
  submitting: boolean,
  submitted: boolean,
  accountType: number,
  errorMessage: string
};

type StateT = {
  isEditing: boolean
};

class RegionalManagerProfile extends React.Component<PropsT & BrowserHistory, StateT> {
  state = { isEditing: false };

  componentDidMount() {
    const { id } = this.props.match.params;

    if (id) {
      this.props.receiveRManager(id);
    }
  }

  componentDidUpdate(oldProps) {
    if (this.props.submitted && !oldProps.submitted) {
      this.setState({
        isEditing: false
      });
    }
  }

  changeMode = event => {
    event && event.preventDefault();
    this.setState(state => ({ isEditing: !state.isEditing }));
  };

  submitForm = values => {
    this.props.editManagerProfile(formatFormValues(values));
  };

  render() {
    return (
      <Paper className="mainContent">
        <div className={styles.formWrapper}>
          {this.props.loading && !this.props.manager ? (
            <CircularProgress classes={classes} />
          ) : (
            <RegionalManagerInfoForm
              initialValues={this.props.manager}
              isEditing={this.state.isEditing}
              submitForm={this.submitForm}
              changeMode={this.changeMode}
              errorMessage={this.props.errorMessage}
              loading={this.props.submitting}
              accountType={this.props.accountType}
              editMode
              status={this.props.status}
              userId={this.props.userId}
            />
          )}
          <ActivityTable columns={activityHistoryColumns} data={this.props.activityHistory} />
        </div>
      </Paper>
    );
  }
}

const mapStateToProps = state => {
  const {
    managerProfile: { loading, submitting, submitted, error, manager },
    authenticationReducer: {
      user: { accountType, id }
    }
  } = state;
  const status = manager && manager.account && manager.account.status;
  return {
    manager: RMProfileSelector(state),
    activityHistory: RMActivityHistorySelector(state),
    loading,
    submitting,
    submitted,
    accountType,
    errorMessage: error,
    status,
    userId: id
  };
};

const mapDispatchToProps = {
  receiveRManager,
  editManagerProfile
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(RegionalManagerProfile);
