import { nameRegexp } from "../../utils/reduxFormValidation";
import { validationErrorMessages } from "../../constants";

export const validate = values => {
  const { required, notCorrectData } = validationErrorMessages();
  const errors = {};

  if (!values.firstName) {
    errors.firstName = required;
  } else if (!nameRegexp(values.firstName)) {
    errors.firstName = notCorrectData;
  }

  if (!values.lastName) {
    errors.lastName = required;
  } else if (!nameRegexp(values.lastName)) {
    errors.lastName = notCorrectData;
  }

  if (!values.city || !values.city.length) {
    errors.city = required;
  }

  if (!values.responsibleManager) {
    errors.responsibleManager = required;
  }

  if (!values.middleName) {
    errors.middleName = required;
  } else if (!nameRegexp(values.middleName)) {
    errors.middleName = notCorrectData;
  }

  if (!values.phone) {
    errors.phone = required;
  } else if (values.phone.length < 9) {
    errors.phone = "Введіть корректний номер телефону";
  }
  return errors;
};
