// @flow
import React, { useEffect, useState, useRef } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import CircularProgress from "@material-ui/core/CircularProgress";
import type { FormProps } from "redux-form";
import { Field, reduxForm, formValueSelector } from "redux-form";
import { isEqual } from "lodash";
import InputField from "../../components/InputField/InputField";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import BackButton from "../../components/Buttons/BackButton/BackButton";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import ChiefsSelect from "../../components/Select/ChiefsSelect";
import ProfileDisabledInfo from "../../components/ProfileDisabledInfo/ProfileDisabledInfo";
import AsyncCitiesSelect from "../../components/Select/AsyncCitiesSelect";
import { normalizeCyrillicName, phoneMask } from "../../utils/reduxFormNormalizers";
import { classes } from "../../helpers/spinner";
import styles from "./../Supervisors/SupervisorForm/SupervisorForm.module.scss";
import { configByRoles } from "../../constants";
import { validate } from "./validate";
import { getRegions } from "../../api/geo";
import { getChiefs } from "../../api/chiefs";
import { regionsSelector } from "../../store/selectors/common";
import candidateStyles from "./../Candidates/CandidateForm/CandidateForm.module.scss";

type PropsT = {
  isEditing: boolean,
  loading: boolean,
  geoValue: CityT[],
  initialValues: any,
  submitForm: Function,
  accountType: number,
  close?: Function,
  chief: ChiefT,
  editMode: boolean,
  errorMessage: string,
  changeMode: Function,
  classes: { [string]: string }
} & FormProps;

const chiefData = {
  targetAccountType: configByRoles.regionalManagerIOSConfig
};

function usePrevious(value) {
  const ref = useRef();
  useEffect(() => {
    ref.current = value;
  });
  return ref.current;
}

const RegionalManagerForm = (props: PropsT) => {
  const [defaultOptions, setDefaultOptions] = useState([]);
  const {
    geoValue,
    chief,
    handleSubmit,
    loading,
    editMode,
    errorMessage,
    changeMode,
    invalid,
    isEditing,
    submitForm
  } = props;
  let prevGeoIds = usePrevious(geoValue);
  let prevChief = usePrevious(chief);

  useEffect(() => {
    // use isSubscribed for prevent setState of unmounted component and memory leak as result
    let isSubscribed = true;
    async function loadDefaultOptions() {
      const userRole = props.accountType;
      if (!isEqual(prevGeoIds, geoValue)) {
        let targetGeoIds = geoValue.map(id => id.value);
        const defaultOptions = await getChiefs("RegionalManagerIOS", {
          ...chiefData,
          currentAccountType: userRole,
          targetGeoIds
        });
        if (isSubscribed) {
          setDefaultOptions(defaultOptions);
          if (prevChief && prevGeoIds) {
            props.change("responsibleManager", null);
          }
        }
      }
    }
    loadDefaultOptions();
    return () => {
      isSubscribed = false;
    };
  }, [geoValue]);

  const goBack = () => props.history.goBack();

  const disableFieldsExceptPhone = props.status === 5 ? true : false;
  const isDisabledEditFields = (editMode && !isEditing) || disableFieldsExceptPhone;
  const isGeoValue = Array.isArray(geoValue) && geoValue.length ? false : true;
  const isEditButtonHidden = props.status === 4;

  return (
    <>
      {loading && <CircularProgress classes={classes} />}
      <form noValidate autoComplete="off" onSubmit={handleSubmit(submitForm)}>
        {!editMode && <div className={candidateStyles.formTitle}>Новий регіональний менеджер</div>}
        {editMode && (
          <div className={candidateStyles.backButtonWrapper}>
            <BackButton label="Повернутися назад" handleClick={goBack} />
          </div>
        )}
        <Field
          required
          name="lastName"
          component={InputField}
          disabled={isDisabledEditFields}
          placeholder="Ім'я"
          normalize={normalizeCyrillicName}
        />
        <Field
          required
          name="firstName"
          component={InputField}
          disabled={isDisabledEditFields}
          placeholder="Прізвище"
          normalize={normalizeCyrillicName}
        />
        <Field
          required
          name="middleName"
          component={InputField}
          disabled={isDisabledEditFields}
          placeholder="По батькові"
          normalize={normalizeCyrillicName}
        />
        <Field
          required
          name="phone"
          component={InputField}
          disabled={editMode && !isEditing}
          placeholder="Номер телефону"
          defaultValue="380"
          type="tel"
          {...phoneMask}
        />
        <Field
          required
          roleName="RegionalManagerIOS"
          loadOptions={getRegions}
          predefinedOptions
          component={AsyncCitiesSelect}
          isMulti={true}
          name="city"
          placeholder="Регіон"
          className={styles.inputField}
          disabled={isDisabledEditFields}
        />
        <Field
          required
          options={defaultOptions}
          name="responsibleManager"
          component={ChiefsSelect}
          disabled={isDisabledEditFields || isGeoValue}
        />
        {editMode && <ProfileDisabledInfo />}
        {editMode && !isEditButtonHidden && (
          <div className={candidateStyles.editButtonWrapper}>
            {isEditing ? (
              <ContainedButton
                type="submit"
                disabled={invalid}
                label="Зберегти"
                className={candidateStyles.editButton}
              />
            ) : (
              <ContainedButton
                type="button"
                label="Редагувати"
                className={candidateStyles.editButton}
                handleClick={changeMode}
              />
            )}
          </div>
        )}
        {!editMode && (
          <ContainedButton disabled={invalid} type="submit" label="Додати" className={candidateStyles.createButton} />
        )}
        {errorMessage && <ErrorMessage error={errorMessage} />}
      </form>
    </>
  );
};

const selector = formValueSelector("editRegionalManagerForm");

export default compose(
  withRouter,
  connect(state => {
    const {
      managerProfile: { error, loading, submitting }
    } = state;
    const geoValue = selector(state, "city");
    const chief = selector(state, "responsibleManager");
    return {
      cities: regionsSelector(state),
      geoValue,
      chief,
      errorMessage: error,
      loading: loading || submitting
    };
  }),
  reduxForm({
    form: "editRegionalManagerForm",
    validate,
    enableReinitialize: true,
    keepDirtyOnReinitialize: true
  })
)(RegionalManagerForm);
