// @flow
import React from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import debounce from "es6-promise-debounce";
import CircularProgress from "@material-ui/core/CircularProgress";
import Paper from "@material-ui/core/Paper";
import Modal from "../../../components/Modal/Modal";
import CandidatesTable from "../CandidatesTable";
import CandidateForm from "../CandidateForm/CandidateForm";
import OutlinedButton from "../../../components/Buttons/OutlinedButton/OutlinedButton";
import DeactivateForm from "../../../components/DeactivateForm/DeactivateForm";
import {
  receiveCandidates,
  addNewCandidate,
  approveCandidate,
  declineCandidate,
  activateCandidate
} from "../../../store/actions/promoters/candidatesList.js";
import { openModal, closeModal } from "../../../store/actions/common/modals";
import {
  candidatesListRowsCountSelector,
  candidatesListSelector,
  errorCandidatesListState
} from "../../../store/selectors/promoters/candidates";
import { formatFormValues } from "../helpers";
import { classes } from "../../../helpers/spinner";
import { candidatesOptions } from "../../../constants";
import { getCommonParams, changeTab, shouldNotSendRequest } from "../../../helpers/common";
import styles from "./ListOfCandidates.module.scss";
type PropsT = {
  receiveCandidates: Function,
  candidatesList: { rowsCount: number, data: CandidateT[] },
  history: BrowserHistory,
  addNewCandidate: Function,
  approveCandidate: Function,
  declineCandidate: Function,
  activateCandidate: Function,
  loading: boolean,
  user: CurrentUserInfoT,
  isExpandable?: boolean,
  openModal: Function,
  closeModal: Function
} & BrowserHistory;

type StateT = {
  isModalOpened: boolean,
  modalType: string,
  formName: string,
  modalBody: any
};

const tabs = [
  { label: "Потенційні", value: "1" },
  { label: "Відхилені", value: "2" }
];

const commonColumns = [
  { name: "profilePicture", title: "Аватар" },
  { name: "id", title: "ID" },
  { name: "lastName", title: "Прiзвище" },
  { name: "firstName", title: "Ім'я" },
  { name: "middleName", title: "По батьковi" },
  { name: "creationDate", title: "Дата створення" },
  { name: "creator", title: "Створено" },
  { name: "lastModifiedOn", title: "Дата редагування" },
  { name: "lastModifiedBy", title: "Редагував" },
  { name: "geos", title: "Населений пункт" },
  { name: "birthday", title: "Дата народження" },
  { name: "phone", title: "Номер телефону" },
  { name: "projects", title: "Проект" },
  { name: "isMainState", title: "Робочий статус" },
  { name: "chief", title: "Відповідальний" },
  { name: "gender", title: "Стать" },
  { name: "height", title: "Зріст" },
  { name: "weight", title: "Вага" },
  { name: "chestGirth", title: "Груди" },
  { name: "waistGirth", title: "Талiя" },
  { name: "hipGirth", title: "Стегна" },
  { name: "clothesTopSize", title: "Розмір одягу(верх)" },
  { name: "clothesBottomSize", title: "Розмір одягу(низ)" },
  { name: "shoeSize", title: "Розмір взуття" }
];

const supervisorsColumns = {
  "1": [...commonColumns, { name: "details", title: "Деталі профілю" }],
  "2": [
    ...commonColumns,
    { name: "comment", title: "Коментар" },
    { name: "details", title: "Деталі профілю" },
    { name: "activate", title: "Aктивувати" }
  ]
};

const managersColumns = {
  "1": [
    ...commonColumns,
    { name: "details", title: "Деталі профілю" },
    { name: "approve", title: "Підтвердити" },
    { name: "decline", title: "Відмовити" }
  ],
  "2": [
    ...commonColumns,
    { name: "comment", title: "Коментар" },
    { name: "details", title: "Деталі профілю" },
    { name: "activate", title: "Aктивувати" }
  ]
};

class ListOfCandidates extends React.Component<PropsT, StateT> {
  state = {
    isModalOpened: false,
    modalType: "",
    formName: "",
    modalBody: <div />
  };

  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;
    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
  }

  fetchData = debounce(() => {
    const { searchValue, searchFieldName, itemsOnPage, pageNumber, tab } = getCommonParams(this.props.location.search);
    let params = { ItemsOnPage: itemsOnPage, PageNumber: pageNumber, Status: tab };
    if (searchValue) {
      params = { ...params, SearchField: searchFieldName, SearchValue: searchValue };
    }
    this.props.receiveCandidates(params);
  }, 200);

  openDetails = (id: number) => {
    this.props.history.push(`/promoters/candidates/${id}`);
  };

  submitForm = values => {
    const formatted = formatFormValues(values);
    this.props.addNewCandidate(formatted);
  };

  submitDeclineForm = ({ comment }, id) => {
    this.props.declineCandidate({ id, comment });
  };

  changeTab = (event: any, tab: string) => changeTab(tab, this.props.location.search, this.props.history);

  declineCandidate = id => this.openModal("decline", id);

  activateCandidate = id => {
    this.props.activateCandidate(id, "Candidate");
  };

  openModal = (type, id) => {
    switch (type) {
      case "add": {
        const modalBody = <CandidateForm submitForm={this.submitForm} accountType={this.props.user.accountType} />;
        this.setState({ modalBody, modalType: "", formName: "ConsultantForm" });
        return this.props.openModal();
      }
      case "decline": {
        const modalBody = (
          <DeactivateForm
            form="DeclineCandidatePromoters"
            title="Відхилити кандидата?"
            textFieldLabel="Додати коментар"
            textFieldName="comment"
            submitButtonText="Так"
            cancelButtonText="Ні"
            cancelButtonHandler={this.props.closeModal}
            submitForm={values => this.submitDeclineForm(values, id)}
            errorState={errorCandidatesListState}
          />
        );
        this.setState({ modalBody, modalType: "deactivate" });
        return this.props.openModal();
      }
      default:
        return null;
    }
  };

  renderAddButtons = () => (
    <OutlinedButton label="Додати кандидата" clickHandler={() => this.openModal("add")} className={styles.addButton} />
  );

  render() {
    const { tab } = getCommonParams(this.props.location.search);
    const { loading, user } = this.props;
    //  Only Central Department Manager IOS can approve/decline candidates
    const columns = user && (user.accountType === 5 || user.accountType === 1) ? managersColumns : supervisorsColumns;
    return (
      <React.Fragment>
        <Paper square className="mainContent">
          <CandidatesTable
            data={this.props.candidatesList || []}
            rowsCount={this.props.rowsCount}
            activeTab={tab || "1"}
            columns={columns[tab || "1"]}
            changeTab={this.changeTab}
            openModal={this.openModal}
            approve={this.props.approveCandidate}
            decline={this.declineCandidate}
            activate={this.activateCandidate}
            renderAddButtons={this.renderAddButtons}
            openDetails={this.openDetails}
            tabs={tabs}
            filterOptions={candidatesOptions}
            withAdditions
            user={user}
          />
        </Paper>
        {loading && <CircularProgress classes={classes} />}
        <Modal formName={this.state.formName} type={this.state.modalType}>
          {this.state.modalBody}
        </Modal>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  const {
    candidatesListPromoters: { submitting, approving, declining, loading, activating },
    authenticationReducer: { user }
  } = state;

  return {
    candidatesList: candidatesListSelector(state),
    rowsCount: candidatesListRowsCountSelector(state),
    loading: loading || submitting || approving || declining || activating,
    user
  };
};

const mapDispatchToProps = {
  receiveCandidates,
  addNewCandidate,
  approveCandidate,
  declineCandidate,
  activateCandidate,
  openModal,
  closeModal
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(ListOfCandidates);
