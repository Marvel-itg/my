// @flow
import React from "react";
import { connect } from "react-redux";
import { compose } from "redux";
import { Route } from "react-router-dom";
import { reset } from "redux-form";
import Paper from "@material-ui/core/Paper/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import CandidateForm from "../CandidateForm/CandidateForm";
import styles from "./CandidateInfoPage.module.scss";
import ActivityTable from "../../../containers/ActivityHistoryTable/ActivityTable";
import EditRequestsPage from "../../Consultants/EditRequestsPage";
import { getCandidateInfo, editCandidate, clearCandidateInfo } from "../../../store/actions/promoters/candidatesList";
import { formatFormValues } from "../helpers";
import {
  candidateProfileSelector,
  candidateActivityHistorySelector
} from "../../../store/selectors/promoters/candidates";
import { classes } from "../../../helpers/spinner";
import { activityHistoryColumns } from "../../../constants";

type PropsT = {
  editCandidate: Function,
  clearCandidateInfo: Function,
  getCandidateInfo: Function,
  errorMessage: string,
  activityHistory: ActivityRecordT[],
  candidate: CandidateT
} & BrowserHistory;

type StateT = {
  isEditing: boolean
};

class CandidateInfoPage extends React.Component<PropsT, StateT> {
  state = { isEditing: false };

  componentDidMount() {
    const { id, menuSubRoute } = this.props.match.params;
    if (id && !menuSubRoute) {
      this.props.getCandidateInfo(id);
    }
  }

  componentDidUpdate(oldProps) {
    if (this.props.submitted && !oldProps.submitted) {
      this.setState({
        isEditing: false
      });
      this.props.reset("ConsultantForm");
    }
  }

  componentWillUnmount() {
    this.props.clearCandidateInfo();
  }

  changeMode = (event: any) => {
    event.preventDefault();
    this.setState(prevState => ({ isEditing: !prevState.isEditing }));
  };

  submitForm = values => {
    this.props.editCandidate(formatFormValues(values));
    this.setState({ isEditing: false });
  };

  render() {
    const { menuSubRoute } = this.props.match.params;
    return (
      <Paper className="mainContent">
        <div className={styles.formWrapper}>
          {menuSubRoute === "edit-requests" ? (
            <Route path={"/promoters/consultants/edit-requests/:id"} exact component={EditRequestsPage} />
          ) : (
            <>
              {this.props.loading && !this.props.candidate ? (
                <CircularProgress classes={classes} />
              ) : (
                <CandidateForm
                  submitted={this.props.submitted}
                  initialValues={this.props.candidate}
                  isEditing={this.state.isEditing}
                  submitForm={this.submitForm}
                  changeMode={this.changeMode}
                  errorMessage={this.props.errorMessage}
                  loading={this.props.submitting}
                  accountType={this.props.accountType}
                  editMode
                  status={this.props.status}
                  userId={this.props.userId}
                />
              )}
              <ActivityTable columns={activityHistoryColumns} data={this.props.activityHistory} />
            </>
          )}
        </div>
      </Paper>
    );
  }
}

const mapStateToProps = state => {
  const {
    candidatesListPromoters: { loading, error, submitted, candidateData },
    authenticationReducer: {
      user: { accountType, id }
    }
  } = state;
  const status = candidateData && candidateData.account && candidateData.account.status;

  return {
    candidate: candidateProfileSelector(state),
    activityHistory: candidateActivityHistorySelector(state),
    loading,
    errorMessage: error,
    accountType,
    submitted,
    status,
    userId: id
  };
};
const mapDispatchToProps = {
  getCandidateInfo,
  editCandidate,
  clearCandidateInfo,
  reset
};

export default compose(withRouter, connect(mapStateToProps, mapDispatchToProps))(CandidateInfoPage);
