// @flow
import React from "react";
import { Grid, Table, TableHeaderRow, Toolbar } from "@devexpress/dx-react-grid-material-ui";
import { withRouter } from "react-router-dom";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import type { BrowserHistory } from "history";
import { ToolBarRootStyled } from "../../components/TableComponents/ToolbarRoot";
import GridRoot from "../../components/TableComponents/GridRoot";
import TableContainer from "../../components/TableComponents/TableContainer";
import SearchForm from "../../components/TableComponents/SearchForm/SearchForm";
import PagingPanel from "../../components/TableComponents/PagingPanel";
import TabsHeader from "../../components/TableComponents/TabsHeader";
import {
  ImageProvider,
  PhoneProvider,
  EmailProvider,
  ButtonProvider,
  GenderProvider,
  CityProvider,
  ProjectsProvider,
  PersonInfoProvider,
  DateFormatProvider,
  CandidateStatusProvider,
  TransparentButtonProvider,
  DestructiveButtonProvider,
  ActivateButtonProvider
} from "../../components/FormattedData/FormattedData";
import { columnExtensions, availableItemsPerPage } from "../../constants";
import { getPaginationConfig, changeCurrentPage, changePageSize } from "../../helpers/common";
import styles from "../Candidates/ListOfCandidates/ListOfCandidates.module.scss";

type PropsT = {
  data: CandidateT[],
  changeTab: Function,
  activeTab: string,
  openModal: Function,
  approve?: Function,
  decline?: Function,
  deactivate?: Function,
  activate?: Function,
  openDetails: Function,
  renderAddButtons?: Function,
  tabs: TabT[],
  columns: ColumnT[],
  isExpandable?: boolean,
  withAdditions?: boolean,
  rowsCount: number
} & BrowserHistory;

type StateT = {
  currentPage: number,
  pageSize: number,
  pageSizes: Array<number>
};

const forValues = {
  profilePicture: ["profilePicture"],
  phone: ["phone"],
  email: ["email"],
  geos: ["geos"],
  projects: ["projects"],
  lastModifiedBy: ["lastModifiedBy"],
  creator: ["creator"],
  chief: ["chief"],
  deactivatedBy: ["deactivatedBy"],
  date: ["lastModifiedOn", "birthday", "workStartedDate", "creationDate", "deactivationDate"],
  createdOn: ["createdOn"],
  isMainState: ["isMainState"],
  activate: ["activate"],
  approve: ["approve"],
  decline: ["decline"],
  deactivate: ["deactivate"],
  details: ["details"],
  editRequestDetails: ["editRequestDetails"],
  gender: ["gender"]
};

const expandedColumnExtensions = [
  ...columnExtensions,
  { columnName: "creator", width: 270 },
  { columnName: "profilePicture", width: 150 }
];

class CandidatesTable extends React.Component<PropsT, StateT> {
  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  checkDeactivateButtonIsHidden = row => {
    const { user = {} } = this.props;
    return user.accountType !== 1 && user.accountType !== 5 && user.accountType !== 6 && user.id !== row.chief.id;
  };

  checkActivateButtonIsHidden = row => {
    const path = this.props.location.pathname && this.props.location.pathname.split("/")[2];
    const { user = {} } = this.props;
    const RMActivateCandidatesWhereChief = user.accountType === 6 && path === "candidates" && user.id !== row.chief.id;
    return (
      (user.accountType !== 1 && user.accountType !== 5 && (user.accountType === 7 && user.id !== row.chief.id)) ||
      RMActivateCandidatesWhereChief
    );
  };

  render() {
    const {
      columns,
      data,
      activate,
      deactivate,
      decline,
      approve,
      tabs,
      openDetails,
      isExpandable,
      withAdditions,
      activeTab,
      changeTab,
      rowsCount,
      filterOptions,
      openEditRequestDetails
    } = this.props;
    const withInteractions = withAdditions && !isExpandable;
    const { page, count } = getPaginationConfig(this.props.location.search);
    return (
      <Grid rows={data} columns={columns} rootComponent={GridRoot}>
        <PagingState
          currentPage={page}
          onCurrentPageChange={this.changeCurrentPage}
          pageSize={count}
          onPageSizeChange={this.changePageSize}
        />
        <CustomPaging totalCount={rowsCount} />
        <ImageProvider for={forValues.profilePicture} className={styles.avatarStyles} />
        <PhoneProvider for={forValues.phone} />
        <EmailProvider for={forValues.email} />
        <CityProvider for={forValues.geos} />
        <ProjectsProvider for={forValues.projects} />
        <PersonInfoProvider for={forValues.creator} />
        <PersonInfoProvider for={forValues.chief} />
        <PersonInfoProvider for={forValues.lastModifiedBy} />
        <PersonInfoProvider for={forValues.deactivatedBy} />
        <DateFormatProvider for={forValues.date} />
        <DateFormatProvider for={forValues.createdOn} showTime />
        <CandidateStatusProvider for={forValues.isMainState} />
        <ActivateButtonProvider
          for={forValues.activate}
          onClick={activate}
          checkHidden={this.checkActivateButtonIsHidden}
          label="Активувати"
        />
        <ButtonProvider for={forValues.approve} onClick={approve} label="Підтвердити" />
        <DestructiveButtonProvider for={forValues.decline} onClick={decline} label="Відмовити" />
        <DestructiveButtonProvider
          for={forValues.deactivate}
          onClick={deactivate}
          label="Деактивувати"
          checkHidden={this.checkDeactivateButtonIsHidden}
        />
        <TransparentButtonProvider for={forValues.details} onClick={openDetails} label="Деталі профілю" />
        <TransparentButtonProvider
          for={forValues.editRequestDetails}
          onClick={openEditRequestDetails}
          label="Детальніше"
        />
        <GenderProvider for={forValues.gender} />
        <Table columnExtensions={expandedColumnExtensions} containerComponent={TableContainer} height="auto" />
        <TableHeaderRow />
        {<Toolbar rootComponent={ToolBarRootStyled(styles.headerStyles)} />}
        {tabs && (
          <TabsHeader changeTab={changeTab} activeTab={activeTab} tabs={tabs || []}>
            {!!this.props.renderAddButtons && this.props.renderAddButtons()}
          </TabsHeader>
        )}
        <SearchForm
          selectOptions={filterOptions}
          className={withInteractions ? styles.searchForm : styles.searchFormWithAddButton}
          placeholder="Пошук"
        />
        <PagingPanel pageSizes={availableItemsPerPage} noData={!rowsCount} />
      </Grid>
    );
  }
}

export default withRouter(CandidatesTable);
