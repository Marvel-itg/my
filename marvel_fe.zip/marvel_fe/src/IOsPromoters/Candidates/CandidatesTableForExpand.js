// @flow
import React from "react";
import { Grid, Table, TableHeaderRow } from "@devexpress/dx-react-grid-material-ui";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import GridRoot from "../../components/TableComponents/GridRoot";
import TableContainer from "../../components/TableComponents/TableContainer";
import {
  ImageProvider,
  PhoneProvider,
  EmailProvider,
  GenderProvider,
  CityProvider,
  ProjectsProvider,
  PersonInfoProvider,
  DateFormatProvider,
  CandidateStatusProvider,
  TransparentButtonProvider,
  DestructiveButtonProvider
} from "../../components/FormattedData/FormattedData";
import { columnExtensions } from "../../constants";

type PropsT = {
  data: CandidateT[],
  openModal: Function,
  deactivate: Function,
  openDetails: Function,
  columns: ColumnT[]
} & BrowserHistory;

const forValues = {
  profilePicture: ["profilePicture"],
  phone: ["phone"],
  email: ["email"],
  geos: ["geos"],
  projects: ["projects"],
  lastModifiedBy: ["lastModifiedBy"],
  personInfo: ["lastModifiedBy", "creator", "deactivatedBy"],
  chief: ["chief"],
  date: ["lastModifiedOn", "birthday", "workStartedDate", "deactivateDate"],
  isMainState: ["isMainState"],
  deactivate: ["deactivate"],
  details: ["details"],
  gender: ["gender"]
};

class CandidatesTable extends React.Component<PropsT> {
  render() {
    const { columns, data, deactivate, openDetails, user = {} } = this.props;
    const checkDeactivateButtonIsHidden = row => {
      return user.accountType !== 1 && user.accountType !== 5 && user.accountType !== 6 && user.id !== row.chief.id;
    };
    return (
      <Grid rows={data} columns={columns} rootComponent={GridRoot}>
        <ImageProvider for={forValues.profilePicture} />
        <PhoneProvider for={forValues.phone} />
        <EmailProvider for={forValues.email} />
        <CityProvider for={forValues.geos} />
        <ProjectsProvider for={forValues.projects} />
        <PersonInfoProvider for={forValues.personInfo} />
        <PersonInfoProvider for={forValues.chief} />
        <DateFormatProvider for={forValues.date} />
        <CandidateStatusProvider for={forValues.isMainState} />
        <DestructiveButtonProvider
          for={forValues.deactivate}
          onClick={deactivate}
          label="Деактивувати"
          checkHidden={checkDeactivateButtonIsHidden}
        />
        <TransparentButtonProvider for={forValues.details} onClick={openDetails} label="Деталі профілю" />
        <GenderProvider for={forValues.gender} />

        <Table columnExtensions={columnExtensions} containerComponent={TableContainer} height="auto" />

        <TableHeaderRow />
      </Grid>
    );
  }
}

export default withRouter(CandidatesTable);
