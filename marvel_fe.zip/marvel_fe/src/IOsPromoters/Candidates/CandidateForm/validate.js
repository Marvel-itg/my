import { emailRegexp, nameRegexp } from "../../../utils/reduxFormValidation";
import { validationErrorMessages } from "../../../constants";

const validate = values => {
  const { required, notCorrectData } = validationErrorMessages();
  const errors = {};

  if (!values.firstName) {
    errors.firstName = required;
  } else if (!nameRegexp(values.firstName)) {
    errors.firstName = notCorrectData;
  }
  if (!values.lastName) {
    errors.lastName = required;
  } else if (!nameRegexp(values.lastName)) {
    errors.lastName = notCorrectData;
  }
  if (!values.middleName) {
    errors.middleName = required;
  } else if (!nameRegexp(values.middleName)) {
    errors.middleName = notCorrectData;
  }
  if (!values.gender) {
    errors.gender = required;
  }
  if (!values.birthday) {
    errors.birthday = required;
  }
  if (!values.photoIds || !values.photoIds.length) {
    errors.photoIds = required;
  } else if (values.photoIds.length < 2 || values.photoIds.length > 5) {
    errors.photoIds = "Додайте від 2 до 5 фотографій";
  }
  if (!values.phone) {
    errors.phone = required;
  } else if (values.phone.length < 9) {
    errors.phone = "Введіть корректний номер телефону";
  }

  if (!values.city || !values.city.length) {
    errors.city = required;
  }

  if (!values.chiefAccountId) {
    errors.chiefAccountId = required;
  }

  if (!values.isMainState) {
    errors.isMainState = required;
  }

  if (values.projectIds && !values.projectIds.length) {
    errors.projectIds = required;
  }

  if (!values.email) {
    errors.email = required;
  } else if (!emailRegexp(values.email)) {
    errors.email = "Введіть корректну електронну адресу";
  }

  if (!values.height) {
    errors.height = required;
  } else if (Number(values.height) < 145) {
    errors.height = "Мінімальний зріст - 145см";
  } else if (Number(values.height) > 210) {
    errors.height = "Максимальний зріст - 210см";
  }

  if (!values.weight) {
    errors.weight = required;
  } else if (Number(values.weight) < 40) {
    errors.weight = "Мінімальна вага - 40кг";
  } else if (Number(values.weight) > 110) {
    errors.weight = "Максимальна вага - 110кг";
  }

  if (!values.chestGirth) {
    errors.chestGirth = required;
  } else if (Number(values.chestGirth) < 70) {
    errors.chestGirth = "Мінімальний об'єм - 70см";
  } else if (Number(values.chestGirth) > 120) {
    errors.chestGirth = "Макcимальний об'єм - 120см";
  }

  if (!values.waistGirth) {
    errors.waistGirth = required;
  } else if (Number(values.waistGirth) < 40) {
    errors.waistGirth = "Мінімальний об'єм - 40см";
  } else if (Number(values.waistGirth) > 110) {
    errors.waistGirth = "Макcимальний об'єм - 110см";
  }

  if (!values.hipGirth) {
    errors.hipGirth = required;
  } else if (Number(values.hipGirth) < 70) {
    errors.hipGirth = "Мінімальний об'єм - 70см";
  } else if (Number(values.hipGirth) > 120) {
    errors.hipGirth = "Макcимальний об'єм - 120см";
  }

  if (!values.clothesTopSize) {
    errors.clothesTopSize = required;
  }

  if (!values.clothesBottomSize) {
    errors.clothesBottomSize = required;
  }

  if (!values.shoeSize) {
    errors.shoeSize = required;
  }

  return errors;
};

export default validate;
