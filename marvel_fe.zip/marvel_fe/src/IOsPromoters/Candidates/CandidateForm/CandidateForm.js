// @flow
import React, { useEffect, useState, useRef } from "react";
import { reduxForm, Field, formValueSelector } from "redux-form";
import { compose } from "redux";
import cx from "classnames";
import { withRouter } from "react-router-dom";
import type { BrowserHistory } from "history";
import type { FormProps } from "redux-form";
import { connect } from "react-redux";
import FormLabel from "@material-ui/core/FormLabel";
import CircularProgress from "@material-ui/core/CircularProgress";
import { isEqual } from "lodash";
import InputField from "../../../components/InputField/InputField";
import InputFileMultiple from "../../../components/InputFileMultiple/InputFileMultiple";
import InputDatePicker from "../../../components/InputField/InputDatePicker";
import ProfileDisabledInfo from "../../../components/ProfileDisabledInfo/ProfileDisabledInfo";
import AsyncCitiesSelect from "../../../components/Select/AsyncCitiesSelect";
import Select from "../../../components/Select/Select";
import ChiefsSelect from "../../../components/Select/ChiefsSelect";
import ContainedButton from "../../../components/Buttons/ContainedButton/ContainedButton";
import BackButton from "../../../components/Buttons/BackButton/BackButton";
import RadioGroup from "../../../components/RadioGroup/RadioGroup";
import ErrorMessage from "../../../components/ErrorMessage/ErrorMessage";
import { citiesSelector, projectsSelector } from "../../../store/selectors/common";
import { phoneMask, normalizeCyrillicName, onlyNumbers } from "../../../utils/reduxFormNormalizers";
import { configByRoles } from "../../../constants";
import { getChiefs } from "../../../api/chiefs";
import validate from "./validate";
import { genderOptions } from "../../../constants";
import { classes } from "../../../helpers/spinner";

import styles from "./CandidateForm.module.scss";

type PropsT = {
  submitForm: Function,
  changeMode: Function,
  editMode: boolean,
  projects: ProjectT[],
  cities: CityT[],
  errorMessage: string,
  userId: number,
  imageTransactionSuccess: boolean
} & BrowserHistory &
  FormProps;

const chiefData = {
  targetAccountType: configByRoles.consultantIOSConfig
};

function usePrevious(value) {
  const ref = useRef();
  useEffect(() => {
    ref.current = value;
  });
  return ref.current;
}

const ConsultantForm = (props: PropsT) => {
  const [defaultOptions, setDefaultOptions] = useState([]);
  const {
    handleSubmit,
    editMode,
    isEditing,
    changeMode,
    submitForm,
    loading,
    errorMessage,
    invalid,
    geoValue,
    chief,
    accountType,
    imageTransactionSuccess,
    submitted
  } = props;
  let prevGeoIds = usePrevious(geoValue);
  let prevChief = usePrevious(chief);

  useEffect(() => {
    // use isSubscribed for prevent setState of unmounted component and memory leak as result
    let isSubscribed = true;
    async function loadDefaultOptions() {
      if (!isEqual(prevGeoIds, geoValue)) {
        let targetGeoIds = geoValue.map(id => id.value);
        const defaultOptions = await getChiefs("Consultants", {
          ...chiefData,
          currentAccountType: accountType,
          targetGeoIds
        });
        if (isSubscribed) {
          setDefaultOptions(defaultOptions);
          if (prevChief && prevGeoIds) {
            props.change("chiefAccountId", null);
          }
        }
      }
    }
    loadDefaultOptions();
    return () => {
      isSubscribed = false;
    };
  }, [geoValue]);

  const goBack = () => props.history.goBack();

  const isGeoValue = Array.isArray(geoValue) && geoValue.length ? false : true;
  const currentUserId = props.userId;
  const chiefId = props.initialValues && props.initialValues.chiefAccountId && props.initialValues.chiefAccountId.value;
  const generalError = props.creatingError || errorMessage;
  const disableFieldsExceptPhone = props.status === 5 ? true : false;
  const isDisabledEditFields = (editMode && !isEditing) || disableFieldsExceptPhone;

  const path = props.location.pathname && props.location.pathname.split("/")[2];
  const consultantPage = path === "consultants";
  const candidatesAndConsultantsActiveOrPhoneChangedTabs =
    props.status === 3 || props.status === 1 || props.status === 5;
  const superAdminOrCDM = props.accountType === 1 || props.accountType === 5;

  const SVChiefConsultantsOrCandidates =
    candidatesAndConsultantsActiveOrPhoneChangedTabs && props.accountType === 7 && chiefId === currentUserId;
  const RMAllConsultantsAndCandidatesOnlyChief =
    (props.status === 3 ||
      (props.status === 5 && consultantPage) ||
      ((props.status === 1 || props.status === 5) && !consultantPage && chiefId === currentUserId)) &&
    props.accountType === 6;
  const isEditButtonVisible =
    (candidatesAndConsultantsActiveOrPhoneChangedTabs && superAdminOrCDM) ||
    RMAllConsultantsAndCandidatesOnlyChief ||
    SVChiefConsultantsOrCandidates;
  const minBirthDate = new Date(new Date().setFullYear(new Date().getFullYear() - 18));
  return (
    <>
      {loading && <CircularProgress classes={classes} />}
      <form
        autoComplete="off"
        noValidate
        onSubmit={handleSubmit(submitForm)}
        className={styles.newConsultantFormWrapper}
      >
        {!editMode && <div className={styles.formTitle}>Новий кaндидат</div>}
        {editMode && (
          <div className={styles.backButtonWrapper}>
            <BackButton label="Повернутися назад" handleClick={goBack} />
          </div>
        )}
        <Field
          required
          name="lastName"
          component={InputField}
          className={styles.inputField}
          normalize={normalizeCyrillicName}
          disabled={isDisabledEditFields}
        />
        <Field
          required
          name="firstName"
          component={InputField}
          className={styles.inputField}
          normalize={normalizeCyrillicName}
          disabled={isDisabledEditFields}
        />
        <Field
          required
          name="middleName"
          component={InputField}
          className={styles.inputField}
          normalize={normalizeCyrillicName}
          disabled={isDisabledEditFields}
        />
        <Field
          required
          className={styles.inputField}
          name="birthday"
          label="Дата народження"
          maxDateMessage="Мiнiмальний вiк - 18р."
          maxDate={minBirthDate}
          component={InputDatePicker}
          disabled={isDisabledEditFields}
        />

        <Field
          required
          name="gender"
          component={RadioGroup}
          disabled={isDisabledEditFields}
          label="Стать"
          options={genderOptions}
        />
        <Field
          required
          name="photoIds"
          id="photoIds"
          component={InputFileMultiple}
          isMultiple
          limit={5}
          withPreview
          disabled={isDisabledEditFields || !imageTransactionSuccess}
          key={submitted ? "photoIds" : null}
          withSlider
        />
        <Field
          required
          name="phone"
          component={InputField}
          type="tel"
          className={styles.inputField}
          disabled={editMode && !isEditing}
          {...phoneMask}
        />

        <Field
          required
          component={AsyncCitiesSelect}
          roleName="Consultants"
          name="city"
          isMulti={true}
          className={styles.inputField}
          disabled={isDisabledEditFields}
        />

        <Field
          required
          options={defaultOptions}
          name="chiefAccountId"
          component={ChiefsSelect}
          disabled={isDisabledEditFields || isGeoValue}
        />

        <Field
          required
          name="isMainState"
          component={Select}
          className={styles.inputField}
          disabled={isDisabledEditFields}
        />

        <Field
          required
          name="projectIds"
          component={Select}
          className={styles.inputField}
          options={props.projects}
          isMulti
          disabled={isDisabledEditFields}
        />

        <FormLabel className={styles.formLabel} disabled={isDisabledEditFields} component="legend">
          Параметри фiгури
        </FormLabel>

        <div className={styles.inputsFlexWrapper}>
          <Field
            required
            name="height"
            component={InputField}
            className={cx(styles.inputFieldMarginSmall, styles.inputFieldHalf)}
            disabled={isDisabledEditFields}
            normalize={onlyNumbers}
          />

          <Field
            required
            name="weight"
            component={InputField}
            className={cx(styles.inputFieldMarginSmall, styles.inputFieldHalf)}
            disabled={isDisabledEditFields}
            normalize={onlyNumbers}
          />
        </div>

        <div className={styles.inputsFlexWrapper}>
          <Field
            required
            name="chestGirth"
            component={InputField}
            className={styles.inputFieldThird}
            disabled={isDisabledEditFields}
            normalize={onlyNumbers}
          />

          <Field
            required
            name="waistGirth"
            component={InputField}
            className={styles.inputFieldThird}
            disabled={isDisabledEditFields}
            normalize={onlyNumbers}
          />

          <Field
            required
            name="hipGirth"
            component={InputField}
            className={styles.inputFieldThird}
            disabled={isDisabledEditFields}
            normalize={onlyNumbers}
          />
        </div>

        <FormLabel className={styles.formLabel} disabled={isDisabledEditFields} component="legend">
          Розмiри
        </FormLabel>

        <div className={styles.inputsFlexWrapper}>
          <Field
            required
            name="clothesTopSize"
            component={Select}
            className={styles.inputFieldThird}
            disabled={isDisabledEditFields}
          />

          <Field
            required
            name="clothesBottomSize"
            component={Select}
            className={styles.inputFieldThird}
            disabled={isDisabledEditFields}
          />

          <Field
            required
            name="shoeSize"
            component={Select}
            className={styles.inputFieldThird}
            disabled={isDisabledEditFields}
          />
        </div>
        {editMode && <ProfileDisabledInfo />}
        {editMode && isEditButtonVisible && (
          <div className={styles.editButtonWrapper}>
            {isEditing ? (
              <ContainedButton
                type="submit"
                label="Зберегти"
                disabled={invalid || !imageTransactionSuccess}
                className={styles.editButton}
              />
            ) : (
              <ContainedButton
                type="button"
                label="Редагувати"
                className={styles.editButton}
                handleClick={changeMode}
              />
            )}
          </div>
        )}
        {!editMode && (
          <ContainedButton
            type="submit"
            disabled={invalid || !imageTransactionSuccess}
            label="Додати"
            className={styles.createButton}
          />
        )}
        {generalError && <ErrorMessage error={generalError} />}
      </form>
    </>
  );
};

const formValues = formValueSelector("ConsultantForm");

const mapStateToProps = state => {
  const {
    candidatesListPromoters: { loading, error }
  } = state;
  const geoValue = formValues(state, "city");
  const chief = formValues(state, "chiefAccountId");

  const imageTransactionSuccess = state.images && state.images.imageTransactionSuccess;
  return {
    projects: projectsSelector(state),
    cities: citiesSelector(state),
    loading,
    geoValue,
    creatingError: error,
    chief,
    imageTransactionSuccess
  };
};

export default compose(
  withRouter,
  connect(mapStateToProps),
  reduxForm({
    form: "ConsultantForm",
    validate,
    enableReinitialize: true,
    keepDirtyOnReinitialize: true
  })
)(ConsultantForm);
