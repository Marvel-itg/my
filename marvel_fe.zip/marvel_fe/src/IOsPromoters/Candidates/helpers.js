// @flow
import moment from "moment";
import isEmpty from "lodash/isEmpty";
import omit from "lodash/omit";
import { consultantStatus, clothesSizes, clothesSizesByKeys, userStatusConfig } from "../../constants";
import { createOption, formatDate } from "../../utils/formatValues";
import { mapCityToOptionsOfCities, formatObjectToFullName } from "../../helpers/common";

export const formatFormValues = (values: any) => {
  const photoIds = values.photoIds.map(photo => photo.id);
  const projectIds = values.projectIds.map(project => project.value);
  const chiefAccountId = values.chiefAccountId.value;
  const accountId = values.id;
  const phone = values.phone && `+380${values.phone}`;
  const geoIds = values.city.map(city => +city.value);
  const birthday = moment(values.birthday).format("YYYY-MM-DD");
  const clothesTopSize = values.clothesTopSize.value;
  const clothesBottomSize = values.clothesBottomSize.value;
  const shoeSize = values.shoeSize.value;
  const isMainState = consultantStatus[values.isMainState.value];
  const firstName = values.firstName.trim();
  const lastName = values.lastName.trim();
  const middleName = values.middleName.trim();
  values = omit(values, [
    "city",
    "chief",
    "comment",
    "createdAt",
    "createdBy",
    "creationDate",
    "creator",
    "deactivatedBy",
    "deactivationDate",
    "geos",
    "id",
    "photos",
    "projects",
    "status"
  ]);

  const formatted = {
    ...values,
    firstName,
    lastName,
    middleName,
    projectIds,
    chiefAccountId,
    photoIds,
    phone,
    birthday,
    geoIds,
    clothesTopSize,
    clothesBottomSize,
    shoeSize,
    isMainState,
    accountId
  };
  return formatted;
};

export const formatInitialValues = (data: CandidateT) => {
  if (!isEmpty(data)) {
    const projectIds = data && data.projects && data.projects.map<ProjectT>(createOption);

    const chiefAccountId =
      data.chief && data.chief.id
        ? {
            value: data.chief.id,
            label: `${data.chief.lastName} ${data.chief.firstName} ${data.chief.middleName}`
          }
        : null;

    const city: OptionT[] = data.geos && data.geos.map(mapCityToOptionsOfCities);
    const gender = String(data.gender);
    const clothesBottomSize = {
      label: data.clothesBottomSize,
      value: clothesSizes[data.clothesBottomSize]
    };
    const clothesTopSize = {
      label: data.clothesTopSize,
      value: clothesSizes[data.clothesTopSize]
    };
    const isMainState = data.isMainState
      ? { label: "Постійний штат", value: "Постійний штат" }
      : { label: "Резерв", value: "Резерв" };
    const shoeSize = { label: data.shoeSize, value: data.shoeSize };
    const phone = data.phone && data.phone.substr(4);
    const createdAt = data.creationDate && formatDate(data.creationDate);
    const status = userStatusConfig[data.status];
    const creator = data.creator && data.creator.id && formatObjectToFullName(data.creator);
    const photos =
      data.photos &&
      data.photos.length &&
      data.photos.map(photo => {
        return { ...photo };
      });
    const initialValues = {
      ...data,
      projectIds,
      chiefAccountId,
      phone,
      gender,
      clothesBottomSize,
      clothesTopSize,
      shoeSize,
      photoIds: photos,
      city,
      isMainState,
      createdAt,
      status,
      createdBy: creator
    };
    return initialValues;
  } else {
    const minBirthDate = new Date(new Date().setFullYear(new Date().getFullYear() - 18));
    return { birthday: minBirthDate };
  }
};

const mapProjectsToOptions = project => {
  return {
    label: project.name,
    value: project.id
  };
};

export const filterActivityHistoryWithoutCreatingRecord = (
  activityHistory: ActivityRecordT[]
): ActivityRecordFormattedT[] => {
  if (activityHistory && activityHistory.length) {
    const filteredHistory = activityHistory
      .filter(item => item.activityType !== 1)
      .map(item => {
        if (item.key === "Chief") {
          return {
            ...item,
            oldValue: item.oldValue && JSON.parse(item.oldValue)["fullName"],
            newValue: item.newValue && JSON.parse(item.newValue)["fullName"]
          };
        }
        if (item.key === "Geo") {
          const oldRegions = JSON.parse(item.oldValue);
          const newRegions = JSON.parse(item.newValue);
          return {
            ...item,
            oldValue: oldRegions && oldRegions.map(mapCityToOptionsOfCities),
            newValue: newRegions && newRegions.map(mapCityToOptionsOfCities)
          };
        }
        if (item.key === "Projects") {
          const oldProjects = JSON.parse(item.oldValue);
          const newProjects = JSON.parse(item.newValue);
          return {
            ...item,
            oldValue: oldProjects && oldProjects.map(mapProjectsToOptions),
            newValue: newProjects && newProjects.map(mapProjectsToOptions)
          };
        }
        if (item.key === "Images") {
          try {
            const oldImages = JSON.parse(item.oldValue);
            const newImages = JSON.parse(item.newValue);
            return {
              ...item,
              oldValue: oldImages,
              newValue: newImages
            };
          } catch (error) {
            console.error(error);
            return { ...item, oldValue: [], newValue: [] };
          }
        }
        if (item.key === "ClothesTopSize" || item.key === "ClothesBottomSize") {
          return {
            ...item,
            oldValue: clothesSizesByKeys[item.oldValue],
            newValue: clothesSizesByKeys[item.newValue]
          };
        }
        return item;
      });
    return filteredHistory;
  }
  return [];
};
