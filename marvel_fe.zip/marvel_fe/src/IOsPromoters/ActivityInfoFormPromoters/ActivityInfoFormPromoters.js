// @flow
import React from "react";
import { connect } from "react-redux";
import { submit } from "redux-form";
import type { FormProps } from "redux-form";
import CircularProgress from "@material-ui/core/CircularProgress";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import Form from "../Candidates/CandidateForm/CandidateForm";
import styles from "./ActivityInfoFormPromoters.module.scss";

type PropsT = {
  edit: Function,
  editing: boolean
};

type StateT = {
  isEditingMode: boolean
};

const classes = { root: styles.spinner };

class ActivityInfoFormPromoters extends React.Component<PropsT & FormProps, StateT> {
  state = {
    isEditingMode: false
  };

  changeMode = event => {
    event && event.preventDefault();
    this.setState(state => ({ isEditingMode: !state.isEditingMode }));
  };

  submitForm = dispatch => {
    dispatch(submit("UserPromotersForm"));

    this.changeMode();
  };

  renderSubmitButton = () => {
    const { dispatch, editing } = this.props;
    const { isEditingMode } = this.state;

    return isEditingMode ? (
      <ContainedButton
        label="Зберегти"
        type="button"
        handleClick={this.submitForm.bind(this, dispatch)}
        disabled={editing}
      />
    ) : (
      <ContainedButton label="Редагувати" handleClick={this.changeMode} type="button" disabled={editing} />
    );
  };

  render() {
    const { initialValues, editing } = this.props;
    const { isEditingMode } = this.state;

    return (
      <div className={styles.mainContainer}>
        <div className={styles.editButtonWrapper}>{this.renderSubmitButton()}</div>
        <div className={styles.infoBlock}>
          <div className={styles.inputsWrapper}>
            <Form initialValues={initialValues} editMode isEditing={isEditingMode} />
          </div>
          {editing && <CircularProgress classes={classes} />}
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state, props) => {
  return {
    initialValues: props.info
  };
};

export default connect(mapStateToProps)(ActivityInfoFormPromoters);
