//@flow
import React from "react";
import { Field, reduxForm } from "redux-form";
import moment from "moment";
import { compose } from "redux";
import type { FormProps } from "redux-form";
import { connect } from "react-redux";
import ContainedButton from "../../components/Buttons/ContainedButton/ContainedButton";
import InputDatePicker from "../../components/InputField/InputDatePicker";
import { validationErrorMessages } from "../../constants";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";
import styles from "./MaterialsTable/MaterialsTable.module.scss";

export const validate = (values: any) => {
  const { required } = validationErrorMessages();
  const errors = {};
  if (!values.endDate) {
    errors.endDate = required;
  }
  return errors;
};

type PropsT = {
  formData: MaterialT,
  errorMessage: string
} & FormProps;

class EndDateForm extends React.Component<PropsT> {
  submitForm = ({ endDate }) => {
    this.props.submitForm(this.props.formData && this.props.formData.id, endDate);
  };

  render() {
    const today = moment();
    const { handleSubmit, invalid, errorMessage } = this.props;
    return (
      <form onSubmit={handleSubmit(this.submitForm)}>
        <div className={styles.formTitle}>Відредагуйте дату закінчення</div>
        <Field required name="endDate" label="Дата закінчення" component={InputDatePicker} minDate={today} />
        <ContainedButton type="submit" disabled={invalid} label="Активувати" className={styles.button} />
        {errorMessage && <ErrorMessage error={errorMessage} />}
      </form>
    );
  }
}

const mapStateToProps = ({ materialsList: { formError } }) => {
  return { errorMessage: formError };
};

export default compose(
  connect(mapStateToProps),
  reduxForm({
    form: "EndDateForm",
    validate
  })
)(EndDateForm);
