// @flow
import moment from "moment";

export const formatFormValues = (values: any) => {
  const fileId = values.material.map(item => item.id)[0];
  const geoIds = values.geos && values.geos.map(city => +city.value);
  const roleIds = values.roleIds.map(role => role.value);
  const startDate = moment(values.startDate).format("YYYY-MM-DD");
  const endDate = moment(values.endDate).format("YYYY-MM-DD");

  const formatted = {
    fileId,
    geoIds,
    roleIds,
    startDate,
    endDate
  };
  return formatted;
};
