// @flow
import React from "react";
import { connect } from "react-redux";
import { formValueSelector, reset } from "redux-form";
import moment from "moment";
import type { BrowserHistory } from "history";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import MaterialsTable from "./MaterialsTable/MaterialsTable";
import NewMaterialForm from "../../components/NewMaterialForm/NewMaterialForm";
import ReportToolbar from "../../components/ExportTablesToolbar/ExportTablesToolbar";
import Modal from "../../components/Modal/Modal";
import EndDateForm from "./FormForEndDateChange";
import { materialsListSelector, materialsRowsCountSelector } from "../../store/selectors/promoters/materials";
import { classes } from "../../helpers/spinner";
import {
  getPaginationConfig,
  getCommonParams,
  changeCurrentPage,
  changePageSize,
  changeTab,
  filterByDate,
  shouldNotSendRequest,
  getSearchQuery
} from "../../helpers/common";
import { receiveMaterials, deactivateMaterial, activateMaterial } from "../../store/actions/promoters/materialsList";
import { openModal } from "../../store/actions/common/modals";

type PropsT = {
  receiveMaterials: Function,
  deactivateMaterial: Function,
  activateMaterial: Function,
  openModal: Function,
  rowsCount: number,
  materialsList: MaterialT[],
  startDateField: Date,
  endDateField: Date,
  loading: boolean,
  modalName: string,
  user: CurrentUserInfoT
} & BrowserHistory;

type StateT = {
  modalType: string,
  formName: string,
  modalBody: any
};

const modalName = "MaterialForm";

class ListOfMaterials extends React.Component<PropsT, StateT> {
  state = {
    formName: "",
    modalType: "",
    modalBody: <div />
  };

  componentDidMount() {
    this.fetchData();
  }

  componentDidUpdate(prevProps) {
    const {
      location: { key }
    } = this.props;
    if (prevProps.location.key !== key) {
      const shouldNotSend = shouldNotSendRequest(prevProps.location.search, this.props.location.search);
      if (!shouldNotSend) {
        this.fetchData();
      }
    }
  }

  changeCurrentPage = (currentPage: number) =>
    changeCurrentPage(currentPage, this.props.location.search, this.props.history);

  changePageSize = (pageSize: number) => changePageSize(pageSize, this.props.location.search, this.props.history);

  changeTab = (event: any, tab: string) => changeTab(tab, this.props.location.search, this.props.history);

  checkEndDate = (id, data) => {
    if (moment(data.endDate).isBefore(moment())) {
      this.openModal("activate", data);
    } else {
      this.activateMaterial(id, data.endDate);
    }
  };

  activateMaterial = (id, newEndDate) => {
    const params = {
      id,
      newEndDate: moment(newEndDate).format("YYYY-MM-DD")
    };
    this.props.activateMaterial(params);
  };

  openAddModal = () => this.openModal("add");

  openEditModal = (id, data) => this.openModal("edit", data);

  deactivateMaterial = id => {
    const { tab } = getCommonParams(this.props.location.search);
    this.props.deactivateMaterial(id, tab);
  };

  fetchData = () => {
    const { pageNumber, itemsOnPage, tab } = getCommonParams(this.props.location.search);
    const { startDate, endDate } = this.getDateFromSearch();
    let params = { ItemsOnPage: itemsOnPage, PageNumber: pageNumber, Status: tab };
    if (startDate && endDate) {
      params = { ...params, dateStart: startDate, dateEnd: endDate };
    }
    this.props.receiveMaterials(params);
  };

  openModal = (type, data) => {
    switch (type) {
      case "add":
      case "edit": {
        const modalBody = <NewMaterialForm id={(data && data.id) || null} />;
        this.setState({ modalBody, modalType: "", formName: "newMaterialForm" });
        return this.props.openModal(modalName);
      }
      case "activate": {
        const modalBody = <EndDateForm formData={data} submitForm={this.activateMaterial} />;
        this.setState({ modalBody });
        return this.props.openModal(modalName);
      }
      default:
        return null;
    }
  };

  filterByDate = (rangeFilter: RangeFilterT) =>
    filterByDate(rangeFilter, this.props.location.search, this.props.history);

  resetDateFilters = () => {
    const { count, tab } = getSearchQuery(this.props.location.search);
    const { startDate, endDate } = this.getDateFromSearch();
    if (startDate && endDate) {
      this.props.history.push(`?page=1${count}${tab}`);
    } else {
      this.props.reset("materialsFilters");
    }
  };

  getDateFromSearch = () => {
    const searchParams = new URLSearchParams(this.props.location.search);
    const startDate = searchParams.get("start") && moment(searchParams.get("start"), "DD/MM/YYYY").format("YYYY-MM-DD");
    const endDate = searchParams.get("end") && moment(searchParams.get("end"), "DD/MM/YYYY").format("YYYY-MM-DD");
    return { startDate, endDate };
  };

  render() {
    const { page, count, tab } = getPaginationConfig(this.props.location.search);
    const { rowsCount, materialsList, loading, startDateField, endDateField } = this.props;
    const disableFilterButton = !startDateField || !endDateField;
    const initialValues = this.getDateFromSearch();
    return (
      <>
        <ReportToolbar
          filterData={this.filterByDate}
          form="materialsFilters"
          initialValues={initialValues}
          disableFilterButton={disableFilterButton}
          isClearable
          resetFilterHandler={this.resetDateFilters}
        />
        <Paper square className="mainContent">
          <MaterialsTable
            data={materialsList}
            changeCurrentPage={this.changeCurrentPage}
            changePageSize={this.changePageSize}
            changeTab={this.changeTab}
            activateMaterial={this.checkEndDate}
            deactivateMaterial={this.deactivateMaterial}
            openModal={this.openAddModal}
            openEditForm={this.openEditModal}
            rowsCount={rowsCount}
            page={page}
            count={count}
            tab={tab || "1"}
            user={this.props.user}
          />
          {loading && <CircularProgress classes={classes} />}
          {modalName === this.props.modalName && (
            <Modal formName={this.state.formName} type={this.state.modalType}>
              {this.state.modalBody}
            </Modal>
          )}
        </Paper>
      </>
    );
  }
}

const mapStateToProps = state => {
  const {
    materialsList: { loading },
    authenticationReducer: { user },
    modals: { modalName }
  } = state;
  const materialsList = materialsListSelector(state);
  const rowsCount = materialsRowsCountSelector(state);
  const selector = formValueSelector("materialsFilters");
  const startDateField = selector(state, "startDate");
  const endDateField = selector(state, "endDate");
  return {
    materialsList,
    loading,
    user,
    rowsCount,
    modalName,
    startDateField,
    endDateField
  };
};

const mapDispatchToProps = {
  receiveMaterials,
  deactivateMaterial,
  activateMaterial,
  openModal,
  reset
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ListOfMaterials);
