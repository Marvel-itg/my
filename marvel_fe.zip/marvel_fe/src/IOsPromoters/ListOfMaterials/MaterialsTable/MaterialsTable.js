// @flow
import React from "react";
import { PagingState, CustomPaging } from "@devexpress/dx-react-grid";
import { Grid, Table, TableHeaderRow, Toolbar } from "@devexpress/dx-react-grid-material-ui";
import { withStyles } from "@material-ui/core/styles";
import {
  TransparentButtonProvider,
  ButtonProvider,
  DestructiveButtonProvider,
  DateFormatProvider,
  ListProvider,
  PersonInfoProvider,
  DownloadButtonProvider
} from "../../../components/FormattedData/FormattedData";
import GridRoot from "../../../components/TableComponents/GridRoot";
import TabsHeader from "../../../components/TableComponents/TabsHeader";
import PagingPanel from "../../../components/TableComponents/PagingPanel";
import { ToolBarRootStyled } from "../../../components/TableComponents/ToolbarRoot";

import OutlinedButton from "../../../components/Buttons/OutlinedButton/OutlinedButton";
import HeaderWrap from "../../../components/TableComponents/HeaderWrap";
import { availableItemsPerPage, columnExtensions } from "../../../constants";
import styles from "./MaterialsTable.module.scss";

type PropsT = {
  data: MaterialT[],
  tab: string,
  page: number,
  changeCurrentPage: Function,
  count: number,
  changePageSize: Function,
  rowsCount: number,
  deactivateMaterial: Function,
  activateMaterial: Function,
  openEditForm: Function,
  user: CurrentUserInfoT,
  changeTab: Function,
  openModal: Function,
  classes: { [string]: string }
};

const wordWrapStyles = {
  whiteSpace: "normal",
  wordWrap: "break-word"
};

const CellComponent = ({ style, ...props }) => {
  return <Table.Cell style={wordWrapStyles} {...props} />;
};

const commonColumns = [
  { name: "fileName", title: "Назва" },
  { name: "startDate", title: "Дата старту активності" },
  { name: "endDate", title: "Дата завершення активності" },
  {
    name: "access",
    title: "Дозвіл"
  },
  { name: "createdOn", title: "Дата завантаження" },
  { name: "createdBy", title: "Ким завантажено" },
  { name: "lastModifiedBy", title: "Ким редаговано" },
  { name: "lastModifiedOn", title: "Дата редагування" }
];

const columnsForRMandSV = {
  "1": [...commonColumns, { name: "download", title: "Завантажити" }]
};
const columnsForRolesWithoutRestrictions = {
  "1": [
    ...commonColumns,
    { name: "edit", title: "Редагувати" },
    { name: "deactivate", title: "Деактивувати" },
    { name: "download", title: "Завантажити" }
  ],
  "3": [
    ...commonColumns,
    { name: "edit", title: "Редагувати" },
    { name: "deactivate", title: "Деактивувати" },
    { name: "download", title: "Завантажити" }
  ],
  "2": [...commonColumns, { name: "activate", title: "Активувати" }, { name: "download", title: "Завантажити" }]
};

const forValues = {
  date: ["startDate", "endDate", "createdOn", "lastModifiedOn"],
  createdBy: ["createdBy"],
  lastModifiedBy: ["lastModifiedBy"],
  access: ["access"],
  download: ["download"],
  edit: ["edit"],
  activate: ["activate"],
  deactivate: ["deactivate"]
};

const tabsForSAandCDM = [
  { label: "Активні", value: "1" },
  { label: "В очікуванні", value: "3" },
  { label: "Неактивні", value: "2" }
];

const tabsForRMandSV = [{ label: "Активні", value: "1" }];

const columnExtendedExtensions = [
  ...columnExtensions,
  { columnName: "access", width: 200 },
  { columnName: "download", width: 170 },
  { columnName: "fileName", width: 170 }
];

class MaterialsTable extends React.Component<PropsT> {
  renderHeaderButtons = () => (
    <OutlinedButton
      label="Додати матеріал"
      clickHandler={this.props.openModal}
      className={this.props.classes.addButton}
    />
  );

  render() {
    const {
      data,
      tab,
      page,
      changeCurrentPage,
      count,
      changePageSize,
      rowsCount,
      deactivateMaterial,
      activateMaterial,
      // downloadMaterial,
      changeTab,
      openEditForm,
      user
    } = this.props;
    const superAdminOrCDM = user && (user.accountType === 1 || user.accountType === 5);
    const shouldRenderButton = superAdminOrCDM;
    const tabsForRoles = superAdminOrCDM ? tabsForSAandCDM : tabsForRMandSV;
    const columnsForRoles = superAdminOrCDM ? columnsForRolesWithoutRestrictions : columnsForRMandSV;
    return (
      <>
        <Grid rows={data} columns={columnsForRoles[tab || 1]} rootComponent={GridRoot}>
          <PagingState
            currentPage={page}
            onCurrentPageChange={changeCurrentPage}
            pageSize={count}
            onPageSizeChange={changePageSize}
          />
          <CustomPaging totalCount={rowsCount} />

          <Table columnExtensions={columnExtendedExtensions} cellComponent={CellComponent} />

          <DateFormatProvider unixTimeStamp for={forValues.date} />
          <PersonInfoProvider for={forValues.createdBy} />
          <PersonInfoProvider for={forValues.lastModifiedBy} />
          <ButtonProvider for={forValues.activate} label="Активувати" onClick={activateMaterial} />
          <TransparentButtonProvider for={forValues.edit} label="Редагувати" onClick={openEditForm} />
          <DownloadButtonProvider for={forValues.download} />
          <DestructiveButtonProvider for={forValues.deactivate} label="Деактивувати" onClick={deactivateMaterial} />
          <ListProvider for={forValues.access} />

          <TableHeaderRow cellComponent={HeaderWrap} />
          <Toolbar rootComponent={ToolBarRootStyled(styles.materialsHeaderStyles)} />
          <TabsHeader changeTab={changeTab} activeTab={tab} tabs={tabsForRoles}>
            {shouldRenderButton && this.renderHeaderButtons()}
          </TabsHeader>
          <PagingPanel pageSizes={availableItemsPerPage} noData={!data.length} />
        </Grid>
      </>
    );
  }
}

export default withStyles(styles)(MaterialsTable);
